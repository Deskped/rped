package deskped.rped.entity;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

public class OrbitingBlockEntity extends Entity {

	private static final EntityDataAccessor<CompoundTag> STATE_TAG = SynchedEntityData.defineId(OrbitingBlockEntity.class, EntityDataSerializers.COMPOUND_TAG);

	private BlockState heldState = Blocks.STONE.defaultBlockState();

	public OrbitingBlockEntity(EntityType<? extends OrbitingBlockEntity> type, Level level) {
		super(type, level);
		this.noPhysics = true;
		this.setNoGravity(true);
	}

	public void setHeldState(BlockState state) {
		this.heldState = state;
		CompoundTag tag = new CompoundTag();
		tag.put("state", NbtUtils.writeBlockState(state));
		this.entityData.set(STATE_TAG, tag);
	}

	public BlockState getHeldState() {
		if (this.level().isClientSide) {
			CompoundTag tag = this.entityData.get(STATE_TAG);
			if (tag.contains("state"))
				return NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), tag.getCompound("state"));
			return Blocks.STONE.defaultBlockState();
		}
		return heldState;
	}

	public void moveTowards(double x, double y, double z) {
		this.setDeltaMovement(x - this.getX(), y - this.getY(), z - this.getZ());
		this.setPos(x, y, z);
	}

	@Override
	public void tick() {
		super.tick();
		if (this.level().isClientSide) {
			Vec3 v = this.getDeltaMovement();
			this.setPos(this.getX() + v.x, this.getY() + v.y, this.getZ() + v.z);
		}
	}

	@Override
	protected void defineSynchedData() {
		this.entityData.define(STATE_TAG, new CompoundTag());
	}

	@Override
	protected void readAdditionalSaveData(CompoundTag tag) {
	}

	@Override
	protected void addAdditionalSaveData(CompoundTag tag) {
	}

	@Override
	public boolean shouldBeSaved() {
		return false;
	}

	@Override
	public boolean isPickable() {
		return false;
	}

	@Override
	public boolean isPushable() {
		return false;
	}

	@Override
	public Packet<ClientGamePacketListener> getAddEntityPacket() {
		return new ClientboundAddEntityPacket(this);
	}
}
