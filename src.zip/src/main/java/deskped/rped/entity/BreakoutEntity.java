package deskped.rped.entity;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.network.PlayMessages;
import net.minecraftforge.network.NetworkHooks;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.ThrownPotion;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.sounds.SoundEvent;

import deskped.rped.init.RpedModEntities;
import deskped.rped.init.RpedModItems;

import java.util.List;
import java.util.Random;

public class BreakoutEntity extends Monster {

	private static final int   PULL_RADIUS        = 16;
	private static final int   BLOCK_RADIUS       = 14;
	private static final float DESTROY_RADIUS     = 2.2f;
	private static final float PULL_FORCE         = 0.09f;
	private static final float ORBIT_SPEED        = 0.045f;
	private static final int   BLOCK_PULL_TICKS   = 25;
	private static final int   MAX_BLOCKS_QUEUED  = 8;
	private static final float MOVE_SPEED         = 0.20f;
	private static final int   SEALING_DURATION   = 80;

	private Vec3    moveDir         = Vec3.ZERO;
	private boolean dirInitialized  = false;
	private boolean isSealing       = false;
	private int     sealingTimer    = 0;

	private final Random rand = new Random();

	public BreakoutEntity(PlayMessages.SpawnEntity packet, Level world) {
		this(RpedModEntities.BREAKOUT.get(), world);
	}

	public BreakoutEntity(EntityType<BreakoutEntity> type, Level world) {
		super(type, world);
		setMaxUpStep(0.6f);
		xpReward = 0;
		setNoAi(false);
		setPersistenceRequired();
	}

	@Override
	public Packet<ClientGamePacketListener> getAddEntityPacket() {
		return NetworkHooks.getEntitySpawningPacket(this);
	}

	@Override
	protected void registerGoals() {
		super.registerGoals();

	}

	@Override
	public void tick() {
		super.tick();

		if (isSealing) {
			tickSealing();
			return;
		}

		if (!level().isClientSide) {
			if (!dirInitialized) {
				initMoveDir();
			}
			checkOperatorLead();
			applyMovement();

			if (tickCount % 4 == 0) {
				pullEntities();
			}
			if (tickCount % BLOCK_PULL_TICKS == 0) {
				absorbNearbyBlocks();
			}
		}
	}

	private void initMoveDir() {
		double angle = rand.nextDouble() * Math.PI * 2;
		moveDir = new Vec3(Math.cos(angle), 0, Math.sin(angle)).normalize().scale(MOVE_SPEED);
		dirInitialized = true;
	}

	private void applyMovement() {
		Vec3 pos  = position();
		Vec3 next = pos.add(moveDir);
		double safeY = Math.max(1.0, next.y);
		setDeltaMovement(moveDir);
		setPos(next.x, safeY, next.z);
	}

	private void checkOperatorLead() {
		Vec3 myPos = position();
		List<Player> players = level().getEntitiesOfClass(Player.class,
				new AABB(myPos.x - 8, myPos.y - 8, myPos.z - 8,
				         myPos.x + 8, myPos.y + 8, myPos.z + 8));

		for (Player player : players) {
			if (!isOperator(player)) continue;
			ItemStack held = player.getMainHandItem();
			if (!held.isEmpty() && held.getItem() == RpedModItems.CRYSTAL_EYE.get()) {
				Vec3 target = player.position().add(0, player.getEyeHeight() * 0.5, 0);
				Vec3 diff   = target.subtract(myPos);
				if (diff.length() > 2.5) {
					moveDir = diff.normalize().scale(MOVE_SPEED);
				} else {
					moveDir = Vec3.ZERO;
				}
				return;
			}
		}
	}

	private boolean isOperator(Player player) {
		if (!(player instanceof ServerPlayer sp)) return false;
		return sp.getServer() != null && sp.getServer().getPlayerList().isOp(sp.getGameProfile());
	}

	private void pullEntities() {
		Vec3 center = position().add(0, 1.5, 0);

		List<Entity> nearby = level().getEntities(this,
				new AABB(center.x - PULL_RADIUS, center.y - PULL_RADIUS, center.z - PULL_RADIUS,
				         center.x + PULL_RADIUS, center.y + PULL_RADIUS, center.z + PULL_RADIUS));

		for (Entity e : nearby) {
			if (e == this) continue;
			if (e instanceof Player player) {
				if (player.isCreative() || isOperator(player)) continue;
			}

			Vec3   toCenter  = center.subtract(e.position());
			double dist      = toCenter.length();
			if (dist < 0.01 || dist > PULL_RADIUS) continue;

			double forceMult = 1.0 - (dist / PULL_RADIUS);

			double angle      = Math.atan2(toCenter.z, toCenter.x) + ORBIT_SPEED;
			double nextRadius = Math.max(0, dist - PULL_FORCE * 2.5);
			double targetX    = center.x + Math.cos(angle) * nextRadius;
			double targetZ    = center.z + Math.sin(angle) * nextRadius;
			double targetY    = e.getY() + Math.sin(tickCount * 0.08 + e.getId()) * 0.12 * forceMult
			                    + (center.y - e.getY()) * 0.04 * forceMult;

			Vec3 delta = new Vec3(
					targetX - e.getX(),
					targetY - e.getY(),
					targetZ - e.getZ()
			).scale(0.14 * forceMult).add(toCenter.normalize().scale(PULL_FORCE * forceMult));

			e.setDeltaMovement(e.getDeltaMovement().add(delta));
			e.hurtMarked = true;

			if (dist < DESTROY_RADIUS) {
				if (!(e instanceof Player)) {
					if (level() instanceof ServerLevel sl) {
						sl.sendParticles(ParticleTypes.REVERSE_PORTAL,
								e.getX(), e.getY() + 1, e.getZ(), 14, 0.3, 0.3, 0.3, 0.04);
					}
					e.remove(Entity.RemovalReason.DISCARDED);
				} else {
					e.hurt(level().damageSources().magic(), 4.0f);
					e.setDeltaMovement(toCenter.normalize().scale(0.5));
				}
			}
		}
	}

	private void absorbNearbyBlocks() {
		if (!(level() instanceof ServerLevel sl)) return;
		Vec3 center  = position();
		int absorbed = 0;

		for (int attempt = 0; attempt < 80 && absorbed < MAX_BLOCKS_QUEUED; attempt++) {
			int rx = (int) (rand.nextDouble() * BLOCK_RADIUS * 2 - BLOCK_RADIUS);
			int ry = (int) (rand.nextDouble() * BLOCK_RADIUS * 2 - BLOCK_RADIUS);
			int rz = (int) (rand.nextDouble() * BLOCK_RADIUS * 2 - BLOCK_RADIUS);

			BlockPos   bp = BlockPos.containing(center.x + rx, center.y + ry, center.z + rz);
			BlockState bs = sl.getBlockState(bp);

			if (bs.isAir()) continue;
			if (bs.is(Blocks.BEDROCK)) continue;
			if (bs.is(Blocks.BARRIER)) continue;
			if (bs.is(Blocks.COMMAND_BLOCK)) continue;
			if (bs.getDestroySpeed(sl, bp) < 0) continue;

			sl.setBlock(bp, Blocks.AIR.defaultBlockState(), 3);
			sl.sendParticles(ParticleTypes.REVERSE_PORTAL,
					bp.getX() + 0.5, bp.getY() + 0.5, bp.getZ() + 0.5,
					8, 0.25, 0.25, 0.25, 0.08);
			sl.playSound(null, bp, SoundEvents.ENDERMAN_TELEPORT,
					SoundSource.BLOCKS, 0.25f, 1.7f + rand.nextFloat() * 0.5f);
			absorbed++;
		}
	}

	@Override
	public InteractionResult interactAt(Player player, Vec3 vec, InteractionHand hand) {
		if (isSealing) return InteractionResult.PASS;

		ItemStack stack = player.getItemInHand(hand);
		if (!stack.isEmpty() && stack.getItem() == RpedModItems.CRYSTAL_EYE.get()) {
			if (!level().isClientSide) {
				beginSealing(player, stack);
			}
			return InteractionResult.SUCCESS;
		}
		return super.interactAt(player, vec, hand);
	}

	private void beginSealing(Player player, ItemStack crystalEye) {
		isSealing    = true;
		sealingTimer = 0;
		moveDir      = Vec3.ZERO;

		crystalEye.shrink(1);

		level().playSound(null, getX(), getY(), getZ(),
				SoundEvents.END_PORTAL_SPAWN, SoundSource.HOSTILE, 1.5f, 0.45f);
		level().playSound(null, getX(), getY(), getZ(),
				SoundEvents.ENDER_CHEST_OPEN, SoundSource.HOSTILE, 1.0f, 0.35f);

		if (level() instanceof ServerLevel sl) {
			Vec3 c = position().add(0, 1.5, 0);
			sl.sendParticles(ParticleTypes.REVERSE_PORTAL, c.x, c.y, c.z, 50, 1.2, 1.2, 1.2, 0.15);
			sl.sendParticles(ParticleTypes.END_ROD,         c.x, c.y, c.z, 25, 1.0, 1.0, 1.0, 0.08);
		}
	}

	private void tickSealing() {
		sealingTimer++;
		Level lvl = level();
		Vec3  c   = position().add(0, 1.5, 0);

		if (lvl instanceof ServerLevel sl) {
			float progress = sealingTimer / (float) SEALING_DURATION;
			double radius  = Math.max(0.05, 2.8 * (1.0 - progress));
			double angle   = sealingTimer * 0.42;

			sl.sendParticles(ParticleTypes.PORTAL,
					c.x + Math.cos(angle) * radius,
					c.y + Math.sin(angle * 0.7) * 0.5,
					c.z + Math.sin(angle) * radius,
					4, 0.04, 0.04, 0.04, 0.01);

			sl.sendParticles(ParticleTypes.REVERSE_PORTAL, c.x, c.y, c.z,
					2, radius * 0.25, radius * 0.25, radius * 0.25, 0.0);

			if (sealingTimer % 6 == 0) {
				lvl.playSound(null, getX(), getY(), getZ(),
						SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.HOSTILE,
						0.7f, 1.1f + progress * 1.2f);
			}
			if (sealingTimer % 20 == 0) {
				lvl.playSound(null, getX(), getY(), getZ(),
						SoundEvents.ENDER_EYE_DEATH, SoundSource.HOSTILE,
						0.9f, 0.8f + progress * 0.8f);
			}
		}

		if (sealingTimer >= SEALING_DURATION) {
			if (lvl instanceof ServerLevel sl) {
				sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 1, 0, 0, 0, 0.1);
				sl.sendParticles(ParticleTypes.END_ROD,            c.x, c.y, c.z, 80, 2.5, 2.5, 2.5, 0.35);
				sl.sendParticles(ParticleTypes.REVERSE_PORTAL,     c.x, c.y, c.z, 60, 2.0, 2.0, 2.0, 0.2);
				lvl.playSound(null, getX(), getY(), getZ(),
						SoundEvents.END_PORTAL_SPAWN,  SoundSource.HOSTILE, 2.0f, 1.9f);
				lvl.playSound(null, getX(), getY(), getZ(),
						SoundEvents.ENDER_CHEST_CLOSE, SoundSource.HOSTILE, 1.5f, 1.5f);
				lvl.playSound(null, getX(), getY(), getZ(),
						SoundEvents.ENDER_EYE_DEATH,   SoundSource.HOSTILE, 1.5f, 0.6f);
			}
			this.remove(Entity.RemovalReason.KILLED);
		}
	}

	@Override
	public MobType getMobType() {
		return MobType.UNDEFINED;
	}

	@Override
	public boolean removeWhenFarAway(double distanceToClosestPlayer) {
		return false;
	}

	@Override
	public double getMyRidingOffset() {
		return -0.35D;
	}

	protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHitIn) {
		super.dropCustomDeathLoot(source, looting, recentlyHitIn);
		this.spawnAtLocation(new ItemStack(Blocks.AIR));
	}

	@Override
	public SoundEvent getAmbientSound() {
		return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("rped:gravity_wrench_release"));
	}

	@Override
	public SoundEvent getDeathSound() {
		return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("rped:item_outbreak"));
	}

	@Override
	public boolean hurt(DamageSource damagesource, float amount) {
		if (damagesource.is(DamageTypes.IN_FIRE))
			return false;
		if (damagesource.getDirectEntity() instanceof AbstractArrow)
			return false;
		if (damagesource.getDirectEntity() instanceof Player)
			return false;
		if (damagesource.getDirectEntity() instanceof ThrownPotion || damagesource.getDirectEntity() instanceof AreaEffectCloud)
			return false;
		if (damagesource.is(DamageTypes.FALL))
			return false;
		if (damagesource.is(DamageTypes.CACTUS))
			return false;
		if (damagesource.is(DamageTypes.DROWN))
			return false;
		if (damagesource.is(DamageTypes.LIGHTNING_BOLT))
			return false;
		if (damagesource.is(DamageTypes.EXPLOSION) || damagesource.is(DamageTypes.PLAYER_EXPLOSION))
			return false;
		if (damagesource.is(DamageTypes.TRIDENT))
			return false;
		if (damagesource.is(DamageTypes.FALLING_ANVIL))
			return false;
		if (damagesource.is(DamageTypes.DRAGON_BREATH))
			return false;
		if (damagesource.is(DamageTypes.WITHER) || damagesource.is(DamageTypes.WITHER_SKULL))
			return false;
		return super.hurt(damagesource, amount);
	}

	@Override
	public boolean ignoreExplosion() {
		return true;
	}

	@Override
	public void readAdditionalSaveData(CompoundTag tag) {
		super.readAdditionalSaveData(tag);
		if (tag.contains("MoveDirX")) {
			moveDir        = new Vec3(tag.getDouble("MoveDirX"), 0, tag.getDouble("MoveDirZ"));
			dirInitialized = true;
		}
		isSealing    = tag.getBoolean("IsSealing");
		sealingTimer = tag.getInt("SealingTimer");
	}

	@Override
	public void addAdditionalSaveData(CompoundTag tag) {
		super.addAdditionalSaveData(tag);
		tag.putDouble("MoveDirX",   moveDir.x);
		tag.putDouble("MoveDirZ",   moveDir.z);
		tag.putBoolean("IsSealing", isSealing);
		tag.putInt("SealingTimer",  sealingTimer);
	}

	public static void init() {
	}

	public static AttributeSupplier.Builder createAttributes() {
		AttributeSupplier.Builder builder = Mob.createMobAttributes();
		builder = builder.add(Attributes.MOVEMENT_SPEED, 0.3);
		builder = builder.add(Attributes.MAX_HEALTH, 1024);
		builder = builder.add(Attributes.ARMOR, 100);
		builder = builder.add(Attributes.ATTACK_DAMAGE, 0);
		builder = builder.add(Attributes.FOLLOW_RANGE, 33);
		return builder;
	}
}