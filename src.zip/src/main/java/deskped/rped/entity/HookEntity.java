package deskped.rped.entity;

import deskped.rped.ext.RpedExtra;

import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class HookEntity extends Projectile {

    private static final EntityDataAccessor<Boolean> ANCHORED =
            SynchedEntityData.defineId(HookEntity.class, EntityDataSerializers.BOOLEAN);

    private static final double MAX_RANGE = 33.0;
    private static final double PULL_STRENGTH = 0.62;
    private static final double RELEASE_DISTANCE = 1.6;

    private int life = 0;

    public HookEntity(EntityType<? extends HookEntity> type, Level level) {
        super(type, level);
    }

    public HookEntity(Level level, LivingEntity owner) {
        super(RpedExtra.HOOK_ENTITY.get(), level);
        this.setOwner(owner);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(ANCHORED, false);
    }

    public boolean isAnchored() {
        return this.entityData.get(ANCHORED);
    }

    @Override
    public void tick() {
        super.tick();
        life++;

        Entity owner = this.getOwner();
        if (owner == null || !owner.isAlive() || (owner instanceof LivingEntity le && le.isSpectator())) {
            if (!this.level().isClientSide)
                this.discard();
            return;
        }

        if (!this.level().isClientSide) {
            if (this.distanceTo(owner) > MAX_RANGE + 6 || life > 600) {
                this.discard();
                return;
            }
        }

        if (isAnchored()) {
            Vec3 target = this.position().subtract(owner.getX(), owner.getY() + owner.getBbHeight() * 0.5, owner.getZ());
            double dist = target.length();
            if (dist < RELEASE_DISTANCE) {
                if (!this.level().isClientSide)
                    this.discard();
                return;
            }
            Vec3 pull = target.normalize().scale(PULL_STRENGTH);
            double damp = dist < 4.0 ? dist / 4.0 : 1.0;
            if (!this.level().isClientSide) {
                owner.setDeltaMovement(owner.getDeltaMovement().scale(0.55).add(pull.scale(damp)));
                owner.fallDistance = 0;
                owner.hurtMarked = true;
            }
            this.setDeltaMovement(Vec3.ZERO);
            return;
        }

        if (!this.level().isClientSide) {
            HitResult hit = ProjectileUtil.getHitResultOnMoveVector(this, e -> canHitEntity(e));
            if (hit.getType() == HitResult.Type.BLOCK) {
                onHitBlock((BlockHitResult) hit);
            } else if (this.distanceTo(owner) > MAX_RANGE) {
                this.discard();
                return;
            }
        }

        Vec3 motion = this.getDeltaMovement();
        this.setPos(this.getX() + motion.x, this.getY() + motion.y, this.getZ() + motion.z);
        this.setDeltaMovement(motion.add(0, -0.03, 0).scale(0.99));
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (this.level().isClientSide)
            return;
        Vec3 loc = result.getLocation();
        this.setPos(loc.x, loc.y, loc.z);
        this.setDeltaMovement(Vec3.ZERO);
        this.entityData.set(ANCHORED, true);
    }

    @Override
    protected boolean canHitEntity(Entity entity) {
        return false;
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("anchored", isAnchored());
        tag.putInt("life", life);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(ANCHORED, tag.getBoolean("anchored"));
        life = tag.getInt("life");
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return new ClientboundAddEntityPacket(this);
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 4096;
    }
}
