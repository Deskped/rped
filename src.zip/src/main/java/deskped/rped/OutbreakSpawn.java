package deskped.rped;

import deskped.rped.init.RpedModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class OutbreakSpawn {
	@SubscribeEvent
	public static void onEntityDeath(LivingDeathEvent event) {
		if (!(event.getEntity().level() instanceof ServerLevel level))
			return;

		if (!(event.getEntity() instanceof Mob mob))
			return;

		if (level.random.nextFloat() < 0.03F) {
			BlockPos pos = mob.blockPosition();

			if (level.isEmptyBlock(pos)) {
				level.setBlock(pos, RpedModBlocks.OUTBREAK.get().defaultBlockState(), 3);
			} else if (level.isEmptyBlock(pos.above())) {
				level.setBlock(pos.above(), RpedModBlocks.OUTBREAK.get().defaultBlockState(), 3);
			}
		}
	}
}