package deskped.rped.block.model;

import deskped.rped.init.RpedModBlocks;
import net.minecraft.client.renderer.block.BlockModelShaper;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ModelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;

@Mod.EventBusSubscriber(modid = "rped", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MimicModelHandler {

	@SubscribeEvent
	public static void onModifyBakingResult(ModelEvent.ModifyBakingResult event) {
		wrap(event.getModels(), RpedModBlocks.MIMIC_BLOCK.get());
		wrap(event.getModels(), RpedModBlocks.MIMIC_STAIRS.get());
		wrap(event.getModels(), RpedModBlocks.MIMIC_SLAB.get());
	}

	private static void wrap(Map<ResourceLocation, BakedModel> models, Block block) {
		for (BlockState state : block.getStateDefinition().getPossibleStates()) {
			ModelResourceLocation loc = BlockModelShaper.stateToModelLocation(state);
			BakedModel model = models.get(loc);
			if (model != null && !(model instanceof MimicBakedModel))
				models.put(loc, new MimicBakedModel(model));
		}
	}
}
