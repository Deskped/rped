package deskped.rped.block.model;

import deskped.rped.block.entity.IMimic;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.ItemOverrides;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.client.ChunkRenderTypeSet;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraftforge.client.model.IDynamicBakedModel;
import net.minecraftforge.client.model.data.ModelData;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class MimicBakedModel implements IDynamicBakedModel {

	private final BakedModel base;
	private final Map<String, List<BakedQuad>> cache = new ConcurrentHashMap<>();

	public MimicBakedModel(BakedModel base) {
		this.base = base;
	}

	@Override
	public List<BakedQuad> getQuads(@Nullable BlockState state, @Nullable Direction side, RandomSource rand, ModelData data, @Nullable RenderType renderType) {
		TextureAtlasSprite sprite = resolveSprite(data);
		if (sprite == null)
			return base.getQuads(state, side, rand, data, renderType);
		if (renderType != null && renderType != chunkType(data))
			return Collections.emptyList();
		String key = sprite.contents().name() + "|" + (side == null ? "n" : side.getName());
		List<BakedQuad> cached = cache.get(key);
		if (cached != null)
			return cached;
		List<BakedQuad> remapped = remap(base.getQuads(state, side, rand, ModelData.EMPTY, null), sprite);
		cache.put(key, remapped);
		return remapped;
	}

	private TextureAtlasSprite resolveSprite(ModelData data) {
		BlockState mimic = data.get(IMimic.MIMIC);
		if (mimic != null && !mimic.isAir())
			return Minecraft.getInstance().getBlockRenderer().getBlockModel(mimic).getParticleIcon(ModelData.EMPTY);
		Item item = data.get(IMimic.MIMIC_ITEM);
		if (item != null && item != Items.AIR) {
			BakedModel m = Minecraft.getInstance().getItemRenderer().getItemModelShaper().getItemModel(item);
			if (m != null)
				return m.getParticleIcon(ModelData.EMPTY);
		}
		return null;
	}

	private RenderType chunkType(ModelData data) {
		BlockState mimic = data.get(IMimic.MIMIC);
		if (mimic != null && !mimic.isAir())
			return ItemBlockRenderTypes.getChunkRenderType(mimic);
		return RenderType.cutout();
	}

	private static List<BakedQuad> remap(List<BakedQuad> quads, TextureAtlasSprite sprite) {
		List<BakedQuad> out = new ArrayList<>(quads.size());
		for (BakedQuad q : quads)
			out.add(retexture(q, sprite));
		return out;
	}

	private static BakedQuad retexture(BakedQuad quad, TextureAtlasSprite ns) {
		TextureAtlasSprite os = quad.getSprite();
		int[] v = quad.getVertices().clone();
		int stride = v.length / 4;
		float ou0 = os.getU0(), ou1 = os.getU1(), ov0 = os.getV0(), ov1 = os.getV1();
		float du = ou1 - ou0, dv = ov1 - ov0;
		for (int i = 0; i < 4; i++) {
			int o = i * stride;
			float u = Float.intBitsToFloat(v[o + 4]);
			float w = Float.intBitsToFloat(v[o + 5]);
			float fu = du != 0f ? (u - ou0) / du : 0f;
			float fv = dv != 0f ? (w - ov0) / dv : 0f;
			v[o + 4] = Float.floatToRawIntBits(ns.getU0() + fu * (ns.getU1() - ns.getU0()));
			v[o + 5] = Float.floatToRawIntBits(ns.getV0() + fv * (ns.getV1() - ns.getV0()));
		}
		return new BakedQuad(v, -1, quad.getDirection(), ns, quad.isShade());
	}

	@Override
	public boolean useAmbientOcclusion() {
		return base.useAmbientOcclusion();
	}

	@Override
	public boolean isGui3d() {
		return base.isGui3d();
	}

	@Override
	public boolean usesBlockLight() {
		return base.usesBlockLight();
	}

	@Override
	public boolean isCustomRenderer() {
		return false;
	}

	@Override
	public TextureAtlasSprite getParticleIcon() {
		return base.getParticleIcon();
	}

	@Override
	public TextureAtlasSprite getParticleIcon(ModelData data) {
		TextureAtlasSprite s = resolveSprite(data);
		return s != null ? s : base.getParticleIcon(data);
	}

	@Override
	public ItemOverrides getOverrides() {
		return base.getOverrides();
	}

	@Override
	public ItemTransforms getTransforms() {
		return base.getTransforms();
	}

	@Override
	public ChunkRenderTypeSet getRenderTypes(BlockState state, RandomSource rand, ModelData data) {
		if (resolveSprite(data) != null)
			return ChunkRenderTypeSet.of(chunkType(data));
		return base.getRenderTypes(state, rand, data);
	}
}