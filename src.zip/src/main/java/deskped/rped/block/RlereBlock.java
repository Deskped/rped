package deskped.rped.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.common.util.ForgeSoundType;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.pathfinder.BlockPathTypes;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Mob;
import net.minecraft.util.RandomSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.List;

import deskped.rped.procedures.RlereTikProcedure;

public class RlereBlock extends Block implements SimpleWaterloggedBlock {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
	public static final EnumProperty<AttachFace> FACE = FaceAttachedHorizontalDirectionalBlock.FACE;
	public static final BooleanProperty WATERLOGGED = BlockStateProperties.WATERLOGGED;

	public RlereBlock() {
		super(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_BLUE)
				.sound(new ForgeSoundType(1.0f, 1.0f, () -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("rped:gravity_wrench_throw")), () -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("rped:gravity_wrench_grab")),
						() -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("rped:gravity_wrench_hum")), () -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("rped:gravity_wrench_impact")),
						() -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("rped:gravity_wrench_release"))))
				.strength(13f, 33f).lightLevel(s -> 6).requiresCorrectToolForDrops().noOcclusion().hasPostProcess((bs, br, bp) -> true).emissiveRendering((bs, br, bp) -> true).isRedstoneConductor((bs, br, bp) -> false)
				.instrument(NoteBlockInstrument.CHIME));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(FACE, AttachFace.WALL).setValue(WATERLOGGED, false));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, BlockGetter level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, level, list, flag);
		list.add(Component.translatable("block.rped.rlere.description_0"));
		list.add(Component.translatable("block.rped.rlere.description_1"));
		list.add(Component.translatable("block.rped.rlere.description_2"));
		list.add(Component.translatable("block.rped.rlere.description_3"));
		list.add(Component.translatable("block.rped.rlere.description_4"));
		list.add(Component.translatable("block.rped.rlere.description_5"));
	}

	@Override
	public float[] getBeaconColorMultiplier(BlockState state, LevelReader world, BlockPos pos, BlockPos beaconPos) {
		return new float[]{0.5607843137f, 0.6901960784f, 0.7607843137f};
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return state.getFluidState().isEmpty();
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(5, 13, 5, 11, 16, 11), box(5, 0, 5, 11, 3, 11), box(6, 2, 6, 10, 14, 10));
				case WALL -> Shapes.or(box(5, 5, 13, 11, 11, 16), box(5, 5, 0, 11, 11, 3), box(6, 6, 2, 10, 10, 14));
				case CEILING -> Shapes.or(box(5, 0, 5, 11, 3, 11), box(5, 13, 5, 11, 16, 11), box(6, 2, 6, 10, 14, 10));
			};
			case NORTH -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(5, 13, 5, 11, 16, 11), box(5, 0, 5, 11, 3, 11), box(6, 2, 6, 10, 14, 10));
				case WALL -> Shapes.or(box(5, 5, 0, 11, 11, 3), box(5, 5, 13, 11, 11, 16), box(6, 6, 2, 10, 10, 14));
				case CEILING -> Shapes.or(box(5, 0, 5, 11, 3, 11), box(5, 13, 5, 11, 16, 11), box(6, 2, 6, 10, 14, 10));
			};
			case EAST -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(5, 13, 5, 11, 16, 11), box(5, 0, 5, 11, 3, 11), box(6, 2, 6, 10, 14, 10));
				case WALL -> Shapes.or(box(13, 5, 5, 16, 11, 11), box(0, 5, 5, 3, 11, 11), box(2, 6, 6, 14, 10, 10));
				case CEILING -> Shapes.or(box(5, 0, 5, 11, 3, 11), box(5, 13, 5, 11, 16, 11), box(6, 2, 6, 10, 14, 10));
			};
			case WEST -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(5, 13, 5, 11, 16, 11), box(5, 0, 5, 11, 3, 11), box(6, 2, 6, 10, 14, 10));
				case WALL -> Shapes.or(box(0, 5, 5, 3, 11, 11), box(13, 5, 5, 16, 11, 11), box(2, 6, 6, 14, 10, 10));
				case CEILING -> Shapes.or(box(5, 0, 5, 11, 3, 11), box(5, 13, 5, 11, 16, 11), box(6, 2, 6, 10, 14, 10));
			};
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING, FACE, WATERLOGGED);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		boolean flag = context.getLevel().getFluidState(context.getClickedPos()).getType() == Fluids.WATER;
		if (context.getClickedFace().getAxis() == Direction.Axis.Y)
			return super.getStateForPlacement(context).setValue(FACE, context.getClickedFace().getOpposite() == Direction.UP ? AttachFace.CEILING : AttachFace.FLOOR).setValue(FACING, context.getHorizontalDirection()).setValue(WATERLOGGED, flag);
		return super.getStateForPlacement(context).setValue(FACE, AttachFace.WALL).setValue(FACING, context.getClickedFace()).setValue(WATERLOGGED, flag);
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public FluidState getFluidState(BlockState state) {
		return state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
	}

	@Override
	public BlockState updateShape(BlockState state, Direction facing, BlockState facingState, LevelAccessor world, BlockPos currentPos, BlockPos facingPos) {
		if (state.getValue(WATERLOGGED)) {
			world.scheduleTick(currentPos, Fluids.WATER, Fluids.WATER.getTickDelay(world));
		}
		return super.updateShape(state, facing, facingState, world, currentPos, facingPos);
	}

	@Override
	public BlockPathTypes getBlockPathType(BlockState state, BlockGetter world, BlockPos pos, Mob entity) {
		return BlockPathTypes.DANGER_OTHER;
	}

	@Override
	public boolean canConnectRedstone(BlockState state, BlockGetter world, BlockPos pos, Direction side) {
		return true;
	}

	@Override
	public void onPlace(BlockState blockstate, Level world, BlockPos pos, BlockState oldState, boolean moving) {
		super.onPlace(blockstate, world, pos, oldState, moving);
		world.scheduleTick(pos, this, 3);
	}

	@Override
	public void tick(BlockState blockstate, ServerLevel world, BlockPos pos, RandomSource random) {
		super.tick(blockstate, world, pos, random);
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		RlereTikProcedure.execute(world, x, y, z);
		world.scheduleTick(pos, this, 3);
	}
}