package deskped.rped.block;

import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.WallBlock;
import net.minecraft.world.level.block.SoundType;

public class OxidizedIronCasingWallBlock extends WallBlock {
	public OxidizedIronCasingWallBlock() {
		super(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_GREEN).sound(SoundType.COPPER).strength(18f, 21.5f).instrument(NoteBlockInstrument.BIT).forceSolidOn());
	}
}