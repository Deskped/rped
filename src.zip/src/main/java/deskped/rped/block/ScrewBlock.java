package deskped.rped.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.AttachFace;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.List;

public class ScrewBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
	public static final EnumProperty<AttachFace> FACE = FaceAttachedHorizontalDirectionalBlock.FACE;

	public ScrewBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.METAL).strength(0.65f, 4f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false).instrument(NoteBlockInstrument.GUITAR));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(FACE, AttachFace.WALL));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, BlockGetter level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, level, list, flag);
		list.add(Component.translatable("block.rped.screw.description_0"));
		list.add(Component.translatable("block.rped.screw.description_1"));
		list.add(Component.translatable("block.rped.screw.description_2"));
		list.add(Component.translatable("block.rped.screw.description_3"));
		list.add(Component.translatable("block.rped.screw.description_4"));
		list.add(Component.translatable("block.rped.screw.description_5"));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(6, -9, 6, 10, -1, 10), box(4, -1, 4, 12, 2, 12));
				case WALL -> Shapes.or(box(6, 6, -9, 10, 10, -1), box(4, 4, -1, 12, 12, 2));
				case CEILING -> Shapes.or(box(6, 17, 6, 10, 25, 10), box(4, 14, 4, 12, 17, 12));
			};
			case NORTH -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(6, -9, 6, 10, -1, 10), box(4, -1, 4, 12, 2, 12));
				case WALL -> Shapes.or(box(6, 6, 17, 10, 10, 25), box(4, 4, 14, 12, 12, 17));
				case CEILING -> Shapes.or(box(6, 17, 6, 10, 25, 10), box(4, 14, 4, 12, 17, 12));
			};
			case EAST -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(6, -9, 6, 10, -1, 10), box(4, -1, 4, 12, 2, 12));
				case WALL -> Shapes.or(box(-9, 6, 6, -1, 10, 10), box(-1, 4, 4, 2, 12, 12));
				case CEILING -> Shapes.or(box(6, 17, 6, 10, 25, 10), box(4, 14, 4, 12, 17, 12));
			};
			case WEST -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(6, -9, 6, 10, -1, 10), box(4, -1, 4, 12, 2, 12));
				case WALL -> Shapes.or(box(17, 6, 6, 25, 10, 10), box(14, 4, 4, 17, 12, 12));
				case CEILING -> Shapes.or(box(6, 17, 6, 10, 25, 10), box(4, 14, 4, 12, 17, 12));
			};
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING, FACE);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return super.getStateForPlacement(context).setValue(FACE, faceForDirection(context.getNearestLookingDirection())).setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	private AttachFace faceForDirection(Direction direction) {
		if (direction.getAxis() == Direction.Axis.Y)
			return direction == Direction.UP ? AttachFace.CEILING : AttachFace.FLOOR;
		else
			return AttachFace.WALL;
	}
}