package deskped.rped.block;

import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.SlabBlock;

public class OxidizedIronCasingSlabsBlock extends SlabBlock {
	public OxidizedIronCasingSlabsBlock() {
		super(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_GREEN).sound(SoundType.COPPER).strength(18f, 21.5f).instrument(NoteBlockInstrument.BIT));
	}
}