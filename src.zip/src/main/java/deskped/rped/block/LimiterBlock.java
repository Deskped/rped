package deskped.rped.block;

import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;

import java.util.List;

import deskped.rped.procedures.LimiterTikProcedure;

public class LimiterBlock extends Block {
	public LimiterBlock() {
		super(BlockBehaviour.Properties.of().mapColor(MapColor.ICE).sound(SoundType.COPPER).strength(2.7f, 10f).pushReaction(PushReaction.BLOCK).instrument(NoteBlockInstrument.FLUTE));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, BlockGetter level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, level, list, flag);
		list.add(Component.translatable("block.rped.limiter.description_0"));
		list.add(Component.translatable("block.rped.limiter.description_1"));
		list.add(Component.translatable("block.rped.limiter.description_2"));
		list.add(Component.translatable("block.rped.limiter.description_3"));
		list.add(Component.translatable("block.rped.limiter.description_4"));
		list.add(Component.translatable("block.rped.limiter.description_5"));
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 15;
	}

	@Override
	public void neighborChanged(BlockState blockstate, Level world, BlockPos pos, Block neighborBlock, BlockPos fromPos, boolean moving) {
		super.neighborChanged(blockstate, world, pos, neighborBlock, fromPos, moving);
		if (world.getBestNeighborSignal(pos) > 0) {
			LimiterTikProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
		}
	}
}