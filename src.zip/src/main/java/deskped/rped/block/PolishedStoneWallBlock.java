package deskped.rped.block;

import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.WallBlock;

public class PolishedStoneWallBlock extends WallBlock {
	public PolishedStoneWallBlock() {
		super(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).strength(5f, 21.5f).instrument(NoteBlockInstrument.BANJO).forceSolidOn());
	}
}