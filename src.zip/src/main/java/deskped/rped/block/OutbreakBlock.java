package deskped.rped.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.util.RandomSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;

import deskped.rped.procedures.OutbreakTikProcedure;
import deskped.rped.procedures.OutbreakPKMProcedure;

public class OutbreakBlock extends Block {
	private static final int LIFETIME_TICKS = 3600;
	private static final int EAT_RADIUS = 13;
	private static final Map<ServerLevel, Map<BlockPos, Long>> BORN = new WeakHashMap<>();

	public OutbreakBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.EMPTY).strength(-1, 3600000).noCollission().noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return box(3, 3, 3, 13, 13, 13);
	}

	@Override
	public void onPlace(BlockState blockstate, Level world, BlockPos pos, BlockState oldState, boolean moving) {
		super.onPlace(blockstate, world, pos, oldState, moving);
		if (world instanceof ServerLevel sl)
			born(sl).putIfAbsent(pos.immutable(), sl.getGameTime());
		world.scheduleTick(pos, this, 3);
	}

	@Override
	public void onRemove(BlockState state, Level world, BlockPos pos, BlockState newState, boolean moving) {
		if (state.getBlock() != newState.getBlock() && world instanceof ServerLevel sl)
			born(sl).remove(pos);
		super.onRemove(state, world, pos, newState, moving);
	}

	@Override
	public void tick(BlockState blockstate, ServerLevel world, BlockPos pos, RandomSource random) {
		super.tick(blockstate, world, pos, random);
		long now = world.getGameTime();
		Map<BlockPos, Long> map = born(world);
		long start = map.computeIfAbsent(pos.immutable(), k -> now);
		if (now - start >= LIFETIME_TICKS) {
			map.remove(pos);
			world.removeBlock(pos, false);
			world.sendParticles(ParticleTypes.FLASH, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 1, 0, 0, 0, 0);
			world.sendParticles(ParticleTypes.LARGE_SMOKE, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 20, 0.4, 0.4, 0.4, 0.02);
			world.playSound(null, pos, SoundEvents.FIRE_EXTINGUISH, SoundSource.BLOCKS, 1f, 0.6f);
			return;
		}
		if (now % 40 < 3)
			eat(world, pos, map);
		OutbreakTikProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
		world.scheduleTick(pos, this, 3);
	}

	private void eat(ServerLevel world, BlockPos pos, Map<BlockPos, Long> map) {
		int r = EAT_RADIUS;
		for (BlockPos p : BlockPos.betweenClosed(pos.offset(-r, -r, -r), pos.offset(r, r, r))) {
			if (p.equals(pos) || p.distSqr(pos) > r * r)
				continue;
			if (!world.getBlockState(p).is(this))
				continue;
			BlockPos eaten = p.immutable();
			map.remove(eaten);
			world.removeBlock(eaten, false);
			world.sendParticles(ParticleTypes.FLASH, eaten.getX() + 0.5, eaten.getY() + 0.5, eaten.getZ() + 0.5, 1, 0, 0, 0, 0);
			world.sendParticles(ParticleTypes.SOUL, eaten.getX() + 0.5, eaten.getY() + 0.5, eaten.getZ() + 0.5, 12, 0.3, 0.3, 0.3, 0.05);
			world.playSound(null, eaten, SoundEvents.GENERIC_EAT, SoundSource.BLOCKS, 1f, 0.5f);
		}
	}

	private static Map<BlockPos, Long> born(ServerLevel level) {
		synchronized (BORN) {
			return BORN.computeIfAbsent(level, k -> new HashMap<>());
		}
	}

	@Override
	public InteractionResult use(BlockState blockstate, Level world, BlockPos pos, Player entity, InteractionHand hand, BlockHitResult hit) {
		super.use(blockstate, world, pos, entity, hand, hit);
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		double hitX = hit.getLocation().x;
		double hitY = hit.getLocation().y;
		double hitZ = hit.getLocation().z;
		Direction direction = hit.getDirection();
		OutbreakPKMProcedure.execute(world, x, y, z, entity);
		return InteractionResult.SUCCESS;
	}
}
