package deskped.rped.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.FrontAndTop;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Container;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.WorldlyContainerHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

import java.util.List;
import java.util.Optional;

import deskped.rped.block.entity.CrafterBlockEntity;
import deskped.rped.ext.CrafterRegistry;
import deskped.rped.init.RpedModSounds;

public class CrafterBlock extends BaseEntityBlock {
	public static final EnumProperty<FrontAndTop> ORIENTATION = BlockStateProperties.ORIENTATION;
	public static final BooleanProperty TRIGGERED = BlockStateProperties.TRIGGERED;
	public static final BooleanProperty CRAFTING = BooleanProperty.create("crafting");

	private static final int MAX_CRAFTING_TICKS = 6;
	private static final int CRAFTING_TICK_DELAY = 4;
	private static final int EVENT_PARTICLES_SHOOT = 2000;

	private static final RecipeManager.CachedCheck<CraftingContainer, CraftingRecipe> RECIPE_CACHE = RecipeManager.createCheck(RecipeType.CRAFTING);

	public CrafterBlock() {
		super(BlockBehaviour.Properties.of().mapColor(MapColor.STONE).sound(SoundType.METAL).requiresCorrectToolForDrops().strength(1.5f, 3.5f));
		this.registerDefaultState(this.stateDefinition.any().setValue(ORIENTATION, FrontAndTop.NORTH_UP).setValue(TRIGGERED, false).setValue(CRAFTING, false));
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(ORIENTATION, TRIGGERED, CRAFTING);
	}

	@Override
	public RenderShape getRenderShape(BlockState state) {
		return RenderShape.MODEL;
	}

	@Override
	public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
		return new CrafterBlockEntity(pos, state);
	}

	@Nullable
	@Override
	public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
		return level.isClientSide() ? null : createTickerHelper(type, CrafterRegistry.CRAFTER.get(), CrafterBlockEntity::serverTick);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		Direction looking = context.getNearestLookingDirection();
		Direction top;
		if (looking == Direction.DOWN)
			top = context.getHorizontalDirection().getOpposite();
		else if (looking == Direction.UP)
			top = context.getHorizontalDirection();
		else
			top = Direction.UP;
		return this.defaultBlockState().setValue(ORIENTATION, FrontAndTop.fromFrontAndTop(looking.getOpposite(), top)).setValue(TRIGGERED, context.getLevel().hasNeighborSignal(context.getClickedPos()));
	}

	@Override
	public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean moving) {
		if (state.is(oldState.getBlock()))
			return;
		if (level.getBlockEntity(pos) instanceof CrafterBlockEntity crafter)
			crafter.setTriggered(state.getValue(TRIGGERED));
	}

	@Override
	public void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos, boolean moving) {
		boolean powered = level.hasNeighborSignal(pos) || level.hasNeighborSignal(pos.above());
		boolean triggered = state.getValue(TRIGGERED);
		if (powered && !triggered) {
			level.scheduleTick(pos, this, CRAFTING_TICK_DELAY);
			level.setBlock(pos, state.setValue(TRIGGERED, true), 2);
			if (level.getBlockEntity(pos) instanceof CrafterBlockEntity crafter)
				crafter.setTriggered(true);
		} else if (!powered && triggered) {
			level.setBlock(pos, state.setValue(TRIGGERED, false).setValue(CRAFTING, false), 2);
			if (level.getBlockEntity(pos) instanceof CrafterBlockEntity crafter)
				crafter.setTriggered(false);
		}
	}

	@Override
	public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
		this.dispenseFrom(state, level, pos);
	}

	@Override
	public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
		if (level.isClientSide())
			return InteractionResult.SUCCESS;
		if (level.getBlockEntity(pos) instanceof CrafterBlockEntity crafter)
			player.openMenu(crafter);
		return InteractionResult.CONSUME;
	}

	@Override
	public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
		if (state.is(newState.getBlock()))
			return;
		if (level.getBlockEntity(pos) instanceof CrafterBlockEntity crafter) {
			Containers.dropContents(level, pos, crafter);
			level.updateNeighbourForOutputSignal(pos, this);
		}
		super.onRemove(state, level, pos, newState, moving);
	}

	@Override
	public boolean hasAnalogOutputSignal(BlockState state) {
		return true;
	}

	@Override
	public int getAnalogOutputSignal(BlockState state, Level level, BlockPos pos) {
		return level.getBlockEntity(pos) instanceof CrafterBlockEntity crafter ? crafter.getRedstoneSignal() : 0;
	}

	@Override
	public BlockState rotate(BlockState state, Rotation rotation) {
		return state.setValue(ORIENTATION, rotation.rotation().rotate(state.getValue(ORIENTATION)));
	}

	@Override
	public BlockState mirror(BlockState state, Mirror mirror) {
		return state.setValue(ORIENTATION, mirror.rotation().rotate(state.getValue(ORIENTATION)));
	}

	private void dispenseFrom(BlockState state, ServerLevel level, BlockPos pos) {
		if (!(level.getBlockEntity(pos) instanceof CrafterBlockEntity crafter))
			return;
		Optional<CraftingRecipe> found = RECIPE_CACHE.getRecipeFor(crafter, level);
		if (found.isEmpty()) {
			level.playSound(null, pos, RpedModSounds.BLOCK_CRAFTER_FAIL.get(), SoundSource.BLOCKS, 1, 1);
			return;
		}
		CraftingRecipe recipe = found.get();
		ItemStack result = recipe.assemble(crafter, level.registryAccess());
		if (result.isEmpty()) {
			level.playSound(null, pos, RpedModSounds.BLOCK_CRAFTER_FAIL.get(), SoundSource.BLOCKS, 1, 1);
			return;
		}
		crafter.setCraftingTicksRemaining(MAX_CRAFTING_TICKS);
		level.setBlock(pos, state.setValue(CRAFTING, true), 3);
		this.dispenseItem(level, pos, crafter, result, state);
		for (ItemStack remaining : recipe.getRemainingItems(crafter))
			if (!remaining.isEmpty())
				this.dispenseItem(level, pos, crafter, remaining, state);
		for (ItemStack input : crafter.getItems())
			if (!input.isEmpty())
				input.shrink(1);
		crafter.setChanged();
		level.playSound(null, pos, RpedModSounds.BLOCK_CRAFTER_CRAFT.get(), SoundSource.BLOCKS, 1, 1);
	}

	private void dispenseItem(ServerLevel level, BlockPos pos, CrafterBlockEntity crafter, ItemStack stack, BlockState state) {
		Direction front = state.getValue(ORIENTATION).front();
		Container target = getContainerAt(level, pos.relative(front));
		ItemStack rest = stack.copy();
		if (target != null && (target instanceof CrafterBlockEntity || rest.getCount() > target.getMaxStackSize())) {
			while (!rest.isEmpty()) {
				ItemStack single = rest.copy();
				single.setCount(1);
				if (!addItem(crafter, target, single, front.getOpposite()).isEmpty())
					break;
				rest.shrink(1);
			}
		} else if (target != null) {
			while (!rest.isEmpty()) {
				int before = rest.getCount();
				rest = addItem(crafter, target, rest, front.getOpposite());
				if (before == rest.getCount())
					break;
			}
		}
		if (!rest.isEmpty()) {
			Vec3 center = Vec3.atCenterOf(pos).add(front.getStepX() * 0.7, front.getStepY() * 0.7, front.getStepZ() * 0.7);
			spawnItem(level, rest, 6, front, center);
			level.levelEvent(EVENT_PARTICLES_SHOOT, pos, front.get3DDataValue());
		}
	}

	private static void spawnItem(Level level, ItemStack stack, int speed, Direction direction, Vec3 position) {
		double x = position.x();
		double y = position.y();
		double z = position.z();
		if (direction.getAxis() == Direction.Axis.Y)
			y = y - 0.125;
		else
			y = y - 0.15625;
		ItemEntity item = new ItemEntity(level, x, y, z, stack);
		double spread = level.random.nextDouble() * 0.1 + 0.2;
		item.setDeltaMovement(level.random.triangle(direction.getStepX() * spread, 0.0172275 * speed), level.random.triangle(0.2, 0.0172275 * speed),
				level.random.triangle(direction.getStepZ() * spread, 0.0172275 * speed));
		level.addFreshEntity(item);
	}

	@Nullable
	private static Container getContainerAt(Level level, BlockPos pos) {
		Container container = null;
		BlockState state = level.getBlockState(pos);
		Block block = state.getBlock();
		if (block instanceof WorldlyContainerHolder holder) {
			container = holder.getContainer(state, level, pos);
		} else if (state.hasBlockEntity()) {
			BlockEntity blockEntity = level.getBlockEntity(pos);
			if (blockEntity instanceof Container found) {
				container = found;
				if (container instanceof ChestBlockEntity && block instanceof ChestBlock chest)
					container = ChestBlock.getContainer(chest, state, level, pos, true);
			}
		}
		if (container == null) {
			List<Entity> entities = level.getEntities((Entity) null,
					new AABB(pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1.0, pos.getY() + 1.0, pos.getZ() + 1.0), EntitySelector.CONTAINER_ENTITY_SELECTOR);
			if (!entities.isEmpty())
				container = (Container) entities.get(level.random.nextInt(entities.size()));
		}
		return container;
	}

	private static ItemStack addItem(Container source, Container target, ItemStack stack, @Nullable Direction side) {
		if (target instanceof WorldlyContainer worldly && side != null) {
			int[] slots = worldly.getSlotsForFace(side);
			for (int i = 0; i < slots.length && !stack.isEmpty(); i++)
				stack = tryMoveInItem(target, stack, slots[i], side);
		} else {
			for (int i = 0; i < target.getContainerSize() && !stack.isEmpty(); i++)
				stack = tryMoveInItem(target, stack, i, side);
		}
		return stack;
	}

	private static ItemStack tryMoveInItem(Container target, ItemStack stack, int slot, @Nullable Direction side) {
		ItemStack current = target.getItem(slot);
		if (!canPlaceItemInContainer(target, stack, slot, side))
			return stack;
		if (current.isEmpty()) {
			target.setItem(slot, stack);
			target.setChanged();
			return ItemStack.EMPTY;
		}
		if (canMergeItems(current, stack)) {
			int space = Math.min(stack.getMaxStackSize(), target.getMaxStackSize()) - current.getCount();
			int moved = Math.min(stack.getCount(), space);
			if (moved > 0) {
				stack.shrink(moved);
				current.grow(moved);
				target.setChanged();
			}
		}
		return stack;
	}

	private static boolean canPlaceItemInContainer(Container container, ItemStack stack, int slot, @Nullable Direction side) {
		if (!container.canPlaceItem(slot, stack))
			return false;
		return !(container instanceof WorldlyContainer worldly) || worldly.canPlaceItemThroughFace(slot, stack, side);
	}

	private static boolean canMergeItems(ItemStack current, ItemStack stack) {
		return current.getCount() < current.getMaxStackSize() && ItemStack.isSameItemSameTags(current, stack);
	}
}
