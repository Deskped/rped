package deskped.rped.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.AttachFace;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class TumaniteSmallBudBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
	public static final EnumProperty<AttachFace> FACE = FaceAttachedHorizontalDirectionalBlock.FACE;

	public TumaniteSmallBudBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.AMETHYST).strength(-1, 3600000).lightLevel(s -> 15).noCollission().noOcclusion().pushReaction(PushReaction.BLOCK).hasPostProcess((bs, br, bp) -> true)
				.emissiveRendering((bs, br, bp) -> true).isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(FACE, AttachFace.WALL));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(6, -4, 6, 12, 7, 12), box(7, -6, 2, 11, 4, 6), box(12, -5, 7, 16, 4, 11));
				case WALL -> Shapes.or(box(6, 4, -4, 12, 10, 7), box(7, 10, -6, 11, 14, 4), box(12, 5, -5, 16, 9, 4));
				case CEILING -> Shapes.or(box(4, 9, 6, 10, 20, 12), box(5, 12, 2, 9, 22, 6), box(0, 12, 7, 4, 21, 11));
			};
			case NORTH -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(4, -4, 4, 10, 7, 10), box(5, -6, 10, 9, 4, 14), box(0, -5, 5, 4, 4, 9));
				case WALL -> Shapes.or(box(4, 4, 9, 10, 10, 20), box(5, 10, 12, 9, 14, 22), box(0, 5, 12, 4, 9, 21));
				case CEILING -> Shapes.or(box(6, 9, 4, 12, 20, 10), box(7, 12, 10, 11, 22, 14), box(12, 12, 5, 16, 21, 9));
			};
			case EAST -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(6, -4, 4, 12, 7, 10), box(2, -6, 5, 6, 4, 9), box(7, -5, 0, 11, 4, 4));
				case WALL -> Shapes.or(box(-4, 4, 4, 7, 10, 10), box(-6, 10, 5, 4, 14, 9), box(-5, 5, 0, 4, 9, 4));
				case CEILING -> Shapes.or(box(6, 9, 6, 12, 20, 12), box(2, 12, 7, 6, 22, 11), box(7, 12, 12, 11, 21, 16));
			};
			case WEST -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(4, -4, 6, 10, 7, 12), box(10, -6, 7, 14, 4, 11), box(5, -5, 12, 9, 4, 16));
				case WALL -> Shapes.or(box(9, 4, 6, 20, 10, 12), box(12, 10, 7, 22, 14, 11), box(12, 5, 12, 21, 9, 16));
				case CEILING -> Shapes.or(box(4, 9, 4, 10, 20, 10), box(10, 12, 5, 14, 22, 9), box(5, 12, 0, 9, 21, 4));
			};
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING, FACE);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return super.getStateForPlacement(context).setValue(FACE, faceForDirection(context.getNearestLookingDirection())).setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	private AttachFace faceForDirection(Direction direction) {
		if (direction.getAxis() == Direction.Axis.Y)
			return direction == Direction.UP ? AttachFace.CEILING : AttachFace.FLOOR;
		else
			return AttachFace.WALL;
	}
}