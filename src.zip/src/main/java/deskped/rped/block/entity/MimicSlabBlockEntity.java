package deskped.rped.block.entity;

import net.minecraftforge.items.wrapper.SidedInvWrapper;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.client.model.data.ModelData;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.ContainerHelper;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.network.chat.Component;
import net.minecraft.network.Connection;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.NonNullList;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

import java.util.stream.IntStream;

import deskped.rped.init.RpedModBlockEntities;

public class MimicSlabBlockEntity extends RandomizableContainerBlockEntity implements WorldlyContainer, IMimic {
	private NonNullList<ItemStack> stacks = NonNullList.withSize(0, ItemStack.EMPTY);
	private Block mimicBlock = Blocks.AIR;
	private Item mimicItem = null;
	private final LazyOptional<? extends IItemHandler>[] handlers = SidedInvWrapper.create(this, Direction.values());

	public MimicSlabBlockEntity(BlockPos position, BlockState state) {
		super(RpedModBlockEntities.MIMIC_SLAB.get(), position, state);
	}

	@Override
	public void load(CompoundTag compound) {
		super.load(compound);
		if (!this.tryLoadLootTable(compound))
			this.stacks = NonNullList.withSize(this.getContainerSize(), ItemStack.EMPTY);
		ContainerHelper.loadAllItems(compound, this.stacks);
		if (compound.contains("Mimic", 8)) {
			ResourceLocation rl = ResourceLocation.tryParse(compound.getString("Mimic"));
			this.mimicBlock = rl != null ? BuiltInRegistries.BLOCK.get(rl) : Blocks.AIR;
		} else {
			this.mimicBlock = Blocks.AIR;
		}
		this.mimicItem = null;
		if (compound.contains("MimicItem", 8)) {
			ResourceLocation ri = ResourceLocation.tryParse(compound.getString("MimicItem"));
			Item it = ri != null ? BuiltInRegistries.ITEM.get(ri) : Items.AIR;
			this.mimicItem = it == Items.AIR ? null : it;
		}
	}

	@Override
	public void saveAdditional(CompoundTag compound) {
		super.saveAdditional(compound);
		if (!this.trySaveLootTable(compound)) {
			ContainerHelper.saveAllItems(compound, this.stacks);
		}
		compound.putString("Mimic", BuiltInRegistries.BLOCK.getKey(this.mimicBlock).toString());
		if (this.mimicItem != null)
			compound.putString("MimicItem", BuiltInRegistries.ITEM.getKey(this.mimicItem).toString());
	}

	@Override
	public ClientboundBlockEntityDataPacket getUpdatePacket() {
		return ClientboundBlockEntityDataPacket.create(this);
	}

	@Override
	public CompoundTag getUpdateTag() {
		return this.saveWithFullMetadata();
	}

	@Override
	public void onDataPacket(Connection net, ClientboundBlockEntityDataPacket pkt) {
		CompoundTag tag = pkt.getTag();
		if (tag != null)
			this.handleUpdateTag(tag);
		this.requestModelDataUpdate();
		if (this.level != null)
			this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), Block.UPDATE_ALL);
	}

	@Override
	public ModelData getModelData() {
		ModelData.Builder builder = ModelData.builder().with(IMimic.MIMIC, this.mimicBlock.defaultBlockState());
		if (this.mimicItem != null)
			builder.with(IMimic.MIMIC_ITEM, this.mimicItem);
		return builder.build();
	}

	@Override
	public BlockState getMimic() {
		return this.mimicBlock.defaultBlockState();
	}

	@Override
	public Item getMimicItem() {
		return this.mimicItem;
	}

	@Override
	public void setMimic(Block block) {
		this.mimicBlock = block == null ? Blocks.AIR : block;
		this.mimicItem = null;
		this.setChanged();
		if (this.level != null && !this.level.isClientSide())
			this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), Block.UPDATE_ALL);
	}

	@Override
	public void setMimicFrom(ItemStack stack) {
		if (stack == null || stack.isEmpty()) {
			this.mimicBlock = Blocks.AIR;
			this.mimicItem = null;
		} else if (stack.getItem() instanceof BlockItem blockItem) {
			this.mimicBlock = blockItem.getBlock();
			this.mimicItem = null;
		} else {
			this.mimicBlock = Blocks.AIR;
			this.mimicItem = stack.getItem();
		}
		this.setChanged();
		if (this.level != null && !this.level.isClientSide())
			this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), Block.UPDATE_ALL);
	}

	@Override
	public int getContainerSize() {
		return stacks.size();
	}

	@Override
	public boolean isEmpty() {
		for (ItemStack itemstack : this.stacks)
			if (!itemstack.isEmpty())
				return false;
		return true;
	}

	@Override
	public Component getDefaultName() {
		return Component.literal("mimic_slab");
	}

	@Override
	public AbstractContainerMenu createMenu(int id, Inventory inventory) {
		return ChestMenu.threeRows(id, inventory);
	}

	@Override
	public Component getDisplayName() {
		return Component.literal("Mimic Slab");
	}

	@Override
	protected NonNullList<ItemStack> getItems() {
		return this.stacks;
	}

	@Override
	protected void setItems(NonNullList<ItemStack> stacks) {
		this.stacks = stacks;
	}

	@Override
	public boolean canPlaceItem(int index, ItemStack stack) {
		return true;
	}

	@Override
	public int[] getSlotsForFace(Direction side) {
		return IntStream.range(0, this.getContainerSize()).toArray();
	}

	@Override
	public boolean canPlaceItemThroughFace(int index, ItemStack itemstack, @Nullable Direction direction) {
		return this.canPlaceItem(index, itemstack);
	}

	@Override
	public boolean canTakeItemThroughFace(int index, ItemStack itemstack, Direction direction) {
		return true;
	}

	@Override
	public <T> LazyOptional<T> getCapability(Capability<T> capability, @Nullable Direction facing) {
		if (!this.remove && facing != null && capability == ForgeCapabilities.ITEM_HANDLER)
			return handlers[facing.ordinal()].cast();
		return super.getCapability(capability, facing);
	}

	@Override
	public void onLoad() {
		super.onLoad();
		this.requestModelDataUpdate();
	}

	@Override
	public void setRemoved() {
		super.setRemoved();
		for (LazyOptional<? extends IItemHandler> handler : handlers)
			handler.invalidate();
	}
}
