package deskped.rped.block.entity;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.client.model.data.ModelProperty;

public interface IMimic {
	ModelProperty<BlockState> MIMIC = new ModelProperty<>();
	ModelProperty<Item> MIMIC_ITEM = new ModelProperty<>();

	BlockState getMimic();

	Item getMimicItem();

	void setMimic(Block block);

	void setMimicFrom(ItemStack stack);
}
