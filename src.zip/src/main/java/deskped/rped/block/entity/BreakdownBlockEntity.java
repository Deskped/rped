package deskped.rped.block.entity;

import net.minecraftforge.items.wrapper.SidedInvWrapper;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.capabilities.Capability;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.ContainerHelper;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.NonNullList;
import net.minecraft.core.Holder;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

import java.util.stream.IntStream;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

import deskped.rped.RpedMod;
import deskped.rped.entity.OrbitingBlockEntity;
import deskped.rped.ext.RpedExtra;
import deskped.rped.init.RpedModBlockEntities;
import deskped.rped.init.RpedModBlocks;
import deskped.rped.init.RpedModParticleTypes;
import deskped.rped.init.RpedModSounds;

public class BreakdownBlockEntity extends RandomizableContainerBlockEntity implements WorldlyContainer {
	private NonNullList<ItemStack> stacks = NonNullList.withSize(9, ItemStack.EMPTY);
	private final LazyOptional<? extends IItemHandler>[] handlers = SidedInvWrapper.create(this, Direction.values());

	private int soundTimer = 0;
	private int pullTimer = 0;
	private final List<Pull> pulls = new ArrayList<>();
	private final List<Orb> orbiters = new ArrayList<>();

	private static final class Pull {
		final OrbitingBlockEntity e;
		final double sx;
		final double sy;
		final double sz;
		final float yaw0;
		final float startR;
		final boolean toOrbit;
		int age = 0;

		Pull(OrbitingBlockEntity e, double sx, double sy, double sz, float yaw0, float startR, boolean toOrbit) {
			this.e = e;
			this.sx = sx;
			this.sy = sy;
			this.sz = sz;
			this.yaw0 = yaw0;
			this.startR = startR;
			this.toOrbit = toOrbit;
		}
	}

	private static final class Orb {
		final OrbitingBlockEntity e;
		float phase;
		final float bob;

		Orb(OrbitingBlockEntity e, float phase, float bob) {
			this.e = e;
			this.phase = phase;
			this.bob = bob;
		}
	}

	public BreakdownBlockEntity(BlockPos position, BlockState state) {
		super(RpedModBlockEntities.BREAKDOWN.get(), position, state);
	}

	public void serverTick(Level lvl, BlockPos pos) {
		if (!(lvl instanceof ServerLevel level))
			return;
		double cx = pos.getX() + 0.5;
		double cy = pos.getY() + 0.5;
		double cz = pos.getZ() + 0.5;
		if (soundTimer % 3600 == 0)
			playLoopSound(level, cx, cy, cz);
		soundTimer++;
		if (++pullTimer >= 260) {
			pullTimer = 0;
			if (pulls.size() < 4)
				capture(level, pos, cx, cy, cz);
		}
		tickPulls(level, cx, cy, cz);
		tickOrbiters(cx, cy, cz);
	}

	private void playLoopSound(ServerLevel level, double x, double y, double z) {
		SoundEvent snd = RpedModSounds.GRAVITY_WRENCH_IMPACT.get();
		Holder<SoundEvent> holder = BuiltInRegistries.SOUND_EVENT.wrapAsHolder(snd);
		long seed = level.getRandom().nextLong();
		for (ServerPlayer p : level.players())
			if (p.distanceToSqr(x, y, z) <= 33 * 33)
				p.connection.send(new ClientboundSoundPacket(holder, SoundSource.MASTER, x, y, z, 100.0F, 1.0F, seed));
	}

	private void capture(ServerLevel level, BlockPos pos, double cx, double cy, double cz) {
		RandomSource rnd = level.getRandom();
		for (int attempt = 0; attempt < 48; attempt++) {
			int dx = rnd.nextInt(15) - 7;
			int dy = rnd.nextInt(15) - 7;
			int dz = rnd.nextInt(15) - 7;
			if (dx == 0 && dy == 0 && dz == 0)
				continue;
			if (dx * dx + dy * dy + dz * dz > 49)
				continue;
			BlockPos t = pos.offset(dx, dy, dz);
			BlockState st = level.getBlockState(t);
			if (st.isAir() || !st.getFluidState().isEmpty())
				continue;
			if (st.getBlock() == RpedModBlocks.BREAKDOWN.get())
				continue;
			if (st.getDestroySpeed(level, t) < 0)
				continue;
			if (level.getBlockEntity(t) != null)
				continue;
			boolean toOrbit = orbiters.size() < 6 && rnd.nextFloat() < 0.3f;
			OrbitingBlockEntity fly = new OrbitingBlockEntity(RpedExtra.ORBITING_BLOCK.get(), level);
			fly.setHeldState(st);
			double sx = t.getX() + 0.5;
			double sy = t.getY() + 0.5;
			double sz = t.getZ() + 0.5;
			fly.setPos(sx, sy, sz);
			level.levelEvent(2001, t, Block.getId(st));
			level.removeBlock(t, false);
			level.addFreshEntity(fly);
			float yaw0 = (float) Math.atan2(sz - cz, sx - cx);
			float startR = (float) Math.max(1.4, Math.sqrt((sx - cx) * (sx - cx) + (sz - cz) * (sz - cz)));
			pulls.add(new Pull(fly, sx, sy, sz, yaw0, startR, toOrbit));
			level.playSound(null, t, SoundEvents.CHORUS_FRUIT_TELEPORT, SoundSource.BLOCKS, 0.9f, 0.55f);
			return;
		}
	}

	private void tickPulls(ServerLevel level, double cx, double cy, double cz) {
		Iterator<Pull> it = pulls.iterator();
		while (it.hasNext()) {
			Pull p = it.next();
			if (!p.e.isAlive()) {
				it.remove();
				continue;
			}
			p.age++;
			float t = Math.min(1f, p.age / 55f);
			float r = p.startR * (1f - t) * (1f - t);
			float targetR = p.toOrbit ? Math.max(r, 2.7f) : r;
			float ang = p.yaw0 + p.age * 0.22f;
			float blend = Math.min(1f, p.age / 8f);
			double px = cx + Mth.cos(ang) * targetR;
			double pz = cz + Mth.sin(ang) * targetR;
			double py = cy + (p.sy - cy) * (1f - t) + Math.sin(p.age * 0.31) * 0.12;
			double fx = p.sx + (px - p.sx) * blend;
			double fy = p.sy + (py - p.sy) * blend;
			double fz = p.sz + (pz - p.sz) * blend;
			p.e.moveTowards(fx, fy, fz);
			if (p.toOrbit && t > 0.4f && targetR <= 2.75f) {
				orbiters.add(new Orb(p.e, ang, level.getRandom().nextFloat() * 6.28f));
				it.remove();
				continue;
			}
			if (!p.toOrbit && t >= 1f) {
				level.sendParticles(RpedModParticleTypes.ROD.get(), cx, cy, cz, 6, 0.15, 0.15, 0.15, 0.06);
				level.sendParticles(ParticleTypes.END_ROD, cx, cy, cz, 5, 0.1, 0.1, 0.1, 0.08);
				level.playSound(null, BlockPos.containing(cx, cy, cz), SoundEvents.AMETHYST_BLOCK_BREAK, SoundSource.BLOCKS, 1.1f, 0.5f);
				p.e.discard();
				it.remove();
			}
		}
	}

	private void tickOrbiters(double cx, double cy, double cz) {
		Iterator<Orb> it = orbiters.iterator();
		while (it.hasNext()) {
			Orb o = it.next();
			if (!o.e.isAlive()) {
				it.remove();
				continue;
			}
			o.phase += 0.055f;
			double px = cx + Mth.cos(o.phase) * 2.7;
			double pz = cz + Mth.sin(o.phase) * 2.7;
			double py = cy + Math.sin(o.phase * 0.8 + o.bob) * 0.5;
			o.e.moveTowards(px, py, pz);
		}
	}

	public void onDestroyed(ServerLevel level, BlockPos pos) {
		double cx = pos.getX() + 0.5;
		double cy = pos.getY() + 0.5;
		double cz = pos.getZ() + 0.5;
		hurl(level, cx, cy, cz);
		deathAnimation(level, cx, cy, cz);
	}

	private void hurl(ServerLevel level, double cx, double cy, double cz) {
		List<OrbitingBlockEntity> all = new ArrayList<>();
		for (Orb o : orbiters)
			if (o.e.isAlive())
				all.add(o.e);
		for (Pull p : pulls)
			if (p.e.isAlive())
				all.add(p.e);
		orbiters.clear();
		pulls.clear();
		RandomSource rnd = level.getRandom();
		for (OrbitingBlockEntity e : all) {
			Vec3 dir = new Vec3(e.getX() - cx, 0, e.getZ() - cz);
			if (dir.lengthSqr() < 0.01)
				dir = new Vec3(rnd.nextFloat() - 0.5f, 0, rnd.nextFloat() - 0.5f);
			dir = dir.normalize();
			FallingBlockEntity fb = FallingBlockEntity.fall(level, e.blockPosition(), e.getHeldState());
			fb.time = 1;
			fb.dropItem = false;
			fb.setHurtsEntities(3.0f, 15);
			fb.setDeltaMovement(dir.x * (0.8 + rnd.nextFloat() * 0.5), 0.45 + rnd.nextFloat() * 0.35, dir.z * (0.8 + rnd.nextFloat() * 0.5));
			e.discard();
		}
	}

	private void deathAnimation(ServerLevel level, double cx, double cy, double cz) {
		for (int i = 0; i < 20; i++) {
			double a = i * (Math.PI * 2 / 20);
			SimpleParticleType type = i % 2 == 0 ? RpedModParticleTypes.DARKROD.get() : RpedModParticleTypes.ROD.get();
			level.sendParticles(type, cx + Math.cos(a) * 3.0, cy + (level.getRandom().nextFloat() - 0.5f) * 2.0, cz + Math.sin(a) * 3.0, 0, -Math.cos(a) * 0.35, 0, -Math.sin(a) * 0.35, 1.0);
		}
		level.playSound(null, BlockPos.containing(cx, cy, cz), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.BLOCKS, 2.5f, 0.55f);
		RpedMod.queueServerWork(7, () -> {
			level.sendParticles(ParticleTypes.FLASH, cx, cy, cz, 2, 0, 0, 0, 0);
			level.sendParticles(RpedModParticleTypes.RLSTA.get(), cx, cy, cz, 26, 0.3, 0.3, 0.3, 0.5);
			level.sendParticles(ParticleTypes.END_ROD, cx, cy, cz, 40, 0.2, 0.2, 0.2, 0.55);
			level.playSound(null, BlockPos.containing(cx, cy, cz), SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 2.5f, 0.5f);
		});
		RpedMod.queueServerWork(12, () -> ring(level, cx, cy, cz, 2.2, RpedModParticleTypes.ROD.get()));
		RpedMod.queueServerWork(17, () -> {
			ring(level, cx, cy, cz, 4.0, RpedModParticleTypes.DARKROD.get());
			level.playSound(null, BlockPos.containing(cx, cy, cz), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.BLOCKS, 1.6f, 1.6f);
		});
	}

	private void ring(ServerLevel level, double cx, double cy, double cz, double r, SimpleParticleType type) {
		for (int i = 0; i < 26; i++) {
			double a = i * (Math.PI * 2 / 26);
			level.sendParticles(type, cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r, 0, Math.cos(a) * 0.4, 0.03, Math.sin(a) * 0.4, 1.0);
		}
	}

	@Override
	public void load(CompoundTag compound) {
		super.load(compound);
		if (!this.tryLoadLootTable(compound))
			this.stacks = NonNullList.withSize(this.getContainerSize(), ItemStack.EMPTY);
		ContainerHelper.loadAllItems(compound, this.stacks);
	}

	@Override
	public void saveAdditional(CompoundTag compound) {
		super.saveAdditional(compound);
		if (!this.trySaveLootTable(compound)) {
			ContainerHelper.saveAllItems(compound, this.stacks);
		}
	}

	@Override
	public ClientboundBlockEntityDataPacket getUpdatePacket() {
		return ClientboundBlockEntityDataPacket.create(this);
	}

	@Override
	public CompoundTag getUpdateTag() {
		return this.saveWithFullMetadata();
	}

	@Override
	public int getContainerSize() {
		return stacks.size();
	}

	@Override
	public boolean isEmpty() {
		for (ItemStack itemstack : this.stacks)
			if (!itemstack.isEmpty())
				return false;
		return true;
	}

	@Override
	public Component getDefaultName() {
		return Component.literal("breakdown");
	}

	@Override
	public AbstractContainerMenu createMenu(int id, Inventory inventory) {
		return ChestMenu.threeRows(id, inventory);
	}

	@Override
	public Component getDisplayName() {
		return Component.literal("Breakdown");
	}

	@Override
	protected NonNullList<ItemStack> getItems() {
		return this.stacks;
	}

	@Override
	protected void setItems(NonNullList<ItemStack> stacks) {
		this.stacks = stacks;
	}

	@Override
	public boolean canPlaceItem(int index, ItemStack stack) {
		return true;
	}

	@Override
	public int[] getSlotsForFace(Direction side) {
		return IntStream.range(0, this.getContainerSize()).toArray();
	}

	@Override
	public boolean canPlaceItemThroughFace(int index, ItemStack itemstack, @Nullable Direction direction) {
		return this.canPlaceItem(index, itemstack);
	}

	@Override
	public boolean canTakeItemThroughFace(int index, ItemStack itemstack, Direction direction) {
		return true;
	}

	@Override
	public <T> LazyOptional<T> getCapability(Capability<T> capability, @Nullable Direction facing) {
		if (!this.remove && facing != null && capability == ForgeCapabilities.ITEM_HANDLER)
			return handlers[facing.ordinal()].cast();
		return super.getCapability(capability, facing);
	}

	@Override
	public void setRemoved() {
		super.setRemoved();
		for (LazyOptional<? extends IItemHandler> handler : handlers)
			handler.invalidate();
	}
}
