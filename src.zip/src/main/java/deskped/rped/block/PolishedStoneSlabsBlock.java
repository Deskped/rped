package deskped.rped.block;

import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SlabBlock;

public class PolishedStoneSlabsBlock extends SlabBlock {
	public PolishedStoneSlabsBlock() {
		super(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).strength(5f, 21.5f).instrument(NoteBlockInstrument.BANJO));
	}
}