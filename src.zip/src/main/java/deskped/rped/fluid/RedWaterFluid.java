package deskped.rped.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import deskped.rped.init.RpedModItems;
import deskped.rped.init.RpedModFluids;
import deskped.rped.init.RpedModFluidTypes;
import deskped.rped.init.RpedModBlocks;

public abstract class RedWaterFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> RpedModFluidTypes.RED_WATER_TYPE.get(), () -> RpedModFluids.RED_WATER.get(), () -> RpedModFluids.FLOWING_RED_WATER.get())
			.explosionResistance(100f).bucket(() -> RpedModItems.RED_WATER_BUCKET.get()).block(() -> (LiquidBlock) RpedModBlocks.RED_WATER.get());

	private RedWaterFluid() {
		super(PROPERTIES);
	}

	public static class Source extends RedWaterFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends RedWaterFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}