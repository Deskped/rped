package deskped.rped.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import deskped.rped.init.RpedModItems;
import deskped.rped.init.RpedModFluids;
import deskped.rped.init.RpedModFluidTypes;
import deskped.rped.init.RpedModBlocks;

public abstract class YellowWaterFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> RpedModFluidTypes.YELLOW_WATER_TYPE.get(), () -> RpedModFluids.YELLOW_WATER.get(), () -> RpedModFluids.FLOWING_YELLOW_WATER.get())
			.explosionResistance(100f).bucket(() -> RpedModItems.YELLOW_WATER_BUCKET.get()).block(() -> (LiquidBlock) RpedModBlocks.YELLOW_WATER.get());

	private YellowWaterFluid() {
		super(PROPERTIES);
	}

	public static class Source extends YellowWaterFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends YellowWaterFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}