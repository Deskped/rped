package deskped.rped.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import deskped.rped.init.RpedModItems;
import deskped.rped.init.RpedModFluids;
import deskped.rped.init.RpedModFluidTypes;
import deskped.rped.init.RpedModBlocks;

public abstract class OrangeWaterFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> RpedModFluidTypes.ORANGE_WATER_TYPE.get(), () -> RpedModFluids.ORANGE_WATER.get(), () -> RpedModFluids.FLOWING_ORANGE_WATER.get())
			.explosionResistance(100f).bucket(() -> RpedModItems.ORANGE_WATER_BUCKET.get()).block(() -> (LiquidBlock) RpedModBlocks.ORANGE_WATER.get());

	private OrangeWaterFluid() {
		super(PROPERTIES);
	}

	public static class Source extends OrangeWaterFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends OrangeWaterFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}