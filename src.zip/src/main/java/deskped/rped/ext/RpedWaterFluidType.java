package deskped.rped.ext;

import java.util.function.Consumer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BiomeColors;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.material.FluidState;

import net.minecraftforge.client.extensions.common.IClientFluidTypeExtensions;
import net.minecraftforge.common.SoundActions;
import net.minecraftforge.fluids.FluidType;

public class RpedWaterFluidType extends FluidType {

	public RpedWaterFluidType() {
		super(FluidType.Properties.create()
				.descriptionId("fluid_type.rped.water")
				.canSwim(true)
				.canDrown(true)
				.canPushEntity(true)
				.canExtinguish(true)
				.canConvertToSource(true)
				.canHydrate(true)
				.supportsBoating(true)
				.motionScale(0.014D)
				.fallDistanceModifier(0.0F)
				.density(1000)
				.viscosity(1000)
				.temperature(300)
				.sound(SoundActions.BUCKET_FILL, SoundEvents.BUCKET_FILL)
				.sound(SoundActions.BUCKET_EMPTY, SoundEvents.BUCKET_EMPTY));
	}

	@Override
	public void initializeClient(Consumer<IClientFluidTypeExtensions> consumer) {
		consumer.accept(new IClientFluidTypeExtensions() {
			private final ResourceLocation still = new ResourceLocation("minecraft", "block/water_still");
			private final ResourceLocation flow = new ResourceLocation("minecraft", "block/water_flow");
			private final ResourceLocation overlay = new ResourceLocation("minecraft", "block/water_overlay");
			private final ResourceLocation screen = new ResourceLocation("minecraft", "textures/misc/underwater.png");

			@Override
			public ResourceLocation getStillTexture() {
				return still;
			}

			@Override
			public ResourceLocation getFlowingTexture() {
				return flow;
			}

			@Override
			public ResourceLocation getOverlayTexture() {
				return overlay;
			}

			@Override
			public ResourceLocation getRenderOverlayTexture(Minecraft mc) {
				return screen;
			}

			@Override
			public int getTintColor() {
				return 0xFF3F76E4;
			}

			@Override
			public int getTintColor(FluidState state, BlockAndTintGetter getter, BlockPos pos) {
				return 0xFF000000 | BiomeColors.getAverageWaterColor(getter, pos);
			}
		});
	}
}
