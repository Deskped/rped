package deskped.rped.ext;

import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.RegistryObject;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.level.block.entity.BlockEntityType;

import deskped.rped.block.entity.CrafterBlockEntity;
import deskped.rped.init.RpedModBlockEntities;
import deskped.rped.init.RpedModBlocks;
import deskped.rped.init.RpedModMenus;
import deskped.rped.world.inventory.CrafterMenu;

public class CrafterRegistry {

	public static final RegistryObject<BlockEntityType<CrafterBlockEntity>> CRAFTER = RpedModBlockEntities.REGISTRY.register("crafter",
			() -> BlockEntityType.Builder.of(CrafterBlockEntity::new, RpedModBlocks.CRAFTER.get()).build(null));

	public static final RegistryObject<MenuType<CrafterMenu>> CRAFTER_MENU = RpedModMenus.REGISTRY.register("crafter",
			() -> IForgeMenuType.create(CrafterMenu::new));

	public static void init() {
	}
}
