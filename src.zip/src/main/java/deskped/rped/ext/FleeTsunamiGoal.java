package deskped.rped.ext;

import java.util.EnumSet;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.phys.Vec3;

public class FleeTsunamiGoal extends Goal {

	private static final int DETECT = 5;
	private static final int SCAN_INTERVAL = 20;

	private final PathfinderMob mob;
	private final double speed;
	private double tx;
	private double ty;
	private double tz;

	public FleeTsunamiGoal(PathfinderMob mob, double speed) {
		this.mob = mob;
		this.speed = speed;
		this.setFlags(EnumSet.of(Goal.Flag.MOVE));
	}

	@Override
	public boolean canUse() {
		if (mob.tickCount % SCAN_INTERVAL != 0)
			return false;
		BlockPos threat = findTsunami();
		if (threat == null)
			return false;
		Vec3 away = DefaultRandomPos.getPosAway(mob, 16, 7, Vec3.atCenterOf(threat));
		if (away == null)
			return false;
		this.tx = away.x;
		this.ty = away.y;
		this.tz = away.z;
		return true;
	}

	@Override
	public boolean canContinueToUse() {
		return !mob.getNavigation().isDone();
	}

	@Override
	public void start() {
		mob.getNavigation().moveTo(tx, ty, tz, speed);
	}

	private BlockPos findTsunami() {
		BlockPos base = mob.blockPosition();
		Fluid src = RpedFluids.WATER.get();
		Fluid flow = RpedFluids.FLOWING_WATER.get();
		BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
		for (int dx = -DETECT; dx <= DETECT; dx++) {
			for (int dy = -DETECT; dy <= DETECT; dy++) {
				for (int dz = -DETECT; dz <= DETECT; dz++) {
					m.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
					Fluid f = mob.level().getFluidState(m).getType();
					if (f == src || f == flow)
						return m.immutable();
				}
			}
		}
		return null;
	}
}
