package deskped.rped.ext;

import deskped.rped.RpedClientConfig;
import deskped.rped.entity.HookEntity;
import deskped.rped.entity.OrbitingBlockEntity;
import deskped.rped.enchantment.AutosmeltEnchantment;
import deskped.rped.enchantment.DecapitatorEnchantment;
import deskped.rped.init.RpedModEnchantments;
import deskped.rped.init.RpedModEntities;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.enchantment.Enchantment;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.RegistryObject;

public class RpedExtra {

    public static final RegistryObject<EntityType<HookEntity>> HOOK_ENTITY = RpedModEntities.REGISTRY.register("hook",
            () -> EntityType.Builder.<HookEntity>of(HookEntity::new, MobCategory.MISC)
                    .sized(0.25f, 0.25f)
                    .clientTrackingRange(64)
                    .updateInterval(2)
                    .build("hook"));

    public static final RegistryObject<EntityType<OrbitingBlockEntity>> ORBITING_BLOCK = RpedModEntities.REGISTRY.register("orbiting_block",
            () -> EntityType.Builder.<OrbitingBlockEntity>of(OrbitingBlockEntity::new, MobCategory.MISC)
                    .sized(0.75f, 0.75f)
                    .clientTrackingRange(96)
                    .updateInterval(1)
                    .build("orbiting_block"));

    public static final RegistryObject<Enchantment> AUTOSMELT = RpedModEnchantments.REGISTRY.register("autosmelt", AutosmeltEnchantment::new);
    public static final RegistryObject<Enchantment> DECAPITATOR = RpedModEnchantments.REGISTRY.register("decapitator", DecapitatorEnchantment::new);

    public static void init(IEventBus bus) {
        RpedFluids.register(bus);
        RpedFeaturesConfig.register();
        RpedClientConfig.register();
        CrafterRegistry.init();
    }
}
