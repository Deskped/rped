package deskped.rped.ext;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import deskped.rped.init.RpedModTabs;
import deskped.rped.init.RpedModBlocks;
import deskped.rped.init.RpedModItems;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = "rped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class BannerDividers {
    public static final String KEY = "ylbanner";
    public static final String TYPE = "yltype";
    private static final String UID = "yluid";
    private static int counter = 0;

    public static int role(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.contains(KEY) ? tag.getInt(KEY) : 0;
    }

    public static int bannerType(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.contains(TYPE) ? tag.getInt(TYPE) : 0;
    }

    private static int sectionBanner(ItemStack stack) {
        Item item = stack.getItem();
        if (item == RpedModBlocks.OXIDIZED_IRON_CASING.get().asItem())
            return 0;
        if (item == RpedModBlocks.LAMP.get().asItem())
            return 1;
        if (item == RpedModItems.TUMANITE_BLOCK.get())
            return 2;
        if (item == RpedModItems.CLOCK_PARTS.get())
            return 3;
        if (item == RpedModItems.ANCIENT_BASALT_BARREL.get())
            return 4;
        if (item == RpedModItems.INFO.get())
            return 5;
        if (item == RpedModItems.GLACIER.get())
            return 6;
        return -1;
    }

    private static ItemStack marker(int kind, int type) {
        ItemStack stack = new ItemStack(Items.PAPER);
        CompoundTag tag = new CompoundTag();
        tag.putInt(KEY, kind);
        tag.putInt(TYPE, type);
        tag.putInt(UID, counter++);
        stack.setTag(tag);
        return stack;
    }

    @SubscribeEvent
    public static void onBuild(BuildCreativeModeTabContentsEvent event) {
        if (event.getTab() != RpedModTabs.RPED.get())
            return;
        var entries = event.getEntries();
        List<ItemStack> all = new ArrayList<>();
        List<ItemStack> stacks = new ArrayList<>();
        List<CreativeModeTab.TabVisibility> vis = new ArrayList<>();
        for (var e : entries) {
            all.add(e.getKey());
            if (role(e.getKey()) == 0) {
                stacks.add(e.getKey());
                vis.add(e.getValue());
            }
        }
        for (ItemStack s : all)
            entries.remove(s);
        int col = 0;
        for (int i = 0; i < stacks.size(); i++) {
            int type = sectionBanner(stacks.get(i));
            if (type >= 0) {
                while (col != 0) {
                    entries.put(marker(2, 0), CreativeModeTab.TabVisibility.PARENT_TAB_ONLY);
                    col = (col + 1) % 9;
                }
                for (int c = 0; c < 9; c++)
                    entries.put(marker(1, type), CreativeModeTab.TabVisibility.PARENT_TAB_ONLY);
            }
            entries.put(stacks.get(i), vis.get(i));
            col = (col + 1) % 9;
        }
    }
}