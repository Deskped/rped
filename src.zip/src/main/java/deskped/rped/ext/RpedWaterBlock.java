package deskped.rped.ext;

import java.util.Optional;
import java.util.function.Supplier;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.material.FluidState;

public class RpedWaterBlock extends LiquidBlock {

	public static final int WAVE_INTERVAL = 1200;

	private static final Direction[] SPREAD_DIRS = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.DOWN};

	public RpedWaterBlock(Supplier<? extends net.minecraft.world.level.material.FlowingFluid> fluid, BlockBehaviour.Properties props) {
		super(fluid, props);
	}

	@Override
	public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean isMoving) {
		if (!level.isClientSide()) {
			level.scheduleTick(pos, state.getFluidState().getType(), 5);
			level.scheduleTick(pos, this, WAVE_INTERVAL);
		}
	}

	@Override
	public void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock, BlockPos neighborPos, boolean movedByPiston) {
		if (!level.isClientSide()) {
			level.scheduleTick(pos, state.getFluidState().getType(), 5);
		}
	}

	@Override
	public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
		if (state.getBlock() != this)
			return;
		if (!state.getFluidState().isSource())
			return;
		for (Direction dir : SPREAD_DIRS)
			spreadInto(level, pos, dir, random);
		level.scheduleTick(pos, this, WAVE_INTERVAL);
	}

	private void spreadInto(ServerLevel level, BlockPos pos, Direction dir, RandomSource random) {
		BlockPos npos = pos.relative(dir);
		BlockState ns = level.getBlockState(npos);
		FluidState nf = ns.getFluidState();
		Fluid ft = nf.getType();
		if (ft == RpedFluids.WATER.get() || ft == RpedFluids.FLOWING_WATER.get())
			return;
		if (ft == Fluids.WATER || ft == Fluids.FLOWING_WATER) {
			placeSource(level, npos);
			if (random.nextFloat() < 0.15F)
				splash(level, npos);
			return;
		}
		if (!nf.isEmpty())
			return;
		if (isOpen(ns)) {
			placeSource(level, npos);
			return;
		}
		if (dir == Direction.DOWN)
			return;
		if (canBreak(level, npos, ns) && openBehind(level, npos, dir)) {
			breakWall(level, npos, ns, random);
			placeSource(level, npos);
		}
	}

	private static boolean isOpen(BlockState s) {
		return s.isAir() || s.canBeReplaced(RpedFluids.WATER.get());
	}

	private boolean isOpenOrWater(BlockState s) {
		if (isOpen(s))
			return true;
		Fluid f = s.getFluidState().getType();
		return f == Fluids.WATER || f == Fluids.FLOWING_WATER || f == RpedFluids.WATER.get() || f == RpedFluids.FLOWING_WATER.get();
	}

	private boolean openBehind(ServerLevel level, BlockPos npos, Direction dir) {
		return isOpenOrWater(level.getBlockState(npos.relative(dir))) || isOpenOrWater(level.getBlockState(npos.relative(dir).below()));
	}

	private static boolean canBreak(ServerLevel level, BlockPos npos, BlockState s) {
		if (s.isAir() || s.hasBlockEntity())
			return false;
		if (!s.getFluidState().isEmpty())
			return false;
		return s.getDestroySpeed(level, npos) >= 0.0F;
	}

	private void placeSource(ServerLevel level, BlockPos npos) {
		level.setBlock(npos, RpedFluids.WATER_BLOCK.get().defaultBlockState(), 3);
	}

	private void breakWall(ServerLevel level, BlockPos npos, BlockState s, RandomSource random) {
		level.levelEvent(2001, npos, Block.getId(s));
		if (random.nextFloat() < 0.6F)
			level.playSound(null, npos, SoundEvents.GENERIC_SPLASH, SoundSource.BLOCKS, 0.7F, 0.85F + random.nextFloat() * 0.3F);
		splash(level, npos);
	}

	private void splash(ServerLevel level, BlockPos npos) {
		level.sendParticles(ParticleTypes.SPLASH, npos.getX() + 0.5D, npos.getY() + 0.9D, npos.getZ() + 0.5D, 6, 0.25D, 0.1D, 0.25D, 0.0D);
	}

	@Override
	public ItemStack pickupBlock(LevelAccessor level, BlockPos pos, BlockState state) {
		if (state.getValue(LEVEL) == 0) {
			level.setBlock(pos, Blocks.AIR.defaultBlockState(), 11);
			return new ItemStack(Items.WATER_BUCKET);
		}
		return ItemStack.EMPTY;
	}

	@Override
	public Optional<SoundEvent> getPickupSound() {
		return Optional.of(SoundEvents.BUCKET_FILL);
	}
}
