package deskped.rped.ext;

import deskped.rped.RpedMod;
import deskped.rped.init.RpedModBlocks;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fluids.FluidType;
import net.minecraftforge.fluids.ForgeFlowingFluid;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class RpedFluids {

	public static final DeferredRegister<FluidType> FLUID_TYPES = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, RpedMod.MODID);
	public static final DeferredRegister<Fluid> FLUIDS = DeferredRegister.create(ForgeRegistries.FLUIDS, RpedMod.MODID);

	public static final RegistryObject<FluidType> WATER_TYPE = FLUID_TYPES.register("water", RpedWaterFluidType::new);

	public static final RegistryObject<FlowingFluid> WATER = FLUIDS.register("water", () -> new ForgeFlowingFluid.Source(properties()));

	public static final RegistryObject<FlowingFluid> FLOWING_WATER = FLUIDS.register("flowing_water", () -> new ForgeFlowingFluid.Flowing(properties()));

	public static final RegistryObject<LiquidBlock> WATER_BLOCK = RpedModBlocks.REGISTRY.register("water",
			() -> new RpedWaterBlock(WATER, BlockBehaviour.Properties.copy(Blocks.WATER).noLootTable()));

	private static ForgeFlowingFluid.Properties properties() {
		return new ForgeFlowingFluid.Properties(WATER_TYPE, WATER, FLOWING_WATER)
				.slopeFindDistance(4)
				.levelDecreasePerBlock(1)
				.tickRate(5)
				.explosionResistance(100.0F)
				.block(WATER_BLOCK);
	}

	public static void register(IEventBus bus) {
		FLUID_TYPES.register(bus);
		FLUIDS.register(bus);
	}
}