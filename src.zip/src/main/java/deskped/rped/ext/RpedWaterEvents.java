package deskped.rped.ext;

import deskped.rped.RpedMod;

import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.animal.WaterAnimal;

import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = RpedMod.MODID)
public class RpedWaterEvents {

	@SubscribeEvent
	public static void onEntityJoin(EntityJoinLevelEvent event) {
		if (event.getLevel().isClientSide())
			return;
		if (event.getEntity() instanceof PathfinderMob mob && !(mob instanceof WaterAnimal))
			mob.goalSelector.addGoal(1, new FleeTsunamiGoal(mob, 1.3D));
	}
}
