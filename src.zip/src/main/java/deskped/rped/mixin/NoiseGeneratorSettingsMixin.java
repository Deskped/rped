package deskped.rped.mixin;

import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin {
}