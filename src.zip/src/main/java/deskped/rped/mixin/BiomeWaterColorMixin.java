package deskped.rped.mixin;

import net.minecraft.world.level.biome.Biome;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Biome.class)
public class BiomeWaterColorMixin {

    @Inject(method = "getWaterColor", at = @At("HEAD"), cancellable = true)
    private void rped$getWaterColor(CallbackInfoReturnable<Integer> cir) {
        cir.setReturnValue(0xFFFFFF);
    }
}