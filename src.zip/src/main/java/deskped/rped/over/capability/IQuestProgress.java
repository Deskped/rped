package deskped.rped.over.capability;

import net.minecraft.nbt.CompoundTag;
import java.util.Map;
import java.util.Set;

public interface IQuestProgress {

    int getProgress(String clockId);
    void setProgress(String clockId, int value);
    void addProgress(String clockId, int amount);

    int getCompletions(String clockId);
    void setCompletions(String clockId, int count);

    boolean hasAbility(String clockId);
    void grantAbility(String clockId);

    default boolean isCompletedAtLeastOnce(String clockId) {
        return getCompletions(clockId) > 0;
    }

    void clearAllProgress();

    int getKillCount();
    void setKillCount(int count);

    Set<String> getGrantedAbilities();
    Map<String, Integer> getAllProgress();

    Set<String> getVisitedBiomes();
    void addVisitedBiome(String biomeId);

    long getLastDayChecked();
    void setLastDayChecked(long day);

    long getLastClockAwardTime();
    void setLastClockAwardTime(long time);

    CompoundTag serializeNBT();
    void deserializeNBT(CompoundTag tag);
}
