package deskped.rped.over.capability;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PlayerRelicInventoryProvider implements ICapabilitySerializable<CompoundTag> {

    public static final Capability<ItemStackHandler> RELIC_INVENTORY =
            CapabilityManager.get(new CapabilityToken<>() {});

    public static final int SLOTS = 33;

    private final ItemStackHandler handler = new ItemStackHandler(SLOTS);
    private final LazyOptional<ItemStackHandler> optional = LazyOptional.of(() -> handler);

    @NotNull
    @Override
    public <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        return cap == RELIC_INVENTORY ? optional.cast() : LazyOptional.empty();
    }

    @Override
    public CompoundTag serializeNBT() {
        return handler.serializeNBT();
    }

    @Override
    public void deserializeNBT(CompoundTag nbt) {
        handler.deserializeNBT(nbt);
    }

    public static void register(RegisterCapabilitiesEvent event) {
        event.register(ItemStackHandler.class);
    }

    public void invalidate() {
        optional.invalidate();
    }
}
