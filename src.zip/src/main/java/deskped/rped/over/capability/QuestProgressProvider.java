package deskped.rped.over.capability;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.common.util.LazyOptional;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class QuestProgressProvider implements ICapabilitySerializable<CompoundTag> {

    public static final Capability<IQuestProgress> QUEST_PROGRESS = CapabilityManager.get(new CapabilityToken<>() {});

    private final QuestProgress instance = new QuestProgress();
    private final LazyOptional<IQuestProgress> optional = LazyOptional.of(() -> instance);

    @NotNull
    @Override
    public <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        return cap == QUEST_PROGRESS ? optional.cast() : LazyOptional.empty();
    }

    @Override
    public CompoundTag serializeNBT() {
        return instance.serializeNBT();
    }

    @Override
    public void deserializeNBT(CompoundTag nbt) {
        instance.deserializeNBT(nbt);
    }

    public static void register(RegisterCapabilitiesEvent event) {
        event.register(IQuestProgress.class);
    }

    public void invalidate() {
        optional.invalidate();
    }
}
