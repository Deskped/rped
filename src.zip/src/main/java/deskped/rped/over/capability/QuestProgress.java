package deskped.rped.over.capability;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import java.util.*;

public class QuestProgress implements IQuestProgress {

    private final Map<String, Integer> progress     = new HashMap<>();
    private final Map<String, Integer> completions  = new HashMap<>();
    private final Set<String> grantedAbilities      = new HashSet<>();
    private final Set<String> visitedBiomes         = new HashSet<>();

    private int killCount        = 0;
    private long lastDayChecked  = -1L;
    private long lastClockAwardTime = 0L;

    @Override public int  getProgress(String id)           { return progress.getOrDefault(id, 0); }
    @Override public void setProgress(String id, int v)    { progress.put(id, Math.max(0, v)); }
    @Override public void addProgress(String id, int amt)  { progress.merge(id, amt, Integer::sum); }

    @Override public int  getCompletions(String id)        { return completions.getOrDefault(id, 0); }
    @Override public void setCompletions(String id, int n) { completions.put(id, n); }

    @Override public boolean hasAbility(String id)         { return grantedAbilities.contains(id); }
    @Override public void grantAbility(String id)          { grantedAbilities.add(id); }

    @Override public int  getKillCount()                   { return killCount; }
    @Override public void setKillCount(int c)              { killCount = c; }

    @Override public Set<String>           getGrantedAbilities() { return Collections.unmodifiableSet(grantedAbilities); }
    @Override public Map<String, Integer>  getAllProgress()       { return Collections.unmodifiableMap(progress); }
    @Override public Set<String>           getVisitedBiomes()    { return Collections.unmodifiableSet(visitedBiomes); }

    @Override public long getLastDayChecked()              { return lastDayChecked; }
    @Override public void setLastDayChecked(long day)      { lastDayChecked = day; }

    @Override public long getLastClockAwardTime()          { return lastClockAwardTime; }
    @Override public void setLastClockAwardTime(long time) { lastClockAwardTime = time; }

    @Override
    public void addVisitedBiome(String biomeId) {
        visitedBiomes.add(biomeId);
        progress.put("radio", visitedBiomes.size());
    }

    @Override
    public void clearAllProgress() {
        progress.clear();
        completions.clear();
        grantedAbilities.clear();
        visitedBiomes.clear();
        killCount = 0;
        lastDayChecked = -1L;
        lastClockAwardTime = 0L;
    }

    @Override
    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();

        CompoundTag prog = new CompoundTag();
        progress.forEach(prog::putInt);
        tag.put("progress", prog);

        CompoundTag comps = new CompoundTag();
        completions.forEach(comps::putInt);
        tag.put("completions", comps);

        ListTag abilities = new ListTag();
        grantedAbilities.forEach(s -> abilities.add(StringTag.valueOf(s)));
        tag.put("abilities", abilities);

        ListTag biomes = new ListTag();
        visitedBiomes.forEach(s -> biomes.add(StringTag.valueOf(s)));
        tag.put("visitedBiomes", biomes);

        tag.putInt("killCount", killCount);
        tag.putLong("lastDayChecked", lastDayChecked);
        tag.putLong("lastClockAwardTime", lastClockAwardTime);
        return tag;
    }

    @Override
    public void deserializeNBT(CompoundTag tag) {
        progress.clear();
        completions.clear();
        grantedAbilities.clear();
        visitedBiomes.clear();

        if (tag.contains("progress", Tag.TAG_COMPOUND)) {
            CompoundTag p = tag.getCompound("progress");
            p.getAllKeys().forEach(k -> progress.put(k, p.getInt(k)));
        }
        if (tag.contains("completions", Tag.TAG_COMPOUND)) {
            CompoundTag c = tag.getCompound("completions");
            c.getAllKeys().forEach(k -> completions.put(k, c.getInt(k)));
        }
        if (tag.contains("abilities", Tag.TAG_LIST)) {
            tag.getList("abilities", Tag.TAG_STRING)
               .forEach(t -> grantedAbilities.add(t.getAsString()));
        }
        if (tag.contains("visitedBiomes", Tag.TAG_LIST)) {
            tag.getList("visitedBiomes", Tag.TAG_STRING)
               .forEach(t -> visitedBiomes.add(t.getAsString()));
        }
        killCount = tag.getInt("killCount");
        lastDayChecked = tag.contains("lastDayChecked") ? tag.getLong("lastDayChecked") : -1L;
        lastClockAwardTime = tag.contains("lastClockAwardTime") ? tag.getLong("lastClockAwardTime") : 0L;
    }
}
