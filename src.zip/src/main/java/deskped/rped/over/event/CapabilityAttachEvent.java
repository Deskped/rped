package deskped.rped.over.event;

import deskped.rped.over.capability.PlayerRelicInventoryProvider;
import deskped.rped.over.capability.QuestProgressProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class CapabilityAttachEvent {

    @SubscribeEvent
    public static void onAttachCapabilities(AttachCapabilitiesEvent<Entity> event) {
        if (!(event.getObject() instanceof Player)) return;

        QuestProgressProvider questProvider = new QuestProgressProvider();
        event.addCapability(ResourceLocation.tryParse("rped:quest_progress"), questProvider);
        event.addListener(questProvider::invalidate);

        PlayerRelicInventoryProvider relicProvider = new PlayerRelicInventoryProvider();
        event.addCapability(ResourceLocation.tryParse("rped:relic_inventory"), relicProvider);
        event.addListener(relicProvider::invalidate);
    }
}
