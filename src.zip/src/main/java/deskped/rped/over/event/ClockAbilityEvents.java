package deskped.rped.over.event;

import deskped.rped.over.util.ClockAbilityManager;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingExperienceDropEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;

@Mod.EventBusSubscriber
public class ClockAbilityEvents {

    private static final Map<Integer, Long> radioLastBroadcast = new HashMap<>();
    private static final long RADIO_INTERVAL_TICKS = 20 * 60 * 10L;

    @SubscribeEvent
    public static void onLivingFall(LivingFallEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        Set<String> a = ClockAbilityManager.getActiveClocks(player);
        if (a.contains("attitude_indicator") || a.contains("anemometer")) {
            event.setDistance(0f);
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        LivingEntity entity = event.getEntity();

        if (entity instanceof ServerPlayer player) {
            Set<String> a = ClockAbilityManager.getActiveClocks(player);

            if (a.contains("alarm_clock")) {
                boolean day = player.level().getDayTime() % 24000 < 12000;
                if (day && event.getAmount() < 2.0f) { event.setCanceled(true); return; }
            }
            if (a.contains("attitude_indicator") && event.getSource().is(DamageTypeTags.IS_FALL)) {
                event.setCanceled(true); return;
            }
            if (a.contains("anemometer") && event.getSource().is(DamageTypeTags.IS_FALL)) {
                event.setCanceled(true); return;
            }
            if (a.contains("demon_clock") && event.getSource().is(DamageTypeTags.IS_FIRE)) {
                event.setCanceled(true); return;
            }
            if (a.contains("mechanical_crane_scales") && event.getSource().is(DamageTypeTags.IS_EXPLOSION)) {
                event.setAmount(0f);
            }
            if (a.contains("totem_clock")) {
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 1, false, false, true));
            }
            if (a.contains("scroll_clock") && event.getSource().getMsgId().equals("outOfWorld")) {
                event.setCanceled(true); return;
            }
            if (a.contains("angel_clock") && event.getSource().getMsgId().equals("outOfWorld")) {
                event.setCanceled(true); return;
            }
            if (a.contains("chess_clock")) {
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 60, 0, false, false, true));
            }
            if (a.contains("ships_clock") && event.getSource().getMsgId().equals("drown")) {
                event.setCanceled(true); return;
            }

            if (a.contains("clock_of_seven_curses")) {
                float amt = event.getAmount();

                amt *= 2.0f;

                amt *= 1.30f;

                event.setAmount(amt);
            }
        }

        if (entity instanceof Monster mob) {
            Entity attacker = event.getSource().getEntity();
            if (!(attacker instanceof ServerPlayer sp)) return;
            Set<String> a = ClockAbilityManager.getActiveClocks(sp);

            if (a.contains("clock_of_seven_curses")) {
                event.setAmount(event.getAmount() * 0.5f);
            }

        }
    }

    @SubscribeEvent
    public static void onAttackEntity(AttackEntityEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        Set<String> a = ClockAbilityManager.getActiveClocks(player);
        ServerLevel level = (ServerLevel) player.level();
        Entity target = event.getTarget();

        if (a.contains("chess_clock")) {
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 5, 2, false, false));
        }

        if (a.contains("compass_clock") && target instanceof LivingEntity le) {
            le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1, false, false));
            le.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 0, false, false));
        }

        if (a.contains("stopwatch") && target instanceof LivingEntity le) {
            if (player.tickCount % 5 == 0) le.setSecondsOnFire(2);
        }

        if (a.contains("meter") && target instanceof LivingEntity) {
            if (player.tickCount % 20 == 0) {
                level.getEntitiesOfClass(Monster.class, new AABB(target.blockPosition()).inflate(3))
                     .forEach(m -> m.hurt(level.damageSources().playerAttack(player), 3.0f));
            }
        }

        if (a.contains("demon_clock") && target instanceof LivingEntity le) {
            le.setSecondsOnFire(5);
        }

        if (a.contains("dont_forget_clock") && target instanceof LivingEntity le) {
            le.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1, false, false));
            le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0, false, false));
        }

        if (a.contains("sun_on_a_stick_with_a_clock") && target instanceof LivingEntity le) {
            le.setSecondsOnFire(4);
            le.addEffect(new MobEffectInstance(MobEffects.GLOWING, 60, 0, false, false));
        }

        if (a.contains("wall_clock") && target instanceof LivingEntity) {
            level.getEntitiesOfClass(Monster.class, new AABB(target.blockPosition()).inflate(4))
                 .stream().filter(m -> m != target)
                 .forEach(m -> m.hurt(level.damageSources().playerAttack(player), 1.0f));
        }

        if (a.contains("aqua_clock") && player.isUnderWater() && target instanceof LivingEntity le) {
            le.addEffect(new MobEffectInstance(MobEffects.POISON, 60, 0, false, false));
        }

        if (a.contains("alarm_clock") && player.level().getDayTime() % 24000 < 12000 && target instanceof LivingEntity le) {
            le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 0, false, false));
        }

        if (a.contains("angel_clock") && player.tickCount % 600 == 0) {
            player.removeEffect(MobEffects.POISON);
            player.removeEffect(MobEffects.WITHER);
            player.removeEffect(MobEffects.BLINDNESS);
            player.removeEffect(MobEffects.WEAKNESS);
        }

        if (a.contains("paper_clock") && player.tickCount % 30 == 0 && target instanceof LivingEntity le) {
            le.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0, false, false));
        }
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        Entity src = event.getSource().getEntity();
        if (!(src instanceof ServerPlayer player)) return;
        LivingEntity killed = event.getEntity();
        Set<String> a = ClockAbilityManager.getActiveClocks(player);
        ServerLevel level = (ServerLevel) player.level();

        if (a.contains("totem_clock")) {
            player.heal(4.0f);
        }

        if (a.contains("chess_clock")) {
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 1, false, false, true));
        }

        if (a.contains("angel_clock")) {
            player.heal(2.0f);
        }

        if (a.contains("wristwatch")) {
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 80, 1, false, true, true));
        }

        if (a.contains("meter") && level.dimension() == Level.NETHER) {
            player.giveExperiencePoints(5);
        }

        if (a.contains("demon_clock") && level.dimension() == Level.NETHER) {
            player.heal(3.0f);
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 200, 0, false, true, true));
        }

        if (a.contains("clock_of_seven_curses")) {
            giveSevenCursesUniqueDrop(player, killed, level);
        }

        if (a.contains("aqua_clock") && killed instanceof net.minecraft.world.entity.monster.Guardian) {
            if (new Random().nextBoolean()) {
                player.getInventory().add(new ItemStack(Items.PRISMARINE_SHARD, 2 + new Random().nextInt(3)));
            }
        }

        if (a.contains("sundial") && level.getDayTime() % 24000 < 12000) {
            player.giveExperiencePoints(3);
        }

        if (a.contains("scroll_clock") && level.dimension() == Level.END) {
            player.giveExperiencePoints(10);
        }
    }

    @SubscribeEvent
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        if (!(event.getPlayer() instanceof ServerPlayer player)) return;
        Set<String> a = ClockAbilityManager.getActiveClocks(player);
        BlockPos pos = event.getPos();
        ServerLevel level = (ServerLevel) player.level();

        if (a.contains("stopwatch")) {
            var block = event.getState().getBlock();
            if (block == Blocks.STONE || block == Blocks.COBBLESTONE || block == Blocks.DEEPSLATE) {
                if (new Random().nextInt(10) == 0) {
                    player.getInventory().add(new ItemStack(Items.FLINT));
                }
            }
        }

        if (a.contains("digital_clock")) {
            var block = event.getState().getBlock();
            if (block == Blocks.REDSTONE_ORE || block == Blocks.DEEPSLATE_REDSTONE_ORE) {
                player.getInventory().add(new ItemStack(Items.REDSTONE, 1 + new Random().nextInt(3)));
            }
        }

        if (a.contains("paper_clock")) {
            if (event.getState().getBlock() == Blocks.BOOKSHELF) {
                if (new Random().nextInt(3) == 0) {
                    player.getInventory().add(new ItemStack(Items.BOOK));
                }
            }
        }

        if (a.contains("dont_forget_clock")) {
            if (event.getState().getBlock() == Blocks.CHEST || event.getState().getBlock() == Blocks.TRAPPED_CHEST) {
                player.giveExperiencePoints(5);
            }
        }

        if (a.contains("holographic_clock")) {
            var block = event.getState().getBlock();
            if (block == Blocks.COAL_ORE || block == Blocks.IRON_ORE || block == Blocks.GOLD_ORE
                    || block == Blocks.DIAMOND_ORE || block == Blocks.EMERALD_ORE
                    || block == Blocks.DEEPSLATE_DIAMOND_ORE || block == Blocks.DEEPSLATE_IRON_ORE) {
                player.sendSystemMessage(Component.literal("\u00a79[OverPED] \u00a7f\u041e\u0440\u0435 detected nearby!"));
            }
        }
    }

    @SubscribeEvent
    public static void onExperienceDrop(LivingExperienceDropEvent event) {
        Player killer = event.getAttackingPlayer();
        if (!(killer instanceof ServerPlayer player)) return;
        Set<String> a = ClockAbilityManager.getActiveClocks(player);

        if (a.contains("paper_clock")) {
            event.setDroppedExperience(event.getDroppedExperience() * 4);
        }

        if (a.contains("clock_of_seven_curses")) {
            event.setDroppedExperience(event.getDroppedExperience() * 4);
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        if (player.tickCount % 20 != 0) return;

        Set<String> a = ClockAbilityManager.getActiveClocks(player);

        ClockAbilityManager.applyPassiveAbilities(player, a);

        if (a.contains("radio") && player.isShiftKeyDown()) {
            long now = player.tickCount;
            long last = radioLastBroadcast.getOrDefault(player.getId(), -RADIO_INTERVAL_TICKS);
            if (now - last >= RADIO_INTERVAL_TICKS) {
                radioLastBroadcast.put(player.getId(), now);
                broadcastPlayerLocations(player);
            }
        }

        if (a.contains("meter") && player.isShiftKeyDown()) {
            player.getCapability(deskped.rped.over.capability.QuestProgressProvider.QUEST_PROGRESS)
                .ifPresent(cap -> {
                    int kills = cap.getKillCount();
                    player.displayClientMessage(
                        Component.literal("\u00a7b\u2694 \u00a7f" + kills + " \u00a77kills"), true);
                });
        }

        if (a.contains("alarm_clock") && player.level().dimension() == Level.NETHER) {
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 25, 0, false, false, true));
        }

        if (a.contains("ships_clock")) {
            player.level().getEntitiesOfClass(net.minecraft.world.entity.vehicle.Boat.class,
                new AABB(player.blockPosition()).inflate(5))
                .forEach(b -> {
                    if (b.getDeltaMovement().length() > 0.01) {
                        b.setDeltaMovement(b.getDeltaMovement().scale(1.05));
                    }
                });
        }

        if (a.contains("anemometer") && !player.onGround()) {
            player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 25, 0, false, false, true));
            if (player.fallDistance > 3f) {
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 25, 0, false, false, true));
            }
        }

        if (a.contains("scroll_clock") && player.level().dimension() == Level.END) {
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 25, 0, false, false, true));
        }

        if (a.contains("attitude_indicator") && player.isFallFlying()) {
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 25, 1, false, false, true));
        }

        if (a.contains("aqua_clock") && player.isUnderWater()) {
            player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 240, 0, false, false, true));
        }

        if (a.contains("mechanical_crane_scales") && player.level().dimension() == Level.NETHER) {
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 25, 1, false, false, true));
        }

        if (a.contains("ok_clock") && player.getHealth() >= player.getMaxHealth()) {
            player.addEffect(new MobEffectInstance(MobEffects.SATURATION, 25, 0, false, false, true));
        }

        if (a.contains("sun_on_a_stick_with_a_clock") && player.level().dimension() == Level.NETHER) {
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 25, 1, false, false, true));
        }

        if (a.contains("sundial") && player.getY() > 200) {
            player.addEffect(new MobEffectInstance(MobEffects.LUCK, 25, 1, false, false, true));
        }
    }

    private static void broadcastPlayerLocations(ServerPlayer sender) {
        var server = sender.server;
        var players = server.getPlayerList().getPlayers();

        if (players.size() <= 1) {
            var spawn = server.getLevel(Level.OVERWORLD);
            if (spawn != null) {
                BlockPos bed = sender.getRespawnPosition();
                if (bed != null) {
                    sender.sendSystemMessage(Component.literal(
                        "\u00a76[Radio] \u00a7f\u0421\u043f\u0430\u0432\u043d/\u043a\u0440\u043e\u0432\u0430\u0442\u044c: \u00a7e"
                        + bed.getX() + " " + bed.getY() + " " + bed.getZ()));
                } else {
                    BlockPos worldSpawn = spawn.getSharedSpawnPos();
                    sender.sendSystemMessage(Component.literal(
                        "\u00a76[Radio] \u00a7f\u041c\u0438\u0440\u043e\u0432\u043e\u0439 \u0441\u043f\u0430\u0432\u043d: \u00a7e"
                        + worldSpawn.getX() + " " + worldSpawn.getY() + " " + worldSpawn.getZ()));
                }
            }
            return;
        }

        sender.sendSystemMessage(Component.literal("\u00a76[Radio] \u00a7f=== \u0421\u0438\u0433\u043d\u0430\u043b ==="));
        for (ServerPlayer p : players) {
            if (p == sender) continue;
            int px = (int) p.getX();
            int py = (int) p.getY();
            int pz = (int) p.getZ();
            String dim = p.level().dimension() == Level.NETHER ? "\u041d\u0435\u0437\u0435\u0440"
                       : p.level().dimension() == Level.END ? "\u041a\u0440\u0430\u0439" : "\u041c\u0438\u0440";
            sender.sendSystemMessage(Component.literal(
                "\u00a7e" + p.getName().getString()
                + "\u00a77: \u00a7f" + px + " " + py + " " + pz
                + " \u00a77[" + dim + "]"));
        }
    }

    private static void giveSevenCursesUniqueDrop(ServerPlayer player, LivingEntity killed, ServerLevel level) {
        Random rng = new Random();
        if (rng.nextInt(3) != 0) return;

        ItemStack drop;
        if (killed instanceof net.minecraft.world.entity.monster.Zombie) {
            drop = new ItemStack(Items.ROTTEN_FLESH, 1 + rng.nextInt(3));
        } else if (killed instanceof net.minecraft.world.entity.monster.Skeleton) {
            drop = new ItemStack(Items.BONE_MEAL, 2 + rng.nextInt(3));
        } else if (killed instanceof net.minecraft.world.entity.monster.Creeper) {
            drop = new ItemStack(Items.GUNPOWDER, 2 + rng.nextInt(4));
        } else if (killed instanceof net.minecraft.world.entity.monster.Blaze) {
            drop = new ItemStack(Items.BLAZE_ROD, 1 + rng.nextInt(2));
        } else if (killed instanceof net.minecraft.world.entity.monster.Spider) {
            drop = new ItemStack(Items.SPIDER_EYE, 1 + rng.nextInt(3));
        } else if (killed instanceof net.minecraft.world.entity.monster.Witch) {
            drop = new ItemStack(Items.GLOWSTONE_DUST, 3 + rng.nextInt(5));
        } else if (killed instanceof net.minecraft.world.entity.monster.EnderMan) {
            drop = new ItemStack(Items.ENDER_PEARL, 1 + rng.nextInt(2));
        } else if (killed instanceof net.minecraft.world.entity.boss.wither.WitherBoss) {
            drop = new ItemStack(Items.NETHER_STAR);
        } else if (killed instanceof net.minecraft.world.entity.boss.enderdragon.EnderDragon) {
            drop = new ItemStack(Items.DRAGON_BREATH, 3);
        } else {
            return;
        }

        player.getInventory().add(drop);
    }
}
