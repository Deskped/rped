package deskped.rped.over.event;

import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerPlayer;

import deskped.rped.init.RpedModItems;
import deskped.rped.over.OverGate;
import deskped.rped.over.network.OverNetwork;
import deskped.rped.over.network.OpenIntroPacket;
import deskped.rped.over.network.OpenConfirmEquipPacket;

import java.util.Map;
import java.util.HashMap;
import java.util.UUID;

@Mod.EventBusSubscriber
public class RlereEquipEvents {

	private static final Map<UUID, int[]> CLICKS = new HashMap<>();

	@SubscribeEvent(priority = EventPriority.HIGH)
	public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
		if (handleClick(event.getEntity(), event.getHand())) {
			event.setCanceled(true);
			event.setCancellationResult(InteractionResult.SUCCESS);
		}
	}

	@SubscribeEvent(priority = EventPriority.HIGH)
	public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
		if (handleClick(event.getEntity(), event.getHand())) {
			event.setCanceled(true);
			event.setCancellationResult(InteractionResult.SUCCESS);
		}
	}

	private static boolean handleClick(Player player, InteractionHand hand) {
		if (player.isShiftKeyDown())
			return false;
		ItemStack held = player.getItemInHand(hand);
		if (!OverGate.isRlere(held))
			return false;
		if (OverGate.isWearing(player))
			return false;
		if (!player.getItemBySlot(EquipmentSlot.CHEST).isEmpty())
			return false;
		if (player instanceof ServerPlayer sp)
			registerClick(sp);
		return true;
	}

	private static void registerClick(ServerPlayer sp) {
		long now = sp.level().getGameTime();
		int[] data = CLICKS.get(sp.getUUID());
		if (data == null || now - data[1] > 40) {
			data = new int[]{0, 0};
			CLICKS.put(sp.getUUID(), data);
		}
		data[0]++;
		data[1] = (int) now;
		if (data[0] >= 3) {
			CLICKS.remove(sp.getUUID());
			OverNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> sp), new OpenConfirmEquipPacket());
		}
	}

	public static void doEquip(ServerPlayer player) {
		if (OverGate.isWearing(player))
			return;
		ItemStack held = player.getMainHandItem();
		InteractionHand hand = InteractionHand.MAIN_HAND;
		if (!OverGate.isRlere(held)) {
			held = player.getOffhandItem();
			hand = InteractionHand.OFF_HAND;
		}
		if (!OverGate.isRlere(held))
			return;
		if (!player.getItemBySlot(EquipmentSlot.CHEST).isEmpty())
			return;
		ItemStack worn = held.copy();
		worn.setCount(1);
		player.setItemSlot(EquipmentSlot.CHEST, worn);
		player.getItemInHand(hand).shrink(1);
		OverGate.setLocked(player, true);
		if (!OverGate.isIntroShown(player)) {
			OverGate.setIntroShown(player, true);
			OverNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new OpenIntroPacket());
		}
	}

	@SubscribeEvent
	public static void onServerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase != TickEvent.Phase.END)
			return;
		if (!(event.player instanceof ServerPlayer player))
			return;
		if (!OverGate.isLocked(player))
			return;
		if (OverGate.isWearing(player))
			return;
		ItemStack restore = new ItemStack(RpedModItems.RLERE.get());
		for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
			if (OverGate.isRlere(player.getInventory().getItem(i))) {
				player.getInventory().setItem(i, ItemStack.EMPTY);
				break;
			}
		}
		if (OverGate.isRlere(player.containerMenu.getCarried())) {
			player.containerMenu.setCarried(ItemStack.EMPTY);
		}
		player.setItemSlot(EquipmentSlot.CHEST, restore);
	}

	@SubscribeEvent
	public static void onItemToss(ItemTossEvent event) {
		Player player = event.getPlayer();
		if (!OverGate.isLocked(player))
			return;
		if (OverGate.isRlere(event.getEntity().getItem())) {
			event.setCanceled(true);
			player.getInventory().add(event.getEntity().getItem());
		}
	}

	@SubscribeEvent
	public static void onLivingDrops(LivingDropsEvent event) {
		if (!(event.getEntity() instanceof Player))
			return;
		event.getDrops().removeIf(item -> OverGate.isRlere(item.getItem()));
	}

	@SubscribeEvent
	public static void onClone(PlayerEvent.Clone event) {
		if (!event.isWasDeath())
			return;
		Player original = event.getOriginal();
		Player clone = event.getEntity();
		OverGate.copy(original, clone);
		if (OverGate.isLocked(clone)) {
			clone.setItemSlot(EquipmentSlot.CHEST, new ItemStack(RpedModItems.RLERE.get()));
		}
	}

	@SubscribeEvent
	public static void onLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
		if (!(event.getEntity() instanceof ServerPlayer player))
			return;
		if (OverGate.isLocked(player) && !OverGate.isWearing(player)) {
			player.setItemSlot(EquipmentSlot.CHEST, new ItemStack(RpedModItems.RLERE.get()));
		}
	}
}
