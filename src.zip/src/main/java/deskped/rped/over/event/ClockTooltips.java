package deskped.rped.over.event;

import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.client.resources.language.I18n;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@Mod.EventBusSubscriber(value = Dist.CLIENT)
@OnlyIn(Dist.CLIENT)
public class ClockTooltips {

	private static final Set<String> COMPONENTS = new HashSet<>();

	static {
		String[] ids = {"clock_parts", "transistor", "printed_circuit_board", "overidium",
			"redstone_calculator", "advanced_clock_circuit", "volcanic_block", "overidium_block"};
		for (String id : ids)
			COMPONENTS.add("rped:" + id);
	}

	private record Clock(String ability, String quest) {}

	private static final Map<String, Clock> CLOCKS = new HashMap<>();

	private static void C(String itemPath, String ability, String quest) {
		CLOCKS.put("rped:" + itemPath, new Clock(ability, quest));
	}

	private static final Set<String> PLAIN_CLOCKS = new HashSet<>();

	static {
		C("alarm_clock", "Speed I during daytime, prevents damage under 2 during daytime", "Kill 100 hostile mobs during daytime");
		C("sundial", "Strength and Regeneration during daytime", "Survive 500 game days");
		C("chess_clock", "Faster attack cooldown, +10% critical hit chance", "Kill 100 mobs without receiving damage from them");
		C("dont_forget_clock", "Only for big shots", "Kill 100 skeletons");
		C("wristwatch", "Constant Speed I, faster item use", "Take 1000 steps");
		C("paper_clock", "Huge bonus to experience gained", "Sign 100 written books");
		C("stopwatch", "+20% attack speed and faster block mining", "Break 1000 blocks");
		C("meter", "Shows how many hostile mobs you killed when sneaking", "Kill 100 hostile mobs");
		C("holographic_clock", "Highlights dropped items within 30 blocks", "Pick up 1000 items");
		C("ok_clock", "Ok.", "Type 'ok' in chat 1000 times");
		C("compass_clock", "Shows coords of nearest hostile mob when sneaking", "Hit 1000 hostile mobs");
		C("totem_clock", "Receive Regeneration 2 when taking damage", "Trade with villager 100 times");
		C("demon_clock", "Immunity to fire and lava", "Kill 100 Blazes");
		C("mechanical_crane_scales", "Complete knockback resistance", "Place 100 minecarts");
		C("sensor", "Hostile mobs highlighted within 20 blocks", "Get Glowing effect 100 times");
		C("digital_clock", "Haste and Night Vision when holding a redstone torch", "Place 1000 redstone");
		C("ships_clock", "Speeds up boats around you, constant Luck", "Break 100 boats");
		C("anemometer", "Infinite flight for elytra", "Fall in free fall 1000 times");
		C("attitude_indicator", "No nausea, no fall damage", "Fall onto a block 1000 times");
		C("wall_clock", "Damages hostile entities within 5 blocks", "Kill 100 raiders");
		C("its_time_to_have_some_clock", "Periodically gives random strong positive effects", "Live 100 game days");
		C("clock_of_the_seven_curses", "Seven curses and seven blessings", "Obtain all effects in the game once");
		C("aqua_clock", "Underwater breathing, night vision underwater, faster swimming", "Defeat 100 Guardians");
		C("sun_on_a_stick_with_a_clock", "Light aura, additional fire damage to enemies", "Kill the Wither 100 times");
		C("angel_clock", "Constant Regeneration and reduced mob aggression", "Restore 100 health points to yourself");
		C("radio", "Detects structures, periodically weakens mobs around", "Visit 60 biomes");
		C("scroll_clock", "Negates void fall damage, immunity to negative effects", "Be in the Void biome");

		String[] plain = {"childhood_clock", "glass_clock", "residence_clock", "hourglass", "fallen_clock", "im_old_clock"};
		for (String p : plain)
			PLAIN_CLOCKS.add("rped:" + p);
	}

	@SubscribeEvent
	public static void onTooltip(ItemTooltipEvent event) {
		ItemStack stack = event.getItemStack();
		ResourceLocation key = ForgeRegistries.ITEMS.getKey(stack.getItem());
		if (key == null)
			return;
		String id = key.toString();

		Clock clock = CLOCKS.get(id);
		if (clock != null) {
			event.getToolTip().add(Component.literal("\u00a76" + clock.ability()));
			event.getToolTip().add(Component.literal(""));
			event.getToolTip().add(Component.literal("\u00a78Quest: " + clock.quest()));
			return;
		}

		if (PLAIN_CLOCKS.contains(id)) {
			event.getToolTip().add(Component.literal("\u00a78Collectible clock, no special ability"));
			return;
		}

		if (COMPONENTS.contains(id)) {
			String base = "item." + key.getNamespace() + "." + key.getPath() + ".description_";
			for (int i = 0; i < 8; i++) {
				if (I18n.exists(base + i))
					event.getToolTip().add(Component.translatable(base + i));
				else
					break;
			}
		}
	}
}
