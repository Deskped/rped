package deskped.rped.over.event;

import deskped.rped.over.capability.PlayerRelicInventoryProvider;
import deskped.rped.over.inventory.InventoryMenu;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.entity.player.PlayerContainerEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.items.ItemStackHandler;

@Mod.EventBusSubscriber
public class RelicInventoryEvents {

    @SubscribeEvent
    public static void onContainerOpen(PlayerContainerEvent.Open event) {
        if (!(event.getContainer() instanceof InventoryMenu menu)) return;
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        player.getCapability(PlayerRelicInventoryProvider.RELIC_INVENTORY).ifPresent(saved -> {
            ItemStackHandler relicHandler = menu.getRelicHandler();
            for (int i = 0; i < PlayerRelicInventoryProvider.SLOTS; i++) {
                relicHandler.setStackInSlot(i, saved.getStackInSlot(i).copy());
            }
        });
    }

    @SubscribeEvent
    public static void onContainerClose(PlayerContainerEvent.Close event) {
        if (!(event.getContainer() instanceof InventoryMenu menu)) return;
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        ItemStackHandler relicHandler = menu.getRelicHandler();
        player.getCapability(PlayerRelicInventoryProvider.RELIC_INVENTORY).ifPresent(saved -> {
            for (int i = 0; i < PlayerRelicInventoryProvider.SLOTS; i++) {
                saved.setStackInSlot(i, relicHandler.getStackInSlot(i).copy());
            }
        });
    }

    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        event.getOriginal().reviveCaps();
        event.getOriginal().getCapability(PlayerRelicInventoryProvider.RELIC_INVENTORY).ifPresent(old ->
            event.getEntity().getCapability(PlayerRelicInventoryProvider.RELIC_INVENTORY).ifPresent(neo -> {
                for (int i = 0; i < PlayerRelicInventoryProvider.SLOTS; i++) {
                    neo.setStackInSlot(i, old.getStackInSlot(i).copy());
                }
            })
        );
        event.getOriginal().invalidateCaps();
    }

    @SubscribeEvent
    public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
    }

    @SubscribeEvent
    public static void onPlayerChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
    }
}
