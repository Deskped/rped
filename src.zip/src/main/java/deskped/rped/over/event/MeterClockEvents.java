package deskped.rped.over.event;

import deskped.rped.over.capability.QuestProgressProvider;
import deskped.rped.over.util.ClockAbilityManager;
import deskped.rped.over.util.L10n;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Set;

@Mod.EventBusSubscriber
public class MeterClockEvents {

    private static int tick = 0;

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        if (!deskped.rped.over.OverGate.isWearing(player)) return;
        tick++;
        if (tick % 20 != 0) return;
        if (!player.isShiftKeyDown()) return;

        player.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap -> {
            Set<String> active = ClockAbilityManager.getActiveClocks(player);

            if (active.contains("meter")) {
                int kills = cap.getKillCount();
                player.connection.send(new ClientboundSetTitlesAnimationPacket(0, 40, 10));
                player.connection.send(new ClientboundSetTitleTextPacket(
                    Component.literal(L10n.Msg.meterKills(kills))
                ));
            }

            if (active.contains("compass_clock")) {
                Monster nearest = findNearestMob(player);
                if (nearest != null) {
                    int x = (int) nearest.getX();
                    int y = (int) nearest.getY();
                    int z = (int) nearest.getZ();
                    player.sendSystemMessage(Component.literal(
                        L10n.Msg.nearestMob(nearest.getName().getString(), x, y, z)
                    ));
                }
            }
        });
    }

    private static Monster findNearestMob(ServerPlayer player) {
        return player.level().getEntitiesOfClass(
            Monster.class,
            new AABB(player.blockPosition()).inflate(64)
        ).stream().min((a, b) -> Double.compare(
            a.distanceToSqr(player), b.distanceToSqr(player)
        )).orElse(null);
    }
}
