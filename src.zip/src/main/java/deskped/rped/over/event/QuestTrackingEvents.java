package deskped.rped.over.event;

import deskped.rped.over.capability.IQuestProgress;
import deskped.rped.over.capability.QuestProgressProvider;
import deskped.rped.over.network.OverNetwork;
import deskped.rped.over.network.SyncQuestProgressPacket;
import deskped.rped.over.quest.ClockQuestData;
import deskped.rped.over.util.ClockAbilityManager;
import deskped.rped.over.util.L10n;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Blaze;
import net.minecraft.world.entity.monster.Guardian;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Skeleton;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.raid.Raider;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.WrittenBookItem;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityLeaveLevelEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.HashSet;
import java.util.Set;

@Mod.EventBusSubscriber
public class QuestTrackingEvents {

    private static final Set<Integer> noHitTargets = new HashSet<>();
    private static final ResourceLocation ALL_EFFECTS_ADV =
            ResourceLocation.tryParse("minecraft:nether/all_potions");

    static void track(ServerPlayer player, IQuestProgress cap,
                      String clockId, int amount, int required) {
        if (!deskped.rped.over.OverGate.isWearing(player)) return;
        int before  = cap.getProgress(clockId);
        cap.addProgress(clockId, amount);
        int after   = cap.getProgress(clockId);

        int cyclesBefore = before / required;
        int cyclesAfter  = after  / required;

        if (cyclesAfter > cyclesBefore) {
            if (!cap.hasAbility(clockId)) cap.grantAbility(clockId);
            int newCycles = cyclesAfter - cyclesBefore;
            cap.setCompletions(clockId, cap.getCompletions(clockId) + newCycles);
            for (int i = 0; i < newCycles; i++) awardClock(player, clockId);
        }
    }

    static void awardClock(ServerPlayer player, String clockId) {
        player.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap -> {
            long now = player.level().getGameTime();
            long last = cap.getLastClockAwardTime();
            long cooldown = 20 * 60 * 10;

            if (now - last < cooldown) return;

            cap.setLastClockAwardTime(now);

            ClockQuestData.getQuestById(clockId).ifPresent(quest -> {
                ResourceLocation loc = ResourceLocation.tryParse(quest.itemId());
                Item item = (loc != null) ? ForgeRegistries.ITEMS.getValue(loc) : null;
                if (item == null || item == Items.AIR) item = Items.CLOCK;

                ItemStack stack = new ItemStack(item);
                boolean placed = player.getInventory().add(stack);
                if (!placed || !stack.isEmpty()) player.drop(stack.copy(), false);
            });
        });
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        Entity src = event.getSource().getEntity();
        if (!(src instanceof ServerPlayer player)) return;
        LivingEntity killed = event.getEntity();
        boolean day = player.level().getDayTime() % 24000 < 12000;

        player.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap -> {
            if (killed instanceof Monster) {
                if (day) track(player, cap, "alarm_clock", 1, 100);
                track(player, cap, "meter", 1, 100);
                cap.setKillCount(cap.getKillCount() + 1);
            }
            if (killed instanceof Skeleton)    track(player, cap, "dont_forget_clock", 1, 100);
            if (killed instanceof Blaze)       track(player, cap, "demon_clock", 1, 100);
            if (killed instanceof Guardian)    track(player, cap, "aqua_clock", 1, 100);
            if (killed instanceof WitherBoss)  track(player, cap, "sun_on_a_stick_with_a_clock", 1, 100);
            if (killed instanceof Raider)      track(player, cap, "wall_clock", 1, 100);
            if (noHitTargets.contains(killed.getId()) && killed instanceof Monster) {
                track(player, cap, "chess_clock", 1, 100);
                noHitTargets.remove(killed.getId());
            }
            syncProgress(player, cap);
        });
    }

    @SubscribeEvent
    public static void onBoatRemoved(EntityLeaveLevelEvent event) {
        if (!(event.getEntity() instanceof Boat boat)) return;
        if (!(event.getLevel() instanceof net.minecraft.server.level.ServerLevel level)) return;
        if (!boat.isRemoved()) return;
        for (ServerPlayer p : level.players()) {
            if (p.distanceToSqr(boat) < 36) {
                p.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap -> {
                    track(p, cap, "ships_clock", 1, 100);
                    syncProgress(p, cap);
                });
                break;
            }
        }
    }

    @SubscribeEvent
    public static void onAttackEntity(AttackEntityEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!(event.getTarget() instanceof Monster)) return;
        player.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap -> {
            track(player, cap, "compass_clock", 1, 1000);
            syncProgress(player, cap);
        });
        noHitTargets.add(event.getTarget().getId());
    }

    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        noHitTargets.clear();
    }

    @SubscribeEvent
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        if (!(event.getPlayer() instanceof ServerPlayer player)) return;
        player.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap -> {
            track(player, cap, "stopwatch", 1, 1000);
            syncProgress(player, cap);
        });
    }

    @SubscribeEvent
    public static void onItemPickup(EntityItemPickupEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        player.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap -> {
            track(player, cap, "holographic_clock", 1, 1000);
            syncProgress(player, cap);
        });
    }

    @SubscribeEvent
    public static void onChat(ServerChatEvent event) {
        ServerPlayer player = event.getPlayer();
        String msg = event.getMessage().getString().trim().toLowerCase();
        if (msg.equals("\u043e\u043a") || msg.equals("ok")) {
            player.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap -> {
                track(player, cap, "ok_clock", 1, 1000);
                syncProgress(player, cap);
            });
        }
    }

    @SubscribeEvent
    public static void onItemUse(PlayerInteractEvent.RightClickItem event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (event.getItemStack().getItem() instanceof WrittenBookItem) {
            player.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap -> {
                track(player, cap, "paper_clock", 1, 100);
                syncProgress(player, cap);
            });
        }
    }

    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (event.getTarget() instanceof Villager) {
            player.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap -> {
                track(player, cap, "totem_clock", 1, 100);
                syncProgress(player, cap);
            });
        }
    }

    @SubscribeEvent
    public static void onPlayerFall(LivingFallEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        player.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap -> {
            track(player, cap, "attitude_indicator", 1, 1000);
            syncProgress(player, cap);
        });
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        if (player.tickCount % 20 != 0) return;

        player.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap -> {
            boolean changed = false;

            int totalCm = player.getStats().getValue(Stats.CUSTOM.get(Stats.WALK_ONE_CM))
                        + player.getStats().getValue(Stats.CUSTOM.get(Stats.SPRINT_ONE_CM))
                        + player.getStats().getValue(Stats.CUSTOM.get(Stats.CROUCH_ONE_CM));
            int nowH = totalCm / 100;
            int prevH = cap.getProgress("_steps_raw");
            if (nowH > prevH) {
                cap.setProgress("_steps_raw", nowH);
                track(player, cap, "wristwatch", nowH - prevH, 1000);
                changed = true;
            }

            if (!player.onGround() && !player.isFallFlying() && !player.isInWater()
                    && player.fallDistance > 2.0f && player.getDeltaMovement().y < -0.3) {
                track(player, cap, "anemometer", 1, 1000);
                changed = true;
            }

            float currentHP = player.getHealth();
            float lastHP = cap.getProgress("_angel_last_hp") / 10.0f;
            if (lastHP == 0) lastHP = currentHP;
            if (currentHP > lastHP) {
                int healed = (int)((currentHP - lastHP) * 10);
                track(player, cap, "angel_clock", healed, 100);
                changed = true;
            }
            cap.setProgress("_angel_last_hp", (int)(currentHP * 10));

            long curDay = player.level().getDayTime() / 24000L;
            long lastDay = cap.getLastDayChecked();
            if (lastDay == -1L) {
                cap.setLastDayChecked(curDay);
                changed = true;
            } else if (curDay > lastDay) {
                long diff = curDay - lastDay;
                cap.setLastDayChecked(curDay);
                track(player, cap, "sundial", (int) diff, 500);
                track(player, cap, "its_time_to_have_some_clock", (int) diff, 100);
                changed = true;
            }

            if (player.hasEffect(MobEffects.GLOWING)) {
                track(player, cap, "sensor", 1, 100);
                changed = true;
            }

            var biome = player.level().getBiome(player.blockPosition());
            String biomeKey = biome.unwrapKey().map(k -> k.location().toString()).orElse("");
            if (!biomeKey.isEmpty() && !cap.getVisitedBiomes().contains(biomeKey)) {
                cap.addVisitedBiome(biomeKey);
                int visited = cap.getVisitedBiomes().size();
                cap.setProgress("radio", visited);
                if (visited >= ClockQuestData.VANILLA_BIOME_COUNT && !cap.hasAbility("radio")) {
                    cap.grantAbility("radio");
                    cap.setCompletions("radio", 1);
                    awardClock(player, "radio");
                }
                changed = true;
            }

            if (!cap.hasAbility("scroll_clock") && biomeKey.contains("void")) {
                cap.grantAbility("scroll_clock");
                cap.setProgress("scroll_clock", 1);
                cap.setCompletions("scroll_clock", 1);
                awardClock(player, "scroll_clock");
                changed = true;
            }

            Advancement adv = player.server.getAdvancements().getAdvancement(ALL_EFFECTS_ADV);
            if (adv != null) {
                AdvancementProgress prog = player.getAdvancements().getOrStartProgress(adv);
                if (prog.isDone()) {
                    for (String crit : adv.getCriteria().keySet()) {
                        player.getAdvancements().revoke(adv, crit);
                    }
                    cap.grantAbility("clock_of_seven_curses");
                    cap.setCompletions("clock_of_seven_curses",
                            cap.getCompletions("clock_of_seven_curses") + 1);
                    cap.setProgress("clock_of_seven_curses",
                            cap.getCompletions("clock_of_seven_curses"));
                    awardClock(player, "clock_of_seven_curses");
                    changed = true;
                }
            }

            if (changed) syncProgress(player, cap);
        });
    }

    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        if (!event.isWasDeath()) return;
        event.getOriginal().reviveCaps();
        event.getOriginal().getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(old ->
            event.getEntity().getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(neo ->
                neo.deserializeNBT(old.serializeNBT())
            )
        );
        event.getOriginal().invalidateCaps();
    }

    @SubscribeEvent
    public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player)
            player.getCapability(QuestProgressProvider.QUEST_PROGRESS)
                  .ifPresent(cap -> syncProgress(player, cap));
    }

    public static void trackPublic(ServerPlayer player, IQuestProgress cap,
                                   String clockId, int amount, int required) {
        track(player, cap, clockId, amount, required);
    }

    public static void syncProgress(ServerPlayer player, IQuestProgress cap) {
        OverNetwork.CHANNEL.send(
                PacketDistributor.PLAYER.with(() -> player),
                new SyncQuestProgressPacket(cap.serializeNBT()));
    }
}
