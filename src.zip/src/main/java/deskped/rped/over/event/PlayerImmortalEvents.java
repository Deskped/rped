package deskped.rped.over.event;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "rped")
public class PlayerImmortalEvents {

    @SubscribeEvent
    public static void onPlayerDamage(LivingDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (player.level().isClientSide()) return;
        if (!deskped.rped.over.OverGate.isWearing(player)) return;

        DamageSource source = event.getSource();

        if (source.is(DamageTypes.FELL_OUT_OF_WORLD)) return;

        Entity attacker = source.getEntity();
        if (attacker instanceof Player) return;

        Entity directAttacker = source.getDirectEntity();
        if (directAttacker instanceof Player) return;

        if (attacker instanceof Player) return;

        float currentHp = player.getHealth();
        float damage    = event.getAmount();

        if (currentHp - damage <= 0f) {
            event.setAmount(currentHp - 0.5f);
        }
    }
}
