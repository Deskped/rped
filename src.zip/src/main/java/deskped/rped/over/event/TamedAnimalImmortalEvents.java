package deskped.rped.over.event;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.UUID;

@Mod.EventBusSubscriber(modid = "rped")
public class TamedAnimalImmortalEvents {

    @SubscribeEvent
    public static void onTamedDamage(LivingDamageEvent event) {
        if (event.getEntity().level().isClientSide()) return;

        if (!(event.getEntity() instanceof TamableAnimal animal)) return;
        if (!animal.isTame()) return;
        if (!(animal.getOwner() instanceof Player owner)) return;
        if (!deskped.rped.over.OverGate.isWearing(owner)) return;

        DamageSource source = event.getSource();
        Entity attacker       = source.getEntity();
        Entity directAttacker = source.getDirectEntity();

        if (attacker instanceof Player) return;
        if (directAttacker instanceof Player) return;

        float currentHp = animal.getHealth();
        float damage    = event.getAmount();

        if (currentHp - damage <= 0f) {
            event.setAmount(currentHp - 0.5f);
        }
    }
}
