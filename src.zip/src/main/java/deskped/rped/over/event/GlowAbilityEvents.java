package deskped.rped.over.events;

import deskped.rped.over.capability.QuestProgressProvider;
import deskped.rped.over.util.ClockAbilityManager;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;
import java.util.Set;

@Mod.EventBusSubscriber
public class GlowAbilityEvents {

    private static int tickCounter = 0;

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        tickCounter++;
        if (tickCounter % 40 != 0) return;

        for (net.minecraft.server.level.ServerLevel level : event.getServer().getAllLevels()) {
            for (ServerPlayer player : level.players()) {
                if (!deskped.rped.over.OverGate.isWearing(player)) continue;

                player.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap -> {
                    Set<String> active = ClockAbilityManager.getActiveClocks(player);
                    BlockPos pos = player.blockPosition();

                    if (active.contains("holographic_clock")) {
                        List<ItemEntity> drops = level.getEntitiesOfClass(ItemEntity.class,
                            new AABB(pos).inflate(30));
                        for (ItemEntity drop : drops) {
                            drop.setGlowingTag(true);
                        }
                    }

                    if (active.contains("sensor")) {
                        List<Monster> mobs = level.getEntitiesOfClass(Monster.class,
                            new AABB(pos).inflate(20));
                        for (Monster mob : mobs) {
                            mob.addEffect(new MobEffectInstance(MobEffects.GLOWING, 60, 0, false, false));
                        }
                    }

                    if (active.contains("anemometer") && player.isFallFlying()) {
                        player.setDeltaMovement(player.getDeltaMovement().add(
                            player.getLookAngle().scale(0.05)
                        ));
                    }
                });
            }
        }
    }
}
