package deskped.rped.over.event;

import deskped.rped.over.capability.QuestProgressProvider;
import deskped.rped.over.event.QuestTrackingEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class ItemUseQuestEvents {

    @SubscribeEvent
    public static void onMinecartJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getEntity() instanceof AbstractMinecart minecart)) return;

        if (minecart.level() instanceof net.minecraft.server.level.ServerLevel level) {
            for (ServerPlayer player : level.players()) {
                if (player.distanceToSqr(minecart) < 16) {
                    player.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap -> {
                        QuestTrackingEvents.trackPublic(player, cap, "mechanical_crane_scales", 1, 100);
                        QuestTrackingEvents.syncProgress(player, cap);
                    });
                    break;
                }
            }
        }
    }
}
