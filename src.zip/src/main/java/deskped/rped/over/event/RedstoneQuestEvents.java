package deskped.rped.over.event;

import deskped.rped.over.capability.QuestProgressProvider;
import deskped.rped.over.event.QuestTrackingEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class RedstoneQuestEvents {

    @SubscribeEvent
    public static void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        var placed = event.getPlacedBlock();
        if (placed.is(Blocks.REDSTONE_WIRE)
                || placed.is(Blocks.REDSTONE_TORCH)
                || placed.is(Blocks.REDSTONE_WALL_TORCH)
                || placed.is(Blocks.REPEATER)
                || placed.is(Blocks.COMPARATOR)) {
            player.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap -> {
                QuestTrackingEvents.trackPublic(player, cap, "digital_clock", 1, 1000);
                QuestTrackingEvents.syncProgress(player, cap);
            });
        }
    }
}
