package deskped.rped.over.client;

import deskped.rped.over.network.PasswordNetwork;
import deskped.rped.over.network.RunCommandPacket;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE, modid = "rped")
public class ClientCommandScheduler {

    private static final List<DelayedCmd> queue = new ArrayList<>();

    public static void schedule(String command, int delayTicks) {
        queue.add(new DelayedCmd(command, delayTicks));
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Iterator<DelayedCmd> it = queue.iterator();
        while (it.hasNext()) {
            DelayedCmd cmd = it.next();
            cmd.ticks--;
            if (cmd.ticks <= 0) {
                PasswordNetwork.CHANNEL.sendToServer(new RunCommandPacket(cmd.command));
                it.remove();
            }
        }
    }

    private static class DelayedCmd {
        String command;
        int ticks;
        DelayedCmd(String command, int ticks) { this.command = command; this.ticks = ticks; }
    }
}
