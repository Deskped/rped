package deskped.rped.over.client.gui;

// Это технологий CorPED, здесь дизайн/интерфейс менять под другой НЕЛЬЗЯ

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import deskped.rped.over.inventory.WarningMenu;
import deskped.rped.over.network.WarningButtonMessage;
import deskped.rped.over.network.OverNetwork;
import deskped.rped.over.init.OverScreens;
import deskped.rped.RpedMod;

import com.mojang.blaze3d.systems.RenderSystem;

public class WarningScreen extends AbstractContainerScreen<WarningMenu> implements OverScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private Button button_ok;

	public WarningScreen(WarningMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 0;
		this.imageHeight = 0;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(guiGraphics);
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(new ResourceLocation("rped:textures/screens/op_inventory_icon.png"), this.leftPos + -167, this.topPos + -38, 0, 0, 77, 34, 77, 34);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.rped.warning.label_warning1"), -29, -64, -10092544, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.rped.warning.label_warning"), -30, -65, -65536, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.rped.warning.label_the_overped_custom_inventory_is1"), -114, -50, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.rped.warning.label_the_overped_custom_inventory_is"), -115, -51, -1, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.rped.warning.label_this_is_a_hardcore_advanced_pla1"), -129, 4, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.rped.warning.label_this_is_a_hardcore_advanced_pla"), -130, 4, -1, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.rped.warning.label_you_have_access_to_only_9_basic1"), -165, 15, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.rped.warning.label_you_have_access_to_only_9_basic"), -166, 14, -1, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.rped.warning.label_the_slots_you_see_in_the_middle1"), -144, 25, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.rped.warning.label_the_slots_you_see_in_the_middle"), -145, 24, -1, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.rped.warning.label_these_slots_are_unavailable_for1"), -87, -25, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.rped.warning.label_these_slots_are_unavailable_for"), -88, -26, -1, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.rped.warning.label_these_ones_are_available1"), -89, -4, -10092544, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.rped.warning.label_these_ones_are_available"), -90, -5, -65536, false);
	}

	@Override
	public void init() {
		super.init();
		button_ok = Button.builder(Component.translatable("gui.rped.warning.button_ok"), e -> {
			int x = WarningScreen.this.x;
			int y = WarningScreen.this.y;
			if (true) {
				OverNetwork.CHANNEL.sendToServer(new WarningButtonMessage(0, x, y, z));
				WarningButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + -28, this.topPos + 46, 35, 20).build();
		this.addRenderableWidget(button_ok);
	}
}
