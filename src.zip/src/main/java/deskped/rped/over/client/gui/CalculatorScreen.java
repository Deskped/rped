package deskped.rped.over.client.gui;

// Это технологий CorPED, здесь дизайн/интерфейс менять под другой НЕЛЬЗЯ

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public class CalculatorScreen extends Screen {

    private static final int SCREEN_W  = 200;
    private static final int SCREEN_H  = 260;
    private static final int BTN_W     = 36;
    private static final int BTN_H     = 22;
    private static final int BTN_GAP   = 4;

    private String displayMain    = "0";
    private String displaySub     = "";
    private double accumulator    = 0;
    private String pendingOp      = "";
    private boolean freshInput    = true;
    private boolean justEvaluated = false;

    private int  scanlineOffset = 0;
    private long openTime;

    private int guiLeft, guiTop;
    private String titleText;

    private static final String[][] BTN_LAYOUT = {
        { "C", "\u00b1", "%", "\u00f7" },
        { "7", "8", "9", "\u00d7" },
        { "4", "5", "6", "-" },
        { "1", "2", "3", "+" },
        { "0", ".", "\u232b", "=" },
    };

    public CalculatorScreen() {
        super(Component.literal("CALCULATOR"));
        this.openTime = System.currentTimeMillis();
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        this.titleText = lang != null && lang.startsWith("ru") ? "\u041a\u0410\u041b\u042c\u041a\u0423\u041b\u042f\u0422\u041e\u0420" : "CALCULATOR";
    }

    @Override
    protected void init() {
        guiLeft = (this.width  - SCREEN_W) / 2;
        guiTop  = (this.height - SCREEN_H) / 2;

        addRenderableWidget(
            Button.builder(Component.literal("X"), btn -> this.onClose())
                  .pos(guiLeft + SCREEN_W - 18, guiTop + 4)
                  .size(14, 12)
                  .build()
        );

        int gridStartX = guiLeft + 6;
        int gridStartY = guiTop  + 108;

        for (int row = 0; row < BTN_LAYOUT.length; row++) {
            for (int col = 0; col < BTN_LAYOUT[row].length; col++) {
                String label = BTN_LAYOUT[row][col];
                int bx = gridStartX + col * (BTN_W + BTN_GAP);
                int by = gridStartY + row * (BTN_H + BTN_GAP);

                final String capturedLabel = label;
                addRenderableWidget(
                    Button.builder(Component.literal(label), btn -> handleButtonPress(capturedLabel))
                          .pos(bx, by)
                          .size(BTN_W, BTN_H)
                          .build()
                );
            }
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        long now = System.currentTimeMillis();
        scanlineOffset = (int) ((now / 40) % 4);

        renderBackground(g);
        drawPanel(g);
        drawTopBar(g, now);
        drawDisplay(g);
        drawDivider(g);
        drawScanlines(g);
        drawChromaticAberration(g, now);

        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public void renderBackground(GuiGraphics g) {
        g.fill(0, 0, this.width, this.height, 0xE8080808);
    }

    private void drawPanel(GuiGraphics g) {
        int x = guiLeft, y = guiTop, w = SCREEN_W, h = SCREEN_H;

        g.fill(x, y, x + w, y + h, 0xFF111111);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFF161616);

        for (int i = 0; i < w; i += 3) {
            g.fill(x + i, y, x + i + 1, y + h, 0x04FFFFFF);
        }

        g.fill(x,         y,         x + w,     y + 2,     0xFFE0E0E0);
        g.fill(x,         y + h - 2, x + w,     y + h,     0xFFE0E0E0);
        g.fill(x,         y,         x + 2,     y + h,     0xFFE0E0E0);
        g.fill(x + w - 2, y,         x + w,     y + h,     0xFFE0E0E0);

        g.fill(x + 2,     y + 2,     x + w - 2, y + 4,     0x80888888);
        g.fill(x + 2,     y + h - 4, x + w - 2, y + h - 2, 0x80888888);
        g.fill(x + 2,     y + 2,     x + 4,     y + h - 2, 0x40888888);
        g.fill(x + w - 4, y + 2,     x + w - 2, y + h - 2, 0x40888888);
    }

    private void drawTopBar(GuiGraphics g, long now) {
        int x = guiLeft, y = guiTop;

        g.fill(x + 4, y + 6, x + SCREEN_W - 4, y + 22, 0xFF0D0D0D);
        g.fill(x + 4, y + 6, x + SCREEN_W - 4, y + 8,  0xFFCCCCCC);
        g.fill(x + 4, y + 20, x + SCREEN_W - 4, y + 22, 0xFFCCCCCC);
        g.fill(x + 4, y + 8,  x + 6,            y + 20, 0xFF888888);
        g.fill(x + SCREEN_W - 6, y + 8, x + SCREEN_W - 4, y + 20, 0xFF888888);

        g.drawString(font, Component.literal(titleText), x + 10, y + 12, 0xFFFFFFFF, false);

        long elapsed = (now - openTime) / 600;
        String rec = (elapsed % 2 == 0) ? "\u25cf" : " ";
        g.drawString(font, Component.literal(rec), x + SCREEN_W - 22, y + 12, 0xFFDDDDDD, false);

        g.fill(x + 4, y + 24, x + SCREEN_W - 4, y + 25, 0xFF555555);
    }

    private void drawDisplay(GuiGraphics g) {
        int x  = guiLeft + 4;
        int y  = guiTop + 28;
        int w  = SCREEN_W - 8;
        int h  = 72;

        g.fill(x,         y,         x + w,     y + h,     0xFF0A0A0A);
        g.fill(x,         y,         x + w,     y + 1,     0xFFCCCCCC);
        g.fill(x,         y + h - 1, x + w,     y + h,     0xFFCCCCCC);
        g.fill(x,         y,         x + 1,     y + h,     0xFF888888);
        g.fill(x + w - 1, y,         x + w,     y + h,     0xFF888888);

        if (!displaySub.isEmpty()) {
            String sub = displaySub;
            int maxW = w - 12;
            while (font.width(sub) > maxW && sub.length() > 1) {
                sub = sub.substring(1);
            }
            g.drawString(font, Component.literal(sub), x + w - font.width(sub) - 6, y + 8, 0xFF666666, false);
        }

        String main = clampDisplayString(displayMain, w - 12);
        int mainX = x + w - font.width(main) - 6;
        int mainY = y + h - 22;

        g.drawString(font, Component.literal(main), mainX + 1, mainY + 1, 0x44FFFFFF, false);
        g.drawString(font, Component.literal(main), mainX, mainY, 0xFFFFFFFF, false);

        if (!pendingOp.isEmpty()) {
            g.drawString(font, Component.literal(pendingOp), x + 5, mainY, 0xFF888888, false);
        }
    }

    private String clampDisplayString(String s, int maxWidth) {
        while (font.width(s) > maxWidth && s.length() > 1) {
            s = s.substring(1);
        }
        return s;
    }

    private void drawDivider(GuiGraphics g) {
        int y = guiTop + 104;
        g.fill(guiLeft + 4, y,     guiLeft + SCREEN_W - 4, y + 1, 0xFF444444);
        g.fill(guiLeft + 4, y + 2, guiLeft + SCREEN_W - 4, y + 3, 0xFF222222);
    }

    private void drawScanlines(GuiGraphics g) {
        int x = guiLeft, y = guiTop, w = SCREEN_W, h = SCREEN_H;
        for (int row = scanlineOffset; row < h; row += 4) {
            g.fill(x + 2, y + row, x + w - 2, y + row + 1, 0x12000000);
        }
    }

    private void drawChromaticAberration(GuiGraphics g, long now) {
        int x = guiLeft, y = guiTop, w = SCREEN_W, h = SCREEN_H;

        long seed = now / 3000;
        java.util.Random rng = new java.util.Random(seed);

        if (rng.nextInt(3) != 0) return;

        int glitchLines = rng.nextInt(3) + 1;
        for (int gl = 0; gl < glitchLines; gl++) {
            int gy    = y + rng.nextInt(h);
            int gh    = rng.nextInt(3) + 1;
            int shift = rng.nextInt(5) - 2;

            g.fill(x + shift + 2,  gy, x + w + shift - 2,  gy + gh, 0x18FF0000);
            g.fill(x - shift + 2,  gy, x + w - shift - 2,  gy + gh, 0x180000FF);
            g.fill(x + 2,          gy, x + w - 2,           gy + gh, 0x10FFFFFF);
        }

        if (rng.nextInt(5) == 0) {
            int ny = y + (int) ((seed * 37) % h);
            g.fill(x + 2, ny,     x + w - 2, ny + 2, 0x20FFFFFF);
            g.fill(x + 2, ny + 1, x + w - 2, ny + 2, 0x08FFFFFF);
        }
    }

    private void handleButtonPress(String label) {
        switch (label) {
            case "C" -> {
                displayMain    = "0";
                displaySub     = "";
                accumulator    = 0;
                pendingOp      = "";
                freshInput     = true;
                justEvaluated  = false;
            }
            case "\u00b1" -> {
                if (!displayMain.equals("0")) {
                    if (displayMain.startsWith("-"))
                        displayMain = displayMain.substring(1);
                    else
                        displayMain = "-" + displayMain;
                }
            }
            case "%" -> {
                try {
                    double val = Double.parseDouble(displayMain) / 100.0;
                    displayMain = formatResult(val);
                    freshInput  = true;
                } catch (NumberFormatException ignored) {}
            }
            case "\u232b" -> {
                if (!freshInput && displayMain.length() > 1) {
                    displayMain = displayMain.substring(0, displayMain.length() - 1);
                    if (displayMain.equals("-")) displayMain = "0";
                } else {
                    displayMain = "0";
                    freshInput  = true;
                }
            }
            case "." -> {
                if (freshInput) {
                    displayMain = "0.";
                    freshInput  = false;
                } else if (!displayMain.contains(".")) {
                    displayMain = displayMain + ".";
                }
            }
            case "+", "-", "\u00d7", "\u00f7" -> {
                commitPendingOp();
                pendingOp  = label;
                displaySub = formatResult(accumulator) + " " + label;
                freshInput = true;
                justEvaluated = false;
            }
            case "=" -> {
                if (!pendingOp.isEmpty()) {
                    double rhs = parseDisplay();
                    displaySub    = formatResult(accumulator) + " " + pendingOp + " " + formatResult(rhs) + " =";
                    accumulator   = applyOp(pendingOp, accumulator, rhs);
                    displayMain   = formatResult(accumulator);
                    pendingOp     = "";
                    freshInput    = true;
                    justEvaluated = true;
                }
            }
            default -> {
                if (freshInput) {
                    displayMain = label;
                    freshInput  = false;
                } else {
                    if (displayMain.equals("0") && !label.equals("."))
                        displayMain = label;
                    else
                        displayMain = displayMain + label;
                }
                if (justEvaluated) { justEvaluated = false; displaySub = ""; }
            }
        }
    }

    private void commitPendingOp() {
        double rhs = parseDisplay();
        if (pendingOp.isEmpty()) {
            accumulator = rhs;
        } else {
            accumulator = applyOp(pendingOp, accumulator, rhs);
        }
        displayMain = formatResult(accumulator);
    }

    private double applyOp(String op, double a, double b) {
        return switch (op) {
            case "+"        -> a + b;
            case "-"        -> a - b;
            case "\u00d7"   -> a * b;
            case "\u00f7"   -> (b == 0) ? Double.NaN : a / b;
            default         -> b;
        };
    }

    private double parseDisplay() {
        try { return Double.parseDouble(displayMain); }
        catch (NumberFormatException e) { return 0; }
    }

    private String formatResult(double v) {
        if (Double.isNaN(v))      return "ERR";
        if (Double.isInfinite(v)) return v > 0 ? "\u221e" : "-\u221e";
        if (v == Math.floor(v) && !Double.isInfinite(v) && Math.abs(v) < 1e15)
            return String.valueOf((long) v);
        String s = String.format("%.10g", v);
        if (s.contains(".") && !s.contains("e")) {
            s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
        }
        return s;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        switch (keyCode) {
            case GLFW.GLFW_KEY_ESCAPE      -> { this.onClose(); return true; }
            case GLFW.GLFW_KEY_ENTER,
                 GLFW.GLFW_KEY_KP_ENTER   -> { handleButtonPress("="); return true; }
            case GLFW.GLFW_KEY_BACKSPACE   -> { handleButtonPress("\u232b"); return true; }
            case GLFW.GLFW_KEY_DELETE      -> { handleButtonPress("C"); return true; }
            case GLFW.GLFW_KEY_KP_ADD      -> { handleButtonPress("+"); return true; }
            case GLFW.GLFW_KEY_KP_SUBTRACT -> { handleButtonPress("-"); return true; }
            case GLFW.GLFW_KEY_KP_MULTIPLY -> { handleButtonPress("\u00d7"); return true; }
            case GLFW.GLFW_KEY_KP_DIVIDE   -> { handleButtonPress("\u00f7"); return true; }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char c, int modifiers) {
        if (c >= '0' && c <= '9') { handleButtonPress(String.valueOf(c)); return true; }
        return switch (c) {
            case '.' -> { handleButtonPress("."); yield true; }
            case '+' -> { handleButtonPress("+"); yield true; }
            case '-' -> { handleButtonPress("-"); yield true; }
            case '*' -> { handleButtonPress("\u00d7"); yield true; }
            case '/' -> { handleButtonPress("\u00f7"); yield true; }
            case '%' -> { handleButtonPress("%"); yield true; }
            case '=' -> { handleButtonPress("="); yield true; }
            default  -> super.charTyped(c, modifiers);
        };
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
