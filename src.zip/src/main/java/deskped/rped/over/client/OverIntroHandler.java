package deskped.rped.over.client;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import net.minecraft.client.Minecraft;

import deskped.rped.over.intro.IntroScreen;

@OnlyIn(Dist.CLIENT)
public class OverIntroHandler {
	public static void open() {
		Minecraft mc = Minecraft.getInstance();
		if (mc != null)
			mc.execute(() -> mc.setScreen(new IntroScreen(null)));
	}
}
