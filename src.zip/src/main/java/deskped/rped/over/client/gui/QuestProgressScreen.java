package deskped.rped.over.client.gui;

// Это технологий CorPED, здесь дизайн/интерфейс менять под другой НЕЛЬЗЯ

import com.mojang.blaze3d.systems.RenderSystem;
import deskped.rped.over.quest.ClockQuestData;
import deskped.rped.over.util.L10n;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class QuestProgressScreen extends Screen {

    private static final int ENTRIES_PER_PAGE = 5;
    private static final int SCREEN_W = 340;
    private static final int SCREEN_H = 248;
    private static final int ICON_SIZE = 16;

    private static final Map<String, ResourceLocation> CLOCK_ICONS = new HashMap<>();

    static {
        String[] ids = {
            "alarm_clock", "anemometer", "angel_clock", "aqua_clock",
            "attitude_indicator", "chess_clock", "childhood_clock",
            "seven_curses", "compass_clock", "demon_clock",
            "digital_clock", "dont_forget_clock", "fallen_clock", "glass_clock",
            "halographic", "hourglass", "im_old_clock",
            "its_time_to_have_some_clock", "mechanical_crane_scales", "meter",
            "ok_clock", "paper_clock", "radio", "residence_clock", "scroll_clock",
            "sensor", "ships_clock", "stopwatch", "sundial",
            "sun_on_a_stick_with_a_clock", "totem_clock", "wall_clock", "wristwatch"
        };
        for (String id : ids) {
            CLOCK_ICONS.put(id, ResourceLocation.tryParse("rped:textures/gui/" + id + ".png"));
        }
        CLOCK_ICONS.put("clock_of_seven_curses", ResourceLocation.tryParse("rped:textures/gui/seven_curses.png"));
        CLOCK_ICONS.put("holographic_clock", ResourceLocation.tryParse("rped:textures/gui/halographic.png"));
    }

    private final String targetPlayerName;
    private final CompoundTag progressData;
    private final List<ClockQuestData.ClockQuest> quests;
    private int currentPage = 0;
    private int totalPages;
    private int guiLeft, guiTop;
    private long openTime;
    private int scanlineOffset = 0;

    public QuestProgressScreen(String targetPlayerName, CompoundTag progressData) {
        super(Component.literal(L10n.Gui.screenTitle()));
        this.targetPlayerName = targetPlayerName;
        this.progressData = progressData;
        this.quests = ClockQuestData.getAllQuests();
        this.totalPages = (int) Math.ceil(quests.size() / (double) ENTRIES_PER_PAGE);
        this.openTime = System.currentTimeMillis();
    }

    @Override
    protected void init() {
        guiLeft = (this.width - SCREEN_W) / 2;
        guiTop = (this.height - SCREEN_H) / 2;

        addRenderableWidget(Button.builder(Component.literal(L10n.Gui.btnBack()), btn -> {
            if (currentPage > 0) currentPage--;
        }).pos(guiLeft + 222, guiTop + 218).size(22, 14).build());

        addRenderableWidget(Button.builder(Component.literal(L10n.Gui.btnNext()), btn -> {
            if (currentPage < totalPages - 1) currentPage++;
        }).pos(guiLeft + 250, guiTop + 218).size(22, 14).build());

        addRenderableWidget(Button.builder(Component.literal(L10n.Gui.btnClose()), btn ->
            this.onClose()
        ).pos(guiLeft + SCREEN_W - 18, guiTop + 4).size(14, 12).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        long now = System.currentTimeMillis();
        scanlineOffset = (int) ((now / 40) % 4);

        renderBackground(g);
        drawPanel(g);
        drawTopBar(g, now);
        drawQuestEntries(g, mouseX, mouseY);
        drawBottomBar(g);
        drawScanlines(g);
        drawChromaticAberration(g, now);
        drawCooldownOverlay(g);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public void renderBackground(GuiGraphics g) {
        g.fill(0, 0, this.width, this.height, 0xE8080808);
    }

    private void drawPanel(GuiGraphics g) {
        int x = guiLeft, y = guiTop, w = SCREEN_W, h = SCREEN_H;

        g.fill(x, y, x + w, y + h, 0xFF111111);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFF161616);

        for (int i = 0; i < w; i += 3) {
            g.fill(x + i, y, x + i + 1, y + h, 0x04FFFFFF);
        }

        g.fill(x, y, x + w, y + 2, 0xFFE0E0E0);
        g.fill(x, y + h - 2, x + w, y + h, 0xFFE0E0E0);
        g.fill(x, y, x + 2, y + h, 0xFFE0E0E0);
        g.fill(x + w - 2, y, x + w, y + h, 0xFFE0E0E0);

        g.fill(x + 2, y + 2, x + w - 2, y + 4, 0x80888888);
        g.fill(x + 2, y + h - 4, x + w - 2, y + h - 2, 0x80888888);
        g.fill(x + 2, y + 2, x + 4, y + h - 2, 0x40888888);
        g.fill(x + w - 4, y + 2, x + w - 2, y + h - 2, 0x40888888);
    }

    private void drawTopBar(GuiGraphics g, long now) {
        int x = guiLeft, y = guiTop;

        g.fill(x + 4, y + 6, x + SCREEN_W - 4, y + 28, 0xFF0D0D0D);
        g.fill(x + 4, y + 6, x + SCREEN_W - 4, y + 8, 0xFFCCCCCC);
        g.fill(x + 4, y + 26, x + SCREEN_W - 4, y + 28, 0xFFCCCCCC);
        g.fill(x + 4, y + 8, x + 6, y + 26, 0xFF888888);
        g.fill(x + SCREEN_W - 6, y + 8, x + SCREEN_W - 4, y + 26, 0xFF888888);

        g.drawString(font, Component.literal(L10n.Gui.title()), x + 12, y + 12, 0xFFFFFFFF, false);

        long elapsed = (System.currentTimeMillis() - openTime) / 600;
        String rec = (elapsed % 2 == 0) ? "\u25cf REC" : "  REC";
        g.drawString(font, Component.literal(rec), x + SCREEN_W - 56, y + 12, 0xFFDDDDDD, false);

        g.fill(x + 4, y + 30, x + SCREEN_W - 4, y + 31, 0xFF555555);

        String playerStr = L10n.Gui.player() + targetPlayerName.toUpperCase();
        g.drawString(font, Component.literal(playerStr), x + 8, y + 34, 0xFFCCCCCC, false);

        String pageStr = L10n.Gui.page() + (currentPage + 1) + " / " + totalPages;
        int pw = font.width(pageStr);
        g.drawString(font, Component.literal(pageStr), x + SCREEN_W - pw - 8, y + 34, 0xFFAAAAAA, false);

        g.fill(x + 4, y + 44, x + SCREEN_W - 4, y + 45, 0xFF444444);
    }

    private void drawQuestEntries(GuiGraphics g, int mouseX, int mouseY) {
        int startIdx = currentPage * ENTRIES_PER_PAGE;
        int endIdx = Math.min(startIdx + ENTRIES_PER_PAGE, quests.size());
        int entryY = guiTop + 49;

        CompoundTag progressTag = progressData.contains("progress")
                ? progressData.getCompound("progress") : new CompoundTag();
        CompoundTag completionsTag = progressData.contains("completions")
                ? progressData.getCompound("completions") : new CompoundTag();

        Set<String> completedSet = new HashSet<>();
        for (String k : completionsTag.getAllKeys()) {
            if (completionsTag.getInt(k) > 0) completedSet.add(k);
        }

        for (int i = startIdx; i < endIdx; i++) {
            ClockQuestData.ClockQuest quest = quests.get(i);
            boolean completed = completedSet.contains(quest.clockId());
            int progress = progressTag.getInt(quest.clockId());
            int required = quest.requiredCount();
            float pct = Math.min(1.0f, progress / (float) required);

            boolean hovered = mouseX >= guiLeft + 6 && mouseX <= guiLeft + SCREEN_W - 6
                    && mouseY >= entryY && mouseY <= entryY + 33;

            int rowBg = completed ? 0xFF1A1A1A : (hovered ? 0xFF1E1E1E : 0xFF131313);
            g.fill(guiLeft + 6, entryY, guiLeft + SCREEN_W - 6, entryY + 33, rowBg);

            int topLine = completed ? 0xFFCCCCCC : 0xFF444444;
            g.fill(guiLeft + 6, entryY, guiLeft + SCREEN_W - 6, entryY + 1, topLine);

            ResourceLocation icon = CLOCK_ICONS.get(quest.clockId());
            if (icon != null) {
                RenderSystem.setShaderTexture(0, icon);
                g.blit(icon, guiLeft + 10, entryY + 8, 0, 0, ICON_SIZE, ICON_SIZE, ICON_SIZE, ICON_SIZE);
            }

            int nameColor = completed ? 0xFFFFFFFF : 0xFFCCCCCC;
            String displayName = L10n.Quest.name(quest.clockId(), quest.displayName());
            if (font.width(displayName) > 200) {
                while (font.width(displayName + "..") > 200 && displayName.length() > 2)
                    displayName = displayName.substring(0, displayName.length() - 1);
                displayName = displayName + "..";
            }
            g.drawString(font, Component.literal(displayName), guiLeft + 32, entryY + 5, nameColor, false);

            String statusStr;
            if (completed) {
                statusStr = "\u2713 " + L10n.Gui.complete();
            } else {
                statusStr = L10n.Quest.desc(quest.clockId(), quest.questDescription());
                while (font.width(statusStr) > 220 && statusStr.length() > 2)
                    statusStr = statusStr.substring(0, statusStr.length() - 1);
                if (statusStr.length() < L10n.Quest.desc(quest.clockId(), quest.questDescription()).length())
                    statusStr += "..";
            }
            int statusColor = completed ? 0xFFAAAAAA : 0xFF777777;
            g.drawString(font, Component.literal(statusStr), guiLeft + 32, entryY + 16, statusColor, false);

            int barX = guiLeft + 32;
            int barY = entryY + 26;
            int barW = SCREEN_W - 80;
            int barH = 3;

            g.fill(barX, barY, barX + barW, barY + barH, 0xFF222222);
            g.fill(barX, barY, barX + 1, barY + barH, 0xFF666666);
            g.fill(barX + barW - 1, barY, barX + barW, barY + barH, 0xFF666666);

            int filledW = (int) ((barW - 2) * pct);
            if (filledW > 0) {
                int barFill = completed ? 0xFFEEEEEE : 0xFF888888;
                g.fill(barX + 1, barY, barX + 1 + filledW, barY + barH, barFill);
                if (!completed && filledW > 2) {
                    g.fill(barX + 1, barY, barX + 1 + filledW, barY + 1, 0x40FFFFFF);
                }
            }

            String countStr = progress + " / " + required;
            int cw = font.width(countStr);
            g.drawString(font, Component.literal(countStr),
                    guiLeft + SCREEN_W - cw - 10, entryY + 24, 0xFF666666, false);

            entryY += 37;
        }
    }

    private void drawBottomBar(GuiGraphics g) {
        int y = guiTop + SCREEN_H - 24;
        g.fill(guiLeft + 4, y, guiLeft + SCREEN_W - 4, y + 1, 0xFF444444);
        String pageStr = L10n.Gui.pageBottom() + (currentPage + 1);
        g.drawString(font, Component.literal(pageStr), guiLeft + 10, y + 6, 0xFF888888, false);
    }

    private void drawScanlines(GuiGraphics g) {
        int x = guiLeft, y = guiTop, w = SCREEN_W, h = SCREEN_H;
        for (int row = scanlineOffset; row < h; row += 4) {
            g.fill(x + 2, y + row, x + w - 2, y + row + 1, 0x12000000);
        }
    }

    private void drawChromaticAberration(GuiGraphics g, long now) {
        int x = guiLeft, y = guiTop, w = SCREEN_W, h = SCREEN_H;

        long seed = now / 3000;
        java.util.Random rng = new java.util.Random(seed);

        if (rng.nextInt(3) != 0) return;

        int glitchLines = rng.nextInt(3) + 1;
        for (int gl = 0; gl < glitchLines; gl++) {
            int gy = y + rng.nextInt(h);
            int gh = rng.nextInt(3) + 1;
            int shift = rng.nextInt(5) - 2;

            g.fill(x + shift + 2, gy, x + w + shift - 2, gy + gh, 0x18FF0000);
            g.fill(x - shift + 2, gy, x + w - shift - 2, gy + gh, 0x180000FF);
            g.fill(x + 2, gy, x + w - 2, gy + gh, 0x10FFFFFF);
        }

        if (rng.nextInt(5) == 0) {
            int ny = y + (int) ((seed * 37) % h);
            g.fill(x + 2, ny, x + w - 2, ny + 2, 0x20FFFFFF);
            g.fill(x + 2, ny + 1, x + w - 2, ny + 2, 0x08FFFFFF);
        }
    }

    private void drawCooldownOverlay(GuiGraphics g) {
        long lastAward = progressData.contains("lastClockAwardTime") ? progressData.getLong("lastClockAwardTime") : 0L;
        long gameTime = minecraft.level != null ? minecraft.level.getGameTime() : 0L;
        long cooldown = 20 * 60 * 10;
        long remaining = cooldown - (gameTime - lastAward);

        if (remaining <= 0) return;

        g.fill(0, 0, this.width, this.height, 0xD0000000);

        int barWidth = 300;
        int barHeight = 20;
        int barX = (this.width - barWidth) / 2;
        int barY = (this.height - barHeight) / 2;

        float progress = 1.0f - ((float) remaining / (float) cooldown);
        int fillWidth = (int) (barWidth * progress);

        g.fill(barX - 2, barY - 2, barX + barWidth + 2, barY + barHeight + 2, 0xFF444444);
        g.fill(barX, barY, barX + barWidth, barY + barHeight, 0xFF222222);
        g.fill(barX, barY, barX + fillWidth, barY + barHeight, 0xFF00AA00);

        int minutes = (int)(remaining / 20 / 60);
        int seconds = (int)((remaining / 20) % 60);
        String timeText = String.format("%02d:%02d", minutes, seconds);
        int timeWidth = font.width(timeText);
        g.drawString(font, Component.literal(timeText), barX + (barWidth - timeWidth) / 2, barY + 5, 0xFFFFFFFF, false);

        String message = L10n.Gui.cooldownWait();
        int msgWidth = font.width(message);
        g.drawString(font, Component.literal(message), (this.width - msgWidth) / 2, barY - 20, 0xFFFFFFFF, false);
    }

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) { this.onClose(); return true; }
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT && currentPage > 0) { currentPage--; return true; }
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT && currentPage < totalPages - 1) { currentPage++; return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
