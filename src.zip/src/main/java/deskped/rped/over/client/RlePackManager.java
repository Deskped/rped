package deskped.rped.over.client;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.event.AddPackFindersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.forgespi.locating.IModFile;
import net.minecraftforge.event.TickEvent;

import net.minecraft.client.Minecraft;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.PathPackResources;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.repository.PackSource;
import net.minecraft.server.packs.repository.PackRepository;
import net.minecraft.network.chat.Component;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class RlePackManager {

	public static final String PACK_ID = "overped";

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	@OnlyIn(Dist.CLIENT)
	public static class PackRegistration {
		@SubscribeEvent
		public static void addPackFinders(AddPackFindersEvent event) {
			if (event.getPackType() != PackType.CLIENT_RESOURCES)
				return;
			IModFile modFile = ModList.get().getModFileById("rped").getFile();
			final Path root = modFile.findResource("resourcepacks", "overped");
			Pack pack = Pack.readMetaAndCreate(
				PACK_ID,
				Component.literal("OverPED"),
				false,
				id -> new PathPackResources(id, root, false),
				PackType.CLIENT_RESOURCES,
				Pack.Position.TOP,
				PackSource.BUILT_IN);
			if (pack != null)
				event.addRepositorySource(consumer -> consumer.accept(pack));
		}
	}

	@Mod.EventBusSubscriber(modid = "rped", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
	@OnlyIn(Dist.CLIENT)
	public static class PackToggle {
		private static Boolean lastState = null;

		@SubscribeEvent
		public static void onClientTick(TickEvent.ClientTickEvent event) {
			if (event.phase != TickEvent.Phase.END)
				return;
			Minecraft mc = Minecraft.getInstance();
			if (mc.player == null) {
				lastState = null;
				return;
			}
			if (mc.player.tickCount % 10 != 0)
				return;
			boolean wearing = deskped.rped.over.OverGate.isWearing(mc.player);
			if (lastState != null && lastState == wearing)
				return;
			lastState = wearing;
			apply(mc, wearing);
		}

		private static void apply(Minecraft mc, boolean enable) {
			PackRepository repo = mc.getResourcePackRepository();
			List<String> selected = new ArrayList<>(repo.getSelectedIds());
			boolean present = selected.contains(PACK_ID);
			if (enable && !present) {
				selected.add(0, PACK_ID);
			} else if (!enable && present) {
				selected.remove(PACK_ID);
			} else {
				return;
			}
			mc.options.resourcePacks.clear();
			for (String id : selected) {
				if (!"vanilla".equals(id))
					mc.options.resourcePacks.add(id);
			}
			repo.setSelected(selected);
			mc.options.save();
			mc.reloadResourcePacks();
		}
	}
}
