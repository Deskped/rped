package deskped.rped.over.client;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;

import deskped.rped.over.OverGate;

@Mod.EventBusSubscriber(modid = "rped", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
@OnlyIn(Dist.CLIENT)
public class OverHud {

	@SubscribeEvent
	public static void onHealthPre(RenderGuiOverlayEvent.Pre event) {
		if (event.getOverlay() != VanillaGuiOverlay.PLAYER_HEALTH.type())
			return;
		Minecraft mc = Minecraft.getInstance();
		Player player = mc.player;
		if (player == null)
			return;
		if (!OverGate.isWearing(player))
			return;
		event.setCanceled(true);
		renderCenteredHealth(event.getGuiGraphics());
	}

	private static void renderCenteredHealth(GuiGraphics graphics) {
		Minecraft mc = Minecraft.getInstance();
		Player player = mc.player;
		if (player == null)
			return;
		if (player.isCreative() || player.isSpectator())
			return;

		int screenWidth = mc.getWindow().getGuiScaledWidth();
		int screenHeight = mc.getWindow().getGuiScaledHeight();

		int hotbarWidth = 182;
		int hotbarLeft = (screenWidth - hotbarWidth) / 2;
		int healthY = screenHeight - 39 + 5;

		int maxHealth = (int) Math.ceil(player.getMaxHealth());
		int currentHealth = (int) Math.ceil(player.getHealth());

		int heartsPerRow = 10;
		int heartStep = 8;
		int heartSize = 9;

		int totalHearts = (int) Math.ceil(maxHealth / 2.0f);

		int rowWidth = Math.min(totalHearts, heartsPerRow) * heartStep + (heartSize - heartStep);
		int startX = hotbarLeft + (hotbarWidth - rowWidth) / 2;

		final int ICONS_U_EMPTY = 16;
		final int ICONS_U_FULL = 52;
		final int ICONS_U_HALF = 61;
		final int ICONS_V = 0;

		ResourceLocation icons = new ResourceLocation("minecraft", "textures/gui/icons.png");

		for (int i = 0; i < totalHearts; i++) {
			int row = i / heartsPerRow;
			int col = i % heartsPerRow;

			int hx = startX + col * heartStep;
			int hy = healthY - row * (heartSize + 1);

			graphics.blit(icons, hx, hy, ICONS_U_EMPTY, ICONS_V, heartSize, heartSize);

			int hp = currentHealth - i * 2;
			if (hp >= 2) {
				graphics.blit(icons, hx, hy, ICONS_U_FULL, ICONS_V, heartSize, heartSize);
			} else if (hp == 1) {
				graphics.blit(icons, hx, hy, ICONS_U_HALF, ICONS_V, heartSize, heartSize);
			}
		}
	}
}
