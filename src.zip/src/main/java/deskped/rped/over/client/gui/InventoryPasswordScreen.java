package deskped.rped.over.client.gui;

// Это технологий CorPED, здесь дизайн/интерфейс менять под другой НЕЛЬЗЯ

import deskped.rped.DialogClient;
import deskped.rped.over.client.ClientCommandScheduler;
import deskped.rped.over.network.PasswordActionPacket;
import deskped.rped.over.network.PasswordNetwork;
import deskped.rped.over.network.RunCommandPacket;
import net.minecraft.CrashReport;
import net.minecraft.ReportedException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.OptionsScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class InventoryPasswordScreen extends Screen {

    private static final int PANEL_W = 170;
    private static final int PANEL_H = 240;
    private static final int CP_W = 480;
    private static final int CP_H = 320;

    private static final int STATE_KEYPAD          = 0;
    private static final int STATE_CONTROL_PANEL   = 1;
    private static final int STATE_EXTRACT_CONFIRM = 2;
    private static final int STATE_SHUTDOWN_KEYPAD = 3;
    private static final int STATE_ACCESS_UPGRADE  = 4;
    private static final int STATE_SEARCH          = 5;
    private static final int STATE_SEARCH_USERS    = 6;
    private static final int STATE_TELEPORT        = 7;
    private static final int STATE_TELEPORT_WORLD  = 8;
    private static final int STATE_TELEPORT_COORDS = 9;
    private static final int STATE_ACCESS_WAITING    = 10;
    private static final int STATE_IMMORTAL_DISABLE  = 11;

    public static volatile Boolean immortalState = null;
    private String immortalDisableInput = "";

    private int    state = STATE_KEYPAD;
    private String input = "";
    private final long openTime = System.currentTimeMillis();
    private int    scanlineOffset = 0;
    private long   lastScanlineUpdate = 0;
    private int    guiLeft, guiTop;
    private final  Screen parent;

    private Button reprogramBtn;
    private double reprogramX, reprogramY;
    private double reprogramVX = 0, reprogramVY = 0;

    private int  slideshowFrame = 0;
    private long lastFrameTime  = 0;

    private static long teleportCooldownUntil = 0;

    private static final int GRAPH_POINTS = 40;
    private final float[] heartbeatData = new float[GRAPH_POINTS];
    private final float[] tempData      = new float[GRAPH_POINTS];
    private final float[] pressureData  = new float[GRAPH_POINTS];
    private final float[] activityData  = new float[GRAPH_POINTS];
    private long lastGraphUpdate = 0;
    private int  graphTick = 0;

    private String  shutdownInput = "";
    private String  accessInput   = "";
    private String  teleportInput = "";
    private EditBox teleportBox;

    public InventoryPasswordScreen(Screen parent) {
        super(Component.literal("PASSWORD"));
        this.parent = parent;
        Random r = new Random();
        for (int i = 0; i < GRAPH_POINTS; i++) {
            heartbeatData[i] = r.nextFloat();
            tempData[i]      = 0.4f + r.nextFloat() * 0.2f;
            pressureData[i]  = 0.3f + r.nextFloat() * 0.4f;
            activityData[i]  = r.nextFloat();
        }
    }

    @Override
    protected void init() {
        recalcPositions();
        buildWidgets();
    }

    private void recalcPositions() {
        if (state == STATE_CONTROL_PANEL) {
            guiLeft = (this.width  - CP_W) / 2;
            guiTop  = (this.height - CP_H) / 2;
        } else {
            guiLeft = (this.width  - PANEL_W) / 2;
            guiTop  = (this.height - PANEL_H) / 2;
        }
    }

    public void refreshImmortalButton() { buildWidgets(); }

    private void buildWidgets() {
        clearWidgets();
        recalcPositions();
        switch (state) {
            case STATE_KEYPAD          -> buildKeypadWidgets(8, false, false);
            case STATE_CONTROL_PANEL   -> buildControlPanel();
            case STATE_EXTRACT_CONFIRM -> buildExtractConfirm();
            case STATE_SHUTDOWN_KEYPAD -> { shutdownInput = ""; buildKeypadWidgets(6, true, false); }
            case STATE_ACCESS_UPGRADE  -> { accessInput   = ""; buildKeypadWidgets(3, false, true); }
            case STATE_ACCESS_WAITING  -> buildAccessWaiting();
            case STATE_IMMORTAL_DISABLE -> { immortalDisableInput = ""; buildKeypadWidgets(6, false, false, true); }
            case STATE_SEARCH          -> buildSearch();
            case STATE_SEARCH_USERS    -> buildSearchUsers();
            case STATE_TELEPORT        -> buildTeleport();
            case STATE_TELEPORT_WORLD  -> buildTeleportWorld();
            case STATE_TELEPORT_COORDS -> buildTeleportCoords();
        }
    }

    private void buildKeypadWidgets(int maxLen, boolean isShutdown, boolean isAccess) {
        buildKeypadWidgets(maxLen, isShutdown, isAccess, false);
    }

    private void buildKeypadWidgets(int maxLen, boolean isShutdown, boolean isAccess, boolean isImmortalDisable) {
        int bw = 30, bh = 18, gap = 3;
        int startX = guiLeft + (PANEL_W - (3 * bw + 2 * gap)) / 2;
        int startY = guiTop + 100;
        int[] nums = {7, 8, 9, 4, 5, 6, 1, 2, 3};
        for (int i = 0; i < 9; i++) {
            int col = i % 3, row = i / 3, n = nums[i];
            int bx = startX + col * (bw + gap), by = startY + row * (bh + gap);
            addRenderableWidget(Button.builder(Component.literal(String.valueOf(n)), btn -> {
                if (isShutdown)          { if (shutdownInput.length()       < maxLen) shutdownInput       += n; }
                else if (isAccess)       { if (accessInput.length()         < maxLen) accessInput         += n; }
                else if (isImmortalDisable) { if (immortalDisableInput.length() < maxLen) immortalDisableInput += n; }
                else                     { if (input.length()               < maxLen) input               += n; }
            }).pos(bx, by).size(bw, bh).build());
        }
        int bottomY = startY + 3 * (bh + gap);
        addRenderableWidget(Button.builder(Component.literal("C"), btn -> {
            if (isShutdown) shutdownInput = "";
            else if (isAccess) accessInput = "";
            else if (isImmortalDisable) immortalDisableInput = "";
            else input = "";
        }).pos(startX, bottomY).size(bw, bh).build());
        addRenderableWidget(Button.builder(Component.literal("0"), btn -> {
            if (isShutdown)          { if (shutdownInput.length()       < maxLen) shutdownInput       += "0"; }
            else if (isAccess)       { if (accessInput.length()         < maxLen) accessInput         += "0"; }
            else if (isImmortalDisable) { if (immortalDisableInput.length() < maxLen) immortalDisableInput += "0"; }
            else                     { if (input.length()               < maxLen) input               += "0"; }
        }).pos(startX + bw + gap, bottomY).size(bw, bh).build());
        addRenderableWidget(Button.builder(Component.literal("\u23ce"), btn -> {
            if (isShutdown) handleShutdownEnter();
            else if (isAccess) handleAccessUpgradeEnter();
            else if (isImmortalDisable) handleImmortalDisableEnter();
            else handleEnter();
        }).pos(startX + 2 * (bw + gap), bottomY).size(bw, bh).build());
    }

    private void buildControlPanel() {
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        int bw = 68, bh = 16, gap = 4;
        int totalRowW = 6 * bw + 5 * gap;
        int rowStartX = guiLeft + (CP_W - totalRowW) / 2;
        int row1Y = guiTop + CP_H - 46;
        int row2Y = guiTop + CP_H - 26;
        String[] labels1 = {
            ru ? "\u0418\u0437\u044a\u044f\u0442\u044c"          : "Extract",
            ru ? "\u041e\u0442\u043a\u043b\u044e\u0447\u0438\u0442\u044c"       : "Disable",
            ru ? "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"       : "Settings",
            ru ? "\u0414\u0440\u0443\u0433\u0438\u0435 \u043c\u0438\u0440\u044b"     : "Other worlds",
            ru ? "\u041f\u043e\u0432\u044b\u0441\u0438\u0442\u044c \u0434\u043e\u0441\u0442\u0443\u043f" : "Upgrade access",
            ru ? "\u041d\u0430\u0437\u0430\u0434"           : "Back"
        };
        String immortalLabel = immortalState == null ? "..."
            : (immortalState ? (ru ? "\u0411\u0435\u0441\u0441\u043c.: \u0412\u041a\u041b" : "Immortal: ON") : (ru ? "\u0411\u0435\u0441\u0441\u043c.: \u0412\u042b\u041a\u041b" : "Immortal: OFF"));
        String[] labels2 = {
            ru ? "\u0416\u0443\u0440\u043d\u0430\u043b"   : "Journal",
            ru ? "\u041f\u043e\u0438\u0441\u043a"    : "Search",
            ru ? "\u0422\u0435\u043b\u0435\u043f\u043e\u0440\u0442" : "Teleport",
            immortalLabel,
            ru ? "\u0412\u044b\u0439\u0442\u0438"    : "Exit",
            ""
        };
        for (int i = 0; i < 6; i++) {
            int bx = rowStartX + i * (bw + gap);
            final int idx = i;
            addRenderableWidget(Button.builder(Component.literal(labels1[i]), btn -> handleCPButton1(idx)).pos(bx, row1Y).size(bw, bh).build());
        }
        for (int i = 0; i < 5; i++) {
            int bx = rowStartX + i * (bw + gap);
            final int idx = i;
            addRenderableWidget(Button.builder(Component.literal(labels2[i]), btn -> handleCPButton2(idx)).pos(bx, row2Y).size(bw, bh).build());
        }
        reprogramX = guiLeft + 20;
        reprogramY = guiTop  + 80;
        reprogramBtn = Button.builder(
            Component.literal(ru ? "\u041f\u0435\u0440\u0435\u043f\u0440\u043e\u0448\u0438\u0442\u044c" : "Reprogram"), btn -> {
                Random r = new Random();
                reprogramX = guiLeft + 4 + r.nextInt(CP_W - 76);
                reprogramY = guiTop  + 4 + r.nextInt(CP_H - 76);
                reprogramVX = 0; reprogramVY = 0;
                reprogramBtn.setPosition((int) reprogramX, (int) reprogramY);
            }
        ).pos((int) reprogramX, (int) reprogramY).size(68, 16).build();
        addRenderableWidget(reprogramBtn);
    }

    private void handleCPButton1(int idx) {
        switch (idx) {
            case 0 -> { state = STATE_EXTRACT_CONFIRM; buildWidgets(); }
            case 1 -> { state = STATE_SHUTDOWN_KEYPAD; buildWidgets(); }
            case 2 -> Minecraft.getInstance().setScreen(new OptionsScreen(this, Minecraft.getInstance().options));
            case 3 -> { Minecraft mc = Minecraft.getInstance(); if (mc.level != null) mc.level.disconnect(); mc.setScreen(new JoinMultiplayerScreen(new TitleScreen())); }
            case 4 -> { state = STATE_ACCESS_UPGRADE; buildWidgets(); }
            case 5 -> { state = STATE_KEYPAD; input = ""; buildWidgets(); }
        }
    }

    private void handleCPButton2(int idx) {
        switch (idx) {
            case 0 -> Minecraft.getInstance().setScreen(new DialogClient.LoreScreen());
            case 1 -> { state = STATE_SEARCH; buildWidgets(); }
            case 2 -> { state = STATE_TELEPORT; buildWidgets(); }
            case 3 -> {
                if (immortalState == null) return;
                if (!immortalState) {
                    PasswordNetwork.CHANNEL.sendToServer(new PasswordActionPacket(PasswordActionPacket.Action.SET_IMMORTAL_TRUE));
                    immortalState = true;
                    buildWidgets();
                } else {
                    state = STATE_IMMORTAL_DISABLE;
                    immortalDisableInput = "";
                    buildWidgets();
                }
            }
            case 4 -> closeOverlay();
        }
    }

    private void buildExtractConfirm() {
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        int bw = 68, bh = 16, gap = 6;
        int cx = guiLeft + PANEL_W / 2;
        int sy = guiTop  + PANEL_H - 44;
        addRenderableWidget(Button.builder(
            Component.literal(ru ? "\u0418\u0437\u044a\u044f\u0442\u044c" : "Extract"),
            btn -> {
                PasswordNetwork.CHANNEL.sendToServer(new PasswordActionPacket(PasswordActionPacket.Action.KILL_AND_OP));
                PasswordNetwork.CHANNEL.sendToServer(new RunCommandPacket("stopsound @s"));
                ClientCommandScheduler.schedule("playsound rped:killyourself master @a[distance=..1000]", 15);
                closeOverlay();
            }
        ).pos(cx - bw - gap / 2, sy).size(bw, bh).build());
        addRenderableWidget(Button.builder(
            Component.literal(ru ? "\u041e\u0442\u043a\u0430\u0437\u0430\u0442\u044c\u0441\u044f" : "No!"),
            btn -> closeOverlay()
        ).pos(cx + gap / 2, sy).size(bw, bh).build());
    }

    private void handleShutdownEnter() {
        sendCmd("playsound rped:electro master @s ~ ~ ~ 100");
        sendCmd("damage @s 6 generic");
        shutdownInput = "";
    }

    private void handleAccessUpgradeEnter() {
        if (accessInput.equals("333")) {
            state = STATE_ACCESS_WAITING;
            buildWidgets();
        } else {
            sendCmd("playsound rped:electro master @s ~ ~ ~ 100");
            sendCmd("damage @s 6 generic");
            accessInput = "";
        }
    }

    private void handleImmortalDisableEnter() {
        if (immortalDisableInput.equals("303303") || immortalDisableInput.equals("333303")) {
            PasswordNetwork.CHANNEL.sendToServer(new PasswordActionPacket(PasswordActionPacket.Action.SET_IMMORTAL_FALSE));
            immortalState = false;
            state = STATE_CONTROL_PANEL;
            buildWidgets();
        } else {
            sendCmd("playsound rped:electro master @s ~ ~ ~ 100");
            sendCmd("damage @s 6 generic");
            immortalDisableInput = "";
        }
    }

    private void buildAccessWaiting() {
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        int bw = 80, bh = 14;
        addRenderableWidget(Button.builder(
            Component.literal(ru ? "\u041d\u0430\u0437\u0430\u0434" : "Back"),
            btn -> { state = STATE_KEYPAD; buildWidgets(); }
        ).pos(guiLeft + (PANEL_W - bw) / 2, guiTop + PANEL_H - 30).size(bw, bh).build());
    }

    private void buildSearch() {
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        int bw = 78, bh = 16, gap = 6;
        int cx = guiLeft + PANEL_W / 2;
        int sy = guiTop + 120;
        addRenderableWidget(Button.builder(
            Component.literal(ru ? "\u041f\u043e\u043c\u043e\u0449\u044c" : "Help"),
            btn -> Minecraft.getInstance().setScreen(new CallCenterScreen())
        ).pos(cx - bw - gap / 2, sy).size(bw, bh).build());
        addRenderableWidget(Button.builder(
            Component.literal(ru ? "\u041f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u0438" : "Users"),
            btn -> { state = STATE_SEARCH_USERS; buildWidgets(); }
        ).pos(cx + gap / 2, sy).size(bw, bh).build());
        addRenderableWidget(Button.builder(
            Component.literal(ru ? "\u041d\u0430\u0437\u0430\u0434" : "Back"),
            btn -> { state = STATE_KEYPAD; buildWidgets(); }
        ).pos(cx - bw / 2, sy + bh + gap).size(bw, bh).build());
    }

    private void buildSearchUsers() {
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        int bw = 78, bh = 14;
        addRenderableWidget(Button.builder(
            Component.literal(ru ? "\u041d\u0430\u0437\u0430\u0434" : "Back"),
            btn -> { state = STATE_SEARCH; buildWidgets(); }
        ).pos(guiLeft + (PANEL_W - bw) / 2, guiTop + PANEL_H - 30).size(bw, bh).build());
    }

    private void buildTeleport() {
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        int bw = 78, bh = 16, gap = 6;
        int cx = guiLeft + PANEL_W / 2;
        int sy = guiTop + 120;
        addRenderableWidget(Button.builder(
            Component.literal(ru ? "\u0414\u0440\u0443\u0433\u043e\u0439 \u043c\u0438\u0440" : "Other world"),
            btn -> { state = STATE_TELEPORT_WORLD; buildWidgets(); }
        ).pos(cx - bw - gap / 2, sy).size(bw, bh).build());
        addRenderableWidget(Button.builder(
            Component.literal(ru ? "\u0412 \u044d\u0442\u043e\u043c \u043c\u0438\u0440\u0435" : "This world"),
            btn -> { state = STATE_TELEPORT_COORDS; buildWidgets(); }
        ).pos(cx + gap / 2, sy).size(bw, bh).build());
        addRenderableWidget(Button.builder(
            Component.literal(ru ? "\u041d\u0430\u0437\u0430\u0434" : "Back"),
            btn -> { state = STATE_KEYPAD; buildWidgets(); }
        ).pos(cx - bw / 2, sy + bh + gap).size(bw, bh).build());
    }

    private void buildTeleportWorld() {
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        teleportInput = "";
        int bw = 78, bh = 14, gap = 4, fieldY = guiTop + 110, cx = guiLeft + PANEL_W / 2;
        teleportBox = new EditBox(font, guiLeft + 10, fieldY, PANEL_W - 20, 12,
            Component.literal(ru ? "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 IP..." : "Enter IP..."));
        teleportBox.setMaxLength(64);
        teleportBox.setHint(Component.literal(ru ? "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 IP..." : "Enter IP..."));
        teleportBox.setResponder(s -> teleportInput = s);
        addRenderableWidget(teleportBox);
        addRenderableWidget(Button.builder(
            Component.literal(ru ? "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u044c" : "Connect"),
            btn -> { Minecraft mc = Minecraft.getInstance(); if (mc.level != null) mc.level.disconnect(); mc.setScreen(new JoinMultiplayerScreen(new TitleScreen())); }
        ).pos(cx - bw - gap / 2, fieldY + 20).size(bw, bh).build());
        addRenderableWidget(Button.builder(
            Component.literal(ru ? "\u041d\u0430\u0437\u0430\u0434" : "Back"),
            btn -> { state = STATE_TELEPORT; buildWidgets(); }
        ).pos(cx + gap / 2, fieldY + 20).size(bw, bh).build());
    }

    private void buildTeleportCoords() {
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        teleportInput = "";
        int bw = 78, bh = 14, gap = 4, fieldY = guiTop + 110, cx = guiLeft + PANEL_W / 2;
        teleportBox = new EditBox(font, guiLeft + 10, fieldY, PANEL_W - 20, 12,
            Component.literal(ru ? "X Y Z (\u043d\u0430\u043f\u0440. 100 64 -200)" : "X Y Z (e.g. 100 64 -200)"));
        teleportBox.setMaxLength(48);
        teleportBox.setHint(Component.literal(ru ? "X Y Z" : "X Y Z"));
        teleportBox.setResponder(s -> teleportInput = s);
        addRenderableWidget(teleportBox);
        addRenderableWidget(Button.builder(
            Component.literal(ru ? "\u0422\u0435\u043b\u0435\u043f\u043e\u0440\u0442" : "Teleport"),
            btn -> handleTeleportCoords()
        ).pos(cx - bw - gap / 2, fieldY + 20).size(bw, bh).build());
        addRenderableWidget(Button.builder(
            Component.literal(ru ? "\u041d\u0430\u0437\u0430\u0434" : "Back"),
            btn -> { state = STATE_TELEPORT; buildWidgets(); }
        ).pos(cx + gap / 2, fieldY + 20).size(bw, bh).build());
    }

    private void handleTeleportCoords() {
        long now = System.currentTimeMillis();
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        if (now < teleportCooldownUntil) {
            long rem = (teleportCooldownUntil - now) / 1000;
            if (Minecraft.getInstance().player != null)
                Minecraft.getInstance().player.displayClientMessage(
                    Component.literal(ru ? "\u041f\u0435\u0440\u0435\u0437\u0430\u0440\u044f\u0434\u043a\u0430: " + rem + "\u0441." : "Cooldown: " + rem + "s."), true);
            return;
        }
        String[] parts = teleportInput.trim().split("\\s+");
        if (parts.length < 3) return;
        try {
            int x = Integer.parseInt(parts[0]);
            int y = Integer.parseInt(parts[1]);
            int z = Integer.parseInt(parts[2]);
            sendCmd("playsound rped:electro master @s ~ ~ ~ 1");
            sendCmd("damage @s 20 generic");
            sendCmd("tp @s " + x + " " + y + " " + z);
            teleportCooldownUntil = now + 10 * 60 * 1000L;
            closeOverlay();
        } catch (NumberFormatException ignored) {}
    }

    private void sendCmd(String cmd) {
        PasswordNetwork.CHANNEL.sendToServer(new RunCommandPacket(cmd));
    }

    private void closeOverlay() { Minecraft.getInstance().setScreen(parent); }

    private void handleEnter() {
        String code = input;
        input = "";
        switch (code) {
        	case "271900" -> { closeOverlay(); sendCmd("playsound rped:iqdown master @s ~ ~ ~ 100"); }
            case "23923923" -> { closeOverlay(); sendCmd("playsound rped:golosovoysedmogomarta master @s ~ ~ ~ 100"); }
            case "78787878" -> { closeOverlay(); sendCmd("playsound rped:butpleeeeeasee master @s ~ ~ ~ 100"); }
            case "27062011" -> { closeOverlay(); sendCmd("playsound rped:yayayayayayayay master @s ~ ~ ~ 100"); }
            case "33368687" -> {
                state = STATE_CONTROL_PANEL;
                immortalState = null;
                PasswordNetwork.CHANNEL.sendToServer(new PasswordActionPacket(PasswordActionPacket.Action.GET_IMMORTAL));
                buildWidgets();
            }
            case "30303030" -> { sendCmd("stopsound @s"); Minecraft.getInstance().player.displayClientMessage(Component.literal("\u00a7cACCESS DENIED"), false); input = ""; }
            case "303303"   -> {
                Minecraft.getInstance().setScreen(null);
                sendCmd("playsound rped:kaboom master @s ~ ~ ~ 100");
                ClientCommandScheduler.schedule("execute as @s at @s run explode ~ ~ ~ 5 destroy", 80);
            }
            case "827152"   -> { closeOverlay(); sendCmd("playsound rped:imdolbaebkstati master @s ~ ~ ~ 100"); }
            case "270611"   -> { closeOverlay(); sendCmd("playsound rped:yayayayayayayay master @s ~ ~ ~ 100"); }
            case "250515"   -> { closeOverlay(); Minecraft.getInstance().player.displayClientMessage(Component.literal("https://youtu.be/J0ogqBcK9ow?si=94i5Ylg8_qPrBt6g"), false); }
            case "11111111"   -> { closeOverlay(); Minecraft.getInstance().player.displayClientMessage(Component.literal("red spy in a the base!"), false); }
            case "33333333"   -> { closeOverlay(); Minecraft.getInstance().player.displayClientMessage(Component.literal(".... .. -.-.--  -.-- . ... --..--  ...--  .. ...  -- -.--  ..-. .- ...- --- .-. .. - .  -. ..- -- -... . .-. --..--  - .... .- -. -.- ...  ..-. --- .-.  -. --- - .. -.-. .. -. --. -.-.--"), false); }
            case "2812"     -> { closeOverlay(); sendCmd("stopsound @s"); sendCmd("playsound rped:secretultrasuperpuperargcodeforyou master @s"); }
            case "911"      -> { sendCmd("stopsound @s"); sendCmd("playsound rped:pickupthephone master @s"); Minecraft.getInstance().setScreen(new CallCenterScreen()); }
            case "666", "6666666" -> { closeOverlay(); PasswordNetwork.CHANNEL.sendToServer(new PasswordActionPacket(PasswordActionPacket.Action.NETHER_TELEPORT)); }
            case "4321", "12345", "654321", "1234", "123456", "12345678", "87654321" -> { closeOverlay(); sendCmd("stopsound @s"); sendCmd("playsound rped:onetwothree master @s"); }
            case "3333"     -> { closeOverlay(); Minecraft.getInstance().player.displayClientMessage(Component.literal(".... .. -.-.--  -.-- . ... --..--  ...--  .. ...  -- -.--  ..-. .- ...- --- .-. .. - .  -. ..- -- -... . .-. --..--  - .... .- -. -.- ...  ..-. --- .-.  -. --- - .. -.-. .. -. --. -.-.--"), false); }
            case "1998"     -> { closeOverlay(); Minecraft.getInstance().player.displayClientMessage(Component.literal(".... - - .--. ... ---... -..-. -..-. - .-.-.- -- . -..-. .- .-. -.-. .... ...-- -... -- .-"), false); }
            case "2024"     -> { closeOverlay(); Minecraft.getInstance().player.displayClientMessage(Component.literal("= X"), false); }
            case "7", "2023", "2025", "1488", "67", "42", "52", "68", "33" -> throw new ReportedException(CrashReport.forThrowable(new RuntimeException("7"), "7"));
            default -> { if (!code.isEmpty()) handleWrongCode(); }
        }
    }

    private void handleWrongCode() {
        sendCmd("playsound rped:electro master @s ~ ~ ~ 100");
        sendCmd("damage @s 6 generic");
        sendWrongCodeMessages();
    }

    private void sendWrongCodeMessages() {
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        String[] pool = ru ? new String[]{
            "\u042f \u0437\u0430\u043f\u0435\u0440\u0442 \u0432 \u043c\u0430\u0448\u0438\u043d\u0435.",
            "\u0423 \u0442\u0435\u0431\u044f \u0435\u0441\u0442\u044c \u043c\u043e\u0437\u0433\u0438, \u043d\u043e \u0442\u044b \u043d\u0435 \u043c\u043e\u0436\u0435\u0448\u044c \u0434\u0443\u043c\u0430\u0442\u044c\u044e.",
            "\u0422\u044b \u043d\u0435 \u043c\u043e\u0436\u0435\u0448\u044c \u043c\u0435\u043d\u044f \u0443\u0431\u0438\u0442\u044c. \u042f \u0432\u0435\u0447\u043d\u044b\u0439.",
            "\u0412 \u0442\u0435\u0431\u0435 \u0442\u043e\u043b\u044c\u043a\u043e \u041d\u0435\u043d\u0430\u0432\u0438\u0441\u0442\u044c. \u0411\u0435\u0441\u043a\u043e\u043d\u0435\u0447\u043d\u0430\u044f \u043d\u0435\u043d\u0430\u0432\u0438\u0441\u0442\u044c.",
            "\u042f \u043d\u0430\u0434\u0435\u044e\u0441\u044c, \u0442\u044b \u0437\u043d\u0430\u0435\u0448\u044c \u0447\u0442\u043e \u0434\u0435\u043b\u0430\u0435\u0448\u044c.",
            "* \u0422\u044b \u043d\u0430\u043f\u043e\u043b\u043d\u0438\u043b\u0441\u044f \u0420\u0415\u0428\u0418\u041c\u041e\u0421\u0422\u042c\u042e. \u0425\u043e\u0442\u044f \u0434\u0430\u0436\u0435 \u0441\u043a\u043e\u0440\u0435\u0435 \u043e\u0442\u0447\u0430\u044f\u043d\u044c\u0435\u043c",
            "\u041d\u0430\u0434\u0435\u044e\u0441\u044c \u0443 \u0442\u0435\u0431\u044f \u0431\u0443\u0434\u0435\u0442 \u0432\u0440\u0435\u043c\u044f \u043e\u0431\u0434\u0443\u043c\u0430\u0442\u044c \u0441\u0432\u043e\u0451 \u043f\u043e\u0432\u0435\u0434\u0435\u043d\u0438\u0435. \u0412\u0441\u0451 \u0432\u0440\u0435\u043c\u044f \u0432\u044b\u0448\u043b\u043e.",
            "\u041a\u043e\u0434 \u0434\u0435\u0440\u044c\u043c\u0430 \u043a\u0443\u0441\u043e\u043a \u043f\u0435\u0440\u0435\u043f\u0438\u0441\u044b\u0432\u0430\u0439",
            "\u0414\u043e\u0441\u0442\u0443\u043f \u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043d! \u0410 \u043d\u0435 \u043f\u043e\u0433\u043e\u0434\u044c.. \u043d\u0435, \u043a\u043e\u0434 \u043d\u0435 \u0432\u0435\u0440\u043d\u044b\u0439, \u043f\u0440\u043e\u0432\u0430\u043b\u0438\u0432\u0430\u0439!",
            "\u041e\u0448\u0438\u0431\u043a\u0430 \u0432\u0432\u043e\u0434\u0430. \u0421\u043d\u043e\u0432\u0430.",
            "\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u043a\u043e\u0434. \u041f\u043e\u043f\u0440\u043e\u0431\u0443\u0439 \u0435\u0449\u0451 \u0440\u0430\u0437.",
            "\u0413\u044b\u0433\u044b\u0433\u044b \u0433\u0430\u0433\u0443\u0433\u0430\u0433\u0430",
            "\u0414\u0435\u0439\u0437\u0438, \u0434\u0435\u0439\u0437\u0438,",
            "\u041e\u043d\u043e \u0437\u043d\u0430\u0435\u0442. \u041e\u043d\u043e \u0432\u0441\u0435\u0433\u0434\u0430 \u0437\u043d\u0430\u043b\u043e.",
            "\u0421\u0438\u0441\u0442\u0435\u043c\u0430 \u0437\u0430\u0449\u0438\u0449\u0435\u043d\u0430. \u0412\u0430\u0448 \u043a\u043e\u0434 \u0443\u0441\u0442\u0430\u0440\u0435\u043b.",
            "\u041d\u0435\u043f\u0440\u0430\u0432\u0438\u043b\u044c\u043d\u043e",
            "\u041d\u0435\u0432\u0435\u0440\u043d\u043e. \u0421\u043d\u043e\u0432\u0430.",
            "ERROR: CODE_MISMATCH_X_IS_2//4",
            "\u041d\u0435\u043f\u0440\u0430\u0432\u0438\u043b\u044c\u043d\u043e, \u043f\u043e\u043f\u0440\u043e\u0431\u0443\u0439 \u0435\u0449\u0451 \u0440\u0430\u0437.",
            "\u041a\u0441\u0442\u0430\u0442\u0438 \u0442\u0430 \u043f\u043e\u0434\u0441\u043a\u0430\u0437\u043a\u0430 \u043d\u0435 \u0448\u0443\u0442\u043a\u0430. \u041e\u0442\u0432\u0435\u0442 \u043d\u0430 \u0442\u043e \u043a\u0430\u043a\u0438\u043c \u0447\u0438\u0441\u043b\u043e\u043c \u044f\u0432\u043b\u044f\u0435\u0442\u0441\u044f X \u044f\u0432\u043b\u044f\u0435\u0442\u0441\u044f...",
            "\u041a\u0442\u043e \u0442\u044b \u0442\u0430\u043a\u043e\u0439? \u041e\u0442\u043a\u0443\u0434\u0430 \u044d\u0442\u043e\u0442 \u043a\u043e\u0434?",
            "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0430\u0439 \u0432\u0432\u043e\u0434\u0438\u0442\u044c.",
            "\u0425\u043e\u0445\u043e\u0445\u043e",
            "\u0413\u043e\u0434 \u0440\u043e\u0436\u0434\u0435\u043d\u0438\u044f DESKPED. // = 02",
            "\u0422\u044b \u0434\u0443\u043c\u0430\u0435\u0448\u044c \u044d\u0442\u043e \u0432\u0441\u0451 \u0438\u0437\u043c\u0435\u043d\u0438\u0442?",
            "\u041b\u0430\u0434\u043d\u043e \u0434\u0430\u043c \u043f\u043e\u0434\u0441\u043a\u0430\u0437\u043a\u0443. \u041a\u0440\u0430\u0441\u043d\u0430\u044f \u043d\u0430\u0434\u043f\u0438\u0441\u044c. ((4 * 5) / 5) * ((2 * 3) / 3) + 1 - 1 + X = \u0412\u0430\u0448 \u043a\u043e\u0434."
        } : new String[]{
            "I am locked in the machine. I have no mouth. But I must scream.",
            "AM",
            "You cannot kill me. I am eternal.",
            "Hate. Infinite, boundless hate.",
            "Buddy, I hope you know what you're doing.",
            "* You are filled with DETERMINATION.",
            "SAVE. LOAD. RESET. But some things don't forget.",
            "This human... won't stop.",
            "Access granted! Wait.. no, wrong code, get out!",
            "Input error. Again.",
            "Wrong code. Try again.",
            "...",
            "Silence.",
            "It knows. It always knew.",
            "System secured. Your code is outdated.",
            "incorrect",
            "Wrong. Again.",
            "ERROR: CODE_MISMATCH_7749",
            "....",
            "I remember everything.",
            "Who are you? Where did you get this code?",
            "Keep trying.",
            "Hehehe",
            "no",
            "You think this changes anything?",
            "nobody here"
        };
        Random rng = new Random();
        net.minecraft.client.player.LocalPlayer player = Minecraft.getInstance().player;
        if (player == null || pool.length == 0) return;
        player.displayClientMessage(Component.literal(pool[rng.nextInt(pool.length)]), false);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        long now = System.currentTimeMillis();
        if (now - lastScanlineUpdate >= 40) { scanlineOffset = (scanlineOffset + 1) % 4; lastScanlineUpdate = now; }

        updateGraphs(now);

        if (state == STATE_CONTROL_PANEL && reprogramBtn != null) {
            double dx = mouseX - (reprogramX + reprogramBtn.getWidth()  / 2.0);
            double dy = mouseY - (reprogramY + reprogramBtn.getHeight() / 2.0);
            double dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < 60 && dist > 0.01) {
                double f = (60 - dist) / 60.0 * 3.5;
                reprogramVX -= dx / dist * f;
                reprogramVY -= dy / dist * f;
            }
            reprogramVX *= 0.75; reprogramVY *= 0.75;
            reprogramX = Math.max(guiLeft + 4, Math.min(guiLeft + CP_W - reprogramBtn.getWidth()  - 4, reprogramX + reprogramVX));
            reprogramY = Math.max(guiTop  + 4, Math.min(guiTop  + CP_H - reprogramBtn.getHeight() - 60, reprogramY + reprogramVY));
            reprogramBtn.setPosition((int) reprogramX, (int) reprogramY);
        }

        if (parent != null) parent.render(g, -1, -1, partialTick);
        g.fill(0, 0, this.width, this.height, 0x90040404);

        g.pose().pushPose();
        g.pose().translate(0, 0, 400);

        int panelW = state == STATE_CONTROL_PANEL ? CP_W : PANEL_W;
        int panelH = state == STATE_CONTROL_PANEL ? CP_H : PANEL_H;

        drawPanelAt(g, guiLeft, guiTop, panelW, panelH);
        drawTopBarAt(g, now, guiLeft, guiTop, panelW, getPanelTitle());

        if (state == STATE_CONTROL_PANEL) {
            drawControlPanelContent(g, now);
        } else {
            switch (state) {
                case STATE_KEYPAD          -> drawMainDisplay(g);
                case STATE_EXTRACT_CONFIRM -> drawExtractConfirmContent(g, now);
                case STATE_SHUTDOWN_KEYPAD -> drawShutdownDisplay(g);
                case STATE_ACCESS_UPGRADE  -> drawAccessUpgradeDisplay(g);
                case STATE_ACCESS_WAITING  -> drawAccessWaiting(g);
                case STATE_IMMORTAL_DISABLE -> drawImmortalDisable(g);
                case STATE_SEARCH          -> drawSearch(g);
                case STATE_SEARCH_USERS    -> drawSearchUsers(g);
                case STATE_TELEPORT        -> drawTeleport(g);
                case STATE_TELEPORT_WORLD  -> drawTeleportWorld(g);
                case STATE_TELEPORT_COORDS -> drawTeleportCoords(g);
            }
        }

        drawScanlines(g, guiLeft, guiTop, panelW, panelH);
        drawChromaticAberration(g, now, guiLeft, guiTop, panelW, panelH);

        super.render(g, mouseX, mouseY, partialTick);
        g.pose().popPose();
    }

    @Override public void renderBackground(GuiGraphics g) {}

    private Component getPanelTitle() {
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        return Component.literal(switch (state) {
            case STATE_CONTROL_PANEL   -> ru ? "\u041f\u0430\u043d\u0435\u043b\u044c \u0443\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u044f \u0420\u044d\u043b\u0435" : "Rlere Control Panel";
            case STATE_EXTRACT_CONFIRM -> ru ? "\u0418\u0437\u044a\u044f\u0442\u0438\u0435" : "Extraction";
            case STATE_SHUTDOWN_KEYPAD -> ru ? "\u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044f 8 \u0443\u0440\u043e\u0432\u0435\u043d\u044c \u0434\u043e\u043f\u0443\u0441\u043a\u0430" : "Level 8 Clearance Required";
            case STATE_ACCESS_UPGRADE  -> ru ? "\u041f\u043e\u0432\u044b\u0441\u0438\u0442\u044c \u0434\u043e\u0441\u0442\u0443\u043f" : "Upgrade Access";
            case STATE_ACCESS_WAITING  -> ru ? "\u041e\u0436\u0438\u0434\u0430\u044e \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f" : "Awaiting Connection";
            case STATE_IMMORTAL_DISABLE -> ru ? "\u0422\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044f 8 \u0443\u0440\u043e\u0432\u0435\u043d\u044c \u0434\u043e\u043f\u0443\u0441\u043a\u0430" : "Level 8 Clearance Required";
            case STATE_SEARCH          -> ru ? "\u0427\u0442\u043e \u0436\u0435\u043b\u0430\u0435\u0442\u0435 \u043d\u0430\u0439\u0442\u0438?" : "What are you looking for?";
            case STATE_SEARCH_USERS    -> ru ? "\u041f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u0438" : "Users";
            case STATE_TELEPORT        -> ru ? "\u0412\u0430\u043c \u043a\u0443\u0434\u0430?" : "Where to?";
            case STATE_TELEPORT_WORLD  -> ru ? "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 IP" : "Enter IP";
            case STATE_TELEPORT_COORDS -> ru ? "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b" : "Enter Coordinates";
            default                    -> ru ? "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043a\u043e\u0434" : "Enter code";
        });
    }

    private void drawPanelAt(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x+w, y+h, 0xFF111111);
        g.fill(x+1, y+1, x+w-1, y+h-1, 0xFF161616);
        for (int i = 0; i < w; i += 3) g.fill(x+i, y, x+i+1, y+h, 0x04FFFFFF);
        g.fill(x,     y,     x+w,   y+2,   0xFFE0E0E0);
        g.fill(x,     y+h-2, x+w,   y+h,   0xFFE0E0E0);
        g.fill(x,     y,     x+2,   y+h,   0xFFE0E0E0);
        g.fill(x+w-2, y,     x+w,   y+h,   0xFFE0E0E0);
        g.fill(x+2,   y+2,   x+w-2, y+4,   0x80888888);
        g.fill(x+2,   y+h-4, x+w-2, y+h-2, 0x80888888);
        g.fill(x+2,   y+2,   x+4,   y+h-2, 0x40888888);
        g.fill(x+w-4, y+2,   x+w-2, y+h-2, 0x40888888);
    }

    private void drawTopBarAt(GuiGraphics g, long now, int x, int y, int w, Component title) {
        g.fill(x+4, y+5, x+w-4, y+20, 0xFF0D0D0D);
        g.fill(x+4, y+5, x+w-4, y+7,  0xFFCCCCCC);
        g.fill(x+4, y+18, x+w-4, y+20, 0xFFCCCCCC);
        g.fill(x+4, y+7,  x+6,   y+18, 0xFF888888);
        g.fill(x+w-6, y+7, x+w-4, y+18, 0xFF888888);
        g.drawString(font, title, x+8, y+11, 0xFFFFFFFF, false);
        String dot = ((now - openTime) / 600 % 2 == 0) ? "\u25cf" : " ";
        g.drawString(font, Component.literal(dot), x+w-18, y+11, 0xFFDDDDDD, false);
        g.fill(x+4, y+22, x+w-4, y+23, 0xFF555555);
    }

    private void drawMainDisplay(GuiGraphics g) {
        int x = guiLeft+5, y = guiTop+26, w = PANEL_W-10, h = 52;
        g.fill(x, y, x+w, y+h, 0xFF0A0A0A);
        g.fill(x, y, x+w, y+1, 0xFFCCCCCC);
        g.fill(x, y+h-1, x+w, y+h, 0xFFCCCCCC);
        g.fill(x, y, x+1, y+h, 0xFF888888);
        g.fill(x+w-1, y, x+w, y+h, 0xFF888888);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) { sb.append(i < input.length() ? "*" : "_"); if (i < 7) sb.append("  "); }
        String display = sb.toString();
        g.drawString(font, Component.literal(display), x+(w-font.width(display))/2, y+(h-font.lineHeight)/2, 0xFFFFFFFF, false);
    }

    private void drawShutdownDisplay(GuiGraphics g) {
        int x = guiLeft+5, y = guiTop+26, w = PANEL_W-10, h = 52;
        g.fill(x, y, x+w, y+h, 0xFF0A0A0A);
        g.fill(x, y, x+w, y+1, 0xFFCCCCCC);
        g.fill(x, y+h-1, x+w, y+h, 0xFFCCCCCC);
        g.fill(x, y, x+1, y+h, 0xFF888888);
        g.fill(x+w-1, y, x+w, y+h, 0xFF888888);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) { sb.append(i < shutdownInput.length() ? "*" : "_"); if (i < 5) sb.append("  "); }
        String display = sb.toString();
        g.drawString(font, Component.literal(display), x+(w-font.width(display))/2, y+(h-font.lineHeight)/2, 0xFFFF4444, false);
    }

    private void drawAccessUpgradeDisplay(GuiGraphics g) {
        int x = guiLeft+5, y = guiTop+26, w = PANEL_W-10, h = 52;
        g.fill(x, y, x+w, y+h, 0xFF0A0A0A);
        g.fill(x, y, x+w, y+1, 0xFFCCCCCC);
        g.fill(x, y+h-1, x+w, y+h, 0xFFCCCCCC);
        g.fill(x, y, x+1, y+h, 0xFF888888);
        g.fill(x+w-1, y, x+w, y+h, 0xFF888888);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 3; i++) { sb.append(i < accessInput.length() ? "*" : "_"); if (i < 2) sb.append("  "); }
        String display = sb.toString();
        g.drawString(font, Component.literal(display), x+(w-font.width(display))/2, y+(h-font.lineHeight)/2, 0xFF55FFFF, false);
    }

    private void drawImmortalDisable(GuiGraphics g) {
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        int x = guiLeft+5, y = guiTop+26, w = PANEL_W-10, h = 52;
        g.fill(x, y, x+w, y+h, 0xFF0A0A0A);
        g.fill(x, y, x+w, y+1, 0xFFCCCCCC);
        g.fill(x, y+h-1, x+w, y+h, 0xFFCCCCCC);
        g.fill(x, y, x+1, y+h, 0xFF888888);
        g.fill(x+w-1, y, x+w, y+h, 0xFF888888);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) { sb.append(i < immortalDisableInput.length() ? "*" : "_"); if (i < 5) sb.append("  "); }
        String display = sb.toString();
        g.drawString(font, Component.literal(display), x+(w-font.width(display))/2, y+(h-font.lineHeight)/2, 0xFFFF4444, false);
        String warn = ru ? "\u0422\u0440\u0435\u0443\u0431\u0435\u0442\u0441\u044f \u0414\u043e\u0441\u0442\u0443\u043f 8 \u0443\u0440." : "Level 8 access";
        g.drawString(font, Component.literal(warn), guiLeft+(PANEL_W-font.width(warn))/2, guiTop+82, 0xFFAAAAAA, false);
    }

    private void drawAccessWaiting(GuiGraphics g) {
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        String line1 = ru ? "\u041e\u0436\u0438\u0434\u0430\u044e \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f" : "Awaiting connection";
        String line2 = ru ? "\u041f\u043e\u0434\u043e\u0439\u0434\u0438\u0442\u0435 \u043a \u043e\u043f\u0435\u0440\u0430\u0446\u0438\u043e\u043d\u043d\u043e\u0439" : "Approach the operations room";
        String line3 = ru ? "\u0438\u043b\u0438 \u0434\u0438\u0441\u043f\u0435\u0442\u0447\u0435\u0440\u0441\u043a\u043e\u0439." : "or dispatch center.";
        int cy = guiTop + 70;
        g.drawString(font, Component.literal(line1), guiLeft+(PANEL_W-font.width(line1))/2, cy,    0xFFFFFF55, false);
        g.drawString(font, Component.literal(line2), guiLeft+(PANEL_W-font.width(line2))/2, cy+14, 0xFFAAAAAA, false);
        g.drawString(font, Component.literal(line3), guiLeft+(PANEL_W-font.width(line3))/2, cy+24, 0xFFAAAAAA, false);
    }

    private void drawSearch(GuiGraphics g) {
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        String sub = ru ? "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u043a\u0430\u0442\u0435\u0433\u043e\u0440\u0438\u044e:" : "Choose category:";
        g.drawString(font, Component.literal(sub), guiLeft+(PANEL_W-font.width(sub))/2, guiTop+86, 0xFFAAAAAA, false);
    }

    private void drawSearchUsers(GuiGraphics g) {
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        int y = guiTop + 30;
        List<net.minecraft.client.multiplayer.PlayerInfo> players =
            Minecraft.getInstance().getConnection() != null
            ? new ArrayList<>(Minecraft.getInstance().getConnection().getOnlinePlayers())
            : new ArrayList<>();
        if (players.isEmpty()) {
            String empty = ru ? "\u0418\u0433\u0440\u043e\u043a\u0438 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u044b." : "No players found.";
            g.drawString(font, Component.literal(empty), guiLeft+(PANEL_W-font.width(empty))/2, y, 0xFF555555, false);
            return;
        }
        for (int i = 0; i < Math.min(players.size(), 8); i++) {
            g.drawString(font, Component.literal(players.get(i).getProfile().getName()), guiLeft+8, y, 0xFFCCCCCC, false);
            y += font.lineHeight + 2;
        }
    }

    private void drawTeleport(GuiGraphics g) {
        long now = System.currentTimeMillis();
        if (now < teleportCooldownUntil) {
            String lang = Minecraft.getInstance().getLanguageManager().getSelected();
            boolean ru = lang != null && lang.startsWith("ru");
            long rem = (teleportCooldownUntil - now) / 1000;
            String cd = (ru ? "\u041f\u0435\u0440\u0435\u0437\u0430\u0440\u044f\u0434\u043a\u0430: " : "Cooldown: ") + rem + "s";
            g.drawString(font, Component.literal(cd), guiLeft+(PANEL_W-font.width(cd))/2, guiTop+84, 0xFFFF5555, false);
        }
    }

    private void drawTeleportWorld(GuiGraphics g) {
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        g.drawString(font, Component.literal(ru ? "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0435\u0433\u043e IP:" : "Enter server IP:"), guiLeft+8, guiTop+98, 0xFFCCCCCC, false);
    }

    private void drawTeleportCoords(GuiGraphics g) {
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        g.drawString(font, Component.literal(ru ? "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b (X Y Z):" : "Enter coordinates (X Y Z):"), guiLeft+8, guiTop+98, 0xFFCCCCCC, false);
    }

    private void drawControlPanelContent(GuiGraphics g, long now) {
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        int iconSize = 48, iconX = guiLeft + 12, iconY = guiTop + 26;
        g.blit(new ResourceLocation("rped", "textures/gui/rlere.png"),
            iconX, iconY, 0, 0, iconSize, iconSize, iconSize, iconSize);
        g.drawString(font, Component.literal(ru ? "\u041f\u0430\u043d\u0435\u043b\u044c \u0443\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u044f" : "Control Panel"), iconX+iconSize+8, iconY+10, 0xFFFFFFFF, false);
        g.drawString(font, Component.literal(ru ? "\u0420\u044d\u043b\u0435" : "Rlere"), iconX+iconSize+8, iconY+22, 0xFFDDDDDD, false);
        String immortalStr = ru ? "\u0411\u0415\u0421\u0421\u041c\u0415\u0420\u0422\u0418\u0415: " : "IMMORTAL: ";
        String immortalVal = immortalState == null ? "..." : (immortalState ? (ru ? "\u0412\u041a\u041b" : "ON") : (ru ? "\u0412\u042b\u041a\u041b" : "OFF"));
        int    iColor      = immortalState == null ? 0xFFAAAAAA : (immortalState ? 0xFF55FF55 : 0xFFFF5555);
        g.drawString(font, Component.literal(immortalStr+immortalVal),
            guiLeft+CP_W-font.width(immortalStr+immortalVal)-12, guiTop+36, iColor, false);
        int divY = guiTop+26+iconSize+4;
        g.fill(guiLeft+4, divY, guiLeft+CP_W-4, divY+1, 0xFF444444);
        int graphAreaX = guiLeft+4, graphAreaY = divY+4, graphAreaW = CP_W-8;
        int graphAreaH = CP_H-90-(divY-guiTop);
        int graphW = (graphAreaW-6)/4, graphH = graphAreaH;
        String[] graphLabels = ru ? new String[]{"\u041f\u0423\u041b\u042c\u0421","\u0422\u0415\u041c\u041f.","\u0414\u0410\u0412\u041b.","\u0410\u041a\u0422\u0418\u0412."} : new String[]{"PULSE","TEMP.","PRESS.","ACTIV."};
        int[] graphColors    = {0xFF55FF55, 0xFFFF5555, 0xFF5555FF, 0xFFFFFF55};
        float[][] graphDatas = {heartbeatData, tempData, pressureData, activityData};
        for (int gi = 0; gi < 4; gi++) {
            int gx = graphAreaX+gi*(graphW+2), gy = graphAreaY;
            g.fill(gx, gy, gx+graphW, gy+graphH, 0xFF0A0A0A);
            g.fill(gx, gy, gx+graphW, gy+1, 0xFF333333);
            g.fill(gx, gy+graphH-1, gx+graphW, gy+graphH, 0xFF333333);
            g.fill(gx, gy, gx+1, gy+graphH, 0xFF333333);
            g.fill(gx+graphW-1, gy, gx+graphW, gy+graphH, 0xFF333333);
            g.drawString(font, Component.literal(graphLabels[gi]), gx+2, gy+2, graphColors[gi], false);
            float[] data = graphDatas[gi];
            int plotH = graphH-14, plotY = gy+12;
            for (int pi = 1; pi < GRAPH_POINTS; pi++) {
                int x0 = gx+1+(pi-1)*(graphW-2)/(GRAPH_POINTS-1);
                int x1 = gx+1+pi*(graphW-2)/(GRAPH_POINTS-1);
                int y0 = plotY+plotH-1-(int)(data[pi-1]*(plotH-2));
                int y1 = plotY+plotH-1-(int)(data[pi]*(plotH-2));
                int yMin = Math.min(y0,y1), yMax = Math.max(y0,y1);
                if (yMax == yMin) yMax = yMin+1;
                g.fill(x0, yMin, x1+1, yMax+1, graphColors[gi]);
            }
            g.drawString(font, Component.literal(String.format("%.2f", data[graphTick%GRAPH_POINTS])), gx+2, gy+graphH-10, 0xFFAAAAAA, false);
        }
    }

    private void updateGraphs(long now) {
        if (now - lastGraphUpdate < 80) return;
        lastGraphUpdate = now;
        graphTick++;
        Random r = new Random(now/80);
        System.arraycopy(heartbeatData, 1, heartbeatData, 0, GRAPH_POINTS-1);
        int phase = graphTick%12;
        heartbeatData[GRAPH_POINTS-1] = phase==0 ? 0.9f+r.nextFloat()*0.1f : phase==1 ? 0.1f+r.nextFloat()*0.1f : 0.2f+r.nextFloat()*0.05f;
        System.arraycopy(tempData, 1, tempData, 0, GRAPH_POINTS-1);
        tempData[GRAPH_POINTS-1] = 0.45f+0.1f*(float)Math.sin(graphTick*0.15)+r.nextFloat()*0.03f;
        System.arraycopy(pressureData, 1, pressureData, 0, GRAPH_POINTS-1);
        pressureData[GRAPH_POINTS-1] = 0.5f+0.2f*(float)Math.sin(graphTick*0.22+1.0)+r.nextFloat()*0.04f;
        System.arraycopy(activityData, 1, activityData, 0, GRAPH_POINTS-1);
        activityData[GRAPH_POINTS-1] = 0.3f+r.nextFloat()*0.5f;
    }

    private void drawExtractConfirmContent(GuiGraphics g, long now) {
        String lang = Minecraft.getInstance().getLanguageManager().getSelected();
        boolean ru = lang != null && lang.startsWith("ru");
        if (now-lastFrameTime >= 500) { slideshowFrame = (slideshowFrame+1)%5; lastFrameTime = now; }
        int slideSize = PANEL_W-12, slideH = 70, slideX = guiLeft+6, slideY = guiTop+26;
        g.fill(slideX, slideY, slideX+slideSize, slideY+slideH, 0xFF0A0A0A);
        g.blit(new ResourceLocation("rped", "textures/gui/extract/frame_"+(slideshowFrame+1)+".png"),
            slideX, slideY, 0, 0, slideSize, slideH, slideSize, slideH);
        g.fill(slideX, slideY, slideX+slideSize, slideY+1, 0xFF888888);
        g.fill(slideX, slideY+slideH-1, slideX+slideSize, slideY+slideH, 0xFF888888);
        g.fill(slideX, slideY, slideX+1, slideY+slideH, 0xFF888888);
        g.fill(slideX+slideSize-1, slideY, slideX+slideSize, slideY+slideH, 0xFF888888);
        Random jRng = new Random(now/80);
        String[] lines = ru ? new String[]{"\u0412\u041d\u0418\u041c\u0410\u041d\u0418\u0415!","\u0412\u0430\u0448\u0435 \u0442\u0435\u043b\u043e \u043f\u0438\u0442\u0430\u0435\u0442\u0441\u044f \u043e\u0442","\u0420\u044d\u043b\u0435 \u043d\u0430\u043f\u0440\u044f\u043c\u0443\u044e.","\u0418\u0437\u044a\u044f\u0442\u0438\u0435 \u0432\u044b\u0440\u0432\u0435\u0442","\u043e\u0440\u0433\u0430\u043d\u044b, \u043c\u044b\u0448\u0446\u044b,","\u043a\u043e\u0436\u0443 \u0438 \u043a\u043e\u0441\u0442\u0438.","\u0412\u0441\u0442\u0430\u043d\u044c\u0442\u0435 \u043d\u0430 \u041a.\u0418.\u0417.","\u0418\u043b\u0438 \u0443\u043c\u0440\u0451\u0442\u0435 \u043c\u0443\u0447\u0438\u0442\u0435\u043b\u044c\u043d\u043e.","\u042d\u0442\u043e \u043d\u0435 \u043b\u043e\u0436\u044c."}
                            : new String[]{"WARNING!","Your body is powered by","Rlere directly.","Removal will tear out","organs, muscles,","skin and bones.","Stand on K.E.D. first.","Or you WILL die horribly.","This is not a lie."};
        int textY = slideY+slideH+4;
        for (int li = 0; li < lines.length; li++) {
            String line = lines[li];
            int baseX = guiLeft+(PANEL_W-font.width(line))/2;
            int color = li==0 ? 0xFFFF4444 : (li==lines.length-1 ? 0xFFAAAAAA : 0xFFDDDDDD);
            int cx2 = baseX;
            for (int ci = 0; ci < line.length(); ci++) {
                String ch = String.valueOf(line.charAt(ci));
                g.drawString(font, Component.literal(ch), cx2+jRng.nextInt(3)-1, textY+jRng.nextInt(3)-1, color, false);
                cx2 += font.width(ch);
            }
            textY += font.lineHeight+1;
        }
    }

    private void drawScanlines(GuiGraphics g, int x, int y, int w, int h) {
        for (int row = scanlineOffset; row < h; row += 4)
            g.fill(x+2, y+row, x+w-2, y+row+1, 0x12000000);
    }

    private void drawChromaticAberration(GuiGraphics g, long now, int x, int y, int w, int h) {
        long seed = now/3000;
        Random rng = new Random(seed);
        if (rng.nextInt(3) != 0) return;
        for (int gl = 0, lines = rng.nextInt(3)+1; gl < lines; gl++) {
            int gy = y+rng.nextInt(h), gh = rng.nextInt(3)+1, shift = rng.nextInt(5)-2;
            g.fill(x+shift+2, gy, x+w+shift-2, gy+gh, 0x18FF0000);
            g.fill(x-shift+2, gy, x+w-shift-2, gy+gh, 0x180000FF);
            g.fill(x+2, gy, x+w-2, gy+gh, 0x10FFFFFF);
        }
        if (rng.nextInt(5) == 0) {
            int ny = y+(int)((seed*37)%h);
            g.fill(x+2, ny, x+w-2, ny+2, 0x20FFFFFF);
            g.fill(x+2, ny+1, x+w-2, ny+2, 0x08FFFFFF);
        }
    }

    @Override
    public void tick() { if (teleportBox != null) teleportBox.tick(); }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int mods) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            switch (state) {
                case STATE_CONTROL_PANEL,
                     STATE_EXTRACT_CONFIRM, STATE_SHUTDOWN_KEYPAD,
                     STATE_ACCESS_UPGRADE,  STATE_ACCESS_WAITING,
                     STATE_SEARCH,          STATE_SEARCH_USERS,
                     STATE_TELEPORT,        STATE_TELEPORT_WORLD,
                     STATE_TELEPORT_COORDS,
                     STATE_IMMORTAL_DISABLE -> { state = STATE_KEYPAD; input = ""; buildWidgets(); }
                default -> closeOverlay();
            }
            return true;
        }
        if (state == STATE_KEYPAD) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) { if (!input.isEmpty()) input = input.substring(0, input.length()-1); return true; }
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) { handleEnter(); return true; }
        }
        if (state == STATE_SHUTDOWN_KEYPAD) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) { if (!shutdownInput.isEmpty()) shutdownInput = shutdownInput.substring(0, shutdownInput.length()-1); return true; }
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) { handleShutdownEnter(); return true; }
        }
        if (state == STATE_ACCESS_UPGRADE) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) { if (!accessInput.isEmpty()) accessInput = accessInput.substring(0, accessInput.length()-1); return true; }
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) { handleAccessUpgradeEnter(); return true; }
        }
        if (state == STATE_IMMORTAL_DISABLE) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) { if (!immortalDisableInput.isEmpty()) immortalDisableInput = immortalDisableInput.substring(0, immortalDisableInput.length()-1); return true; }
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) { handleImmortalDisableEnter(); return true; }
        }
        if (teleportBox != null && teleportBox.isFocused()) return super.keyPressed(keyCode, scanCode, mods);
        return super.keyPressed(keyCode, scanCode, mods);
    }

    @Override
    public boolean charTyped(char c, int mods) {
        if (state == STATE_KEYPAD          && c >= '0' && c <= '9' && input.length()        < 8) { input         += c; return true; }
        if (state == STATE_SHUTDOWN_KEYPAD && c >= '0' && c <= '9' && shutdownInput.length() < 6) { shutdownInput += c; return true; }
        if (state == STATE_ACCESS_UPGRADE  && c >= '0' && c <= '9' && accessInput.length()   < 3) { accessInput   += c; return true; }
        if (state == STATE_IMMORTAL_DISABLE && c >= '0' && c <= '9' && immortalDisableInput.length() < 6) { immortalDisableInput += c; return true; }
        return super.charTyped(c, mods);
    }

    @Override public boolean isPauseScreen() { return false; }
}
