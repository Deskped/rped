package deskped.rped.over.client.gui;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import deskped.rped.over.network.ConfirmEquipPacket;
import deskped.rped.over.network.OverNetwork;

@OnlyIn(Dist.CLIENT)
public class ConfirmEquipScreen extends Screen {

	private static final String LINE1 = "\u0412\u044b \u0423\u0412\u0415\u0420\u0415\u041d\u042b \u0447\u0442\u043e \u0445\u043e\u0442\u0438\u0442\u0435 \u0435\u0433\u043e \u043d\u0430\u0434\u0435\u0442\u044c?";
	private static final String LINE2 = "\u0411\u0435\u0437 \u0441\u043f\u0435\u0446\u0438\u0430\u043b\u044c\u043d\u043e\u0433\u043e \u043a\u043e\u0434\u0430 \u0432\u044b \u0435\u0433\u043e \u043d\u0435 \u0441\u043d\u0438\u043c\u0435\u0442\u0435!";

	public ConfirmEquipScreen() {
		super(Component.literal(""));
	}

	public static void open() {
		Minecraft.getInstance().setScreen(new ConfirmEquipScreen());
	}

	@Override
	protected void init() {
		int cx = this.width / 2;
		int cy = this.height / 2;
		this.addRenderableWidget(Button.builder(Component.literal("\u0414\u0430"), b -> {
			OverNetwork.CHANNEL.sendToServer(new ConfirmEquipPacket());
			this.onClose();
		}).bounds(cx - 105, cy + 20, 100, 20).build());
		this.addRenderableWidget(Button.builder(Component.literal("\u041d\u0435\u0442"), b -> this.onClose())
			.bounds(cx + 5, cy + 20, 100, 20).build());
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(g);
		int cx = this.width / 2;
		int cy = this.height / 2;
		g.fill(cx - 160, cy - 40, cx + 160, cy + 50, 0xE0101014);
		g.fill(cx - 160, cy - 40, cx + 160, cy - 39, 0xFF803030);
		g.fill(cx - 160, cy + 49, cx + 160, cy + 50, 0xFF803030);
		g.drawCenteredString(this.font, LINE1, cx, cy - 24, 0xFFFFFFFF);
		g.drawCenteredString(this.font, LINE2, cx, cy - 10, 0xFFFF5555);
		super.render(g, mouseX, mouseY, partialTicks);
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return true;
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
