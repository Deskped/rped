package deskped.rped.over.client.gui;

// Это технологий CorPED, здесь дизайн/интерфейс менять под другой НЕЛЬЗЯ

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.GuiGraphics;

import deskped.rped.over.inventory.InventoryMenu;
import deskped.rped.over.network.InventoryButtonMessage;
import deskped.rped.over.network.OverNetwork;
import deskped.rped.over.init.OverScreens;

import com.mojang.blaze3d.systems.RenderSystem;

@OnlyIn(Dist.CLIENT)
public class InventoryScreen extends AbstractContainerScreen<InventoryMenu> implements OverScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private ImageButton imagebutton_button_live;
	private ImageButton imagebutton_button_clock;
	private ImageButton imagebutton_call_live;
	private ImageButton imagebutton_lore_live;

	public InventoryScreen(InventoryMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 0;
		this.imageHeight = 0;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	private static final ResourceLocation texture = new ResourceLocation("rped:textures/screens/inventory.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(guiGraphics);
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		boolean customTooltipShown = false;
		if (mouseX > leftPos + 91 && mouseX < leftPos + 115 && mouseY > topPos + -88 && mouseY < topPos + -64) {
			guiGraphics.renderTooltip(font, Component.literal("Look what the characters told you"), mouseX, mouseY);
			customTooltipShown = true;
		}
		if (mouseX > leftPos + -118 && mouseX < leftPos + -94 && mouseY > topPos + -89 && mouseY < topPos + -65) {
			guiGraphics.renderTooltip(font, Component.literal("Complete OverPED! Collect all 33 hours!"), mouseX, mouseY);
			customTooltipShown = true;
		}
		if (!customTooltipShown)
			this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(texture, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		guiGraphics.blit(new ResourceLocation("rped:textures/screens/op_inventory.png"), this.leftPos + -118, this.topPos + -6, 0, 0, 234, 87, 234, 87);
		guiGraphics.blit(new ResourceLocation("rped:textures/screens/inventory_clocks.png"), this.leftPos + -89, this.topPos + -121, 0, 0, 176, 176, 176, 176);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
	}

	private void send(int id) {
		OverNetwork.CHANNEL.sendToServer(new InventoryButtonMessage(id, x, y, z));
		InventoryButtonMessage.handleButtonAction(entity, id, x, y, z);
	}

	@Override
	public void init() {
		super.init();
		imagebutton_button_live = new ImageButton(this.leftPos + 95, this.topPos + -52, 18, 22, 0, 0, 22, new ResourceLocation("rped:textures/screens/atlas/imagebutton_button_live.png"), 18, 44, e -> send(0));
		this.addRenderableWidget(imagebutton_button_live);
		imagebutton_button_clock = new ImageButton(this.leftPos + -116, this.topPos + -88, 18, 22, 0, 0, 22, new ResourceLocation("rped:textures/screens/atlas/imagebutton_button_clock.png"), 18, 44, e -> send(1));
		this.addRenderableWidget(imagebutton_button_clock);
		imagebutton_call_live = new ImageButton(this.leftPos + -116, this.topPos + -54, 18, 22, 0, 0, 22, new ResourceLocation("rped:textures/screens/atlas/imagebutton_call_live.png"), 18, 44, e -> send(2));
		this.addRenderableWidget(imagebutton_call_live);
		imagebutton_lore_live = new ImageButton(this.leftPos + 95, this.topPos + -87, 18, 22, 0, 0, 22, new ResourceLocation("rped:textures/screens/atlas/imagebutton_lore_live.png"), 18, 44, e -> send(3));
		this.addRenderableWidget(imagebutton_lore_live);
	}
}
