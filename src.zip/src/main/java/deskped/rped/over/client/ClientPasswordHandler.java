package deskped.rped.over.client;

import deskped.rped.over.client.gui.InventoryPasswordScreen;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE, modid = "rped")
public class ClientPasswordHandler {

    private static int openTicksLeft = -1;

    public static void scheduleOpen() {
        openTicksLeft = 5;
    }

    public static void applyImmortalState(boolean val) {
        InventoryPasswordScreen.immortalState = val;
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof InventoryPasswordScreen screen) {
            screen.refreshImmortalButton();
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || openTicksLeft <= 0) return;
        openTicksLeft--;
        if (openTicksLeft == 0) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.screen != null && !(mc.screen instanceof InventoryPasswordScreen)) {
                mc.setScreen(new InventoryPasswordScreen(mc.screen));
            }
        }
    }
}
