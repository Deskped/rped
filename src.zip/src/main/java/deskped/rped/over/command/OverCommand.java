package deskped.rped.over.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import deskped.rped.over.capability.IQuestProgress;
import deskped.rped.over.capability.QuestProgressProvider;
import deskped.rped.over.network.OpenQuestGuiPacket;
import deskped.rped.over.network.OverNetwork;
import deskped.rped.over.network.SyncQuestProgressPacket;
import deskped.rped.over.util.L10n;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

@Mod.EventBusSubscriber
public class OverCommand {

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        dispatcher.register(
            Commands.literal("rped")
                .then(Commands.literal("clock")
                    .then(Commands.literal("progress")
                        .then(Commands.argument("nick", StringArgumentType.word())
                            .executes(ctx -> executeProgress(ctx, StringArgumentType.getString(ctx, "nick"))))
                        .executes(OverCommand::executeProgressSelf))
                    .then(Commands.literal("clear")
                        .requires(src -> src.hasPermission(2))
                        .then(Commands.argument("nick", StringArgumentType.word())
                            .executes(ctx -> executeClearOther(ctx, StringArgumentType.getString(ctx, "nick"))))
                        .executes(OverCommand::executeClearSelf))
                )
                .then(Commands.literal("unequip")
                    .requires(src -> src.hasPermission(2))
                    .then(Commands.argument("nick", StringArgumentType.word())
                        .executes(ctx -> executeUnequip(ctx.getSource().getServer().getPlayerList().getPlayerByName(StringArgumentType.getString(ctx, "nick")), ctx)))
                    .executes(ctx -> {
                        try { return executeUnequip(ctx.getSource().getPlayerOrException(), ctx); }
                        catch (Exception e) { ctx.getSource().sendFailure(Component.literal(L10n.Msg.mustBePlayer())); return 0; }
                    }))
        );
    }

    private static int executeUnequip(ServerPlayer player, CommandContext<CommandSourceStack> ctx) {
        if (player == null) {
            ctx.getSource().sendFailure(Component.literal(deskped.rped.over.util.L10n.t("Player not found", "\u0418\u0433\u0440\u043e\u043a \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d")));
            return 0;
        }
        deskped.rped.over.OverGate.setLocked(player, false);
        net.minecraft.world.item.ItemStack chest = player.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.CHEST);
        if (deskped.rped.over.OverGate.isRlere(chest)) {
            net.minecraft.world.item.ItemStack give = chest.copy();
            player.setItemSlot(net.minecraft.world.entity.EquipmentSlot.CHEST, net.minecraft.world.item.ItemStack.EMPTY);
            if (!player.getInventory().add(give))
                player.drop(give, false);
        }
        player.sendSystemMessage(Component.literal(deskped.rped.over.util.L10n.t("Rlere removed", "\u0420\u044d\u043b\u0435 \u0441\u043d\u044f\u0442\u043e")));
        return 1;
    }

    private static int executeProgressSelf(CommandContext<CommandSourceStack> ctx) {
        try {
            ServerPlayer player = ctx.getSource().getPlayerOrException();
            player.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap ->
                OverNetwork.CHANNEL.send(
                    PacketDistributor.PLAYER.with(() -> player),
                    new OpenQuestGuiPacket(player.getGameProfile().getName(), cap.serializeNBT())
                )
            );
        } catch (Exception e) {
            ctx.getSource().sendFailure(Component.literal(L10n.Msg.mustBePlayer()));
        }
        return 1;
    }

    private static int executeProgress(CommandContext<CommandSourceStack> ctx, String nick) {
        ServerPlayer requester;
        try { requester = ctx.getSource().getPlayerOrException(); }
        catch (Exception e) { ctx.getSource().sendFailure(Component.literal(L10n.Msg.mustBePlayer())); return 0; }

        ServerPlayer target = ctx.getSource().getServer().getPlayerList().getPlayerByName(nick);
        if (target == null) { ctx.getSource().sendFailure(Component.literal(L10n.Msg.playerNotFound(nick))); return 0; }

        final ServerPlayer req = requester;
        target.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap ->
            OverNetwork.CHANNEL.send(
                PacketDistributor.PLAYER.with(() -> req),
                new OpenQuestGuiPacket(nick, cap.serializeNBT())
            )
        );
        return 1;
    }

    private static int executeClearSelf(CommandContext<CommandSourceStack> ctx) {
        try {
            ServerPlayer player = ctx.getSource().getPlayerOrException();
            player.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap -> {
                cap.clearAllProgress();
                syncAndNotify(player, cap, L10n.Msg.cleared());
            });
            player.getCapability(deskped.rped.over.capability.PlayerRelicInventoryProvider.RELIC_INVENTORY).ifPresent(handler -> {
                for (int i = 0; i < handler.getSlots(); i++) {
                    handler.setStackInSlot(i, net.minecraft.world.item.ItemStack.EMPTY);
                }
            });
        } catch (Exception e) {
            ctx.getSource().sendFailure(Component.literal(L10n.Msg.mustBePlayer()));
        }
        return 1;
    }

    private static int executeClearOther(CommandContext<CommandSourceStack> ctx, String nick) {
        ServerPlayer target = ctx.getSource().getServer().getPlayerList().getPlayerByName(nick);
        if (target == null) { ctx.getSource().sendFailure(Component.literal(L10n.Msg.playerNotFound(nick))); return 0; }
        target.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap -> {
            cap.clearAllProgress();
            syncAndNotify(target, cap, L10n.Msg.clearedByOp());
            ctx.getSource().sendSuccess(() -> Component.literal(L10n.Msg.clearedOther(nick)), true);
        });
        target.getCapability(deskped.rped.over.capability.PlayerRelicInventoryProvider.RELIC_INVENTORY).ifPresent(handler -> {
            for (int i = 0; i < handler.getSlots(); i++) {
                handler.setStackInSlot(i, net.minecraft.world.item.ItemStack.EMPTY);
            }
        });
        return 1;
    }

    private static void syncAndNotify(ServerPlayer player, IQuestProgress cap, String msg) {
        OverNetwork.CHANNEL.send(
            PacketDistributor.PLAYER.with(() -> player),
            new SyncQuestProgressPacket(cap.serializeNBT())
        );
        player.sendSystemMessage(Component.literal(msg));
    }
}
