package deskped.rped.over.command;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.client.Minecraft;
import net.minecraft.commands.Commands;

import deskped.rped.over.client.gui.CallCenterScreen;

@Mod.EventBusSubscriber(value = Dist.CLIENT)
public class CallCenterCommand {

    @SubscribeEvent
    public static void registerClientCommand(RegisterClientCommandsEvent event) {
        event.getDispatcher().register(
            Commands.literal("rped")
                .then(
                    Commands.literal("call")
                        .executes(context -> {
                            Minecraft mc = Minecraft.getInstance();
                            if (mc != null) {
                                mc.execute(() -> mc.setScreen(new CallCenterScreen()));
                            }
                            return 1;
                        })
                )
        );
    }
}
