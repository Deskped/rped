package deskped.rped.over.inventory;

import net.minecraftforge.items.SlotItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.core.BlockPos;

import java.util.function.Supplier;
import java.util.Map;
import java.util.HashMap;
import java.util.Collections;

import deskped.rped.over.init.OverMenus;

public class StorageMenu extends AbstractContainerMenu implements OverMenus.MenuAccessor {

	public static final int STORAGE_SLOTS = 192;

	public final Map<String, Object> menuState = new HashMap<>() {
		@Override
		public Object put(String key, Object value) {
			if (!this.containsKey(key) && this.size() >= 196)
				return null;
			return super.put(key, value);
		}
	};
	public final Level world;
	public final Player entity;
	public int x, y, z;
	private ContainerLevelAccess access = ContainerLevelAccess.NULL;
	private IItemHandler internal;
	private final Map<Integer, Slot> customSlots = new HashMap<>();
	private boolean bound = false;
	private Supplier<Boolean> boundItemMatcher = null;
	private Entity boundEntity = null;
	private BlockEntity boundBlockEntity = null;

	public StorageMenu(int id, Inventory inv, FriendlyByteBuf extraData) {
		super(OverMenus.STORAGE.get(), id);
		this.entity = inv.player;
		this.world = inv.player.level();
		this.internal = new ItemStackHandler(STORAGE_SLOTS);
		BlockPos pos = null;
		if (extraData != null) {
			pos = extraData.readBlockPos();
			this.x = pos.getX();
			this.y = pos.getY();
			this.z = pos.getZ();
			access = ContainerLevelAccess.create(world, pos);
		}
		if (pos != null) {
			if (extraData.readableBytes() == 1) {
				byte hand = extraData.readByte();
				ItemStack itemstack = hand == 0 ? this.entity.getMainHandItem() : this.entity.getOffhandItem();
				this.boundItemMatcher = () -> itemstack == (hand == 0 ? this.entity.getMainHandItem() : this.entity.getOffhandItem());
				itemstack.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
					this.internal = capability;
					this.bound = true;
				});
			} else if (extraData.readableBytes() > 1) {
				extraData.readByte();
				boundEntity = world.getEntity(extraData.readVarInt());
				if (boundEntity != null)
					boundEntity.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
						this.internal = capability;
						this.bound = true;
					});
			} else {
				boundBlockEntity = this.world.getBlockEntity(pos);
				if (boundBlockEntity != null)
					boundBlockEntity.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
						this.internal = capability;
						this.bound = true;
					});
			}
		}

		int[][] positions = {
			{-214,-123},{-196,-123},{-178,-123},{-160,-123},{-142,-123},{-124,-123},{-106,-123},
			{-214,-105},{-196,-105},{-178,-105},{-160,-105},{-142,-105},{-124,-105},{-106,-105},
			{-214,-87},{-196,-87},{-178,-87},{-160,-87},{-142,-87},{-124,-87},{-106,-87},
			{-214,-69},{-196,-69},{-178,-69},{-160,-69},{-142,-69},{-124,-69},{-106,-69},
			{-214,-51},{-196,-51},{-178,-51},{-160,-51},{-142,-51},{-124,-51},{-106,-51},
			{-214,-33},{-196,-33},{-178,-33},{-160,-33},{-142,-33},{-124,-33},{-106,-33},
			{-214,-3},{-196,-3},{-178,-3},{-160,-3},{-142,-3},{-124,-3},{-106,-3},
			{-214,15},{-196,15},{-178,15},{-160,15},{-142,15},{-124,15},{-106,15},
			{-214,33},{-196,33},{-178,33},{-160,33},{-142,33},{-124,33},{-106,33},
			{-214,51},{-196,51},{-178,51},{-160,51},{-142,51},{-124,51},{-106,51},
			{-80,-123},{-62,-123},{-44,-123},{-26,-123},{-8,-123},{10,-123},{28,-123},{46,-123},{64,-123},
			{-80,-105},{-62,-105},{-44,-105},{-26,-105},{-8,-105},{10,-105},{28,-105},{46,-105},{64,-105},
			{-80,-87},{-62,-87},{-44,-87},{-26,-87},{-8,-87},{10,-87},{28,-87},{46,-87},{64,-87},
			{-80,-69},{-62,-69},{-44,-69},{-26,-69},{-8,-69},{10,-69},{28,-69},{46,-69},{64,-69},
			{-80,-51},{-62,-51},{-44,-51},{-26,-51},{-8,-51},{10,-51},{28,-51},{46,-51},{64,-51},
			{-80,-33},{-62,-33},{-44,-33},{-26,-33},{-8,-33},{10,-33},{28,-33},{46,-33},{64,-33},
			{90,-123},{108,-123},{126,-123},{144,-123},{162,-123},{180,-123},{198,-123},
			{90,-105},{108,-105},{126,-105},{144,-105},{162,-105},{180,-105},{198,-105},
			{90,-87},{108,-87},{126,-87},{144,-87},{162,-87},{180,-87},{198,-87},
			{90,-69},{108,-69},{126,-69},{144,-69},{162,-69},{180,-69},{198,-69},
			{90,-51},{108,-51},{126,-51},{144,-51},{162,-51},{180,-51},{198,-51},
			{90,-33},{108,-33},{126,-33},{144,-33},{162,-33},{180,-33},{198,-33},
			{90,-3},{108,-3},{126,-3},{144,-3},{162,-3},{180,-3},{198,-3},
			{90,15},{108,15},{126,15},{144,15},{162,15},{180,15},{198,15},
			{90,33},{108,33},{126,33},{144,33},{162,33},{180,33},{198,33},
			{90,51},{108,51},{126,51},{144,51},{162,51},
		};

		int handlerSize = this.internal.getSlots();
		int slotsToRegister = Math.min(handlerSize, positions.length);
		for (int i = 0; i < slotsToRegister; i++) {
			final int slotIndex = i;
			this.customSlots.put(i, this.addSlot(new SlotItemHandler(internal, i, positions[i][0], positions[i][1]) {
				private final int slot = slotIndex;
			}));
		}

		for (int si = 0; si < 3; ++si)
			for (int sj = 0; sj < 9; ++sj)
				this.addSlot(new Slot(inv, sj + (si + 1) * 9, -88 + 8 + sj * 18, -83 + 84 + si * 18));
		for (int si = 0; si < 9; ++si)
			this.addSlot(new Slot(inv, si, -88 + 8 + si * 18, -83 + 142));
	}

	@Override
	public boolean stillValid(Player player) {
		if (this.bound) {
			if (this.boundItemMatcher != null)
				return this.boundItemMatcher.get();
			else if (this.boundBlockEntity != null)
				return AbstractContainerMenu.stillValid(this.access, player, this.boundBlockEntity.getBlockState().getBlock());
			else if (this.boundEntity != null)
				return this.boundEntity.isAlive();
		}
		return true;
	}

	@Override
	public ItemStack quickMoveStack(Player playerIn, int index) {
		int storageSize = this.internal.getSlots();
		ItemStack itemstack = ItemStack.EMPTY;
		Slot slot = this.slots.get(index);
		if (slot != null && slot.hasItem()) {
			ItemStack itemstack1 = slot.getItem();
			itemstack = itemstack1.copy();
			if (index < storageSize) {
				if (!this.moveItemStackTo(itemstack1, storageSize, this.slots.size(), true))
					return ItemStack.EMPTY;
				slot.onQuickCraft(itemstack1, itemstack);
			} else if (!this.moveItemStackTo(itemstack1, 0, storageSize, false)) {
				if (index < storageSize + 27) {
					if (!this.moveItemStackTo(itemstack1, storageSize + 27, this.slots.size(), true))
						return ItemStack.EMPTY;
				} else {
					if (!this.moveItemStackTo(itemstack1, storageSize, storageSize + 27, false))
						return ItemStack.EMPTY;
				}
				return ItemStack.EMPTY;
			}
			if (itemstack1.isEmpty()) {
				slot.setByPlayer(ItemStack.EMPTY);
			} else {
				slot.setChanged();
			}
			if (itemstack1.getCount() == itemstack.getCount()) {
				return ItemStack.EMPTY;
			}
			slot.onTake(playerIn, itemstack1);
		}
		return itemstack;
	}

	@Override
	protected boolean moveItemStackTo(ItemStack p_38904_, int p_38905_, int p_38906_, boolean p_38907_) {
		boolean flag = false;
		int i = p_38905_;
		if (p_38907_) {
			i = p_38906_ - 1;
		}
		if (p_38904_.isStackable()) {
			while (!p_38904_.isEmpty()) {
				if (p_38907_) {
					if (i < p_38905_) break;
				} else if (i >= p_38906_) break;
				Slot slot = this.slots.get(i);
				ItemStack itemstack = slot.getItem();
				if (slot.mayPlace(itemstack) && !itemstack.isEmpty() && ItemStack.isSameItemSameTags(p_38904_, itemstack)) {
					int j = itemstack.getCount() + p_38904_.getCount();
					int maxSize = Math.min(slot.getMaxStackSize(), p_38904_.getMaxStackSize());
					if (j <= maxSize) {
						p_38904_.setCount(0);
						itemstack.setCount(j);
						slot.set(itemstack);
						flag = true;
					} else if (itemstack.getCount() < maxSize) {
						p_38904_.shrink(maxSize - itemstack.getCount());
						itemstack.setCount(maxSize);
						slot.set(itemstack);
						flag = true;
					}
				}
				if (p_38907_) --i; else ++i;
			}
		}
		if (!p_38904_.isEmpty()) {
			i = p_38907_ ? p_38906_ - 1 : p_38905_;
			while (true) {
				if (p_38907_) {
					if (i < p_38905_) break;
				} else if (i >= p_38906_) break;
				Slot slot1 = this.slots.get(i);
				ItemStack itemstack1 = slot1.getItem();
				if (itemstack1.isEmpty() && slot1.mayPlace(p_38904_)) {
					if (p_38904_.getCount() > slot1.getMaxStackSize()) {
						slot1.setByPlayer(p_38904_.split(slot1.getMaxStackSize()));
					} else {
						slot1.setByPlayer(p_38904_.split(p_38904_.getCount()));
					}
					slot1.setChanged();
					flag = true;
					break;
				}
				if (p_38907_) --i; else ++i;
			}
		}
		return flag;
	}

	@Override
	public void removed(Player playerIn) {
		super.removed(playerIn);
		if (!bound && playerIn instanceof ServerPlayer serverPlayer) {
			if (!serverPlayer.isAlive() || serverPlayer.hasDisconnected()) {
				for (int j = 0; j < internal.getSlots(); ++j) {
					playerIn.drop(internal.getStackInSlot(j), false);
					if (internal instanceof IItemHandlerModifiable ihm)
						ihm.setStackInSlot(j, ItemStack.EMPTY);
				}
			} else {
				for (int i = 0; i < internal.getSlots(); ++i) {
					playerIn.getInventory().placeItemBackInInventory(internal.getStackInSlot(i));
					if (internal instanceof IItemHandlerModifiable ihm)
						ihm.setStackInSlot(i, ItemStack.EMPTY);
				}
			}
		}
	}

	@Override
	public Map<Integer, Slot> getSlots() {
		return Collections.unmodifiableMap(customSlots);
	}

	@Override
	public Map<String, Object> getMenuState() {
		return menuState;
	}
}
