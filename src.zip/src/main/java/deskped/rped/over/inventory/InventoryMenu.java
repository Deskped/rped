package deskped.rped.over.inventory;

import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.items.SlotItemHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerContainerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.core.BlockPos;

import java.util.Map;
import java.util.HashMap;
import java.util.Collections;

import deskped.rped.over.capability.PlayerRelicInventoryProvider;
import deskped.rped.over.procedures.InventoryOpenWarningProcedure;
import deskped.rped.over.procedures.InventoryMusicProcedure;
import deskped.rped.over.init.OverItems;
import deskped.rped.over.init.OverMenus;

@Mod.EventBusSubscriber
public class InventoryMenu extends AbstractContainerMenu implements OverMenus.MenuAccessor {

	private static final String[] CLOCK_FOR_SLOT = {
		"alarm_clock", "anemometer", "angel_clock", "aqua_clock", "attitude_indicator",
		"chess_clock", "childhood_clock", "clock_of_the_seven_curses", "compass_clock", "demon_clock",
		"digital_clock", "dont_forget_clock", "fallen_clock", "glass_clock", "holographic_clock",
		"hourglass", "im_old_clock", "its_time_to_have_some_clock", "mechanical_crane_scales", "meter",
		"ok_clock", "paper_clock", "radio", "residence_clock", "scroll_clock",
		"sensor", "ships_clock", "stopwatch", "sundial", "sun_on_a_stick_with_a_clock",
		"totem_clock", "wall_clock", "wristwatch"
	};

	private static final int[][] RELIC_POS = {
		{-29, -93}, {-11, -93}, {7, -93},
		{-47, -75}, {-29, -75}, {-11, -75}, {7, -75}, {25, -75},
		{-65, -57}, {-47, -57}, {-29, -57}, {-11, -57}, {7, -57}, {25, -57}, {43, -57},
		{-65, -39}, {-47, -39}, {-29, -39}, {-11, -39}, {7, -39}, {25, -39}, {43, -39},
		{-65, -21}, {-47, -21}, {-29, -21}, {-11, -21}, {7, -21}, {25, -21}, {43, -21},
		{-29, -3}, {-11, -3}, {7, -3},
		{-11, 15}
	};

	public final Map<String, Object> menuState = new HashMap<>() {
		@Override
		public Object put(String key, Object value) {
			if (!this.containsKey(key) && this.size() >= 8)
				return null;
			return super.put(key, value);
		}
	};
	public final Level world;
	public final Player entity;
	public int x, y, z;
	private ContainerLevelAccess access = ContainerLevelAccess.NULL;
	private final Map<Integer, Slot> customSlots = new HashMap<>();

	private final ItemStackHandler relicHandler;
	private final ItemStackHandler storageSlotHandler = new ItemStackHandler(1);
	private final ItemStackHandler craftableHandler = new ItemStackHandler(1);

	public ItemStackHandler getRelicHandler() {
		return relicHandler;
	}

	public ItemStackHandler getStorageSlotHandler() {
		return storageSlotHandler;
	}

	public InventoryMenu(int id, Inventory inv, FriendlyByteBuf extraData) {
		super(OverMenus.INVENTORY.get(), id);
		this.entity = inv.player;
		this.world = inv.player.level();
		this.relicHandler = inv.player.getCapability(PlayerRelicInventoryProvider.RELIC_INVENTORY)
			.orElseGet(() -> new ItemStackHandler(PlayerRelicInventoryProvider.SLOTS));
		if (extraData != null) {
			BlockPos pos = extraData.readBlockPos();
			this.x = pos.getX();
			this.y = pos.getY();
			this.z = pos.getZ();
			access = ContainerLevelAccess.create(world, pos);
		}
		for (int si = 0; si < 3; ++si)
			for (int sj = 0; sj < 9; ++sj)
				this.addSlot(new Slot(inv, sj + (si + 1) * 9, -88 + 8 + sj * 18, -83 + 84 + si * 18));
		for (int si = 0; si < 9; ++si)
			this.addSlot(new Slot(inv, si, -88 + 8 + si * 18, -83 + 142));
		for (int i = 0; i < RELIC_POS.length; ++i) {
			final int slotIndex = i;
			final String allowed = "rped:" + CLOCK_FOR_SLOT[i];
			SlotItemHandler relic = new SlotItemHandler(relicHandler, slotIndex, RELIC_POS[i][0], RELIC_POS[i][1]) {
				@Override
				public boolean mayPlace(ItemStack stack) {
					ResourceLocation key = ForgeRegistries.ITEMS.getKey(stack.getItem());
					return key != null && key.toString().equals(allowed);
				}

				@Override
				public boolean mayPickup(Player p) {
					return false;
				}

				@Override
				public int getMaxStackSize() {
					return 1;
				}
			};
			this.addSlot(relic);
			customSlots.put(slotIndex, relic);
		}
		SlotItemHandler storage = new SlotItemHandler(storageSlotHandler, 0, -173, 36) {
			@Override
			public boolean mayPlace(ItemStack stack) {
				return stack.getItem() == OverItems.STORAGE_MODULE.get();
			}

			@Override
			public int getMaxStackSize() {
				return 1;
			}
		};
		this.addSlot(storage);
		customSlots.put(101, storage);
		SlotItemHandler craftable = new SlotItemHandler(craftableHandler, 0, 90, 51);
		this.addSlot(craftable);
		customSlots.put(100, craftable);
	}

	@Override
	public boolean stillValid(Player player) {
		return true;
	}

	@Override
	public ItemStack quickMoveStack(Player playerIn, int index) {
		ItemStack itemstack = ItemStack.EMPTY;
		Slot slot = this.slots.get(index);
		if (slot != null && slot.hasItem()) {
			ItemStack itemstack1 = slot.getItem();
			itemstack = itemstack1.copy();
			int playerStart = 0;
			int playerEnd = 36;
			int extraStart = 36;
			int extraEnd = this.slots.size();
			if (index >= extraStart) {
				if (!this.moveItemStackTo(itemstack1, playerStart, playerEnd, true))
					return ItemStack.EMPTY;
			} else {
				if (!this.moveItemStackTo(itemstack1, extraStart, extraEnd, false))
					return ItemStack.EMPTY;
			}
			if (itemstack1.isEmpty())
				slot.setByPlayer(ItemStack.EMPTY);
			else
				slot.setChanged();
			if (itemstack1.getCount() == itemstack.getCount())
				return ItemStack.EMPTY;
			slot.onTake(playerIn, itemstack1);
		}
		return itemstack;
	}

	@Override
	protected boolean moveItemStackTo(ItemStack stack, int start, int end, boolean reverse) {
		boolean flag = false;
		int i = reverse ? end - 1 : start;
		if (stack.isStackable()) {
			while (!stack.isEmpty() && (reverse ? i >= start : i < end)) {
				Slot slot = this.slots.get(i);
				ItemStack itemstack = slot.getItem();
				if (slot.mayPlace(itemstack) && !itemstack.isEmpty() && ItemStack.isSameItemSameTags(stack, itemstack)) {
					int j = itemstack.getCount() + stack.getCount();
					int maxSize = Math.min(slot.getMaxStackSize(), stack.getMaxStackSize());
					if (j <= maxSize) {
						stack.setCount(0);
						itemstack.setCount(j);
						slot.set(itemstack);
						flag = true;
					} else if (itemstack.getCount() < maxSize) {
						stack.shrink(maxSize - itemstack.getCount());
						itemstack.setCount(maxSize);
						slot.set(itemstack);
						flag = true;
					}
				}
				i += reverse ? -1 : 1;
			}
		}
		if (!stack.isEmpty()) {
			i = reverse ? end - 1 : start;
			while (reverse ? i >= start : i < end) {
				Slot slot1 = this.slots.get(i);
				ItemStack itemstack1 = slot1.getItem();
				if (itemstack1.isEmpty() && slot1.mayPlace(stack)) {
					if (stack.getCount() > slot1.getMaxStackSize())
						slot1.setByPlayer(stack.split(slot1.getMaxStackSize()));
					else
						slot1.setByPlayer(stack.split(stack.getCount()));
					slot1.setChanged();
					flag = true;
					break;
				}
				i += reverse ? -1 : 1;
			}
		}
		return flag;
	}

	@Override
	public Map<Integer, Slot> getSlots() {
		return Collections.unmodifiableMap(customSlots);
	}

	@Override
	public Map<String, Object> getMenuState() {
		return menuState;
	}

	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		Player entity = event.player;
		if (event.phase == TickEvent.Phase.END && entity.containerMenu instanceof InventoryMenu menu) {
			InventoryMusicProcedure.execute(entity);
		}
	}

	@SubscribeEvent
	public static void onContainerOpen(PlayerContainerEvent.Open event) {
		Player entity = event.getEntity();
		if (event.getContainer() instanceof InventoryMenu menu) {
			InventoryOpenWarningProcedure.execute(menu.world, menu.x, menu.y, menu.z, entity);
		}
	}
}