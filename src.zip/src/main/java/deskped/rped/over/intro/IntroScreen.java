package deskped.rped.over.intro;

// Это технологий CorPED, здесь дизайн/интерфейс менять под другой НЕЛЬЗЯ

import deskped.rped.RpedMod;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Checkbox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import org.lwjgl.glfw.GLFW;

public class IntroScreen extends Screen {
private static final String MOD_ID = "rped";
private static final ResourceLocation MUSIC = new ResourceLocation(MOD_ID, "music_begin");
private static final ResourceLocation TYPING_SOUND = new ResourceLocation(MOD_ID, "typing");

private final Screen parent;
private int currentSlide = 0;
private long slideStartTime = 0;
private static final long SLIDE_DURATION = 10000;
private String currentSubtitle = "";
private int subtitleProgress = 0;
private long lastTypingSound = 0;
private boolean showDialog = false;
private Checkbox skipCheckbox;
private boolean musicPlaying = false;
private RandomSource random = RandomSource.create();

private long spaceHoldStartTime = 0;
private boolean isHoldingSpace = false;
private static final long SKIP_HOLD_DURATION = 5000;

private static final int IMAGE_WIDTH = 1280;
private static final int IMAGE_HEIGHT = 720;

private static final String[] SUBTITLE_KEYS = {
    "",
    "rped.intro.slide2",
    "rped.intro.slide3",
    "rped.intro.slide4",
    "rped.intro.slide5",
    "rped.intro.slide6",
    "rped.intro.slide7",
    "rped.intro.slide8",
    "rped.intro.slide9",
    "rped.intro.slide10",
    "rped.intro.slide11",
    "rped.intro.slide12",
    "rped.intro.slide13"
};

public IntroScreen(Screen parent) {
    super(Component.literal("OverPED Intro"));
    this.parent = parent;
}

@Override
protected void init() {
    super.init();

    if (slideStartTime == 0) {
        slideStartTime = System.currentTimeMillis();
    }

    if (!musicPlaying) {
        try {
            SimpleSoundInstance sound = new SimpleSoundInstance(
                MUSIC,
                SoundSource.MASTER,
                0.3F,
                1.0F,
                random,
                false,
                0,
                SimpleSoundInstance.Attenuation.NONE,
                0.0D, 0.0D, 0.0D,
                true
            );
            Minecraft.getInstance().getSoundManager().play(sound);
            musicPlaying = true;
            RpedMod.LOGGER.info("Intro music started");
        } catch (Exception e) {
            RpedMod.LOGGER.error("Failed to play intro music", e);
        }
    }

    if (showDialog) {
        initDialogWidgets();
    }
}

@Override
public void resize(Minecraft minecraft, int width, int height) {
    boolean wasShowingDialog = this.showDialog;
    super.resize(minecraft, width, height);
    this.showDialog = wasShowingDialog;
}

private void initDialogWidgets() {
    this.minecraft.setScreen(null);
}

@Override
public void tick() {
    super.tick();

    if (showDialog) return;

    long currentTime = System.currentTimeMillis();
    long elapsed = currentTime - slideStartTime;

    if (isHoldingSpace) {
        long holdDuration = currentTime - spaceHoldStartTime;
        if (holdDuration >= SKIP_HOLD_DURATION) {
            RpedMod.LOGGER.info("Intro skipped by holding space");
            showEndDialog();
            isHoldingSpace = false;
            return;
        }
    }

    if (currentSlide < SUBTITLE_KEYS.length && !SUBTITLE_KEYS[currentSlide].isEmpty()) {
        String fullText = Component.translatable(SUBTITLE_KEYS[currentSlide]).getString();
        int targetProgress = (int) ((elapsed % SLIDE_DURATION) / 10);

        if (subtitleProgress < fullText.length() && subtitleProgress < targetProgress) {
            subtitleProgress++;
            currentSubtitle = fullText.substring(0, subtitleProgress);

            if (currentTime - lastTypingSound > 10) {
                try {
                    SoundEvent soundEvent = SoundEvent.createVariableRangeEvent(TYPING_SOUND);
                    SimpleSoundInstance sound = new SimpleSoundInstance(
                        TYPING_SOUND,
                        SoundSource.MASTER,
                        0.5F,
                        1.0F,
                        random,
                        false,
                        0,
                        SimpleSoundInstance.Attenuation.NONE,
                        0.0D, 0.0D, 0.0D,
                        true
                    );
                    Minecraft.getInstance().getSoundManager().play(sound);
                } catch (Exception e) {
                    RpedMod.LOGGER.debug("Typing sound failed", e);
                }
                lastTypingSound = currentTime;
            }
        }
    }

    if (elapsed >= SLIDE_DURATION) {
        currentSlide++;
        slideStartTime = currentTime;
        subtitleProgress = 0;
        currentSubtitle = "";

        if (currentSlide >= SUBTITLE_KEYS.length) {
            showEndDialog();
        }
    }
}

@Override
public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
    if (keyCode == GLFW.GLFW_KEY_SPACE && !showDialog) {
        if (!isHoldingSpace) {
            isHoldingSpace = true;
            spaceHoldStartTime = System.currentTimeMillis();
        }
        return true;
    }
    return super.keyPressed(keyCode, scanCode, modifiers);
}

@Override
public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
    if (keyCode == GLFW.GLFW_KEY_SPACE) {
        isHoldingSpace = false;
        spaceHoldStartTime = 0;
        return true;
    }
    return super.keyReleased(keyCode, scanCode, modifiers);
}

@Override
public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
    if (showDialog) {
        renderDialog(graphics, mouseX, mouseY, partialTicks);
        return;
    }

    graphics.fill(0, 0, this.width, this.height, 0xFF000000);

    renderSlideImage(graphics);
    renderVHSEffect(graphics);

    if (currentSlide < SUBTITLE_KEYS.length && !SUBTITLE_KEYS[currentSlide].isEmpty()) {
        if (currentSlide == 12) {
            int textWidth = this.font.width(currentSubtitle);
            graphics.drawString(this.font, currentSubtitle,
                (this.width - textWidth) / 2,
                this.height / 2,
                0xFFFFFF, true);
        } else {
            int textWidth = this.font.width(currentSubtitle);
            int textX = (this.width - textWidth) / 2;
            int textY = this.height - 80;

            graphics.fill(textX - 10, textY - 5, textX + textWidth + 10, textY + 15, 0x80000000);
            graphics.drawString(this.font, currentSubtitle, textX, textY, 0xFFFFFF, true);
        }
    }

    renderTimerBar(graphics);
    renderSkipHint(graphics);

    super.render(graphics, mouseX, mouseY, partialTicks);
}

private void renderSlideImage(GuiGraphics graphics) {
    try {
        ResourceLocation imageLocation = new ResourceLocation(MOD_ID, "textures/gui/intro/slide_" + currentSlide + ".png");

        float scale = 0.25f;
        int displayWidth = Math.max(1, (int) (IMAGE_WIDTH * scale));
        int displayHeight = Math.max(1, (int) (IMAGE_HEIGHT * scale));

        int x = (this.width - displayWidth) / 2;
        int y = (this.height - displayHeight) / 2;

        RenderSystem.setShaderTexture(0, imageLocation);
        graphics.blit(imageLocation, x, y, 0, 0, displayWidth, displayHeight, displayWidth, displayHeight);
    } catch (Exception e) {
        RpedMod.LOGGER.error("Failed to render slide image", e);
    }
}

private void renderVHSEffect(GuiGraphics graphics) {
    for (int y = 0; y < this.height; y += 3) {
        graphics.fill(0, y, this.width, y + 1, 0x30000000);
    }

    if (random.nextFloat() < 0.05f) {
        int glitchY = random.nextInt(this.height);
        int glitchHeight = random.nextInt(20) + 5;
        int offset = random.nextInt(20) - 10;
        graphics.fill(offset, glitchY, this.width + offset, glitchY + glitchHeight, 0x40FFFFFF);
    }

    drawVignette(graphics);
}

private void drawVignette(GuiGraphics graphics) {
    int vignetteAlpha = 80;
    graphics.fill(0, 0, this.width, 50, 0x00000000 | (vignetteAlpha << 24));
    graphics.fill(0, this.height - 50, this.width, this.height, 0x00000000 | (vignetteAlpha << 24));
    graphics.fill(0, 0, 50, this.height, 0x00000000 | (vignetteAlpha << 24));
    graphics.fill(this.width - 50, 0, this.width, this.height, 0x00000000 | (vignetteAlpha << 24));
}

private void renderTimerBar(GuiGraphics graphics) {
    long elapsed = System.currentTimeMillis() - slideStartTime;
    float progress = 1.0f - (float) elapsed / SLIDE_DURATION;
    if (progress < 0) progress = 0;

    int barWidth = this.width * 3 / 4;
    int barHeight = 4;
    int x = (this.width - barWidth) / 2;
    int y = this.height - 30;

    graphics.fill(x, y, x + barWidth, y + barHeight, 0x80000000);

    int progressWidth = (int) (barWidth * progress);
    graphics.fill(x, y, x + progressWidth, y + barHeight, 0xFFFFFFFF);

    int secondsLeft = (int) Math.ceil((SLIDE_DURATION - elapsed) / 1000.0);
    String timerText = secondsLeft + "s";
    int textWidth = this.font.width(timerText);
    graphics.drawString(this.font, timerText, x + barWidth + 10, y - 3, 0xFFFFFF, false);
}

private void renderSkipHint(GuiGraphics graphics) {
    Component skipHint = Component.translatable("rped.intro.hold_space_to_skip");
    int hintWidth = this.font.width(skipHint.getString());
    int hintX = (this.width - hintWidth) / 2;
    int hintY = this.height - 15;

    graphics.drawString(this.font, skipHint.getString(), hintX, hintY, 0x99FFFFFF, false);

    if (isHoldingSpace) {
        long holdDuration = System.currentTimeMillis() - spaceHoldStartTime;
        float skipProgress = Math.min(1.0f, (float) holdDuration / SKIP_HOLD_DURATION);

        int skipBarWidth = 200;
        int skipBarHeight = 3;
        int skipBarX = (this.width - skipBarWidth) / 2;
        int skipBarY = this.height - 8;

        graphics.fill(skipBarX, skipBarY, skipBarX + skipBarWidth, skipBarY + skipBarHeight, 0x80000000);

        int skipProgressWidth = (int) (skipBarWidth * skipProgress);
        graphics.fill(skipBarX, skipBarY, skipBarX + skipProgressWidth, skipBarY + skipBarHeight, 0xFFFFFFFF);

        int secondsLeft = (int) Math.ceil((SKIP_HOLD_DURATION - holdDuration) / 1000.0);
        String progressText = secondsLeft + "s";
        int progressTextWidth = this.font.width(progressText);
        graphics.drawString(this.font, progressText, skipBarX + skipBarWidth + 5, skipBarY - 2, 0xFFFFFF, false);
    }
}

private void showEndDialog() {
    if (musicPlaying) {
        try {
            Minecraft.getInstance().getSoundManager().stop(null, SoundSource.MASTER);
        } catch (Exception e) {
        }
        musicPlaying = false;
    }
    this.minecraft.setScreen(null);
}

@Override
public void removed() {
    super.removed();

    if (musicPlaying) {
        try {
            Minecraft.getInstance().getSoundManager().stop(null, SoundSource.MASTER);
            RpedMod.LOGGER.info("Music stopped on screen close");
        } catch (Exception e) {
            RpedMod.LOGGER.error("Failed to stop music on close", e);
        }
        musicPlaying = false;
    }
}

private void renderDialog(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
    graphics.fill(0, 0, this.width, this.height, 0xCC000000);

    int boxWidth = 300;
    int boxHeight = 150;
    int x = (this.width - boxWidth) / 2;
    int y = (this.height - boxHeight) / 2;

    graphics.fill(x, y, x + boxWidth, y + boxHeight, 0xFF1a1a1a);

    graphics.fill(x, y, x + boxWidth, y + 2, 0xFFFFFFFF);
    graphics.fill(x, y + boxHeight - 2, x + boxWidth, y + boxHeight, 0xFFFFFFFF);
    graphics.fill(x, y, x + 2, y + boxHeight, 0xFFFFFFFF);
    graphics.fill(x + boxWidth - 2, y, x + boxWidth, y + boxHeight, 0xFFFFFFFF);

    Component question = Component.translatable("rped.intro.play_every_time");
    int textWidth = this.font.width(question.getString());
    graphics.drawString(this.font, question.getString(), (this.width - textWidth) / 2, y + 20, 0xFFFFFF, false);

    super.render(graphics, mouseX, mouseY, partialTicks);
}

@Override
public boolean isPauseScreen() {
    return false;
}

@Override
public boolean shouldCloseOnEsc() {
    return false;
}

}
