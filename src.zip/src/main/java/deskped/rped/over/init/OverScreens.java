package deskped.rped.over.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

import deskped.rped.over.client.gui.InventoryScreen;
import deskped.rped.over.client.gui.WarningScreen;
import deskped.rped.over.client.gui.StorageScreen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class OverScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(OverMenus.INVENTORY.get(), InventoryScreen::new);
			MenuScreens.register(OverMenus.WARNING.get(), WarningScreen::new);
			MenuScreens.register(OverMenus.STORAGE.get(), StorageScreen::new);
		});
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}
}
