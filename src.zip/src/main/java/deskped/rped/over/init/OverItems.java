package deskped.rped.over.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;

public class OverItems {
	public static final RegistryObject<Item> STORAGE_MODULE = RegistryObject.create(new ResourceLocation("rped", "storage_module"), ForgeRegistries.ITEMS);
}
