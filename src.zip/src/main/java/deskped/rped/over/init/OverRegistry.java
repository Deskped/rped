package deskped.rped.over.init;

import net.minecraftforge.registries.RegisterEvent;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.IContainerFactory;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.AbstractContainerMenu;

import deskped.rped.over.potion.ImmortalMobEffect;
import deskped.rped.over.inventory.InventoryMenu;
import deskped.rped.over.inventory.StorageMenu;
import deskped.rped.over.inventory.WarningMenu;
import deskped.rped.over.capability.QuestProgressProvider;
import deskped.rped.over.capability.PlayerRelicInventoryProvider;
import deskped.rped.over.network.OverNetwork;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class OverRegistry {

	@SubscribeEvent
	public static void onRegister(RegisterEvent event) {
		event.register(ForgeRegistries.Keys.MOB_EFFECTS, helper -> {
			helper.register(new ResourceLocation("rped", "immortal"), new ImmortalMobEffect());
		});
		event.register(ForgeRegistries.Keys.SOUND_EVENTS, helper -> {
			for (String name : new String[]{"player_open_quest", "music_begin", "electro", "yayayayayayayay",
					"secretultrasuperpuperargcodeforyou", "pickupthephone", "onetwothree", "killyourself",
					"kaboom", "iqdown", "imdolbaebkstati", "golosovoysedmogomarta", "butpleeeeeasee"}) {
				helper.register(new ResourceLocation("rped", name),
						SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", name)));
			}
		});
		event.register(ForgeRegistries.Keys.MENU_TYPES, helper -> {
			helper.register(new ResourceLocation("rped", "over_inventory"),
					IForgeMenuType.create((IContainerFactory<InventoryMenu>) InventoryMenu::new));
			helper.register(new ResourceLocation("rped", "over_warning"),
					IForgeMenuType.create((IContainerFactory<WarningMenu>) WarningMenu::new));
			helper.register(new ResourceLocation("rped", "over_storage"),
					IForgeMenuType.create((IContainerFactory<StorageMenu>) StorageMenu::new));
		});
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		QuestProgressProvider.register(event);
		PlayerRelicInventoryProvider.register(event);
	}

	@SubscribeEvent
	public static void setup(FMLCommonSetupEvent event) {
		event.enqueueWork(OverNetwork::register);
	}
}