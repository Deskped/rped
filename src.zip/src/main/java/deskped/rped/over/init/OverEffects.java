package deskped.rped.over.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.ResourceLocation;

import deskped.rped.over.procedures.ImmortalEffiektProcedure;

@Mod.EventBusSubscriber
public class OverEffects {
	public static final RegistryObject<MobEffect> IMMORTAL = RegistryObject.create(new ResourceLocation("rped", "immortal"), ForgeRegistries.MOB_EFFECTS);

	@SubscribeEvent
	public static void onMobHurt(LivingHurtEvent event) {
		LivingEntity entity = event.getEntity();
		if (entity.hasEffect(OverEffects.IMMORTAL.get())) {
			ImmortalEffiektProcedure.execute(event.getSource(), entity);
		}
	}
}
