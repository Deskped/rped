package deskped.rped.over.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

public class OverSounds {
	public static final RegistryObject<SoundEvent> PLAYER_OPEN_QUEST = reg("player_open_quest");
	public static final RegistryObject<SoundEvent> MUSIC_BEGIN = reg("music_begin");
	public static final RegistryObject<SoundEvent> ELECTRO = reg("electro");
	public static final RegistryObject<SoundEvent> YAYAYAYAYAYAYAY = reg("yayayayayayayay");
	public static final RegistryObject<SoundEvent> SECRET_ARG = reg("secretultrasuperpuperargcodeforyou");
	public static final RegistryObject<SoundEvent> PICKUPTHEPHONE = reg("pickupthephone");
	public static final RegistryObject<SoundEvent> ONETWOTHREE = reg("onetwothree");
	public static final RegistryObject<SoundEvent> KILLYOURSELF = reg("killyourself");
	public static final RegistryObject<SoundEvent> KABOOM = reg("kaboom");
	public static final RegistryObject<SoundEvent> IQDOWN = reg("iqdown");
	public static final RegistryObject<SoundEvent> IMDOLBAEBKSTATI = reg("imdolbaebkstati");
	public static final RegistryObject<SoundEvent> GOLOSOVOYSEDMOGOMARTA = reg("golosovoysedmogomarta");
	public static final RegistryObject<SoundEvent> BUTPLEEEEEASEE = reg("butpleeeeeasee");

	private static RegistryObject<SoundEvent> reg(String name) {
		return RegistryObject.create(new ResourceLocation("rped", name), ForgeRegistries.SOUND_EVENTS);
	}
}
