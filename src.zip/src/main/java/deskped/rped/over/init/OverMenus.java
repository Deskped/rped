package deskped.rped.over.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.resources.ResourceLocation;

import java.util.Map;

import deskped.rped.over.inventory.InventoryMenu;
import deskped.rped.over.inventory.StorageMenu;
import deskped.rped.over.inventory.WarningMenu;

public class OverMenus {
	public static final RegistryObject<MenuType<InventoryMenu>> INVENTORY = RegistryObject.create(new ResourceLocation("rped", "over_inventory"), ForgeRegistries.MENU_TYPES);
	public static final RegistryObject<MenuType<WarningMenu>> WARNING = RegistryObject.create(new ResourceLocation("rped", "over_warning"), ForgeRegistries.MENU_TYPES);
	public static final RegistryObject<MenuType<StorageMenu>> STORAGE = RegistryObject.create(new ResourceLocation("rped", "over_storage"), ForgeRegistries.MENU_TYPES);

	public interface MenuAccessor {
		Map<Integer, Slot> getSlots();

		Map<String, Object> getMenuState();
	}
}
