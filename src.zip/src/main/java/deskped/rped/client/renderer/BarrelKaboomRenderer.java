package deskped.rped.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import deskped.rped.entity.BarrelKaboomEntity;
import deskped.rped.client.model.animations.BarrelPowderAnimationStart;
import deskped.rped.client.model.ModelBarrelPowder;

public class BarrelKaboomRenderer extends MobRenderer<BarrelKaboomEntity, ModelBarrelPowder<BarrelKaboomEntity>> {
	public BarrelKaboomRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(ModelBarrelPowder.LAYER_LOCATION)), 1f);
	}

	@Override
	public ResourceLocation getTextureLocation(BarrelKaboomEntity entity) {
		return new ResourceLocation("rped:textures/entities/barrelpowder.png");
	}

	private static final class AnimatedModel extends ModelBarrelPowder<BarrelKaboomEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<BarrelKaboomEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(BarrelKaboomEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animate(entity.animationState0, BarrelPowderAnimationStart.start, ageInTicks, 1f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(BarrelKaboomEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}