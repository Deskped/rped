package deskped.rped.client.renderer.block;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import deskped.rped.procedures.EzonetIfTwoToTwoProcedure;
import deskped.rped.procedures.EzonetIfOpenProcedure;
import deskped.rped.procedures.EzonetIfOneToTwoProcedure;
import deskped.rped.procedures.EzonetIfCloseProcedure;
import deskped.rped.init.RpedModBlockEntities;
import deskped.rped.client.model.animations.ezonetAnimationTwoToTwo;
import deskped.rped.client.model.animations.ezonetAnimationOneToTwo;
import deskped.rped.client.model.animations.ezonetAnimationIdleClose;
import deskped.rped.client.model.animations.ezonetAnimationIdle;
import deskped.rped.client.model.Modelezonet;
import deskped.rped.block.entity.EzonetBlockEntity;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class EzonetRenderer implements BlockEntityRenderer<EzonetBlockEntity> {
	private final CustomHierarchicalModel model;
	private final ResourceLocation texture;

	EzonetRenderer(BlockEntityRendererProvider.Context context) {
		this.model = new CustomHierarchicalModel(context.bakeLayer(Modelezonet.LAYER_LOCATION));
		this.texture = new ResourceLocation("rped:textures/block/izonet.png");
	}

	private void updateRenderState(EzonetBlockEntity blockEntity) {
		int tickCount = (int) blockEntity.getLevel().getGameTime();
		blockEntity.animationState0.animateWhen(EzonetIfCloseProcedure.execute(blockEntity.getLevel(), blockEntity.getBlockPos().getX(), blockEntity.getBlockPos().getY(), blockEntity.getBlockPos().getZ()), tickCount);
		blockEntity.animationState1.animateWhen(EzonetIfOneToTwoProcedure.execute(blockEntity.getLevel(), blockEntity.getBlockPos().getX(), blockEntity.getBlockPos().getY(), blockEntity.getBlockPos().getZ()), tickCount);
		blockEntity.animationState2.animateWhen(EzonetIfTwoToTwoProcedure.execute(blockEntity.getLevel(), blockEntity.getBlockPos().getX(), blockEntity.getBlockPos().getY(), blockEntity.getBlockPos().getZ()), tickCount);
		blockEntity.animationState3.animateWhen(EzonetIfOpenProcedure.execute(blockEntity.getLevel(), blockEntity.getBlockPos().getX(), blockEntity.getBlockPos().getY(), blockEntity.getBlockPos().getZ()), tickCount);
	}

	@Override
	public void render(EzonetBlockEntity blockEntity, float partialTick, PoseStack poseStack, MultiBufferSource renderer, int light, int overlayLight) {
		updateRenderState(blockEntity);
		poseStack.pushPose();
		poseStack.scale(-1, -1, 1);
		poseStack.translate(-0.5, -0.5, 0.5);
		poseStack.translate(0, -1, 0);
		VertexConsumer builder = renderer.getBuffer(RenderType.entityCutout(texture));
		model.setupBlockEntityAnim(blockEntity, blockEntity.getLevel().getGameTime() + partialTick);
		model.renderToBuffer(poseStack, builder, light, overlayLight, 1, 1, 1, 1);
		poseStack.popPose();
	}

	@SubscribeEvent
	public static void registerBlockEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerBlockEntityRenderer(RpedModBlockEntities.EZONET.get(), EzonetRenderer::new);
	}

	private static final class CustomHierarchicalModel extends Modelezonet {
		private final ModelPart root;
		private final BlockEntityHierarchicalModel animator = new BlockEntityHierarchicalModel();

		public CustomHierarchicalModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		public void setupBlockEntityAnim(EzonetBlockEntity blockEntity, float ageInTicks) {
			animator.setupBlockEntityAnim(blockEntity, ageInTicks);
			super.setupAnim(null, 0, 0, ageInTicks, 0, 0);
		}

		private class BlockEntityHierarchicalModel extends HierarchicalModel<Entity> {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			}

			public void setupBlockEntityAnim(EzonetBlockEntity blockEntity, float ageInTicks) {
				animator.root().getAllParts().forEach(ModelPart::resetPose);
				animator.animate(blockEntity.animationState0, ezonetAnimationIdleClose.EzonetIdleclose, ageInTicks, 1f);
				animator.animate(blockEntity.animationState1, ezonetAnimationOneToTwo.Ezonetonetotwo, ageInTicks, 1f);
				animator.animate(blockEntity.animationState2, ezonetAnimationTwoToTwo.Ezonettwototwo, ageInTicks, 1f);
				animator.animate(blockEntity.animationState3, ezonetAnimationIdle.Ezonetidle, ageInTicks, 1f);
			}
		}
	}
}