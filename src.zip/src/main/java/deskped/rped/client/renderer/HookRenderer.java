package deskped.rped.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import deskped.rped.entity.HookEntity;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.registries.ForgeRegistries;

import org.joml.Matrix4f;

public class HookRenderer extends EntityRenderer<HookEntity> {

    private ItemStack stack = ItemStack.EMPTY;

    public HookRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    private ItemStack hookStack() {
        if (stack.isEmpty()) {
            Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation("rped", "hook"));
            if (item != null)
                stack = new ItemStack(item);
        }
        return stack;
    }

    @Override
    public void render(HookEntity entity, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        ItemStack s = hookStack();
        if (!s.isEmpty()) {
            poseStack.pushPose();
            poseStack.scale(0.5f, 0.5f, 0.5f);
            poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
            poseStack.mulPose(Axis.YP.rotationDegrees(180.0f));
            Minecraft.getInstance().getItemRenderer().renderStatic(s, ItemDisplayContext.GROUND, packedLight, OverlayTexture.NO_OVERLAY, poseStack, buffer, entity.level(), 0);
            poseStack.popPose();
        }

        Entity owner = entity.getOwner();
        if (owner != null) {
            renderRope(entity, owner, partialTick, poseStack, buffer);
        }

        super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
    }

    private void renderRope(HookEntity hook, Entity owner, float partialTick, PoseStack poseStack, MultiBufferSource buffer) {
        double handX = net.minecraft.util.Mth.lerp(partialTick, owner.xo, owner.getX());
        double handY = net.minecraft.util.Mth.lerp(partialTick, owner.yo, owner.getY()) + owner.getEyeHeight() * 0.85;
        double handZ = net.minecraft.util.Mth.lerp(partialTick, owner.zo, owner.getZ());

        double hx = net.minecraft.util.Mth.lerp(partialTick, hook.xo, hook.getX());
        double hy = net.minecraft.util.Mth.lerp(partialTick, hook.yo, hook.getY());
        double hz = net.minecraft.util.Mth.lerp(partialTick, hook.zo, hook.getZ());

        float dx = (float) (handX - hx);
        float dy = (float) (handY - hy);
        float dz = (float) (handZ - hz);

        VertexConsumer consumer = buffer.getBuffer(RenderType.lines());
        Matrix4f matrix = poseStack.last().pose();
        int segments = 16;
        for (int i = 0; i < segments; i++) {
            float t1 = (float) i / segments;
            float t2 = (float) (i + 1) / segments;
            float sag1 = (float) (Math.sin(t1 * Math.PI) * 0.12);
            float sag2 = (float) (Math.sin(t2 * Math.PI) * 0.12);
            consumer.vertex(matrix, dx * t1, dy * t1 - sag1, dz * t1).color(60, 40, 25, 255).normal(0, 1, 0).endVertex();
            consumer.vertex(matrix, dx * t2, dy * t2 - sag2, dz * t2).color(60, 40, 25, 255).normal(0, 1, 0).endVertex();
        }
    }

    @Override
    public ResourceLocation getTextureLocation(HookEntity entity) {
        return new ResourceLocation("minecraft", "textures/misc/unknown_server.png");
    }
}
