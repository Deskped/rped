package deskped.rped.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import deskped.rped.entity.OrbitingBlockEntity;
import deskped.rped.ext.RpedExtra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.model.data.ModelData;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "rped", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class OrbitingBlockRenderer extends EntityRenderer<OrbitingBlockEntity> {

	private final BlockRenderDispatcher blockRenderer;

	public OrbitingBlockRenderer(EntityRendererProvider.Context ctx) {
		super(ctx);
		this.blockRenderer = Minecraft.getInstance().getBlockRenderer();
	}

	@Override
	public void render(OrbitingBlockEntity entity, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {
		BlockState state = entity.getHeldState();
		float spin = (entity.tickCount + partialTick) * 9f;

		poseStack.pushPose();
		poseStack.translate(0.0, 0.38, 0.0);
		poseStack.mulPose(Axis.YP.rotationDegrees(spin));
		poseStack.mulPose(Axis.XP.rotationDegrees(spin * 0.6f));
		poseStack.mulPose(Axis.ZP.rotationDegrees(spin * 0.35f));
		poseStack.scale(0.82f, 0.82f, 0.82f);
		poseStack.translate(-0.5, -0.5, -0.5);

		blockRenderer.renderSingleBlock(state, poseStack, bufferSource, packedLight, OverlayTexture.NO_OVERLAY, ModelData.EMPTY, null);

		poseStack.popPose();
		super.render(entity, yaw, partialTick, poseStack, bufferSource, packedLight);
	}

	@Override
	public ResourceLocation getTextureLocation(OrbitingBlockEntity entity) {
		return new ResourceLocation("minecraft", "textures/misc/unknown_server.png");
	}

	@SubscribeEvent
	public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(RpedExtra.ORBITING_BLOCK.get(), OrbitingBlockRenderer::new);
	}
}
