package deskped.rped.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import deskped.rped.entity.CasingGolemEntity;
import deskped.rped.client.model.animations.*;
import deskped.rped.client.model.ModelIronCasingGolem;

import com.mojang.blaze3d.vertex.PoseStack;

public class CasingGolemRenderer extends MobRenderer<CasingGolemEntity, ModelIronCasingGolem<CasingGolemEntity>> {
	public CasingGolemRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(ModelIronCasingGolem.LAYER_LOCATION)), 3f);
	}

	@Override
	protected void scale(CasingGolemEntity entity, PoseStack poseStack, float f) {
		poseStack.scale(entity.getScale(), entity.getScale(), entity.getScale());
	}

	@Override
	public ResourceLocation getTextureLocation(CasingGolemEntity entity) {
		return new ResourceLocation("rped:textures/entities/casinggolem.png");
	}

	private static final class AnimatedModel extends ModelIronCasingGolem<CasingGolemEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<CasingGolemEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(CasingGolemEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animate(entity.animationState0, IronCasingGolemAnimationIdle.idle, ageInTicks, 1f);
				this.animate(entity.animationState1, IronCasingGolemAnimationIdleWalk.walk, ageInTicks, 1.6f);
				this.animate(entity.animationState2, IronCasingGolemAnimationAttack.attack, ageInTicks, 1f);
				this.animate(entity.animationState3, IronCasingGolemAnimationWalkBolt.walkBolt, ageInTicks, 1f);
				this.animate(entity.animationState4, IronCasingGolemAnimationIdleBolt.walk, ageInTicks, 1f);
				this.animate(entity.animationState5, IronCasingGolemAnimationAttackBolt.attackBolt, ageInTicks, 1f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(CasingGolemEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}