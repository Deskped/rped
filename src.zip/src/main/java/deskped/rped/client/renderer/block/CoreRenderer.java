package deskped.rped.client.renderer.block;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.Minecraft;

import deskped.rped.init.RpedModBlockEntities;
import deskped.rped.block.entity.CoreBlockEntity;

import org.joml.Quaternionf;
import org.joml.Matrix4f;
import org.joml.Matrix3f;

import com.mojang.math.Axis;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class CoreRenderer implements BlockEntityRenderer<CoreBlockEntity> {
	private static final ResourceLocation SPRITE = new ResourceLocation("rped", "block/core");

	private static final float CORE_SIZE = 8.0f / 16.0f;
	private static final float HALF = CORE_SIZE / 2.0f;

	private static final double SPIN_X = 0.55;
	private static final double SPIN_Y = 0.80;
	private static final double SPIN_Z = 0.35;
	private static final double RAYS_SPIN_Y = 0.70;
	private static final double RAYS_SPIN_X = 0.40;

	private static final int RAY_COUNT = 36;
	private static final float RAY_MIN_LENGTH = 1.2f;
	private static final float RAY_EXTRA_LENGTH = 2.0f;
	private static final float RAY_MIN_WIDTH = 0.12f;
	private static final float RAY_EXTRA_WIDTH = 0.22f;
	private static final float HALF_SQRT_3 = (float) (Math.sqrt(3.0) / 2.0);
	private static final float TAU = (float) (Math.PI * 2.0);

	private static final int RAY_ROOT_R = 255;
	private static final int RAY_ROOT_G = 255;
	private static final int RAY_ROOT_B = 255;
	private static final int RAY_TIP_R = 170;
	private static final int RAY_TIP_G = 120;
	private static final int RAY_TIP_B = 255;

	private static final int GLOW_R = 215;
	private static final int GLOW_G = 205;
	private static final int GLOW_B = 255;
	private static final int GLOW_SEGMENTS = 24;

	private static final Quaternionf[] RAY_ORIENT = new Quaternionf[RAY_COUNT];
	private static final float[] RAY_LENGTH = new float[RAY_COUNT];
	private static final float[] RAY_WIDTH = new float[RAY_COUNT];
	private static final float[] RAY_PHASE = new float[RAY_COUNT];
	private static final float[] RAY_SPEED = new float[RAY_COUNT];

	private static final float[][] FACE_VERTS = {
			{-1, 1, 1, 1, 1, 1, 1, 1, -1, -1, 1, -1},
			{-1, -1, -1, 1, -1, -1, 1, -1, 1, -1, -1, 1},
			{-1, -1, 1, 1, -1, 1, 1, 1, 1, -1, 1, 1},
			{1, -1, -1, -1, -1, -1, -1, 1, -1, 1, 1, -1},
			{1, -1, 1, 1, -1, -1, 1, 1, -1, 1, 1, 1},
			{-1, -1, -1, -1, -1, 1, -1, 1, 1, -1, 1, -1}
	};
	private static final float[][] FACE_NORMALS = {{0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}, {1, 0, 0}, {-1, 0, 0}};
	private static final float[] FACE_SHADE = {1.0f, 0.78f, 0.92f, 0.92f, 0.85f, 0.85f};
	private static final float[] CORNER_U = {0, 1, 1, 0};
	private static final float[] CORNER_V = {1, 1, 0, 0};

	static {
		RandomSource random = RandomSource.create(432L);
		for (int i = 0; i < RAY_COUNT; i++) {
			RAY_ORIENT[i] = new Quaternionf((float) random.nextGaussian(), (float) random.nextGaussian(), (float) random.nextGaussian(), (float) random.nextGaussian()).normalize();
			RAY_LENGTH[i] = RAY_MIN_LENGTH + random.nextFloat() * RAY_EXTRA_LENGTH;
			RAY_WIDTH[i] = RAY_MIN_WIDTH + random.nextFloat() * RAY_EXTRA_WIDTH;
			RAY_PHASE[i] = random.nextFloat() * TAU;
			RAY_SPEED[i] = 0.05f + random.nextFloat() * 0.08f;
		}
	}

	CoreRenderer(BlockEntityRendererProvider.Context context) {
	}

	@Override
	public void render(CoreBlockEntity blockEntity, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int light, int overlay) {
		Level level = blockEntity.getLevel();
		if (level == null)
			return;
		double time = level.getGameTime() + (double) partialTick;
		poseStack.pushPose();
		poseStack.translate(0.5, 0.5, 0.5);
		renderCube(poseStack, buffer, time);
		VertexConsumer additive = buffer.getBuffer(RenderType.lightning());
		renderGlow(poseStack, additive, time);
		renderRays(poseStack, additive, time);
		poseStack.popPose();
	}

	private static float degrees(double time, double speed) {
		return (float) ((time * speed) % 360.0);
	}

	private static void renderCube(PoseStack poseStack, MultiBufferSource buffer, double time) {
		TextureAtlasSprite sprite = Minecraft.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS).apply(SPRITE);
		float u0 = sprite.getU0();
		float v0 = sprite.getV0();
		float du = sprite.getU1() - u0;
		float dv = sprite.getV1() - v0;
		VertexConsumer consumer = buffer.getBuffer(RenderType.beaconBeam(InventoryMenu.BLOCK_ATLAS, false));
		poseStack.pushPose();
		poseStack.mulPose(Axis.XP.rotationDegrees(degrees(time, SPIN_X)));
		poseStack.mulPose(Axis.YP.rotationDegrees(degrees(time, SPIN_Y)));
		poseStack.mulPose(Axis.ZP.rotationDegrees(degrees(time, SPIN_Z)));
		Matrix4f pose = poseStack.last().pose();
		Matrix3f normal = poseStack.last().normal();
		for (int face = 0; face < 6; face++) {
			float[] verts = FACE_VERTS[face];
			float[] n = FACE_NORMALS[face];
			float shade = FACE_SHADE[face];
			for (int corner = 0; corner < 4; corner++) {
				consumer.vertex(pose, verts[corner * 3] * HALF, verts[corner * 3 + 1] * HALF, verts[corner * 3 + 2] * HALF)
						.color(shade, shade, shade, 1.0f)
						.uv(u0 + du * CORNER_U[corner], v0 + dv * CORNER_V[corner])
						.overlayCoords(OverlayTexture.NO_OVERLAY)
						.uv2(LightTexture.FULL_BRIGHT)
						.normal(normal, n[0], n[1], n[2])
						.endVertex();
			}
		}
		poseStack.popPose();
	}

	private static void renderGlow(PoseStack poseStack, VertexConsumer consumer, double time) {
		poseStack.pushPose();
		poseStack.mulPose(Minecraft.getInstance().gameRenderer.getMainCamera().rotation());
		Matrix4f pose = poseStack.last().pose();
		float pulse = 1.0f + 0.08f * (float) Math.sin(time * 0.09);
		glowDisc(consumer, pose, 1.0f * pulse, 0.5f);
		glowDisc(consumer, pose, 0.55f * pulse, 0.5f);
		poseStack.popPose();
	}

	private static void glowDisc(VertexConsumer consumer, Matrix4f pose, float radius, float alpha) {
		int a = (int) (alpha * 255.0f);
		for (int i = 0; i < GLOW_SEGMENTS; i++) {
			float angle0 = TAU * i / GLOW_SEGMENTS;
			float angle1 = TAU * (i + 1) / GLOW_SEGMENTS;
			float x0 = Mth.cos(angle0) * radius;
			float y0 = Mth.sin(angle0) * radius;
			float x1 = Mth.cos(angle1) * radius;
			float y1 = Mth.sin(angle1) * radius;
			glowCenter(consumer, pose, a);
			glowCenter(consumer, pose, a);
			glowRim(consumer, pose, x0, y0);
			glowRim(consumer, pose, x1, y1);
			glowCenter(consumer, pose, a);
			glowCenter(consumer, pose, a);
			glowRim(consumer, pose, x1, y1);
			glowRim(consumer, pose, x0, y0);
		}
	}

	private static void glowCenter(VertexConsumer consumer, Matrix4f pose, int alpha) {
		consumer.vertex(pose, 0.0f, 0.0f, 0.0f).color(GLOW_R, GLOW_G, GLOW_B, alpha).endVertex();
	}

	private static void glowRim(VertexConsumer consumer, Matrix4f pose, float x, float y) {
		consumer.vertex(pose, x, y, 0.0f).color(GLOW_R, GLOW_G, GLOW_B, 0).endVertex();
	}

	private static void renderRays(PoseStack poseStack, VertexConsumer consumer, double time) {
		poseStack.pushPose();
		poseStack.mulPose(Axis.YP.rotationDegrees(degrees(time, RAYS_SPIN_Y)));
		poseStack.mulPose(Axis.XP.rotationDegrees(degrees(time, RAYS_SPIN_X)));
		for (int i = 0; i < RAY_COUNT; i++) {
			float wave = 0.5f + 0.5f * (float) Math.sin(time * RAY_SPEED[i] + RAY_PHASE[i]);
			wave = wave * wave * (3.0f - 2.0f * wave);
			float length = RAY_LENGTH[i] * (0.12f + 0.88f * wave);
			float width = RAY_WIDTH[i] * (0.45f + 0.55f * wave);
			int alpha = (int) (255.0f * (0.45f + 0.55f * wave));
			poseStack.pushPose();
			poseStack.mulPose(RAY_ORIENT[i]);
			ray(consumer, poseStack.last().pose(), length, width, alpha);
			poseStack.popPose();
		}
		poseStack.popPose();
	}

	private static void ray(VertexConsumer consumer, Matrix4f pose, float length, float width, int alpha) {
		float side = HALF_SQRT_3 * width;
		float back = -0.5f * width;
		rayFace(consumer, pose, length, alpha, -side, back, side, back);
		rayFace(consumer, pose, length, alpha, side, back, 0.0f, width);
		rayFace(consumer, pose, length, alpha, 0.0f, width, -side, back);
	}

	private static void rayFace(VertexConsumer consumer, Matrix4f pose, float length, int alpha, float x0, float z0, float x1, float z1) {
		consumer.vertex(pose, 0.0f, 0.0f, 0.0f).color(RAY_ROOT_R, RAY_ROOT_G, RAY_ROOT_B, alpha).endVertex();
		consumer.vertex(pose, 0.0f, 0.0f, 0.0f).color(RAY_ROOT_R, RAY_ROOT_G, RAY_ROOT_B, alpha).endVertex();
		consumer.vertex(pose, x0, length, z0).color(RAY_TIP_R, RAY_TIP_G, RAY_TIP_B, 0).endVertex();
		consumer.vertex(pose, x1, length, z1).color(RAY_TIP_R, RAY_TIP_G, RAY_TIP_B, 0).endVertex();
	}

	@SubscribeEvent
	public static void registerBlockEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerBlockEntityRenderer(RpedModBlockEntities.CORE.get(), CoreRenderer::new);
	}
}