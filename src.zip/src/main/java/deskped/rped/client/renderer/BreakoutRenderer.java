package deskped.rped.client.renderer;

import com.mojang.blaze3d.vertex.*;
import com.mojang.math.Axis;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

import org.joml.Matrix3f;
import org.joml.Matrix4f;

import deskped.rped.entity.BreakoutEntity;

import java.util.Random;

public class BreakoutRenderer extends EntityRenderer<BreakoutEntity> {

    private static final int   CUBE_COUNT   = 24;
    private static final float CORE_RADIUS  = 1.4f;
    private static final float OUTER_RADIUS = 3.4f;

    private static final Random SEEDED = new Random(0xC0FFEEL);

    private final float[] cSeed;
    private final float[] cPhase;
    private final float[] cRadius;
    private final float[] cAngle;
    private final float[] cTilt;
    private final float[] cSize;
    private final float[] cSpin;

    public BreakoutRenderer(EntityRendererProvider.Context context) {
        super(context);
        shadowRadius = 0f;
        cSeed  = new float[CUBE_COUNT];
        cPhase = new float[CUBE_COUNT];
        cRadius= new float[CUBE_COUNT];
        cAngle = new float[CUBE_COUNT];
        cTilt  = new float[CUBE_COUNT];
        cSize  = new float[CUBE_COUNT];
        cSpin  = new float[CUBE_COUNT];
        for (int i = 0; i < CUBE_COUNT; i++) {
            cSeed[i]  = SEEDED.nextFloat();
            cPhase[i] = SEEDED.nextFloat() * Mth.TWO_PI;
            cRadius[i]= CORE_RADIUS + SEEDED.nextFloat() * (OUTER_RADIUS - CORE_RADIUS);
            cAngle[i] = SEEDED.nextFloat() * Mth.TWO_PI;
            cTilt[i]  = (SEEDED.nextFloat() - 0.5f) * 1.6f;
            cSize[i]  = 0.22f + SEEDED.nextFloat() * 0.42f;
            cSpin[i]  = (SEEDED.nextFloat() - 0.5f) * 2f;
        }
    }

    @Override
    public ResourceLocation getTextureLocation(BreakoutEntity entity) {
        return new ResourceLocation("minecraft", "textures/block/end_gateway_top.png");
    }

    @Override
    public void render(BreakoutEntity entity, float entityYaw, float partialTick,
                       PoseStack ps, MultiBufferSource buf, int packedLight) {

        float t = entity.tickCount + partialTick;

        ps.pushPose();
        ps.translate(0, 1.5, 0);

        renderCore(ps, buf, t);
        renderOrbitCubes(ps, buf, t);
        renderAccretionRings(ps, buf, t);

        ps.popPose();

        spawnParticles(entity, partialTick, t);

        super.render(entity, entityYaw, partialTick, ps, buf, packedLight);
    }

    private void renderCore(PoseStack ps, MultiBufferSource buf, float t) {
        ps.pushPose();
        float pulse = 1.0f + 0.05f * Mth.sin(t * 0.07f);
        ps.scale(pulse * 1.6f, pulse * 1.6f, pulse * 1.6f);

        VertexConsumer vc  = buf.getBuffer(RenderType.endPortal());
        Matrix4f       mat = ps.last().pose();
        Matrix3f       nm  = ps.last().normal();

        addFace(vc, mat, nm,  0,  0,  1,  0, 0, 1);
        addFace(vc, mat, nm,  0,  0, -1,  0, 0,-1);
        addFace(vc, mat, nm,  1,  0,  0, -1, 0, 0);
        addFace(vc, mat, nm, -1,  0,  0,  1, 0, 0);
        addFace(vc, mat, nm,  0,  1,  0,  0,-1, 0);
        addFace(vc, mat, nm,  0, -1,  0,  0, 1, 0);

        ps.popPose();
    }

    private void renderOrbitCubes(PoseStack ps, MultiBufferSource buf, float t) {
        for (int i = 0; i < CUBE_COUNT; i++) {
            float orbitSpeed = 0.010f + cSeed[i] * 0.016f;
            float angle      = cAngle[i] + t * orbitSpeed * (cSpin[i] > 0 ? 1 : -1);
            float bobSpeed   = 0.048f + cSeed[i] * 0.038f;
            float bob        = Mth.sin(t * bobSpeed + cPhase[i]) * (0.38f + cSeed[i] * 0.44f);
            float r          = cRadius[i];
            float x          = Mth.cos(angle) * r;
            float z          = Mth.sin(angle) * r;
            float y          = bob + cTilt[i];

            float pulseT     = (Mth.sin(t * (0.065f + cSeed[i] * 0.055f) + cPhase[i] * 2f) + 1f) * 0.5f;
            float finalSize  = cSize[i] * (0.28f + pulseT * 0.72f);

            float spinA      = t * (0.025f + cSeed[i] * 0.04f) + cPhase[i];

            ps.pushPose();
            ps.translate(x, y, z);
            ps.mulPose(Axis.YP.rotation(spinA));
            ps.mulPose(Axis.XP.rotation(spinA * 0.65f));
            ps.scale(finalSize, finalSize, finalSize);

            VertexConsumer vc  = buf.getBuffer(RenderType.endPortal());
            Matrix4f       mat = ps.last().pose();
            Matrix3f       nm  = ps.last().normal();

            addFace(vc, mat, nm,  0,  0,  1,  0, 0, 1);
            addFace(vc, mat, nm,  0,  0, -1,  0, 0,-1);
            addFace(vc, mat, nm,  1,  0,  0, -1, 0, 0);
            addFace(vc, mat, nm, -1,  0,  0,  1, 0, 0);
            addFace(vc, mat, nm,  0,  1,  0,  0,-1, 0);
            addFace(vc, mat, nm,  0, -1,  0,  0, 1, 0);

            ps.popPose();
        }
    }

    private void renderAccretionRings(PoseStack ps, MultiBufferSource buf, float t) {
        int rings = 4;
        for (int ring = 0; ring < rings; ring++) {
            float base      = ring * (Mth.TWO_PI / rings);
            float ringR     = 2.6f + ring * 0.55f;
            float spin      = t * (0.008f + ring * 0.003f) * (ring % 2 == 0 ? 1 : -1) + base;
            float alpha     = 0.52f - ring * 0.09f;
            int   segments  = 20;

            VertexConsumer vc  = buf.getBuffer(RenderType.endGateway());
            Matrix4f       mat = ps.last().pose();
            Matrix3f       nm  = ps.last().normal();

            for (int seg = 0; seg < segments; seg++) {
                float a0 = spin + (seg       / (float) segments) * Mth.TWO_PI;
                float a1 = spin + ((seg + 1) / (float) segments) * Mth.TWO_PI;

                float pulse  = (Mth.sin(t * 0.13f + seg * 0.35f + ring * 1.1f) + 1f) * 0.5f;
                float halfH  = 0.10f + pulse * 0.20f;

                float x0 = Mth.cos(a0) * ringR, z0 = Mth.sin(a0) * ringR;
                float x1 = Mth.cos(a1) * ringR, z1 = Mth.sin(a1) * ringR;
                float u0 = seg / (float) segments, u1 = (seg + 1) / (float) segments;

                vc.vertex(mat, x0, -halfH, z0).color(0.04f,0.0f,0.10f,alpha).uv(u0,0).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(0xF000F0).normal(nm,0,1,0).endVertex();
                vc.vertex(mat, x0,  halfH, z0).color(0.04f,0.0f,0.10f,alpha).uv(u0,1).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(0xF000F0).normal(nm,0,1,0).endVertex();
                vc.vertex(mat, x1,  halfH, z1).color(0.04f,0.0f,0.10f,alpha).uv(u1,1).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(0xF000F0).normal(nm,0,1,0).endVertex();
                vc.vertex(mat, x1, -halfH, z1).color(0.04f,0.0f,0.10f,alpha).uv(u1,0).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(0xF000F0).normal(nm,0,1,0).endVertex();
            }
        }
    }

    private void addFace(VertexConsumer vc, Matrix4f mat, Matrix3f nm,
                         float cx, float cy, float cz,
                         float nx, float ny, float nz) {
        float tx, ty, tz;
        if (Math.abs(nx) < 0.01f && Math.abs(nz) < 0.01f) {
            tx = 1; ty = 0; tz = 0;
        } else {
            tx = -nz; ty = 0; tz = nx;
            float len = Mth.sqrt(tx * tx + tz * tz);
            tx /= len; tz /= len;
        }
        float bx = ny * tz - nz * ty;
        float by = nz * tx - nx * tz;
        float bz = nx * ty - ny * tx;

        vc.vertex(mat, cx + (-tx - bx), cy + (-ty - by), cz + (-tz - bz)).color(0f,0f,0f,1f).uv(0,0).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(0xF000F0).normal(nm,nx,ny,nz).endVertex();
        vc.vertex(mat, cx + ( tx - bx), cy + ( ty - by), cz + ( tz - bz)).color(0f,0f,0f,1f).uv(1,0).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(0xF000F0).normal(nm,nx,ny,nz).endVertex();
        vc.vertex(mat, cx + ( tx + bx), cy + ( ty + by), cz + ( tz + bz)).color(0f,0f,0f,1f).uv(1,1).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(0xF000F0).normal(nm,nx,ny,nz).endVertex();
        vc.vertex(mat, cx + (-tx + bx), cy + (-ty + by), cz + (-tz + bz)).color(0f,0f,0f,1f).uv(0,1).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(0xF000F0).normal(nm,nx,ny,nz).endVertex();
    }

    private static final Random PR = new Random();

    private void spawnParticles(BreakoutEntity entity, float partialTick, float t) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;

        double ex = Mth.lerp(partialTick, entity.xOld, entity.getX());
        double ey = Mth.lerp(partialTick, entity.yOld, entity.getY()) + 1.5;
        double ez = Mth.lerp(partialTick, entity.zOld, entity.getZ());

        for (int i = 0; i < 7; i++) {
            double ang  = PR.nextDouble() * Mth.TWO_PI;
            double dist = 1.8 + PR.nextDouble() * 4.0;
            double sx   = ex + Math.cos(ang) * dist;
            double sz   = ez + Math.sin(ang) * dist;
            double sy   = ey + (PR.nextDouble() - 0.5) * 2.2;
            mc.level.addParticle(ParticleTypes.REVERSE_PORTAL,
                    sx, sy, sz,
                    (ex - sx) * 0.09, (ey - sy) * 0.09, (ez - sz) * 0.09);
        }

        for (int i = 0; i < 4; i++) {
            double ang  = t * 0.14 + i * (Mth.TWO_PI / 4f);
            double dist = 2.1 + Math.sin(t * 0.04 + i) * 0.6;
            double sx   = ex + Math.cos(ang) * dist;
            double sz   = ez + Math.sin(ang) * dist;
            mc.level.addParticle(ParticleTypes.PORTAL,
                    sx, ey + (PR.nextDouble() - 0.5) * 0.9, sz,
                    (ex - sx) * 0.28, 0, (ez - sz) * 0.28);
        }

        if (entity.tickCount % 4 == 0) {
            for (int i = 0; i < 2; i++) {
                mc.level.addParticle(ParticleTypes.END_ROD,
                        ex + (PR.nextDouble() - 0.5) * 2.0,
                        ey + (PR.nextDouble() - 0.5) * 2.0,
                        ez + (PR.nextDouble() - 0.5) * 2.0,
                        (PR.nextDouble() - 0.5) * 0.04,
                        (PR.nextDouble() - 0.5) * 0.04,
                        (PR.nextDouble() - 0.5) * 0.04);
            }
        }
    }
}