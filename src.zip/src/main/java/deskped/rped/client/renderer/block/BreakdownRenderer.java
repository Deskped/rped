package deskped.rped.client.renderer.block;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import org.joml.Matrix4f;

import java.util.List;

import deskped.rped.block.entity.BreakdownBlockEntity;
import deskped.rped.entity.OrbitingBlockEntity;
import deskped.rped.init.RpedModBlockEntities;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class BreakdownRenderer implements BlockEntityRenderer<BreakdownBlockEntity> {

	private static final float SCALE = 3.2f;
	private static final int CRACKS = 16;
	private static final int RING_SEG = 24;

	public BreakdownRenderer(BlockEntityRendererProvider.Context context) {
	}

	@Override
	public void render(BreakdownBlockEntity be, float partialTick, PoseStack ps, MultiBufferSource buf, int light, int overlay) {
		float t = (float) (be.getLevel() != null ? be.getLevel().getGameTime() : 0L) + partialTick;
		long jit = (long) Math.floor(t * 2.3);
		long fast = (long) Math.floor(t * 4.7);

		ps.pushPose();
		ps.translate(0.5, 0.5, 0.5);
		float gx = (rnd(1001, jit) - 0.5f) * 0.06f;
		float gy = (rnd(1002, jit) - 0.5f) * 0.06f;
		float gz = (rnd(1003, jit) - 0.5f) * 0.06f;
		ps.translate(gx, gy, gz);

		VertexConsumer vc = buf.getBuffer(RenderType.lightning());

		ps.pushPose();
		ps.scale(SCALE, SCALE, SCALE);
		Matrix4f mat = ps.last().pose();
		renderCore(vc, mat, t, jit, fast);
		renderCracks(vc, mat, t, jit, fast);
		renderRing(vc, mat, t, jit, fast);
		ps.popPose();

		renderBeams(be, partialTick, vc, ps.last().pose(), fast);

		ps.popPose();
	}

	@Override
	public boolean shouldRenderOffScreen(BreakdownBlockEntity be) {
		return true;
	}

	@Override
	public int getViewDistance() {
		return 128;
	}

	private void renderBeams(BreakdownBlockEntity be, float partialTick, VertexConsumer vc, Matrix4f mat, long fast) {
		if (be.getLevel() == null)
			return;
		BlockPos bp = be.getBlockPos();
		List<OrbitingBlockEntity> list = be.getLevel().getEntitiesOfClass(OrbitingBlockEntity.class, new AABB(bp).inflate(11));
		for (OrbitingBlockEntity e : list) {
			Vec3 p = e.getPosition(partialTick);
			float tx = (float) (p.x - (bp.getX() + 0.5));
			float ty = (float) (p.y + 0.38 - (bp.getY() + 0.5));
			float tz = (float) (p.z - (bp.getZ() + 0.5));
			beam(vc, mat, tx, ty, tz, fast * 31L + e.getId() * 77L);
		}
	}

	private void beam(VertexConsumer vc, Matrix4f mat, float tx, float ty, float tz, long seed) {
		float flick = 0.7f + 0.3f * rnd(9, seed);
		int segs = 5;
		float px = 0;
		float py = 0;
		float pz = 0;
		for (int i = 1; i <= segs; i++) {
			float f = i / (float) segs;
			float nx = tx * f;
			float ny = ty * f;
			float nz = tz * f;
			if (i < segs) {
				nx += (rnd(i * 3 + 1, seed) - 0.5f) * 0.55f;
				ny += (rnd(i * 3 + 2, seed) - 0.5f) * 0.55f;
				nz += (rnd(i * 3 + 3, seed) - 0.5f) * 0.55f;
			}
			seg(vc, mat, px, py, pz, nx, ny, nz, 0.045f, 1f, 1f, 1f, 0.92f * flick);
			seg(vc, mat, px, py, pz, nx, ny, nz, 0.13f, 0.72f, 0.9f, 1f, 0.26f * flick);
			px = nx;
			py = ny;
			pz = nz;
		}
	}

	private void seg(VertexConsumer vc, Matrix4f mat, float x1, float y1, float z1, float x2, float y2, float z2, float w, float r, float g, float b, float a) {
		float dx = x2 - x1;
		float dz = z2 - z1;
		float pxn = dz;
		float pzn = -dx;
		float l = Mth.sqrt(pxn * pxn + pzn * pzn);
		if (l < 0.001f) {
			pxn = 1;
			pzn = 0;
			l = 1;
		}
		pxn = pxn / l * w;
		pzn = pzn / l * w;
		quad(vc, mat,
				new float[]{x1 + pxn, y1, z1 + pzn},
				new float[]{x1 - pxn, y1, z1 - pzn},
				new float[]{x2 - pxn, y2, z2 - pzn},
				new float[]{x2 + pxn, y2, z2 + pzn},
				r, g, b, a, r, g, b, a);
		quad(vc, mat,
				new float[]{x1, y1 + w, z1},
				new float[]{x1, y1 - w, z1},
				new float[]{x2, y2 - w, z2},
				new float[]{x2, y2 + w, z2},
				r, g, b, a, r, g, b, a);
	}

	private void renderCore(VertexConsumer vc, Matrix4f mat, float t, long jit, long fast) {
		float glitch = rnd(7, jit) < 0.12f ? 1.7f : 1.0f;
		float pulse = 0.5f + 0.5f * Mth.sin(t * 0.4f);
		float r = (0.11f + pulse * 0.06f) * glitch;
		float jx = (rnd(11, jit) - 0.5f) * 0.05f;
		float jy = (rnd(12, jit) - 0.5f) * 0.05f;
		float jz = (rnd(13, jit) - 0.5f) * 0.05f;
		float[] tp = {jx, r + jy, jz};
		float[] bt = {jx, -r + jy, jz};
		float[] n = {jx, jy, r + jz};
		float[] s = {jx, jy, -r + jz};
		float[] e = {r + jx, jy, jz};
		float[] w = {-r + jx, jy, jz};
		float a = 0.5f + 0.4f * rnd(20, fast);
		float cr = 0.72f;
		float cg = 0.9f;
		tri(vc, mat, tp, n, e, 1f, 1f, 1f, a);
		tri(vc, mat, tp, e, s, cr, cg, 1f, a);
		tri(vc, mat, tp, s, w, 1f, 1f, 1f, a);
		tri(vc, mat, tp, w, n, cr, cg, 1f, a);
		tri(vc, mat, bt, e, n, cr, cg, 1f, a);
		tri(vc, mat, bt, s, e, 1f, 1f, 1f, a);
		tri(vc, mat, bt, w, s, cr, cg, 1f, a);
		tri(vc, mat, bt, n, w, 1f, 1f, 1f, a);
	}

	private void renderCracks(VertexConsumer vc, Matrix4f mat, float t, long jit, long fast) {
		for (int i = 0; i < CRACKS; i++) {
			float flick = rnd(i * 3 + 1, fast);
			if (flick < 0.28f)
				continue;
			float yaw = rnd(i * 7 + 2, jit) * Mth.TWO_PI + i * (Mth.TWO_PI / CRACKS);
			float pitch = (rnd(i * 7 + 3, jit) - 0.5f) * 2.4f;
			float cp = Mth.cos(pitch);
			float dx = Mth.cos(yaw) * cp;
			float dy = Mth.sin(pitch);
			float dz = Mth.sin(yaw) * cp;
			float len = 0.42f + rnd(i * 7 + 4, jit) * 0.5f;
			float width = 0.018f + rnd(i * 7 + 5, jit) * 0.03f;

			float px = -dz;
			float pz = dx;
			float pl = Mth.sqrt(px * px + pz * pz);
			if (pl < 0.001f) {
				px = 1;
				pz = 0;
				pl = 1;
			}
			px /= pl;
			pz /= pl;

			float kink = (rnd(i * 7 + 6, jit) - 0.5f) * 0.16f;
			float mx = dx * len * 0.5f + px * kink;
			float my = dy * len * 0.5f + (rnd(i * 7 + 8, jit) - 0.5f) * 0.12f;
			float mz = dz * len * 0.5f + pz * kink;
			float tx = dx * len;
			float ty = dy * len;
			float tz = dz * len;

			float a0 = 0.55f + 0.4f * flick;
			float a1 = a0 * 0.6f;
			float a2 = 0f;
			float w1 = width * 0.6f;

			quad(vc, mat,
					new float[]{px * width, 0, pz * width},
					new float[]{-px * width, 0, -pz * width},
					new float[]{mx - px * w1, my, mz - pz * w1},
					new float[]{mx + px * w1, my, mz + pz * w1},
					1f, 1f, 1f, a0, 0.6f, 0.85f, 1f, a1);
			quad(vc, mat,
					new float[]{mx + px * w1, my, mz + pz * w1},
					new float[]{mx - px * w1, my, mz - pz * w1},
					new float[]{tx, ty, tz},
					new float[]{tx, ty, tz},
					0.6f, 0.85f, 1f, a1, 0.5f, 0.8f, 1f, a2);
		}
	}

	private void renderRing(VertexConsumer vc, Matrix4f mat, float t, long jit, long fast) {
		float spin = t * 0.05f;
		float baseR = 0.44f;
		for (int seg = 0; seg < RING_SEG; seg++) {
			float a0 = spin + (seg / (float) RING_SEG) * Mth.TWO_PI;
			float a1 = spin + ((seg + 1) / (float) RING_SEG) * Mth.TWO_PI;
			float r0 = baseR + (rnd(seg * 2 + 1, jit) - 0.5f) * 0.12f;
			float r1 = baseR + (rnd(((seg + 1) % RING_SEG) * 2 + 1, jit) - 0.5f) * 0.12f;
			float h = 0.012f + rnd(seg + 3, fast) * 0.05f;
			float alpha = 0.22f + 0.2f * rnd(seg + 5, fast);
			float x0 = Mth.cos(a0) * r0;
			float z0 = Mth.sin(a0) * r0;
			float x1 = Mth.cos(a1) * r1;
			float z1 = Mth.sin(a1) * r1;
			quad(vc, mat,
					new float[]{x0, -h, z0},
					new float[]{x0, h, z0},
					new float[]{x1, h, z1},
					new float[]{x1, -h, z1},
					0.6f, 0.88f, 1f, alpha, 0.6f, 0.88f, 1f, alpha);
		}
	}

	private static void tri(VertexConsumer vc, Matrix4f mat, float[] a, float[] b, float[] c, float r, float g, float bl, float al) {
		v(vc, mat, a, r, g, bl, al);
		v(vc, mat, b, r, g, bl, al);
		v(vc, mat, c, r, g, bl, al);
		v(vc, mat, c, r, g, bl, al);
	}

	private static void quad(VertexConsumer vc, Matrix4f mat, float[] a, float[] b, float[] c, float[] d, float r1, float g1, float b1, float al1, float r2, float g2, float b2, float al2) {
		v(vc, mat, a, r1, g1, b1, al1);
		v(vc, mat, b, r1, g1, b1, al1);
		v(vc, mat, c, r2, g2, b2, al2);
		v(vc, mat, d, r2, g2, b2, al2);
	}

	private static void v(VertexConsumer vc, Matrix4f mat, float[] p, float r, float g, float b, float a) {
		vc.vertex(mat, p[0], p[1], p[2]).color(r, g, b, a).endVertex();
	}

	private static float rnd(int i, long s) {
		long h = (s + 0x9E3779B97F4A7C15L) * 0x9E3779B97F4A7C15L + i * 0xC2B2AE3D27D4EB4FL;
		h ^= (h >>> 29);
		h *= 0xBF58476D1CE4E5B9L;
		h ^= (h >>> 27);
		return (float) ((h >>> 40) / 16777216.0);
	}

	@SubscribeEvent
	public static void registerBlockEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerBlockEntityRenderer(RpedModBlockEntities.BREAKDOWN.get(), BreakdownRenderer::new);
	}
}
