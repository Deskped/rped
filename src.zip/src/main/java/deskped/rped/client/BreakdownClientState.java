package deskped.rped.client;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

public class BreakdownClientState {

	private static volatile boolean active = false;
	private static volatile int remainingTicks = 0;
	private static volatile ResourceLocation controllerDim = null;
	private static volatile BlockPos controllerPos = null;
	private static volatile ResourceLocation dimId = null;

	public static void set(boolean a, int remaining, ResourceLocation ctrlDim, BlockPos ctrlPos, ResourceLocation dim) {
		active = a;
		remainingTicks = remaining;
		controllerDim = ctrlDim;
		controllerPos = ctrlPos;
		dimId = dim;
	}

	public static void tickDown() {
		if (active && remainingTicks > 0)
			remainingTicks--;
	}

	public static boolean active() {
		return active;
	}

	public static int remaining() {
		return remainingTicks;
	}

	public static ResourceLocation controllerDim() {
		return controllerDim;
	}

	public static BlockPos controllerPos() {
		return controllerPos;
	}

	public static ResourceLocation dimId() {
		return dimId;
	}
}
