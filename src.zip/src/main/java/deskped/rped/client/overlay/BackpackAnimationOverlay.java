package deskped.rped.client.overlay;

import com.mojang.blaze3d.systems.RenderSystem;
import deskped.rped.client.gui.BackackScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.minecraftforge.client.gui.overlay.ForgeGui;

public class BackpackAnimationOverlay implements IGuiOverlay {

    private static final int FRAME_COUNT = 20;
    private static final int TICKS_PER_FRAME = 1;
    private static final int ANIM_WIDTH = 440;
    private static final int ANIM_HEIGHT = 690;

    private static final ResourceLocation[] FRAMES = new ResourceLocation[FRAME_COUNT];

    static {
        for (int i = 0; i < FRAME_COUNT; i++) {
            FRAMES[i] = new ResourceLocation("rped", "textures/screens/backpack_ui/backpack_" + i + ".png");
        }
    }

    private int tickCounter = 0;
    private int currentFrame = 0;
    private long lastTick = 0;

    @Override
    public void render(ForgeGui gui, GuiGraphics guiGraphics, float partialTick, int screenWidth, int screenHeight) {
        Minecraft mc = Minecraft.getInstance();

        if (!(mc.screen instanceof BackackScreen screen)) {
            return;
        }

        long currentTime = mc.level != null ? mc.level.getGameTime() : 0;
        if (currentTime != lastTick) {
            lastTick = currentTime;
            tickCounter++;
            if (tickCounter >= TICKS_PER_FRAME) {
                tickCounter = 0;
                currentFrame = (currentFrame + 1) % FRAME_COUNT;
            }
        }

        if (FRAMES[currentFrame] == null) return;

        int bgCenterX = screen.getGuiLeft() - 128 + 176 / 2;
        int bgCenterY = screen.getGuiTop() - 23 + 90 / 2;

        int x = bgCenterX - ANIM_WIDTH / 2 - 5;
        int y = bgCenterY - ANIM_HEIGHT / 2;

        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        guiGraphics.blit(FRAMES[currentFrame], x, y, 0, 0, ANIM_WIDTH, ANIM_HEIGHT, ANIM_WIDTH, ANIM_HEIGHT);
        RenderSystem.disableBlend();
    }
}