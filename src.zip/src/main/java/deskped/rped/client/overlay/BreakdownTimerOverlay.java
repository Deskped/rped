package deskped.rped.client.overlay;

import deskped.rped.client.BreakdownClientState;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "rped", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class BreakdownTimerOverlay implements IGuiOverlay {

	private static final int TOTAL = 5 * 60 * 20;
	private static final double NEAR_SQ = 24 * 24;

	private static boolean transparent = false;

	public static void toggleTransparent() {
		transparent = !transparent;
	}

	@Override
	public void render(ForgeGui gui, GuiGraphics g, float partialTick, int screenWidth, int screenHeight) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null || mc.options.hideGui)
			return;
		if (!BreakdownClientState.active())
			return;

		ResourceLocation here = mc.level.dimension().location();
		boolean inside = here.equals(BreakdownClientState.dimId());
		boolean near = false;
		if (!inside && here.equals(BreakdownClientState.controllerDim())) {
			BlockPos cp = BreakdownClientState.controllerPos();
			if (cp != null)
				near = mc.player.distanceToSqr(cp.getX() + 0.5, cp.getY() + 0.5, cp.getZ() + 0.5) <= NEAR_SQ;
		}
		if (!inside && !near)
			return;

		int rem = Math.max(0, BreakdownClientState.remaining());
		int totalSec = (rem + 19) / 20;
		String text = (totalSec / 60) + ":" + String.format("%02d", totalSec % 60);

		float mul = transparent ? 0.32f : 1.0f;
		int aBg = (int) (0x6E * mul);
		int aFg = Math.max(0x10, (int) (0xFF * mul));
		boolean low = rem <= 600;
		int textCol = low ? 0xFF6666 : 0xFFFFFF;
		int barCol = low ? 0xFF5555 : 0x7ADCFF;

		int tw = mc.font.width(text);
		int pillW = tw + 12;
		int pillH = 14;
		int x0 = (screenWidth - pillW) / 2;
		int y0 = 4;

		g.fill(x0, y0, x0 + pillW, y0 + pillH, aBg << 24);
		int barW = (int) ((pillW - 4) * (rem / (float) TOTAL));
		if (barW > 0)
			g.fill(x0 + 2, y0 + pillH - 2, x0 + 2 + barW, y0 + pillH - 1, (aFg << 24) | barCol);
		g.drawString(mc.font, text, x0 + 6, y0 + 3, (aFg << 24) | textCol, false);
	}

	@SubscribeEvent
	public static void registerOverlay(RegisterGuiOverlaysEvent event) {
		event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "breakdown_timer", new BreakdownTimerOverlay());
	}
}
