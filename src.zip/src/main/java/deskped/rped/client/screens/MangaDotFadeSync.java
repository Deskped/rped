package deskped.rped.client.screens;

import deskped.rped.RpedClientConfig;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.world.phys.Vec3;
import com.mojang.blaze3d.shaders.Uniform;

// Keeps the manga-dot block shaders (rendertype_solid/cutout/cutout_mipped/translucent)
// in sync every rendered frame:
//
// - CameraPos: pushes the camera's true world position. Vanilla's own ChunkOffset is
//   (chunk origin - camera position), so without this the dot grid drifts every time
//   the player moves. Adding CameraPos back in the vertex shader recovers a stable
//   world position, so the dots stay glued to the block and its faces instead of
//   following the player/camera.
// - FadeAmount: the 1 minute off / 1 minute on breathing cycle, eased with smoothstep
//   instead of snapping instantly.
// - VibranceBoost: the saturation push that keeps colors from washing out gray once
//   normal block shading is layered under the dots.
//
// When RpedClientConfig.MANGA_SHADING is off, FadeAmount is forced to 0 and
// VibranceBoost to 1.0 (a no-op), so blocks render exactly as they would in vanilla.
@Mod.EventBusSubscriber(Dist.CLIENT)
public class MangaDotFadeSync {

    // 60 seconds without dots + 60 seconds with dots.
    private static final double CYCLE_SECONDS = 120.0;
    // How long the smooth crossfade takes at each edge of the cycle.
    private static final double FADE_SECONDS = 4.0;

    private static final float VIBRANCE_ON = 1.35f;
    private static final float VIBRANCE_OFF = 1.0f;

    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.START) {
            return;
        }

        Camera camera = Minecraft.getInstance().gameRenderer.getMainCamera();
        Vec3 camPos = camera.getPosition();

        boolean enabled = RpedClientConfig.MANGA_SHADING;
        float fade = enabled ? computeFade((System.currentTimeMillis() / 1000.0) % CYCLE_SECONDS) : 0.0f;
        float vibrance = enabled ? VIBRANCE_ON : VIBRANCE_OFF;

        pushUniforms(GameRenderer.getRendertypeSolidShader(), camPos, fade, vibrance);
        pushUniforms(GameRenderer.getRendertypeCutoutShader(), camPos, fade, vibrance);
        pushUniforms(GameRenderer.getRendertypeCutoutMippedShader(), camPos, fade, vibrance);
        pushUniforms(GameRenderer.getRendertypeTranslucentShader(), camPos, fade, vibrance);
    }

    private static void pushUniforms(ShaderInstance shader, Vec3 camPos, float fade, float vibrance) {
        if (shader == null) {
            return;
        }
        Uniform cameraPosUniform = shader.getUniform("CameraPos");
        if (cameraPosUniform != null) {
            cameraPosUniform.set((float) camPos.x, (float) camPos.y, (float) camPos.z);
        }
        Uniform fadeUniform = shader.getUniform("FadeAmount");
        if (fadeUniform != null) {
            fadeUniform.set(fade);
        }
        Uniform vibranceUniform = shader.getUniform("VibranceBoost");
        if (vibranceUniform != null) {
            vibranceUniform.set(vibrance);
        }
    }

    // [0, FADE_SECONDS)              -> easing out of the previous "on" half
    // [FADE_SECONDS, 60)             -> flat off
    // [60, 60 + FADE_SECONDS)        -> easing into "on"
    // [60 + FADE_SECONDS, 120)       -> flat on
    private static float computeFade(double t) {
        if (t < FADE_SECONDS) {
            return (float) (1.0 - smoothstep(t / FADE_SECONDS));
        } else if (t < 60.0) {
            return 0.0f;
        } else if (t < 60.0 + FADE_SECONDS) {
            return (float) smoothstep((t - 60.0) / FADE_SECONDS);
        } else {
            return 1.0f;
        }
    }

    private static double smoothstep(double x) {
        x = Math.max(0.0, Math.min(1.0, x));
        return x * x * (3.0 - 2.0 * x);
    }
}
