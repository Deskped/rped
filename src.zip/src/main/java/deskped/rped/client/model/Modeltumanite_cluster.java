package deskped.rped.client.model;

import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class Modeltumanite_cluster<T extends Entity> extends EntityModel<T> {
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("rped", "modeltumanite_cluster"), "main");
	public final ModelPart bone6;
	public final ModelPart bone5;
	public final ModelPart bone2;
	public final ModelPart bone;
	public final ModelPart bone4;
	public final ModelPart bone3;

	public Modeltumanite_cluster(ModelPart root) {
		this.bone6 = root.getChild("bone6");
		this.bone5 = this.bone6.getChild("bone5");
		this.bone2 = this.bone6.getChild("bone2");
		this.bone = this.bone6.getChild("bone");
		this.bone4 = this.bone6.getChild("bone4");
		this.bone3 = this.bone6.getChild("bone3");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition bone6 = partdefinition.addOrReplaceChild("bone6", CubeListBuilder.create(), PartPose.offsetAndRotation(10.0F, 21.0F, -9.0F, 0.0F, -0.4363F, -0.3491F));
		PartDefinition bone5 = bone6.addOrReplaceChild("bone5",
				CubeListBuilder.create().texOffs(144, 58).addBox(-6.0F, -27.0F, 0.0F, 6.0F, 34.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(40, 158).addBox(-5.0F, -20.0F, 6.0F, 4.0F, 27.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(56, 158)
						.addBox(-9.0F, -22.0F, 1.0F, 3.0F, 29.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(68, 158).addBox(0.0F, -17.0F, 1.0F, 4.0F, 24.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 2.5744F, 0.0F));
		PartDefinition bone2 = bone6.addOrReplaceChild("bone2",
				CubeListBuilder.create().texOffs(0, 0).addBox(-6.0F, -101.0F, -4.0F, 11.0F, 108.0F, 13.0F, new CubeDeformation(0.0F)).texOffs(88, 0).addBox(-5.0F, -70.0F, 9.0F, 9.0F, 77.0F, 11.0F, new CubeDeformation(0.0F)).texOffs(88, 88)
						.addBox(-4.0F, -57.0F, -13.0F, 7.0F, 64.0F, 9.0F, new CubeDeformation(0.0F)).texOffs(48, 99).addBox(-14.0F, -42.0F, -3.0F, 8.0F, 49.0F, 10.0F, new CubeDeformation(0.0F)).texOffs(48, 0)
						.addBox(5.0F, -81.0F, -3.0F, 9.0F, 88.0F, 11.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-3.0F, 0.0F, 6.0F));
		PartDefinition bone = bone6
				.addOrReplaceChild(
						"bone", CubeListBuilder.create().texOffs(156, 139).addBox(-6.0F, -16.0F, 0.0F, 6.0F, 23.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(128, 62).addBox(-5.0F, -9.0F, 6.0F, 4.0F, 16.0F, 4.0F, new CubeDeformation(0.0F))
								.texOffs(120, 158).addBox(-9.0F, -11.0F, 1.0F, 3.0F, 18.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(156, 38).addBox(0.0F, -6.0F, 1.0F, 4.0F, 13.0F, 4.0F, new CubeDeformation(0.0F)),
						PartPose.offset(-11.0F, 0.0F, 13.0F));
		PartDefinition bone4 = bone6.addOrReplaceChild("bone4",
				CubeListBuilder.create().texOffs(120, 88).addBox(-6.0F, -57.0F, 0.0F, 6.0F, 64.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(0, 121).addBox(-5.0F, -26.0F, 7.0F, 4.0F, 33.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(128, 0)
						.addBox(-9.0F, -52.0F, 1.0F, 3.0F, 59.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(140, 0).addBox(0.0F, -47.0F, 1.0F, 4.0F, 54.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(2.0F, 0.0F, 13.0F, 0.0F, 0.8727F, 0.0F));
		PartDefinition bone3 = bone6.addOrReplaceChild("bone3",
				CubeListBuilder.create().texOffs(16, 121).addBox(-3.125F, -21.25F, -4.125F, 6.0F, 44.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(144, 98).addBox(-2.125F, -14.25F, 1.875F, 4.0F, 37.0F, 4.0F, new CubeDeformation(0.0F))
						.texOffs(144, 139).addBox(-6.125F, -16.25F, -3.125F, 3.0F, 39.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(156, 0).addBox(2.875F, -11.25F, -3.125F, 4.0F, 34.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-9.875F, -15.75F, -1.875F, 0.0F, -2.4871F, 0.0F));
		return LayerDefinition.create(meshdefinition, 256, 256);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		bone6.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}
}