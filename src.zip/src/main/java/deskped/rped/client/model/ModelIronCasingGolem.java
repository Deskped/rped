package deskped.rped.client.model;

import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class ModelIronCasingGolem<T extends Entity> extends EntityModel<T> {
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("rped", "model_iron_casing_golem"), "main");
	public final ModelPart bone;
	public final ModelPart torsdown;
	public final ModelPart torsup;
	public final ModelPart lamp;
	public final ModelPart off;
	public final ModelPart on;
	public final ModelPart right;
	public final ModelPart left;
	public final ModelPart arm;
	public final ModelPart armtwo;
	public final ModelPart armone;
	public final ModelPart head;
	public final ModelPart mount;
	public final ModelPart bolt;

	public ModelIronCasingGolem(ModelPart root) {
		this.bone = root.getChild("bone");
		this.torsdown = this.bone.getChild("torsdown");
		this.torsup = this.bone.getChild("torsup");
		this.lamp = this.torsup.getChild("lamp");
		this.off = this.lamp.getChild("off");
		this.on = this.lamp.getChild("on");
		this.right = root.getChild("right");
		this.left = root.getChild("left");
		this.arm = root.getChild("arm");
		this.armtwo = this.arm.getChild("armtwo");
		this.armone = this.arm.getChild("armone");
		this.head = root.getChild("head");
		this.mount = this.head.getChild("mount");
		this.bolt = this.head.getChild("bolt");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition bone = partdefinition.addOrReplaceChild("bone", CubeListBuilder.create(), PartPose.offset(0.0F, -9.5F, 4.75F));
		PartDefinition torsdown = bone.addOrReplaceChild("torsdown", CubeListBuilder.create(), PartPose.offset(0.0F, -1.0F, 0.0F));
		PartDefinition cube_r1 = torsdown.addOrReplaceChild("cube_r1", CubeListBuilder.create().texOffs(80, 0).addBox(-9.0F, 0.5F, -5.75F, 18.0F, 14.0F, 13.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.5672F, 0.0F, 0.0F));
		PartDefinition cube_r2 = torsdown.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(48, 126).addBox(-3.0F, -7.0F, -13.0F, 8.0F, 2.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-15.7F, -1.5F, 2.75F, -3.1416F, -1.4399F, -1.5708F));
		PartDefinition cube_r3 = torsdown.addOrReplaceChild("cube_r3", CubeListBuilder.create().texOffs(48, 126).addBox(-3.0F, -7.0F, -13.0F, 8.0F, 2.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(3.8F, -1.5F, 2.75F, -3.1416F, -1.4399F, -1.5708F));
		PartDefinition torsup = bone.addOrReplaceChild("torsup", CubeListBuilder.create(), PartPose.offset(0.0F, -1.0F, 0.0F));
		PartDefinition cube_r4 = torsup.addOrReplaceChild("cube_r4", CubeListBuilder.create().texOffs(48, 126).addBox(-3.0F, -7.0F, -13.0F, 8.0F, 2.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-18.7F, -18.5F, -10.25F, -3.1416F, -1.4399F, -1.5708F));
		PartDefinition cube_r5 = torsup.addOrReplaceChild("cube_r5", CubeListBuilder.create().texOffs(48, 126).addBox(-3.0F, -7.0F, -13.0F, 8.0F, 2.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(6.8F, -17.5F, -12.25F, -3.1416F, -1.4399F, -1.5708F));
		PartDefinition cube_r6 = torsup.addOrReplaceChild("cube_r6", CubeListBuilder.create().texOffs(0, 0).addBox(-12.0F, -15.5F, -8.75F, 24.0F, 16.0F, 16.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.5672F, 0.0F, 0.0F));
		PartDefinition cube_r7 = torsup.addOrReplaceChild("cube_r7", CubeListBuilder.create().texOffs(48, 126).addBox(-3.0F, -7.0F, -13.0F, 8.0F, 2.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-14.7F, -17.5F, -16.25F, -3.1416F, -1.4399F, -1.5708F));
		PartDefinition cube_r8 = torsup.addOrReplaceChild("cube_r8", CubeListBuilder.create().texOffs(48, 126).addBox(-3.0F, -7.0F, -13.0F, 8.0F, 2.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(2.8F, -17.5F, -16.25F, -3.1416F, -1.4399F, -1.5708F));
		PartDefinition lamp = torsup.addOrReplaceChild("lamp", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
		PartDefinition cube_r9 = lamp.addOrReplaceChild("cube_r9", CubeListBuilder.create().texOffs(112, 87).addBox(-5.0F, -12.5F, 7.25F, 9.0F, 9.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.5672F, 0.0F, 0.0F));
		PartDefinition off = lamp.addOrReplaceChild("off", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
		PartDefinition cube_r10 = off.addOrReplaceChild("cube_r10",
				CubeListBuilder.create().texOffs(108, 74).addBox(-4.0F, -11.5F, 9.25F, 7.0F, 7.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(108, 27).addBox(-5.0F, -12.5F, 9.25F, 9.0F, 9.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.5672F, 0.0F, 0.0F));
		PartDefinition on = lamp.addOrReplaceChild("on", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
		PartDefinition cube_r11 = on.addOrReplaceChild("cube_r11",
				CubeListBuilder.create().texOffs(108, 44).addBox(-5.0F, -12.5F, 9.25F, 9.0F, 9.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(108, 61).addBox(-4.0F, -11.5F, 9.25F, 7.0F, 7.0F, 6.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.5672F, 0.0F, 0.0F));
		PartDefinition right = partdefinition.addOrReplaceChild("right", CubeListBuilder.create().texOffs(44, 88).addBox(-3.9711F, -14.9769F, -4.3526F, 8.0F, 29.0F, 9.0F, new CubeDeformation(0.0F)), PartPose.offset(-13.0305F, 10.0231F, 12.3529F));
		PartDefinition left = partdefinition.addOrReplaceChild("left", CubeListBuilder.create().texOffs(78, 88).addBox(-4.0F, -12.5347F, 1.9333F, 8.0F, 29.0F, 9.0F, new CubeDeformation(0.0F)), PartPose.offset(13.0F, 9.1096F, 5.0371F));
		PartDefinition arm = partdefinition.addOrReplaceChild("arm", CubeListBuilder.create(), PartPose.offset(-0.0286F, -16.4958F, -7.0596F));
		PartDefinition armtwo = arm.addOrReplaceChild("armtwo", CubeListBuilder.create().texOffs(64, 32).addBox(-5.5F, -5.5F, -5.5F, 11.0F, 45.0F, 11.0F, new CubeDeformation(0.0F)), PartPose.offset(17.5286F, 0.9958F, 0.5596F));
		PartDefinition armone = arm.addOrReplaceChild("armone",
				CubeListBuilder.create().texOffs(0, 72).addBox(-5.4429F, -3.0418F, -4.3809F, 11.0F, 45.0F, 11.0F, new CubeDeformation(0.0F)).texOffs(48, 126).addBox(-3.8429F, -5.0418F, -2.8809F, 8.0F, 2.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-17.5286F, -1.4624F, -0.5596F));
		PartDefinition cube_r12 = armone.addOrReplaceChild("cube_r12", CubeListBuilder.create().texOffs(48, 126).addBox(-4.0F, -1.0F, -4.0F, 8.0F, 2.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-5.8429F, 8.9582F, 0.1191F, 0.0F, 1.4835F, -1.5708F));
		PartDefinition cube_r13 = armone.addOrReplaceChild("cube_r13", CubeListBuilder.create().texOffs(48, 126).addBox(-3.0F, -7.0F, -13.0F, 8.0F, 2.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.1571F, 18.9582F, -1.8809F, -3.1416F, -1.4399F, -1.5708F));
		PartDefinition cube_r14 = armone.addOrReplaceChild("cube_r14", CubeListBuilder.create().texOffs(48, 126).addBox(-4.0F, -1.0F, -4.0F, 8.0F, 2.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.8429F, 12.9582F, 7.1191F, -1.5708F, 0.0F, -3.0543F));
		PartDefinition cube_r15 = armone.addOrReplaceChild("cube_r15", CubeListBuilder.create().texOffs(48, 126).addBox(-4.0F, -1.0F, -4.0F, 8.0F, 2.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.8429F, 13.9582F, -4.8809F, 1.5708F, 0.0F, 0.1745F));
		PartDefinition cube_r16 = armone.addOrReplaceChild("cube_r16", CubeListBuilder.create().texOffs(48, 126).addBox(-4.0F, -1.0F, -4.0F, 8.0F, 2.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.1571F, 25.9582F, -4.8809F, 1.5708F, 0.0F, -0.2182F));
		PartDefinition head = partdefinition.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 32).addBox(-11.0F, -13.0F, -3.0F, 16.0F, 16.0F, 16.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(3.0F, -19.0F, -16.0F, 0.2182F, 0.0F, 0.0F));
		PartDefinition mount = head.addOrReplaceChild("mount", CubeListBuilder.create().texOffs(0, 144).addBox(-8.0F, -4.0F, -8.0F, 16.0F, 8.0F, 16.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-3.0F, 7.0F, 5.0F, 0.3054F, 0.0F, 0.0F));
		PartDefinition bolt = head.addOrReplaceChild("bolt", CubeListBuilder.create().texOffs(112, 98).addBox(-7.0F, -8.0F, -1.0F, 8.0F, 8.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(3.0F, 1.0F, -5.0F));
		return LayerDefinition.create(meshdefinition, 142, 168);
	}

	@Override
	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		bone.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		right.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		left.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		arm.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		head.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}