package deskped.rped.client.model;

import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class Modeltumanitangel<T extends Entity> extends EntityModel<T> {
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("rped", "modeltumanitangel"), "main");
	public final ModelPart core;
	public final ModelPart circleone;
	public final ModelPart circleone2;
	public final ModelPart midle;
	public final ModelPart cr7;
	public final ModelPart cr5;
	public final ModelPart cr4;
	public final ModelPart cr10;
	public final ModelPart cr8;
	public final ModelPart cr6;
	public final ModelPart cr3;
	public final ModelPart up;
	public final ModelPart cr18;
	public final ModelPart cr19;
	public final ModelPart cr20;
	public final ModelPart cr21;
	public final ModelPart cr22;
	public final ModelPart cr23;
	public final ModelPart cr24;
	public final ModelPart cr2;
	public final ModelPart down;
	public final ModelPart cr17;
	public final ModelPart cr16;
	public final ModelPart cr15;
	public final ModelPart cr14;
	public final ModelPart cr13;
	public final ModelPart cr12;
	public final ModelPart cr11;
	public final ModelPart cr;
	public final ModelPart small;
	public final ModelPart midle2;
	public final ModelPart cr26;
	public final ModelPart cr27;
	public final ModelPart cr28;
	public final ModelPart cr29;
	public final ModelPart cr30;
	public final ModelPart cr31;
	public final ModelPart cr32;
	public final ModelPart up2;
	public final ModelPart cr33;
	public final ModelPart cr34;
	public final ModelPart cr35;
	public final ModelPart cr36;
	public final ModelPart cr37;
	public final ModelPart cr38;
	public final ModelPart cr39;
	public final ModelPart cr40;
	public final ModelPart down2;
	public final ModelPart cr41;
	public final ModelPart cr42;
	public final ModelPart cr43;
	public final ModelPart cr44;
	public final ModelPart cr45;
	public final ModelPart cr46;
	public final ModelPart cr47;
	public final ModelPart cr48;

	public Modeltumanitangel(ModelPart root) {
		this.core = root.getChild("core");
		this.circleone = root.getChild("circleone");
		this.circleone2 = root.getChild("circleone2");
		this.midle = root.getChild("midle");
		this.cr7 = this.midle.getChild("cr7");
		this.cr5 = this.midle.getChild("cr5");
		this.cr4 = this.midle.getChild("cr4");
		this.cr10 = this.midle.getChild("cr10");
		this.cr8 = this.midle.getChild("cr8");
		this.cr6 = this.midle.getChild("cr6");
		this.cr3 = this.midle.getChild("cr3");
		this.up = root.getChild("up");
		this.cr18 = this.up.getChild("cr18");
		this.cr19 = this.up.getChild("cr19");
		this.cr20 = this.up.getChild("cr20");
		this.cr21 = this.up.getChild("cr21");
		this.cr22 = this.up.getChild("cr22");
		this.cr23 = this.up.getChild("cr23");
		this.cr24 = this.up.getChild("cr24");
		this.cr2 = this.up.getChild("cr2");
		this.down = root.getChild("down");
		this.cr17 = this.down.getChild("cr17");
		this.cr16 = this.down.getChild("cr16");
		this.cr15 = this.down.getChild("cr15");
		this.cr14 = this.down.getChild("cr14");
		this.cr13 = this.down.getChild("cr13");
		this.cr12 = this.down.getChild("cr12");
		this.cr11 = this.down.getChild("cr11");
		this.cr = this.down.getChild("cr");
		this.small = root.getChild("small");
		this.midle2 = this.small.getChild("midle2");
		this.cr26 = this.midle2.getChild("cr26");
		this.cr27 = this.midle2.getChild("cr27");
		this.cr28 = this.midle2.getChild("cr28");
		this.cr29 = this.midle2.getChild("cr29");
		this.cr30 = this.midle2.getChild("cr30");
		this.cr31 = this.midle2.getChild("cr31");
		this.cr32 = this.midle2.getChild("cr32");
		this.up2 = this.small.getChild("up2");
		this.cr33 = this.up2.getChild("cr33");
		this.cr34 = this.up2.getChild("cr34");
		this.cr35 = this.up2.getChild("cr35");
		this.cr36 = this.up2.getChild("cr36");
		this.cr37 = this.up2.getChild("cr37");
		this.cr38 = this.up2.getChild("cr38");
		this.cr39 = this.up2.getChild("cr39");
		this.cr40 = this.up2.getChild("cr40");
		this.down2 = this.small.getChild("down2");
		this.cr41 = this.down2.getChild("cr41");
		this.cr42 = this.down2.getChild("cr42");
		this.cr43 = this.down2.getChild("cr43");
		this.cr44 = this.down2.getChild("cr44");
		this.cr45 = this.down2.getChild("cr45");
		this.cr46 = this.down2.getChild("cr46");
		this.cr47 = this.down2.getChild("cr47");
		this.cr48 = this.down2.getChild("cr48");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition core = partdefinition.addOrReplaceChild("core", CubeListBuilder.create().texOffs(32, 0).addBox(-4.0F, -3.6667F, -4.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 10.1667F, -0.2F));
		PartDefinition circleone = partdefinition.addOrReplaceChild("circleone",
				CubeListBuilder.create().texOffs(-10, 19).addBox(-5.5F, -1.0F, -5.5F, 11.0F, 2.0F, 11.0F, new CubeDeformation(0.0F)).texOffs(1, 19).addBox(5.4F, -1.0F, -5.5F, 0.0F, 2.0F, 11.0F, new CubeDeformation(0.0F)).texOffs(1, 30)
						.addBox(-5.5F, -1.0F, -5.4F, 11.0F, 2.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(-10, 19).addBox(-5.4F, -1.0F, -5.5F, 0.0F, 2.0F, 11.0F, new CubeDeformation(0.0F)).texOffs(1, 30)
						.addBox(-5.5F, -1.0F, 5.4F, 11.0F, 2.0F, 0.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 10.0F, 0.0F));
		PartDefinition circleone2 = partdefinition.addOrReplaceChild("circleone2", CubeListBuilder.create(), PartPose.offset(0.0F, 10.5F, 0.02F));
		PartDefinition cube_r1 = circleone2.addOrReplaceChild("cube_r1", CubeListBuilder.create().texOffs(4, 30).addBox(-8.0F, -1.0F, -4.0F, 12.0F, 2.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(4, 30)
				.addBox(-8.0F, -1.0F, 7.7F, 12.0F, 2.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(0, 18).addBox(-8.0F, -1.0F, -4.2F, 12.0F, 2.0F, 12.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 2.0F, -1.82F, 0.0F, 0.0F, 1.5708F));
		PartDefinition cube_r2 = circleone2.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(0, 18).addBox(-8.0F, -1.0F, -4.0F, 0.0F, 2.0F, 12.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 2.1F, -2.02F, 0.0F, 0.0F, 1.5708F));
		PartDefinition cube_r3 = circleone2.addOrReplaceChild("cube_r3", CubeListBuilder.create().texOffs(12, 18).addBox(4.0F, -1.0F, -4.0F, 0.0F, 2.0F, 12.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 1.9F, -2.02F, 0.0F, 0.0F, 1.5708F));
		PartDefinition midle = partdefinition.addOrReplaceChild("midle", CubeListBuilder.create(), PartPose.offsetAndRotation(0.125F, 10.1167F, 0.1125F, 0.0F, -0.4363F, 0.0F));
		PartDefinition cr7 = midle.addOrReplaceChild("cr7", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.125F, 0.65F, 0.1875F, 2.4435F, 0.0F, -1.5708F));
		PartDefinition cube_r4 = cr7.addOrReplaceChild("cube_r4", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 13.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r5 = cr7.addOrReplaceChild("cube_r5", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 13.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr5 = midle.addOrReplaceChild("cr5", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.125F, 0.35F, 13.1875F, 1.5708F, 0.0F, -1.5708F));
		PartDefinition cube_r6 = cr5.addOrReplaceChild("cube_r6", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r7 = cr5.addOrReplaceChild("cube_r7", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr4 = midle.addOrReplaceChild("cr4", CubeListBuilder.create(), PartPose.offsetAndRotation(12.875F, 0.35F, -0.3125F, 0.0F, 0.0F, -1.5708F));
		PartDefinition cube_r8 = cr4.addOrReplaceChild("cube_r8", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r9 = cr4.addOrReplaceChild("cube_r9", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr10 = midle.addOrReplaceChild("cr10", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.125F, -1.35F, 0.1875F, 0.829F, 0.0F, -1.5708F));
		PartDefinition cube_r10 = cr10.addOrReplaceChild("cube_r10", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 13.5F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r11 = cr10.addOrReplaceChild("cube_r11", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 13.5F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr8 = midle.addOrReplaceChild("cr8", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.125F, 0.65F, 0.1875F, -0.6981F, 0.0F, -1.5708F));
		PartDefinition cube_r12 = cr8.addOrReplaceChild("cube_r12", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 13.5F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r13 = cr8.addOrReplaceChild("cube_r13", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 13.5F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr6 = midle.addOrReplaceChild("cr6", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.125F, 0.35F, -13.3125F, -1.5708F, 0.0F, -1.5708F));
		PartDefinition cube_r14 = cr6.addOrReplaceChild("cube_r14", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r15 = cr6.addOrReplaceChild("cube_r15", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr3 = midle.addOrReplaceChild("cr3", CubeListBuilder.create(), PartPose.offsetAndRotation(-12.125F, 0.35F, -0.3125F, 3.1416F, 0.0F, -1.5708F));
		PartDefinition cube_r16 = cr3.addOrReplaceChild("cube_r16", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r17 = cr3.addOrReplaceChild("cube_r17", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition up = partdefinition.addOrReplaceChild("up", CubeListBuilder.create(), PartPose.offset(0.0151F, 4.8667F, 0.1184F));
		PartDefinition cr18 = up.addOrReplaceChild("cr18", CubeListBuilder.create(), PartPose.offsetAndRotation(-8.8978F, -2.1F, -9.403F, -2.3976F, -0.4073F, -1.1644F));
		PartDefinition cube_r18 = cr18.addOrReplaceChild("cube_r18", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r19 = cr18.addOrReplaceChild("cube_r19", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr19 = up.addOrReplaceChild("cr19", CubeListBuilder.create(), PartPose.offsetAndRotation(-10.0737F, -0.1F, 8.5378F, 2.5257F, 0.3526F, -1.1168F));
		PartDefinition cube_r20 = cr19.addOrReplaceChild("cube_r20", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r21 = cr19.addOrReplaceChild("cube_r21", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr20 = up.addOrReplaceChild("cr20", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.1151F, -0.4F, 13.1816F, 1.5708F, 0.5672F, -1.5708F));
		PartDefinition cube_r22 = cr20.addOrReplaceChild("cube_r22", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r23 = cr20.addOrReplaceChild("cube_r23", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr21 = up.addOrReplaceChild("cr21", CubeListBuilder.create(), PartPose.offsetAndRotation(12.8849F, -0.4F, -0.3184F, 0.0F, 0.0F, -2.138F));
		PartDefinition cube_r24 = cr21.addOrReplaceChild("cube_r24", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r25 = cr21.addOrReplaceChild("cube_r25", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr22 = up.addOrReplaceChild("cr22", CubeListBuilder.create(), PartPose.offsetAndRotation(9.0054F, -2.1F, 10.1348F, 0.744F, 0.4073F, -1.9772F));
		PartDefinition cube_r26 = cr22.addOrReplaceChild("cube_r26", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r27 = cr22.addOrReplaceChild("cube_r27", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr23 = up.addOrReplaceChild("cr23", CubeListBuilder.create(), PartPose.offsetAndRotation(10.2265F, -0.1F, -8.496F, -0.6159F, -0.3526F, -2.0248F));
		PartDefinition cube_r28 = cr23.addOrReplaceChild("cube_r28", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r29 = cr23.addOrReplaceChild("cube_r29", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr24 = up.addOrReplaceChild("cr24", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.1151F, -0.4F, -13.3184F, -1.5708F, -0.5672F, -1.5708F));
		PartDefinition cube_r30 = cr24.addOrReplaceChild("cube_r30", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r31 = cr24.addOrReplaceChild("cube_r31", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr2 = up.addOrReplaceChild("cr2", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.1151F, 5.6F, -0.3184F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cube_r32 = cr2.addOrReplaceChild("cube_r32", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 13.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r33 = cr2.addOrReplaceChild("cube_r33", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 13.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition down = partdefinition.addOrReplaceChild("down", CubeListBuilder.create(), PartPose.offset(1.7151F, 18.0042F, 0.1184F));
		PartDefinition cr17 = down.addOrReplaceChild("cr17", CubeListBuilder.create(), PartPose.offsetAndRotation(-1.7151F, 1.4625F, -13.3184F, -1.5708F, 0.8727F, -1.5708F));
		PartDefinition cube_r34 = cr17.addOrReplaceChild("cube_r34", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r35 = cr17.addOrReplaceChild("cube_r35", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr16 = down.addOrReplaceChild("cr16", CubeListBuilder.create(), PartPose.offsetAndRotation(8.6265F, 1.7625F, -8.496F, -0.4946F, 0.5148F, -0.8309F));
		PartDefinition cube_r36 = cr16.addOrReplaceChild("cube_r36", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r37 = cr16.addOrReplaceChild("cube_r37", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr15 = down.addOrReplaceChild("cr15", CubeListBuilder.create(), PartPose.offsetAndRotation(7.4054F, -0.2375F, 10.1348F, 0.6117F, -0.6002F, -0.8929F));
		PartDefinition cube_r38 = cr15.addOrReplaceChild("cube_r38", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r39 = cr15.addOrReplaceChild("cube_r39", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr14 = down.addOrReplaceChild("cr14", CubeListBuilder.create(), PartPose.offsetAndRotation(11.2849F, 1.4625F, -0.3184F, 0.0F, 0.0F, -0.6981F));
		PartDefinition cube_r40 = cr14.addOrReplaceChild("cube_r40", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r41 = cr14.addOrReplaceChild("cube_r41", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr13 = down.addOrReplaceChild("cr13", CubeListBuilder.create(), PartPose.offsetAndRotation(-1.7151F, 1.4625F, 13.1816F, 1.5708F, -0.8727F, -1.5708F));
		PartDefinition cube_r42 = cr13.addOrReplaceChild("cube_r42", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r43 = cr13.addOrReplaceChild("cube_r43", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr12 = down.addOrReplaceChild("cr12", CubeListBuilder.create(), PartPose.offsetAndRotation(-11.6737F, 1.7625F, 8.5378F, 2.647F, -0.5148F, -2.3107F));
		PartDefinition cube_r44 = cr12.addOrReplaceChild("cube_r44", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r45 = cr12.addOrReplaceChild("cube_r45", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr11 = down.addOrReplaceChild("cr11", CubeListBuilder.create(), PartPose.offsetAndRotation(-10.4978F, -0.2375F, -9.403F, -2.5299F, 0.6002F, -2.2487F));
		PartDefinition cube_r46 = cr11.addOrReplaceChild("cube_r46", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r47 = cr11.addOrReplaceChild("cube_r47", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr = down.addOrReplaceChild("cr", CubeListBuilder.create(), PartPose.offset(-1.7151F, -7.4375F, -0.3184F));
		PartDefinition cube_r48 = cr.addOrReplaceChild("cube_r48", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 13.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r49 = cr.addOrReplaceChild("cube_r49", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 13.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition small = partdefinition.addOrReplaceChild("small", CubeListBuilder.create(), PartPose.offset(0.6184F, 10.9958F, 0.1164F));
		PartDefinition midle2 = small.addOrReplaceChild("midle2", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.4934F, -0.8792F, -0.0039F, 0.0F, -0.4363F, 0.0F));
		PartDefinition cr26 = midle2.addOrReplaceChild("cr26", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.125F, 0.65F, 0.1875F, 2.4435F, 0.0F, -1.5708F));
		PartDefinition cube_r50 = cr26.addOrReplaceChild("cube_r50", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 13.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r51 = cr26.addOrReplaceChild("cube_r51", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 13.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr27 = midle2.addOrReplaceChild("cr27", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.125F, 0.35F, 13.1875F, 1.5708F, 0.0F, -1.5708F));
		PartDefinition cube_r52 = cr27.addOrReplaceChild("cube_r52", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r53 = cr27.addOrReplaceChild("cube_r53", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr28 = midle2.addOrReplaceChild("cr28", CubeListBuilder.create(), PartPose.offsetAndRotation(12.875F, 0.35F, -0.3125F, 0.0F, 0.0F, -1.5708F));
		PartDefinition cube_r54 = cr28.addOrReplaceChild("cube_r54", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r55 = cr28.addOrReplaceChild("cube_r55", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr29 = midle2.addOrReplaceChild("cr29", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.125F, -1.35F, 0.1875F, 0.829F, 0.0F, -1.5708F));
		PartDefinition cube_r56 = cr29.addOrReplaceChild("cube_r56", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 13.5F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r57 = cr29.addOrReplaceChild("cube_r57", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 13.5F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr30 = midle2.addOrReplaceChild("cr30", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.125F, 0.65F, 0.1875F, -0.6981F, 0.0F, -1.5708F));
		PartDefinition cube_r58 = cr30.addOrReplaceChild("cube_r58", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 13.5F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r59 = cr30.addOrReplaceChild("cube_r59", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 13.5F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr31 = midle2.addOrReplaceChild("cr31", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.125F, 0.35F, -13.3125F, -1.5708F, 0.0F, -1.5708F));
		PartDefinition cube_r60 = cr31.addOrReplaceChild("cube_r60", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r61 = cr31.addOrReplaceChild("cube_r61", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr32 = midle2.addOrReplaceChild("cr32", CubeListBuilder.create(), PartPose.offsetAndRotation(-12.125F, 0.35F, -0.3125F, 3.1416F, 0.0F, -1.5708F));
		PartDefinition cube_r62 = cr32.addOrReplaceChild("cube_r62", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r63 = cr32.addOrReplaceChild("cube_r63", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition up2 = small.addOrReplaceChild("up2", CubeListBuilder.create(), PartPose.offset(-0.6033F, -6.1292F, 0.002F));
		PartDefinition cr33 = up2.addOrReplaceChild("cr33", CubeListBuilder.create(), PartPose.offsetAndRotation(-8.8978F, -2.1F, -9.403F, -2.3976F, -0.4073F, -1.1644F));
		PartDefinition cube_r64 = cr33.addOrReplaceChild("cube_r64", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r65 = cr33.addOrReplaceChild("cube_r65", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr34 = up2.addOrReplaceChild("cr34", CubeListBuilder.create(), PartPose.offsetAndRotation(-10.0737F, -0.1F, 8.5378F, 2.5257F, 0.3526F, -1.1168F));
		PartDefinition cube_r66 = cr34.addOrReplaceChild("cube_r66", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r67 = cr34.addOrReplaceChild("cube_r67", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr35 = up2.addOrReplaceChild("cr35", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.1151F, -0.4F, 13.1816F, 1.5708F, 0.5672F, -1.5708F));
		PartDefinition cube_r68 = cr35.addOrReplaceChild("cube_r68", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r69 = cr35.addOrReplaceChild("cube_r69", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr36 = up2.addOrReplaceChild("cr36", CubeListBuilder.create(), PartPose.offsetAndRotation(12.8849F, -0.4F, -0.3184F, 0.0F, 0.0F, -2.138F));
		PartDefinition cube_r70 = cr36.addOrReplaceChild("cube_r70", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r71 = cr36.addOrReplaceChild("cube_r71", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr37 = up2.addOrReplaceChild("cr37", CubeListBuilder.create(), PartPose.offsetAndRotation(9.0054F, -2.1F, 10.1348F, 0.744F, 0.4073F, -1.9772F));
		PartDefinition cube_r72 = cr37.addOrReplaceChild("cube_r72", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r73 = cr37.addOrReplaceChild("cube_r73", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr38 = up2.addOrReplaceChild("cr38", CubeListBuilder.create(), PartPose.offsetAndRotation(10.2265F, -0.1F, -8.496F, -0.6159F, -0.3526F, -2.0248F));
		PartDefinition cube_r74 = cr38.addOrReplaceChild("cube_r74", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r75 = cr38.addOrReplaceChild("cube_r75", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr39 = up2.addOrReplaceChild("cr39", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.1151F, -0.4F, -13.3184F, -1.5708F, -0.5672F, -1.5708F));
		PartDefinition cube_r76 = cr39.addOrReplaceChild("cube_r76", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r77 = cr39.addOrReplaceChild("cube_r77", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr40 = up2.addOrReplaceChild("cr40", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.1151F, 5.6F, -0.3184F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cube_r78 = cr40.addOrReplaceChild("cube_r78", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 13.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r79 = cr40.addOrReplaceChild("cube_r79", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 13.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition down2 = small.addOrReplaceChild("down2", CubeListBuilder.create(), PartPose.offset(1.0967F, 7.0083F, 0.002F));
		PartDefinition cr41 = down2.addOrReplaceChild("cr41", CubeListBuilder.create(), PartPose.offsetAndRotation(-1.7151F, 1.4625F, -13.3184F, -1.5708F, 0.8727F, -1.5708F));
		PartDefinition cube_r80 = cr41.addOrReplaceChild("cube_r80", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r81 = cr41.addOrReplaceChild("cube_r81", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr42 = down2.addOrReplaceChild("cr42", CubeListBuilder.create(), PartPose.offsetAndRotation(8.6265F, 1.7625F, -8.496F, -0.4946F, 0.5148F, -0.8309F));
		PartDefinition cube_r82 = cr42.addOrReplaceChild("cube_r82", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r83 = cr42.addOrReplaceChild("cube_r83", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr43 = down2.addOrReplaceChild("cr43", CubeListBuilder.create(), PartPose.offsetAndRotation(7.4054F, -0.2375F, 10.1348F, 0.6117F, -0.6002F, -0.8929F));
		PartDefinition cube_r84 = cr43.addOrReplaceChild("cube_r84", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r85 = cr43.addOrReplaceChild("cube_r85", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr44 = down2.addOrReplaceChild("cr44", CubeListBuilder.create(), PartPose.offsetAndRotation(11.2849F, 1.4625F, -0.3184F, 0.0F, 0.0F, -0.6981F));
		PartDefinition cube_r86 = cr44.addOrReplaceChild("cube_r86", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r87 = cr44.addOrReplaceChild("cube_r87", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr45 = down2.addOrReplaceChild("cr45", CubeListBuilder.create(), PartPose.offsetAndRotation(-1.7151F, 1.4625F, 13.1816F, 1.5708F, -0.8727F, -1.5708F));
		PartDefinition cube_r88 = cr45.addOrReplaceChild("cube_r88", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r89 = cr45.addOrReplaceChild("cube_r89", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr46 = down2.addOrReplaceChild("cr46", CubeListBuilder.create(), PartPose.offsetAndRotation(-11.6737F, 1.7625F, 8.5378F, 2.647F, -0.5148F, -2.3107F));
		PartDefinition cube_r90 = cr46.addOrReplaceChild("cube_r90", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r91 = cr46.addOrReplaceChild("cube_r91", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr47 = down2.addOrReplaceChild("cr47", CubeListBuilder.create(), PartPose.offsetAndRotation(-10.4978F, -0.2375F, -9.403F, -2.5299F, 0.6002F, -2.2487F));
		PartDefinition cube_r92 = cr47.addOrReplaceChild("cube_r92", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r93 = cr47.addOrReplaceChild("cube_r93", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		PartDefinition cr48 = down2.addOrReplaceChild("cr48", CubeListBuilder.create(), PartPose.offset(-1.7151F, -7.4375F, -0.3184F));
		PartDefinition cube_r94 = cr48.addOrReplaceChild("cube_r94", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 13.0F, 0.0F, 0.0F, -1.5708F, 3.1416F));
		PartDefinition cube_r95 = cr48.addOrReplaceChild("cube_r95", CubeListBuilder.create().texOffs(0, 36).addBox(0.0F, -7.0F, -7.0F, 0.0F, 14.0F, 14.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 13.0F, 0.0F, 3.1416F, 0.0F, 0.0F));
		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		core.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		circleone.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		circleone2.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		midle.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		up.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		down.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		small.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}
}