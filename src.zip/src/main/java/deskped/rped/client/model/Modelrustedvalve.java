package deskped.rped.client.model;

import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class Modelrustedvalve<T extends Entity> extends EntityModel<T> {
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("rped", "modelrustedvalve"), "main");
	public final ModelPart val;

	public Modelrustedvalve(ModelPart root) {
		this.val = root.getChild("val");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition val = partdefinition.addOrReplaceChild(
				"val", CubeListBuilder.create().texOffs(0, 0).addBox(3.9717F, -2.3989F, -5.9982F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(0, 0).addBox(-4.0283F, -2.3989F, -7.9982F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F))
						.texOffs(0, 0).addBox(-1.0283F, 2.7367F, -0.691F, 2.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(0, 0).addBox(-6.0283F, -2.3989F, -5.9982F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0283F, 19.2633F, -0.309F));
		PartDefinition cube_r1 = val.addOrReplaceChild("cube_r1",
				CubeListBuilder.create().texOffs(0, 0).addBox(2.005F, -6.995F, -1.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(0, 0).addBox(-6.005F, 1.995F, -1.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.0283F, 1.2082F, 0.0161F, 0.0F, 0.0F, 0.7854F));
		PartDefinition cube_r2 = val.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, -9.0F, -1.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.9717F, 4.7367F, -0.691F, 0.7854F, 0.0F, 0.0F));
		PartDefinition cube_r3 = val.addOrReplaceChild("cube_r3", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, -8.0F, 1.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.9717F, 3.3367F, -0.691F, -0.7854F, 0.0F, 0.0F));
		PartDefinition cube_r4 = val.addOrReplaceChild("cube_r4", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -2.3096F, -2.5951F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5717F, -0.0893F, -0.0031F, 0.0F, 1.5708F, 0.0F));
		PartDefinition cube_r5 = val.addOrReplaceChild("cube_r5",
				CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -2.3096F, -2.5951F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(0, 0).addBox(-6.0F, -2.3096F, -0.5951F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.0283F, -0.0893F, 5.3969F, -3.1416F, 0.0F, -3.1416F));
		PartDefinition cube_r6 = val.addOrReplaceChild("cube_r6",
				CubeListBuilder.create().texOffs(0, 0).addBox(-6.0F, -2.3096F, -0.5951F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(0, 0).addBox(-4.0F, -2.3096F, -2.5951F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-5.4283F, -0.0893F, -0.0031F, 0.0F, 1.5708F, 0.0F));
		return LayerDefinition.create(meshdefinition, 16, 16);
	}

	@Override
	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		val.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}