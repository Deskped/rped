package deskped.rped.client.model;

import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class Modelezonet<T extends Entity> extends EntityModel<T> {
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("rped", "modelezonet"), "main");
	public final ModelPart ezonetclose;
	public final ModelPart onetotwo;
	public final ModelPart twototwo;
	public final ModelPart twotothree;
	public final ModelPart rotate;
	public final ModelPart one;
	public final ModelPart two;
	public final ModelPart three;
	public final ModelPart four;
	public final ModelPart five;
	public final ModelPart bb_main;

	public Modelezonet(ModelPart root) {
		this.ezonetclose = root.getChild("ezonetclose");
		this.onetotwo = root.getChild("onetotwo");
		this.twototwo = root.getChild("twototwo");
		this.twotothree = root.getChild("twotothree");
		this.rotate = root.getChild("rotate");
		this.one = this.rotate.getChild("one");
		this.two = this.rotate.getChild("two");
		this.three = this.rotate.getChild("three");
		this.four = this.rotate.getChild("four");
		this.five = this.rotate.getChild("five");
		this.bb_main = root.getChild("bb_main");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition ezonetclose = partdefinition.addOrReplaceChild("ezonetclose", CubeListBuilder.create().texOffs(0, 0).addBox(-15.0F, -16.0F, -1.0F, 16.0F, 0.0F, 16.0F, new CubeDeformation(0.0F)), PartPose.offset(7.0F, 24.0F, -7.0F));
		PartDefinition onetotwo = partdefinition.addOrReplaceChild("onetotwo", CubeListBuilder.create().texOffs(0, 32).addBox(-15.0F, -16.0F, -1.0F, 16.0F, 0.0F, 16.0F, new CubeDeformation(0.0F)), PartPose.offset(7.0F, 24.0F, -7.0F));
		PartDefinition twototwo = partdefinition.addOrReplaceChild("twototwo", CubeListBuilder.create().texOffs(0, 48).addBox(-15.0F, -16.0F, -1.0F, 16.0F, 0.0F, 16.0F, new CubeDeformation(0.0F)), PartPose.offset(7.0F, 24.0F, -7.0F));
		PartDefinition twotothree = partdefinition.addOrReplaceChild("twotothree", CubeListBuilder.create().texOffs(0, 64).addBox(-15.0F, -16.0F, -1.0F, 16.0F, 0.0F, 16.0F, new CubeDeformation(0.0F)), PartPose.offset(7.0F, 24.0F, -7.0F));
		PartDefinition rotate = partdefinition.addOrReplaceChild("rotate", CubeListBuilder.create(), PartPose.offset(0.0F, 8.1F, 0.0F));
		PartDefinition one = rotate.addOrReplaceChild("one", CubeListBuilder.create().texOffs(91, 0).addBox(-11.0F, -16.0F, -1.0F, 12.0F, 0.0F, 12.0F, new CubeDeformation(0.0F)), PartPose.offset(5.0F, 16.0F, -5.0F));
		PartDefinition two = rotate.addOrReplaceChild("two", CubeListBuilder.create().texOffs(91, 16).addBox(-11.0F, -16.0F, -1.0F, 12.0F, 0.0F, 12.0F, new CubeDeformation(0.0F)), PartPose.offset(5.0F, 16.0F, -5.0F));
		PartDefinition three = rotate.addOrReplaceChild("three", CubeListBuilder.create().texOffs(91, 32).addBox(-11.0F, -16.0F, -1.0F, 12.0F, 0.0F, 12.0F, new CubeDeformation(0.0F)), PartPose.offset(5.0F, 16.0F, -5.0F));
		PartDefinition four = rotate.addOrReplaceChild("four", CubeListBuilder.create().texOffs(91, 48).addBox(-11.0F, -16.0F, -1.0F, 12.0F, 0.0F, 12.0F, new CubeDeformation(0.0F)), PartPose.offset(5.0F, 16.0F, -5.0F));
		PartDefinition five = rotate.addOrReplaceChild("five", CubeListBuilder.create().texOffs(91, 64).addBox(-11.0F, -16.0F, -1.0F, 12.0F, 0.0F, 12.0F, new CubeDeformation(0.0F)), PartPose.offset(5.0F, 16.0F, -5.0F));
		PartDefinition bb_main = partdefinition.addOrReplaceChild("bb_main",
				CubeListBuilder.create().texOffs(64, 64).addBox(-8.0F, -16.0F, -8.0F, 16.0F, 16.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(0, 80).addBox(-8.0F, -16.0F, 8.0F, 16.0F, 16.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(64, 0)
						.addBox(8.0F, -16.0F, -8.0F, 0.0F, 16.0F, 16.0F, new CubeDeformation(0.0F)).texOffs(64, 32).addBox(-8.0F, -16.0F, -8.0F, 0.0F, 16.0F, 16.0F, new CubeDeformation(0.0F)).texOffs(0, 16)
						.addBox(-8.0F, 0.0F, -8.0F, 16.0F, 0.0F, 16.0F, new CubeDeformation(0.0F)).texOffs(80, 86).addBox(-8.0F, -15.2F, -8.0F, 16.0F, 0.0F, 16.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 24.0F, 0.0F));
		return LayerDefinition.create(meshdefinition, 128, 128);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		ezonetclose.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		onetotwo.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		twototwo.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		twotothree.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		rotate.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		bb_main.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}
}