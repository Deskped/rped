package deskped.rped.client;

import com.mojang.blaze3d.platform.Lighting;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import deskped.rped.RpedMod;
import deskped.rped.network.SkinUpdatePacket;
import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

@OnlyIn(Dist.CLIENT)
public class SkinPickScreen extends Screen {

	private static final ResourceLocation PREVIEW = new ResourceLocation("rped", "skin_pick_preview");
	private static final ResourceLocation ICON_FOLDER = new ResourceLocation("rped", "textures/gui/skin/folder.png");
	private static final ResourceLocation ICON_CONFIRM = new ResourceLocation("rped", "textures/gui/skin/confirm.png");
	private static final ResourceLocation ICON_TRASH = new ResourceLocation("rped", "textures/gui/skin/trash.png");
	private static final ResourceLocation ICON_WIDE = new ResourceLocation("rped", "textures/gui/skin/arms_wide.png");
	private static final ResourceLocation ICON_SLIM = new ResourceLocation("rped", "textures/gui/skin/arms_slim.png");

	private final int type;
	private byte[] data;
	private boolean previewReady;
	private boolean slim;
	private String status = "";
	private int statusColor = 0xFFAAAAAA;
	private volatile boolean picking;
	private SkinIconButton confirmButton;
	private PlayerModel<AbstractClientPlayer> wideModel;
	private PlayerModel<AbstractClientPlayer> slimModel;

	public SkinPickScreen(int type) {
		super(Component.empty());
		this.type = type;
	}

	@Override
	protected void init() {
		if (this.wideModel == null) {
			this.wideModel = new PlayerModel<>(this.minecraft.getEntityModels().bakeLayer(ModelLayers.PLAYER), false);
			this.slimModel = new PlayerModel<>(this.minecraft.getEntityModels().bakeLayer(ModelLayers.PLAYER_SLIM), true);
			prepare(this.wideModel);
			prepare(this.slimModel);
			if (this.minecraft.player != null && this.minecraft.getConnection() != null) {
				PlayerInfo info = this.minecraft.getConnection().getPlayerInfo(this.minecraft.player.getUUID());
				if (info != null)
					this.slim = "slim".equals(info.getModelName());
			}
			this.status = SkinLang.hint();
		}
		int count = this.type == 0 ? 4 : 3;
		int bw = 20;
		int gap = 8;
		int x = (this.width - count * bw - (count - 1) * gap) / 2;
		int y = this.height - 36;
		this.addRenderableWidget(new SkinIconButton(x, y, bw, () -> ICON_FOLDER, Component.literal(SkinLang.pick()), b -> this.pickFile(), null));
		x += bw + gap;
		if (this.type == 0) {
			this.addRenderableWidget(new SkinIconButton(x, y, bw, () -> this.slim ? ICON_SLIM : ICON_WIDE, Component.literal(this.slim ? SkinLang.modelSlim() : SkinLang.modelWide()), b -> {
				this.slim = !this.slim;
				b.setTooltip(Tooltip.create(Component.literal(this.slim ? SkinLang.modelSlim() : SkinLang.modelWide())));
			}, null));
			x += bw + gap;
		}
		this.confirmButton = new SkinIconButton(x, y, bw, () -> ICON_CONFIRM, Component.literal(SkinLang.confirm()), b -> this.confirm(), null);
		this.confirmButton.active = this.data != null;
		this.addRenderableWidget(this.confirmButton);
		x += bw + gap;
		this.addRenderableWidget(new SkinIconButton(x, y, bw, () -> ICON_TRASH, Component.literal(SkinLang.reset()), b -> this.reset(), null));
	}

	private static void prepare(PlayerModel<AbstractClientPlayer> model) {
		model.young = false;
		model.crouching = false;
		model.setAllVisible(true);
		model.leftArm.zRot = -0.06f;
		model.rightArm.zRot = 0.06f;
		model.hat.copyFrom(model.head);
		model.jacket.copyFrom(model.body);
		model.leftSleeve.copyFrom(model.leftArm);
		model.rightSleeve.copyFrom(model.rightArm);
		model.leftPants.copyFrom(model.leftLeg);
		model.rightPants.copyFrom(model.rightLeg);
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float partial) {
		this.renderBackground(graphics);
		graphics.drawCenteredString(this.font, this.type == 1 ? SkinLang.titleCape() : SkinLang.titleSkin(), this.width / 2, 14, 0xFFFFFF);
		int centerX = this.width / 2;
		int top = 34;
		int bottom = this.height - 62;
		if (this.type == 0) {
			ResourceLocation tex = this.previewReady ? PREVIEW : (this.minecraft.player != null ? this.minecraft.player.getSkinTextureLocation() : null);
			if (tex != null) {
				int size = (bottom - top) / 2;
				if (size > 68)
					size = 68;
				if (size < 20)
					size = 20;
				int neckY = (top + bottom) / 2 - size / 2;
				float yaw = (Util.getMillis() % 14400L) / 40.0f;
				this.renderPlayer(graphics, centerX, neckY, size, yaw, tex);
			}
		} else {
			ResourceLocation tex = null;
			if (this.previewReady) {
				tex = PREVIEW;
			} else if (this.minecraft.player != null) {
				SkinClientCache.Entry entry = SkinClientCache.entry(this.minecraft.player.getUUID());
				tex = entry != null && entry.cape != null ? entry.cape : this.minecraft.player.getCloakTextureLocation();
			}
			int pw = 128;
			int ph = 64;
			int px = centerX - pw / 2;
			int py = (top + bottom - ph) / 2;
			graphics.fill(px - 3, py - 3, px + pw + 3, py + ph + 3, 0x8C0E0C16);
			if (tex != null)
				graphics.blit(tex, px, py, pw, ph, 0.0f, 0.0f, 64, 32, 64, 32);
			else
				graphics.drawCenteredString(this.font, SkinLang.noCape(), centerX, py + ph / 2 - 4, 0xFF777788);
		}
		graphics.drawCenteredString(this.font, this.status, centerX, this.height - 52, this.statusColor);
		super.render(graphics, mouseX, mouseY, partial);
	}

	private void renderPlayer(GuiGraphics graphics, int x, int y, int size, float yaw, ResourceLocation texture) {
		graphics.flush();
		PlayerModel<AbstractClientPlayer> model = this.slim ? this.slimModel : this.wideModel;
		PoseStack pose = graphics.pose();
		pose.pushPose();
		pose.translate(x, y, 120.0f);
		pose.scale(size, size, size);
		pose.mulPose(Axis.YP.rotationDegrees(yaw));
		Lighting.setupForFlatItems();
		MultiBufferSource.BufferSource buffers = this.minecraft.renderBuffers().bufferSource();
		VertexConsumer consumer = buffers.getBuffer(RenderType.entityTranslucent(texture));
		model.renderToBuffer(pose, consumer, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, 1.0f, 1.0f, 1.0f, 1.0f);
		buffers.endBatch();
		Lighting.setupFor3DItems();
		pose.popPose();
	}

	private void pickFile() {
		if (this.picking)
			return;
		this.picking = true;
		Thread thread = new Thread(() -> {
			String path = null;
			try (MemoryStack stack = MemoryStack.stackPush()) {
				PointerBuffer filters = stack.mallocPointer(1);
				filters.put(stack.UTF8("*.png"));
				filters.flip();
				path = TinyFileDialogs.tinyfd_openFileDialog(this.type == 1 ? "Cape PNG" : "Skin PNG", null, filters, "PNG", false);
			} catch (Throwable ignored) {
			}
			byte[] raw = null;
			if (path != null) {
				try {
					raw = Files.readAllBytes(Path.of(path));
				} catch (IOException ignored) {
				}
			}
			byte[] finalRaw = raw;
			boolean chosen = path != null;
			this.minecraft.execute(() -> {
				this.picking = false;
				if (chosen)
					this.accept(finalRaw);
			});
		}, "rped-skin-pick");
		thread.setDaemon(true);
		thread.start();
	}

	private void accept(byte[] raw) {
		if (raw == null) {
			this.setStatus(SkinLang.errRead(), 0xFFFF6666);
			return;
		}
		try {
			BufferedImage source = ImageIO.read(new ByteArrayInputStream(raw));
			if (source == null) {
				this.setStatus(SkinLang.errRead(), 0xFFFF6666);
				return;
			}
			int w = source.getWidth();
			int h = source.getHeight();
			boolean ok = this.type == 1 ? (w == h * 2 && w >= 64 && w <= 256) : ((w == 64 && h == 32) || (w == h && w >= 64 && w <= 256));
			if (!ok) {
				this.setStatus(this.type == 1 ? SkinLang.errSizeCape() : SkinLang.errSizeSkin(), 0xFFFF6666);
				return;
			}
			BufferedImage normalized = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
			Graphics2D g = normalized.createGraphics();
			g.drawImage(source, 0, 0, null);
			g.dispose();
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			ImageIO.write(normalized, "png", out);
			byte[] encoded = out.toByteArray();
			if (encoded.length > 30000) {
				this.setStatus(SkinLang.errHeavy(), 0xFFFF6666);
				return;
			}
			NativeImage preview = NativeImage.read(new ByteArrayInputStream(encoded));
			this.minecraft.getTextureManager().register(PREVIEW, new DynamicTexture(preview));
			this.data = encoded;
			this.previewReady = true;
			if (this.confirmButton != null)
				this.confirmButton.active = true;
			this.setStatus(w + "x" + h, 0xFF9CE89C);
		} catch (IOException e) {
			this.setStatus(SkinLang.errRead(), 0xFFFF6666);
		}
	}

	private void confirm() {
		if (this.data == null || this.minecraft.getConnection() == null)
			return;
		RpedMod.PACKET_HANDLER.sendToServer(new SkinUpdatePacket(this.type, this.slim, this.data));
		this.onClose();
	}

	private void reset() {
		if (this.minecraft.getConnection() == null)
			return;
		RpedMod.PACKET_HANDLER.sendToServer(new SkinUpdatePacket(this.type, false, new byte[0]));
		this.onClose();
	}

	private void setStatus(String text, int color) {
		this.status = text;
		this.statusColor = color;
	}

	@Override
	public void onFilesDrop(List<Path> paths) {
		if (paths.isEmpty())
			return;
		try {
			this.accept(Files.readAllBytes(paths.get(0)));
		} catch (IOException e) {
			this.setStatus(SkinLang.errRead(), 0xFFFF6666);
		}
	}

	@Override
	public void onClose() {
		if (this.previewReady) {
			this.minecraft.getTextureManager().release(PREVIEW);
			this.previewReady = false;
		}
		if (this.minecraft.player != null)
			this.minecraft.setScreen(new InventoryScreen(this.minecraft.player));
		else
			this.minecraft.setScreen(null);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
