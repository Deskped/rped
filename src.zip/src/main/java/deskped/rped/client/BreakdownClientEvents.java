package deskped.rped.client;

import deskped.rped.RpedMod;
import deskped.rped.client.overlay.BreakdownTimerOverlay;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import org.lwjgl.glfw.GLFW;

import java.io.File;
import java.io.IOException;

@Mod.EventBusSubscriber(modid = RpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class BreakdownClientEvents {

	private static ResourceLocation lastDim = null;
	private static boolean warned = false;
	private static boolean warnedChecked = false;

	@SubscribeEvent
	public static void onClientTick(TickEvent.ClientTickEvent event) {
		if (event.phase != TickEvent.Phase.END)
			return;
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null) {
			lastDim = null;
			return;
		}
		BreakdownClientState.tickDown();
		ResourceLocation dim = mc.level.dimension().location();
		if (!dim.equals(lastDim)) {
			lastDim = dim;
			if (dim.getNamespace().equals(RpedMod.MODID) && dim.getPath().startsWith("bd_") && !hasWarned(mc)) {
				markWarned(mc);
				mc.setScreen(new PocketDimWarningScreen());
			}
		}
	}

	@SubscribeEvent
	public static void onKey(InputEvent.Key event) {
		if (event.getAction() != GLFW.GLFW_PRESS)
			return;
		if (event.getKey() != GLFW.GLFW_KEY_LEFT_ALT && event.getKey() != GLFW.GLFW_KEY_RIGHT_ALT)
			return;
		BreakdownTimerOverlay.toggleTransparent();
	}

	private static boolean hasWarned(Minecraft mc) {
		if (warnedChecked)
			return warned;
		warnedChecked = true;
		warned = markerFile(mc).exists();
		return warned;
	}

	private static void markWarned(Minecraft mc) {
		warned = true;
		warnedChecked = true;
		try {
			File f = markerFile(mc);
			File parent = f.getParentFile();
			if (parent != null)
				parent.mkdirs();
			f.createNewFile();
		} catch (IOException ignored) {
		}
	}

	private static File markerFile(Minecraft mc) {
		return new File(mc.gameDirectory, "config" + File.separator + "rped_pocket_warned");
	}
}
