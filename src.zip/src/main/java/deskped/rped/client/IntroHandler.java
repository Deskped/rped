package deskped.rped.client;

import deskped.rped.RpedMod;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "rped", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
@OnlyIn(Dist.CLIENT)
public class IntroHandler {

	private static boolean shown = false;

	@SubscribeEvent
	public static void onClientTick(TickEvent.ClientTickEvent event) {
		if (event.phase != TickEvent.Phase.END)
			return;
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null) {
			shown = false;
			return;
		}
		if (shown)
			return;
		if (mc.screen != null || mc.getOverlay() != null)
			return;
		shown = true;
		if (IntroScreen.seen()) {
			RpedMod.LOGGER.info("[rped] Nova intro skipped, marker exists at {}", IntroScreen.markerInfo());
			return;
		}
		RpedMod.LOGGER.info("[rped] Nova intro starting, marker not found at {}", IntroScreen.markerInfo());
		mc.setScreen(new IntroScreen());
	}
}
