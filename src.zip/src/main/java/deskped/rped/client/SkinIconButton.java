package deskped.rped.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.function.Consumer;
import java.util.function.Supplier;

@OnlyIn(Dist.CLIENT)
public class SkinIconButton extends AbstractButton {

	private final Supplier<ResourceLocation> icon;
	private final Consumer<SkinIconButton> action;
	private final Supplier<int[]> position;

	public SkinIconButton(int x, int y, int size, Supplier<ResourceLocation> icon, Component tooltip, Consumer<SkinIconButton> action, Supplier<int[]> position) {
		super(x, y, size, size, Component.empty());
		this.icon = icon;
		this.action = action;
		this.position = position;
		this.setTooltip(Tooltip.create(tooltip));
	}

	@Override
	public void onPress() {
		this.action.accept(this);
	}

	@Override
	public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partial) {
		if (this.position != null) {
			int[] pos = this.position.get();
			this.setX(pos[0]);
			this.setY(pos[1]);
		}
		int x0 = this.getX();
		int y0 = this.getY();
		int x1 = x0 + this.width;
		int y1 = y0 + this.height;
		boolean hover = this.isHoveredOrFocused();
		graphics.fill(x0, y0, x1, y1, this.active ? (hover ? 0xE6343048 : 0xC81C1A28) : 0x96141420);
		int frame = this.active ? (hover ? 0xFFBCA8FF : 0xFF5B5478) : 0xFF37344E;
		graphics.fill(x0, y0, x1, y0 + 1, frame);
		graphics.fill(x0, y1 - 1, x1, y1, frame);
		graphics.fill(x0, y0 + 1, x0 + 1, y1 - 1, frame);
		graphics.fill(x1 - 1, y0 + 1, x1, y1 - 1, frame);
		graphics.blit(this.icon.get(), x0 + 2, y0 + 2, this.width - 4, this.height - 4, 0.0f, 0.0f, 8, 8, 8, 8);
		if (!this.active)
			graphics.fill(x0, y0, x1, y1, 0x78101018);
	}

	@Override
	protected void updateWidgetNarration(NarrationElementOutput output) {
		this.defaultButtonNarrationText(output);
	}
}
