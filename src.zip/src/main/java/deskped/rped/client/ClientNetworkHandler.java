package deskped.rped.client;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

import deskped.rped.over.capability.QuestProgressProvider;
import deskped.rped.over.client.gui.CalculatorScreen;
import deskped.rped.over.client.gui.QuestProgressScreen;

@OnlyIn(Dist.CLIENT)
public class ClientNetworkHandler {

	public static void openCalculator() {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player != null)
			mc.setScreen(new CalculatorScreen());
	}

	public static void openQuestGui(String targetName, CompoundTag progressData) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player != null)
			mc.setScreen(new QuestProgressScreen(targetName, progressData));
	}

	public static void syncQuestProgress(CompoundTag data) {
		Player player = Minecraft.getInstance().player;
		if (player != null)
			player.getCapability(QuestProgressProvider.QUEST_PROGRESS).ifPresent(cap ->
				cap.deserializeNBT(data));
	}
}
