/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package deskped.rped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import deskped.rped.potion.*;
import deskped.rped.RpedMod;

public class RpedModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, RpedMod.MODID);
	public static final RegistryObject<MobEffect> THE_LAS_CADENAS = REGISTRY.register("the_las_cadenas", () -> new TheLasCadenasMobEffect());
	public static final RegistryObject<MobEffect> THE_LIMITER = REGISTRY.register("the_limiter", () -> new TheLimiterMobEffect());
	public static final RegistryObject<MobEffect> SHAKE = REGISTRY.register("shake", () -> new ShakeMobEffect());
	public static final RegistryObject<MobEffect> EXPLODE = REGISTRY.register("explode", () -> new ExplodeMobEffect());
	public static final RegistryObject<MobEffect> ULTRANOV_E = REGISTRY.register("ultranov_e", () -> new UltranovEMobEffect());
	public static final RegistryObject<MobEffect> ICE_SHIELD = REGISTRY.register("ice_shield", () -> new IceShieldMobEffect());
}