/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package deskped.rped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Block;

import deskped.rped.block.entity.*;
import deskped.rped.RpedMod;

public class RpedModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, RpedMod.MODID);
	public static final RegistryObject<BlockEntityType<RegenBlockEntity>> REGEN = register("regen", RpedModBlocks.REGEN, RegenBlockEntity::new);
	public static final RegistryObject<BlockEntityType<CrusherBlockEntity>> CRUSHER = register("crusher", RpedModBlocks.CRUSHER, CrusherBlockEntity::new);
	public static final RegistryObject<BlockEntityType<BackpackBlockBlockEntity>> BACKPACK_BLOCK = register("backpack_block", RpedModBlocks.BACKPACK_BLOCK, BackpackBlockBlockEntity::new);
	public static final RegistryObject<BlockEntityType<BlockplacerBlockEntity>> BLOCKPLACER = register("blockplacer", RpedModBlocks.BLOCKPLACER, BlockplacerBlockEntity::new);
	public static final RegistryObject<BlockEntityType<MimicBlockBlockEntity>> MIMIC_BLOCK = register("mimic_block", RpedModBlocks.MIMIC_BLOCK, MimicBlockBlockEntity::new);
	public static final RegistryObject<BlockEntityType<MimicStairsBlockEntity>> MIMIC_STAIRS = register("mimic_stairs", RpedModBlocks.MIMIC_STAIRS, MimicStairsBlockEntity::new);
	public static final RegistryObject<BlockEntityType<MimicSlabBlockEntity>> MIMIC_SLAB = register("mimic_slab", RpedModBlocks.MIMIC_SLAB, MimicSlabBlockEntity::new);
	public static final RegistryObject<BlockEntityType<BenisonBlockEntity>> BENISON = register("benison", RpedModBlocks.BENISON, BenisonBlockEntity::new);
	public static final RegistryObject<BlockEntityType<BreakdownBlockEntity>> BREAKDOWN = register("breakdown", RpedModBlocks.BREAKDOWN, BreakdownBlockEntity::new);
	public static final RegistryObject<BlockEntityType<CoreBlockEntity>> CORE = register("core", RpedModBlocks.CORE, CoreBlockEntity::new);
	public static final RegistryObject<BlockEntityType<MimicPanelBlockEntity>> MIMIC_PANEL = register("mimic_panel", RpedModBlocks.MIMIC_PANEL, MimicPanelBlockEntity::new);
	public static final RegistryObject<BlockEntityType<TumaniteClusterBlockEntity>> TUMANITE_CLUSTER = register("tumanite_cluster", RpedModBlocks.TUMANITE_CLUSTER, TumaniteClusterBlockEntity::new);
	public static final RegistryObject<BlockEntityType<MusicBlockBlockEntity>> MUSIC_BLOCK = register("music_block", RpedModBlocks.MUSIC_BLOCK, MusicBlockBlockEntity::new);
	public static final RegistryObject<BlockEntityType<HotCoreBlockEntity>> HOT_CORE = register("hot_core", RpedModBlocks.HOT_CORE, HotCoreBlockEntity::new);
	public static final RegistryObject<BlockEntityType<SoundprooferBlockBlockEntity>> SOUNDPROOFER_BLOCK = register("soundproofer_block", RpedModBlocks.SOUNDPROOFER_BLOCK, SoundprooferBlockBlockEntity::new);
	public static final RegistryObject<BlockEntityType<EzonetBlockEntity>> EZONET = register("ezonet", RpedModBlocks.EZONET, EzonetBlockEntity::new);
	public static final RegistryObject<BlockEntityType<SmallTumaniteClusterBlockEntity>> SMALL_TUMANITE_CLUSTER = register("small_tumanite_cluster", RpedModBlocks.SMALL_TUMANITE_CLUSTER, SmallTumaniteClusterBlockEntity::new);

	// Start of user code block custom block entities
	// End of user code block custom block entities
	private static <T extends BlockEntity> RegistryObject<BlockEntityType<T>> register(String registryname, RegistryObject<Block> block, BlockEntityType.BlockEntitySupplier<T> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}