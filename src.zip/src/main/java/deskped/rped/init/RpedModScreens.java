/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package deskped.rped.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

import deskped.rped.client.gui.CrusherGuiScreen;
import deskped.rped.client.gui.BlockostavGuiScreen;
import deskped.rped.client.gui.BackackScreen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class RpedModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(RpedModMenus.CRUSHER_GUI.get(), CrusherGuiScreen::new);
			MenuScreens.register(RpedModMenus.BACKACK.get(), BackackScreen::new);
			MenuScreens.register(RpedModMenus.BLOCKOSTAV_GUI.get(), BlockostavGuiScreen::new);
		});
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}
}