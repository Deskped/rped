/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package deskped.rped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import deskped.rped.RpedMod;

public class RpedModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, RpedMod.MODID);
	public static final RegistryObject<SoundEvent> MENU = REGISTRY.register("menu", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "menu")));
	public static final RegistryObject<SoundEvent> TYPING = REGISTRY.register("typing", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "typing")));
	public static final RegistryObject<SoundEvent> BLOCK_SIREN = REGISTRY.register("block_siren", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "block_siren")));
	public static final RegistryObject<SoundEvent> AMBIENT_OUTBREAK = REGISTRY.register("ambient_outbreak", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "ambient_outbreak")));
	public static final RegistryObject<SoundEvent> ITEM_CRYSTAL_EYE = REGISTRY.register("item_crystal_eye", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "item_crystal_eye")));
	public static final RegistryObject<SoundEvent> ITEM_OUTBREAK = REGISTRY.register("item_outbreak", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "item_outbreak")));
	public static final RegistryObject<SoundEvent> INDICATOR = REGISTRY.register("indicator", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "indicator")));
	public static final RegistryObject<SoundEvent> EARTH_SOUNDS_OF_HUMAN_AGONY_CAUSED_BY_NOVA = REGISTRY.register("earth_sounds_of_human_agony_caused_by_nova",
			() -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "earth_sounds_of_human_agony_caused_by_nova")));
	public static final RegistryObject<SoundEvent> MUSIC_DEATH_EGG_ROBOT_GENERATIONS = REGISTRY.register("music_death_egg_robot_generations",
			() -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "music_death_egg_robot_generations")));
	public static final RegistryObject<SoundEvent> MUSIC_HONORO = REGISTRY.register("music_honoro", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "music_honoro")));
	public static final RegistryObject<SoundEvent> MUSIC_INTRIGA = REGISTRY.register("music_intriga", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "music_intriga")));
	public static final RegistryObject<SoundEvent> MUSIC_RELEGANT = REGISTRY.register("music_relegant", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "music_relegant")));
	public static final RegistryObject<SoundEvent> MUSIC_WAKFU_NOX = REGISTRY.register("music_wakfu_nox", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "music_wakfu_nox")));
	public static final RegistryObject<SoundEvent> BLOCK_BUTTON_IRON_CASTING = REGISTRY.register("block_button_iron_casting", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "block_button_iron_casting")));
	public static final RegistryObject<SoundEvent> BLOCK_BUTTON_OFFLINE_IRON_CASTING = REGISTRY.register("block_button_offline_iron_casting",
			() -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "block_button_offline_iron_casting")));
	public static final RegistryObject<SoundEvent> BLOCK_LEVER = REGISTRY.register("block_lever", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "block_lever")));
	public static final RegistryObject<SoundEvent> GRAVITY_WRENCH_GRAB = REGISTRY.register("gravity_wrench_grab", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "gravity_wrench_grab")));
	public static final RegistryObject<SoundEvent> GRAVITY_WRENCH_HUM = REGISTRY.register("gravity_wrench_hum", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "gravity_wrench_hum")));
	public static final RegistryObject<SoundEvent> GRAVITY_WRENCH_IMPACT = REGISTRY.register("gravity_wrench_impact", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "gravity_wrench_impact")));
	public static final RegistryObject<SoundEvent> GRAVITY_WRENCH_RELEASE = REGISTRY.register("gravity_wrench_release", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "gravity_wrench_release")));
	public static final RegistryObject<SoundEvent> GRAVITY_WRENCH_THROW = REGISTRY.register("gravity_wrench_throw", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "gravity_wrench_throw")));
	public static final RegistryObject<SoundEvent> YOU_CANT_DIE = REGISTRY.register("you_cant_die", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "you_cant_die")));
	public static final RegistryObject<SoundEvent> ALARM_WHAT = REGISTRY.register("alarm_what", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "alarm_what")));
	public static final RegistryObject<SoundEvent> FUNK_ALARM = REGISTRY.register("funk_alarm", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "funk_alarm")));
	public static final RegistryObject<SoundEvent> PORTAL_SIREN = REGISTRY.register("portal_siren", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "portal_siren")));
	public static final RegistryObject<SoundEvent> WW_ALARM = REGISTRY.register("ww_alarm", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "ww_alarm")));
	public static final RegistryObject<SoundEvent> SWEET_ALARM = REGISTRY.register("sweet_alarm", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "sweet_alarm")));
	public static final RegistryObject<SoundEvent> RU_WARNING = REGISTRY.register("ru_warning", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "ru_warning")));
	public static final RegistryObject<SoundEvent> SOVIET_ATTENTION = REGISTRY.register("soviet_attention", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "soviet_attention")));
	public static final RegistryObject<SoundEvent> SOVIET_ATTENTION_SIMPLE = REGISTRY.register("soviet_attention_simple", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "soviet_attention_simple")));
	public static final RegistryObject<SoundEvent> SOVIET_START = REGISTRY.register("soviet_start", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "soviet_start")));
	public static final RegistryObject<SoundEvent> METRO_WARNING = REGISTRY.register("metro_warning", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "metro_warning")));
	public static final RegistryObject<SoundEvent> BLOCK_LIGHT = REGISTRY.register("block_light", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "block_light")));
	public static final RegistryObject<SoundEvent> CAMERA = REGISTRY.register("camera", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "camera")));
	public static final RegistryObject<SoundEvent> BLOCK_STONE_CUTTER = REGISTRY.register("block_stone_cutter", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "block_stone_cutter")));
	public static final RegistryObject<SoundEvent> BLOCK_CRAFTER_CRAFT = REGISTRY.register("block.crafter.craft", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "block.crafter.craft")));
	public static final RegistryObject<SoundEvent> BLOCK_CRAFTER_FAIL = REGISTRY.register("block.crafter.fail", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "block.crafter.fail")));
	public static final RegistryObject<SoundEvent> CORE_EXPLODE = REGISTRY.register("core_explode", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "core_explode")));
	public static final RegistryObject<SoundEvent> BLOCK_EZONET_OPEN = REGISTRY.register("block_ezonet_open", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "block_ezonet_open")));
	public static final RegistryObject<SoundEvent> BLOCK_EZONET_CLOSE = REGISTRY.register("block_ezonet_close", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "block_ezonet_close")));
	public static final RegistryObject<SoundEvent> BLOCK_BARREL_OPEN = REGISTRY.register("block.barrel.open", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "block.barrel.open")));
	public static final RegistryObject<SoundEvent> NEW_WHAT = REGISTRY.register("new_what", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "new_what")));
	public static final RegistryObject<SoundEvent> MUSIC_LIMPED = REGISTRY.register("music_limped", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "music_limped")));
	public static final RegistryObject<SoundEvent> AMBIENT = REGISTRY.register("ambient", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "ambient")));
	public static final RegistryObject<SoundEvent> BOSS_ANGEL_DIE = REGISTRY.register("boss.angel.die", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "boss.angel.die")));
	public static final RegistryObject<SoundEvent> BOSS_ANGEL_HURT = REGISTRY.register("boss.angel.hurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "boss.angel.hurt")));
	public static final RegistryObject<SoundEvent> BOSS_ANGEL_IDLE = REGISTRY.register("boss.angel.idle", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "boss.angel.idle")));
}