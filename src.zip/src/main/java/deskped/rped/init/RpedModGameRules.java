/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package deskped.rped.init;

import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.GameRules;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class RpedModGameRules {
	public static final GameRules.Key<GameRules.BooleanValue> YOUR_LINE_LAS_CADENAS = GameRules.register("yourLineLasCadenas", GameRules.Category.MISC, GameRules.BooleanValue.create(true));
}