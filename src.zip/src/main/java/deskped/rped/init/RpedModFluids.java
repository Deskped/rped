/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package deskped.rped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import deskped.rped.fluid.*;
import deskped.rped.RpedMod;

public class RpedModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, RpedMod.MODID);
	public static final RegistryObject<FlowingFluid> RED_WATER = REGISTRY.register("red_water", () -> new RedWaterFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_RED_WATER = REGISTRY.register("flowing_red_water", () -> new RedWaterFluid.Flowing());
	public static final RegistryObject<FlowingFluid> ORANGE_WATER = REGISTRY.register("orange_water", () -> new OrangeWaterFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_ORANGE_WATER = REGISTRY.register("flowing_orange_water", () -> new OrangeWaterFluid.Flowing());
	public static final RegistryObject<FlowingFluid> YELLOW_WATER = REGISTRY.register("yellow_water", () -> new YellowWaterFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_YELLOW_WATER = REGISTRY.register("flowing_yellow_water", () -> new YellowWaterFluid.Flowing());
	public static final RegistryObject<FlowingFluid> GREEN_WATER = REGISTRY.register("green_water", () -> new GreenWaterFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_GREEN_WATER = REGISTRY.register("flowing_green_water", () -> new GreenWaterFluid.Flowing());
	public static final RegistryObject<FlowingFluid> BLUE_WATER = REGISTRY.register("blue_water", () -> new BlueWaterFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_BLUE_WATER = REGISTRY.register("flowing_blue_water", () -> new BlueWaterFluid.Flowing());
	public static final RegistryObject<FlowingFluid> PURPLE_WATER = REGISTRY.register("purple_water", () -> new PurpleWaterFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_PURPLE_WATER = REGISTRY.register("flowing_purple_water", () -> new PurpleWaterFluid.Flowing());
	public static final RegistryObject<FlowingFluid> BROWN_WATER = REGISTRY.register("brown_water", () -> new BrownWaterFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_BROWN_WATER = REGISTRY.register("flowing_brown_water", () -> new BrownWaterFluid.Flowing());
	public static final RegistryObject<FlowingFluid> BLACK_WATER = REGISTRY.register("black_water", () -> new BlackWaterFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_BLACK_WATER = REGISTRY.register("flowing_black_water", () -> new BlackWaterFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(RED_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_RED_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(ORANGE_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_ORANGE_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(YELLOW_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_YELLOW_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(GREEN_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_GREEN_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(BLUE_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_BLUE_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(PURPLE_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_PURPLE_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(BROWN_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_BROWN_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(BLACK_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_BLACK_WATER.get(), RenderType.translucent());
		}
	}
}