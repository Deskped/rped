/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package deskped.rped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import deskped.rped.enchantment.TheBreakEnchantment;
import deskped.rped.RpedMod;

public class RpedModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, RpedMod.MODID);
	public static final RegistryObject<Enchantment> THE_BREAK = REGISTRY.register("the_break", () -> new TheBreakEnchantment());
}