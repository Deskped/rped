/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package deskped.rped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import deskped.rped.fluid.types.*;
import deskped.rped.RpedMod;

public class RpedModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, RpedMod.MODID);
	public static final RegistryObject<FluidType> RED_WATER_TYPE = REGISTRY.register("red_water", () -> new RedWaterFluidType());
	public static final RegistryObject<FluidType> ORANGE_WATER_TYPE = REGISTRY.register("orange_water", () -> new OrangeWaterFluidType());
	public static final RegistryObject<FluidType> YELLOW_WATER_TYPE = REGISTRY.register("yellow_water", () -> new YellowWaterFluidType());
	public static final RegistryObject<FluidType> GREEN_WATER_TYPE = REGISTRY.register("green_water", () -> new GreenWaterFluidType());
	public static final RegistryObject<FluidType> BLUE_WATER_TYPE = REGISTRY.register("blue_water", () -> new BlueWaterFluidType());
	public static final RegistryObject<FluidType> PURPLE_WATER_TYPE = REGISTRY.register("purple_water", () -> new PurpleWaterFluidType());
	public static final RegistryObject<FluidType> BROWN_WATER_TYPE = REGISTRY.register("brown_water", () -> new BrownWaterFluidType());
	public static final RegistryObject<FluidType> BLACK_WATER_TYPE = REGISTRY.register("black_water", () -> new BlackWaterFluidType());
}