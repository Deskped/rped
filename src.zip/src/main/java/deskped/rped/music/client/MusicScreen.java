package deskped.rped.music.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import deskped.rped.music.MusicNet;
import deskped.rped.voice.client.ui.Ui;

@OnlyIn(Dist.CLIENT)
public class MusicScreen extends Screen {

	private final BlockPos pos;
	private final String trackName;
	private final boolean playing;
	private int panelX;
	private int panelY;
	private int panelW;
	private int panelH;

	public MusicScreen(BlockPos pos, String trackName, boolean playing) {
		super(Component.literal("\u041C\u0443\u0437\u044B\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u0431\u043B\u043E\u043A"));
		this.pos = pos;
		this.trackName = trackName == null ? "" : trackName;
		this.playing = playing;
	}

	@Override
	protected void init() {
		panelW = 260;
		panelH = 112;
		panelX = (width - panelW) / 2;
		panelY = (height - panelH) / 2;
		int x = panelX + 10;
		int w = panelW - 20;
		addRenderableWidget(new Ui.FlatButton(x, panelY + 44, w, 16, Component.literal("\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0444\u0430\u0439\u043B (.ogg / .wav)"), b -> pick()));
		int half = (w - 4) / 2;
		addRenderableWidget(new Ui.FlatButton(x, panelY + 64, half, 16, Component.literal("\u041F\u0440\u043E\u0438\u0433\u0440\u0430\u0442\u044C"), b -> send(true)));
		addRenderableWidget(new Ui.FlatButton(x + half + 4, panelY + 64, half, 16, Component.literal("\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C"), b -> send(false), true));
	}

	private void pick() {
		onClose();
		MusicClient.pickAndUpload(pos);
	}

	private void send(boolean play) {
		MusicNet.sendToServer(new MusicNet.BlockActionC2S(pos, play));
		onClose();
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		renderBackground(g);
		g.fill(0, 0, width, height, Ui.BG);
		Ui.stars(g, 0, 0, width, height, 415L);
		Ui.panel(g, panelX, panelY, panelW, panelH);
		g.drawCenteredString(font, title, width / 2, panelY + 7, Ui.CYAN);
		String name = trackName.isEmpty() ? "\u043D\u0435\u0442" : trackName;
		if (name.length() > 34)
			name = name.substring(0, 34) + "...";
		g.drawString(font, Component.literal("\u0424\u0430\u0439\u043B: " + name), panelX + 10, panelY + 26, trackName.isEmpty() ? Ui.DIM : 0xFFFFFFFF);
		String status = playing ? "\u0421\u0435\u0439\u0447\u0430\u0441 \u0438\u0433\u0440\u0430\u0435\u0442" : "\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E";
		g.drawString(font, Component.literal(status), panelX + 10, panelY + 94, playing ? Ui.GREEN : Ui.DIM);
		super.render(g, mouseX, mouseY, partialTick);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
