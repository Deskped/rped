package deskped.rped;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.OptionsScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import deskped.rped.client.ClientMenuState;

@Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE, modid = "rped")
@OnlyIn(Dist.CLIENT)
public class OptionsScreenEvent {

    @SubscribeEvent
    public static void onOptionsInit(ScreenEvent.Init.Post event) {
        Screen screen = event.getScreen();
        if (!(screen instanceof OptionsScreen)) return;

        Minecraft mc = Minecraft.getInstance();
        boolean   ru = mc.options.languageCode.startsWith("ru");

        event.addListener(Button.builder(
            Component.literal(buildLabel(ru)),
            b -> {
                ClientMenuState.customMenu = !ClientMenuState.customMenu;
                b.setMessage(Component.literal(buildLabel(ru)));
                if (ClientMenuState.customMenu) Menu.triggerMusicStart();
                else Menu.triggerMusicStop();
            }
        ).bounds(screen.width / 2 - 155, screen.height / 6 - 12, 150, 20).build());
    }

    private static String buildLabel(boolean ru) {
        if (ru) return "Кастомное меню: " + (ClientMenuState.customMenu ? "Да" : "Нет");
        return "Custom menu: " + (ClientMenuState.customMenu ? "Yes" : "No");
    }
}