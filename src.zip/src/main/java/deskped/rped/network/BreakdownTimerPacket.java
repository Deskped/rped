package deskped.rped.network;

import deskped.rped.RpedMod;
import deskped.rped.client.BreakdownClientState;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

@Mod.EventBusSubscriber(modid = "rped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class BreakdownTimerPacket {

	private static final ResourceLocation NONE = new ResourceLocation("minecraft", "overworld");

	private final boolean active;
	private final int remaining;
	private final ResourceLocation ctrlDim;
	private final BlockPos ctrlPos;
	private final ResourceLocation dimId;

	public BreakdownTimerPacket(boolean active, int remaining, ResourceLocation ctrlDim, BlockPos ctrlPos, ResourceLocation dimId) {
		this.active = active;
		this.remaining = remaining;
		this.ctrlDim = ctrlDim == null ? NONE : ctrlDim;
		this.ctrlPos = ctrlPos == null ? BlockPos.ZERO : ctrlPos;
		this.dimId = dimId == null ? NONE : dimId;
	}

	public BreakdownTimerPacket(FriendlyByteBuf buf) {
		this.active = buf.readBoolean();
		this.remaining = buf.readVarInt();
		this.ctrlDim = buf.readResourceLocation();
		this.ctrlPos = buf.readBlockPos();
		this.dimId = buf.readResourceLocation();
	}

	public static void buffer(BreakdownTimerPacket msg, FriendlyByteBuf buf) {
		buf.writeBoolean(msg.active);
		buf.writeVarInt(msg.remaining);
		buf.writeResourceLocation(msg.ctrlDim);
		buf.writeBlockPos(msg.ctrlPos);
		buf.writeResourceLocation(msg.dimId);
	}

	public static void handler(BreakdownTimerPacket msg, Supplier<NetworkEvent.Context> ctx) {
		NetworkEvent.Context context = ctx.get();
		context.enqueueWork(() -> {
			if (context.getDirection().getReceptionSide().isClient())
				BreakdownClientState.set(msg.active, msg.remaining, msg.ctrlDim, msg.ctrlPos, msg.dimId);
		});
		context.setPacketHandled(true);
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		RpedMod.addNetworkMessage(BreakdownTimerPacket.class, BreakdownTimerPacket::buffer, BreakdownTimerPacket::new, BreakdownTimerPacket::handler);
	}
}
