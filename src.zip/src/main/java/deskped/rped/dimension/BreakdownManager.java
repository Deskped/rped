package deskped.rped.dimension;

import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.dimension.LevelStem;
import net.minecraft.world.level.levelgen.Heightmap;

import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;

import deskped.rped.RpedMod;
import deskped.rped.init.RpedModBlocks;
import deskped.rped.network.BreakdownTimerPacket;

@Mod.EventBusSubscriber(modid = RpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class BreakdownManager {

	public static final int LIFETIME = 5 * 60 * 20;

	private static Portal active = null;
	private static final Deque<GlobalPos> QUEUE = new ArrayDeque<>();
	private static long counter = 0;
	private static int bcast = 0;

	private static final class Portal {
		final ResourceKey<Level> dim;
		final ResourceKey<Level> ctrlDim;
		final BlockPos ctrlPos;
		final long expireAt;
		final BlockPos entry;

		Portal(ResourceKey<Level> dim, ResourceKey<Level> ctrlDim, BlockPos ctrlPos, long expireAt, BlockPos entry) {
			this.dim = dim;
			this.ctrlDim = ctrlDim;
			this.ctrlPos = ctrlPos;
			this.expireAt = expireAt;
			this.entry = entry;
		}
	}

	public static void onControllerPlaced(ServerLevel level, BlockPos pos) {
		GlobalPos gp = GlobalPos.of(level.dimension(), pos.immutable());
		if (active != null && active.ctrlDim.equals(gp.dimension()) && active.ctrlPos.equals(gp.pos()))
			return;
		if (QUEUE.contains(gp))
			return;
		QUEUE.addLast(gp);
	}

	public static void onControllerRemoved(Level level, BlockPos pos) {
		if (!(level instanceof ServerLevel sl))
			return;
		MinecraftServer server = sl.getServer();
		GlobalPos gp = GlobalPos.of(sl.dimension(), pos.immutable());
		if (active != null && active.ctrlDim.equals(gp.dimension()) && active.ctrlPos.equals(gp.pos())) {
			Portal p = active;
			active = null;
			playFinale(sl, pos);
			destroyLevel(server, p);
			broadcast(server);
			return;
		}
		QUEUE.remove(gp);
	}

	public static void teleportInto(ServerPlayer player, ServerLevel ctrlLevel, BlockPos pos) {
		if (active == null)
			return;
		if (!active.ctrlDim.equals(ctrlLevel.dimension()) || !active.ctrlPos.equals(pos))
			return;
		if (player.isOnPortalCooldown() || player.isPassenger() || player.isVehicle())
			return;
		MinecraftServer server = ctrlLevel.getServer();
		ServerLevel target = server.getLevel(active.dim);
		if (target == null)
			return;
		BlockPos e = active.entry;
		player.setPortalCooldown();
		player.teleportTo(target, e.getX() + 0.5, e.getY(), e.getZ() + 0.5, player.getYRot(), player.getXRot());
		player.setPortalCooldown();
		player.fallDistance = 0;
		target.playSound(null, e, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 1.4f, 1.7f);
	}

	private static void tryOpenNext(MinecraftServer server) {
		while (active == null && !QUEUE.isEmpty()) {
			GlobalPos gp = QUEUE.pollFirst();
			ServerLevel lvl = server.getLevel(gp.dimension());
			if (lvl == null)
				continue;
			if (lvl.getBlockState(gp.pos()).getBlock() != RpedModBlocks.BREAKDOWN.get())
				continue;
			open(lvl, gp.pos());
			broadcast(server);
			return;
		}
	}

	private static void open(ServerLevel ctrlLevel, BlockPos pos) {
		MinecraftServer server = ctrlLevel.getServer();
		long id = ++counter;
		long seed = mix(server.getWorldData().worldGenOptions().seed(), pos, id);
		int genType = RandomSource.create(seed ^ 0x7ADL).nextInt(BreakdownChunkGenerator.TYPE_COUNT);
		ResourceKey<Level> dimKey = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(RpedMod.MODID, "bd_" + Long.toHexString(id)));
		LevelStem stem = BreakdownDimensions.createStem(server, seed, genType);
		ServerLevel level = RuntimeDimensions.getOrCreate(server, dimKey, stem);
		if (level == null)
			return;
		BlockPos entry = prepareEntry(level, genType);
		long expireAt = server.overworld().getGameTime() + LIFETIME;
		active = new Portal(dimKey, ctrlLevel.dimension(), pos.immutable(), expireAt, entry);
		RpedMod.LOGGER.info("Breakdown: dimension {} (type {}) opened for {} ticks", dimKey.location(), genType, LIFETIME);
	}

	private static BlockPos prepareEntry(ServerLevel level, int genType) {
		int ex = 0;
		int ez = 0;
		level.getChunk(ex >> 4, ez >> 4);
		BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
		int found = Integer.MIN_VALUE;
		int scanTop = genType == BreakdownChunkGenerator.CEILING ? 150 : 205;
		for (int y = scanTop; y >= -60; y--) {
			m.set(ex, y, ez);
			if (!level.getBlockState(m).isAir()) {
				found = y;
				break;
			}
		}
		int entryY = found == Integer.MIN_VALUE ? 100 : found + 1;
		BlockState platform = Blocks.OBSIDIAN.defaultBlockState();
		BlockState air = Blocks.AIR.defaultBlockState();
		for (int dx = -2; dx <= 2; dx++) {
			for (int dz = -2; dz <= 2; dz++) {
				m.set(ex + dx, entryY - 1, ez + dz);
				level.setBlock(m, platform, 2);
				for (int dy = 0; dy <= 2; dy++) {
					m.set(ex + dx, entryY + dy, ez + dz);
					level.setBlock(m, air, 2);
				}
			}
		}
		return new BlockPos(ex, entryY, ez);
	}

	private static void destroyLevel(MinecraftServer server, Portal portal) {
		ServerLevel level = server.getLevel(portal.dim);
		if (level != null) {
			ServerLevel overworld = server.overworld();
			BlockPos out = safeOut(server, portal);
			for (ServerPlayer pl : new ArrayList<>(level.players())) {
				pl.teleportTo(overworld, out.getX() + 0.5, out.getY(), out.getZ() + 0.5, pl.getYRot(), pl.getXRot());
				pl.setPortalCooldown();
				pl.fallDistance = 0;
			}
		}
		RuntimeDimensions.remove(server, portal.dim);
	}

	private static BlockPos safeOut(MinecraftServer server, Portal portal) {
		ServerLevel ow = server.overworld();
		if (portal != null && portal.ctrlDim.equals(Level.OVERWORLD)) {
			int x = portal.ctrlPos.getX();
			int z = portal.ctrlPos.getZ();
			int y = ow.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
			if (y < ow.getMinBuildHeight() + 1)
				y = ow.getMinBuildHeight() + 1;
			return new BlockPos(x, y, z);
		}
		return ow.getSharedSpawnPos();
	}

	private static void contain(ServerLevel level, ServerPlayer player, Portal portal) {
		double x = player.getX();
		double y = player.getY();
		double z = player.getZ();
		boolean oob = Math.abs(x) > BreakdownChunkGenerator.HALF - 1 || Math.abs(z) > BreakdownChunkGenerator.HALF - 1 || y < -20 || y > 260;
		if (oob) {
			BlockPos e = portal.entry;
			player.teleportTo(level, e.getX() + 0.5, e.getY(), e.getZ() + 0.5, player.getYRot(), player.getXRot());
			player.setDeltaMovement(0, 0, 0);
			player.fallDistance = 0;
			player.hurtMarked = true;
		}
	}

	private static void playFinale(ServerLevel level, BlockPos pos) {
		double cx = pos.getX() + 0.5;
		double cy = pos.getY() + 0.5;
		double cz = pos.getZ() + 0.5;
		level.sendParticles(ParticleTypes.FLASH, cx, cy, cz, 2, 0, 0, 0, 0);
		level.sendParticles(ParticleTypes.SONIC_BOOM, cx, cy, cz, 1, 0, 0, 0, 0);
		level.sendParticles(ParticleTypes.END_ROD, cx, cy, cz, 180, 0.4, 0.6, 0.4, 0.15);
		level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, cx, cy, cz, 120, 0.5, 0.7, 0.5, 0.08);
		level.sendParticles(ParticleTypes.SNOWFLAKE, cx, cy, cz, 90, 0.6, 0.9, 0.6, 0.05);
		level.sendParticles(ParticleTypes.FIREWORK, cx, cy, cz, 70, 0.5, 0.7, 0.5, 0.2);
		level.playSound(null, pos, SoundEvents.BEACON_DEACTIVATE, SoundSource.BLOCKS, 3f, 1.4f);
		level.playSound(null, pos, SoundEvents.ENDER_EYE_DEATH, SoundSource.BLOCKS, 3f, 0.7f);
		level.playSound(null, pos, SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 3f, 0.6f);
	}

	private static long mix(long worldSeed, BlockPos pos, long id) {
		long h = worldSeed;
		h = h * 0x9E3779B97F4A7C15L + pos.getX();
		h = h * 0x9E3779B97F4A7C15L + pos.getY();
		h = h * 0x9E3779B97F4A7C15L + pos.getZ();
		h = h * 0x9E3779B97F4A7C15L + id;
		h ^= System.nanoTime();
		return h;
	}

	private static void broadcast(MinecraftServer server) {
		if (active != null) {
			long now = server.overworld().getGameTime();
			int rem = (int) Math.max(0, active.expireAt - now);
			RpedMod.PACKET_HANDLER.send(PacketDistributor.ALL.noArg(), new BreakdownTimerPacket(true, rem, active.ctrlDim.location(), active.ctrlPos, active.dim.location()));
		} else {
			RpedMod.PACKET_HANDLER.send(PacketDistributor.ALL.noArg(), new BreakdownTimerPacket(false, 0, null, null, null));
		}
	}

	@SubscribeEvent
	public static void onServerTick(TickEvent.ServerTickEvent event) {
		if (event.phase != TickEvent.Phase.END)
			return;
		MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
		if (server == null)
			return;
		if (active != null) {
			long now = server.overworld().getGameTime();
			if (now >= active.expireAt) {
				Portal p = active;
				active = null;
				ServerLevel ctrl = server.getLevel(p.ctrlDim);
				if (ctrl != null) {
					playFinale(ctrl, p.ctrlPos);
					if (ctrl.getBlockState(p.ctrlPos).getBlock() == RpedModBlocks.BREAKDOWN.get())
						ctrl.removeBlock(p.ctrlPos, false);
				}
				destroyLevel(server, p);
				broadcast(server);
			} else {
				ServerLevel lvl = server.getLevel(active.dim);
				if (lvl != null)
					for (ServerPlayer pl : new ArrayList<>(lvl.players()))
						contain(lvl, pl, active);
				if (++bcast % 20 == 0)
					broadcast(server);
			}
		} else {
			tryOpenNext(server);
		}
	}

	@SubscribeEvent
	public static void onMobJoin(EntityJoinLevelEvent event) {
		if (event.getLevel().isClientSide())
			return;
		if (!(event.getEntity() instanceof Mob))
			return;
		ResourceLocation dim = event.getLevel().dimension().location();
		if (dim.getNamespace().equals(RpedMod.MODID) && dim.getPath().startsWith("bd_"))
			event.setCanceled(true);
	}

	@SubscribeEvent
	public static void onServerStopping(ServerStoppingEvent event) {
		MinecraftServer server = event.getServer();
		if (active != null) {
			destroyLevel(server, active);
			active = null;
		}
		QUEUE.clear();
	}

	@SubscribeEvent
	public static void onServerStarted(ServerStartedEvent event) {
		RuntimeDimensions.cleanupLeftovers(event.getServer());
	}
}
