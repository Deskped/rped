package deskped.rped.dimension;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.biome.BiomeGenerationSettings;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.blending.Blender;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import deskped.rped.init.RpedModBlocks;

public class BreakdownChunkGenerator extends ChunkGenerator {

	public static final Codec<BreakdownChunkGenerator> CODEC = RecordCodecBuilder.create(inst -> inst.group(
			BiomeSource.CODEC.fieldOf("biome_source").forGetter(g -> g.getBiomeSource()),
			Codec.LONG.fieldOf("seed").forGetter(g -> g.seed),
			Codec.INT.fieldOf("type").forGetter(g -> g.type)
	).apply(inst, BreakdownChunkGenerator::new));

	public static final int HALF = 166;
	public static final int TYPE_COUNT = 7;
	public static final int CEILING = 0;
	public static final int OPEN = 1;
	public static final int FLOATING = 2;
	public static final int TERRAIN_FLOATING = 3;
	public static final int FLAT = 4;
	public static final int ONE_BLOCK = 5;
	public static final int SPIRAL = 6;

	private static final int MIN_Y = -64;
	private static final int GEN_DEPTH = 384;
	private static final int FLOOR = 40;
	private static final int TOP_CAP = 200;
	private static final int CEIL_Y = 168;

	private static final ResourceLocation DUNGEON_LOOT = new ResourceLocation("minecraft", "chests/simple_dungeon");

	private static List<BlockState> POOL;
	private static List<BlockState> DUNGEON;

	private final long seed;
	private final int type;
	private final BlockState[] palette;
	private final BlockState accent;
	private final int baseHeight;
	private final int amplitude;

	public BreakdownChunkGenerator(BiomeSource biomeSource, long seed, int type) {
		super(biomeSource, biome -> BiomeGenerationSettings.EMPTY);
		this.seed = seed;
		this.type = ((type % TYPE_COUNT) + TYPE_COUNT) % TYPE_COUNT;
		RandomSource r = RandomSource.create(seed);
		List<BlockState> pool = pool();
		int count = this.type == ONE_BLOCK ? 1 : 3 + r.nextInt(5);
		BlockState[] pal = new BlockState[count];
		for (int i = 0; i < count; i++)
			pal[i] = pool.get(r.nextInt(pool.size()));
		this.palette = pal;
		this.accent = pool.get(r.nextInt(pool.size()));
		this.baseHeight = 84 + r.nextInt(40);
		this.amplitude = this.type == FLAT ? 0 : 10 + r.nextInt(46);
	}

	private static synchronized List<BlockState> pool() {
		if (POOL != null)
			return POOL;
		List<BlockState> p = new ArrayList<>();
		add(p, Blocks.STONE, Blocks.COBBLESTONE, Blocks.MOSSY_COBBLESTONE, Blocks.DIRT, Blocks.COARSE_DIRT, Blocks.GRASS_BLOCK, Blocks.PODZOL, Blocks.ROOTED_DIRT,
				Blocks.SAND, Blocks.RED_SAND, Blocks.SANDSTONE, Blocks.SMOOTH_SANDSTONE, Blocks.CUT_SANDSTONE, Blocks.RED_SANDSTONE, Blocks.GRAVEL,
				Blocks.ANDESITE, Blocks.POLISHED_ANDESITE, Blocks.DIORITE, Blocks.POLISHED_DIORITE, Blocks.GRANITE, Blocks.POLISHED_GRANITE, Blocks.DEEPSLATE, Blocks.POLISHED_DEEPSLATE, Blocks.COBBLED_DEEPSLATE, Blocks.TUFF, Blocks.CALCITE, Blocks.DRIPSTONE_BLOCK,
				Blocks.MUD, Blocks.PACKED_MUD, Blocks.MUD_BRICKS, Blocks.CLAY, Blocks.TERRACOTTA, Blocks.WHITE_TERRACOTTA, Blocks.ORANGE_TERRACOTTA, Blocks.YELLOW_TERRACOTTA, Blocks.LIGHT_BLUE_TERRACOTTA, Blocks.CYAN_TERRACOTTA, Blocks.BLUE_TERRACOTTA, Blocks.PURPLE_TERRACOTTA, Blocks.GREEN_TERRACOTTA, Blocks.BROWN_TERRACOTTA, Blocks.RED_TERRACOTTA, Blocks.BLACK_TERRACOTTA,
				Blocks.WHITE_WOOL, Blocks.LIGHT_GRAY_WOOL, Blocks.GRAY_WOOL, Blocks.CYAN_WOOL, Blocks.BLUE_WOOL, Blocks.LIGHT_BLUE_WOOL, Blocks.PURPLE_WOOL, Blocks.MAGENTA_WOOL, Blocks.PINK_WOOL, Blocks.LIME_WOOL, Blocks.GREEN_WOOL, Blocks.RED_WOOL,
				Blocks.WHITE_CONCRETE, Blocks.LIGHT_GRAY_CONCRETE, Blocks.LIGHT_BLUE_CONCRETE, Blocks.BLUE_CONCRETE, Blocks.CYAN_CONCRETE, Blocks.PURPLE_CONCRETE, Blocks.GRAY_CONCRETE, Blocks.BLACK_CONCRETE, Blocks.LIME_CONCRETE, Blocks.GREEN_CONCRETE, Blocks.YELLOW_CONCRETE, Blocks.RED_CONCRETE,
				Blocks.PRISMARINE, Blocks.PRISMARINE_BRICKS, Blocks.DARK_PRISMARINE, Blocks.QUARTZ_BLOCK, Blocks.SMOOTH_QUARTZ, Blocks.CHISELED_QUARTZ_BLOCK, Blocks.QUARTZ_BRICKS,
				Blocks.SNOW_BLOCK, Blocks.PACKED_ICE, Blocks.BLUE_ICE, Blocks.MOSS_BLOCK, Blocks.OAK_LOG, Blocks.SPRUCE_LOG, Blocks.BIRCH_LOG, Blocks.DARK_OAK_LOG, Blocks.JUNGLE_LOG, Blocks.OAK_PLANKS, Blocks.SPRUCE_PLANKS, Blocks.BIRCH_PLANKS, Blocks.DARK_OAK_PLANKS,
				Blocks.STONE_BRICKS, Blocks.MOSSY_STONE_BRICKS, Blocks.CRACKED_STONE_BRICKS, Blocks.CHISELED_STONE_BRICKS, Blocks.BRICKS, Blocks.DEEPSLATE_BRICKS, Blocks.DEEPSLATE_TILES, Blocks.POLISHED_BLACKSTONE_BRICKS, Blocks.NETHER_BRICKS, Blocks.RED_NETHER_BRICKS,
				Blocks.IRON_BLOCK, Blocks.GOLD_BLOCK, Blocks.DIAMOND_BLOCK, Blocks.EMERALD_BLOCK, Blocks.LAPIS_BLOCK, Blocks.REDSTONE_BLOCK, Blocks.COAL_BLOCK, Blocks.COPPER_BLOCK, Blocks.EXPOSED_COPPER, Blocks.WEATHERED_COPPER, Blocks.OXIDIZED_COPPER,
				Blocks.IRON_ORE, Blocks.GOLD_ORE, Blocks.DIAMOND_ORE, Blocks.COAL_ORE, Blocks.LAPIS_ORE, Blocks.REDSTONE_ORE, Blocks.EMERALD_ORE, Blocks.COPPER_ORE, Blocks.DEEPSLATE_DIAMOND_ORE, Blocks.DEEPSLATE_GOLD_ORE,
				Blocks.GLOWSTONE, Blocks.SEA_LANTERN, Blocks.SHROOMLIGHT, Blocks.OCHRE_FROGLIGHT, Blocks.VERDANT_FROGLIGHT, Blocks.PEARLESCENT_FROGLIGHT, Blocks.OBSIDIAN, Blocks.CRYING_OBSIDIAN, Blocks.NETHERRACK, Blocks.BASALT, Blocks.SMOOTH_BASALT, Blocks.POLISHED_BASALT, Blocks.BLACKSTONE, Blocks.GILDED_BLACKSTONE,
				Blocks.BONE_BLOCK, Blocks.END_STONE, Blocks.END_STONE_BRICKS, Blocks.PURPUR_BLOCK, Blocks.PURPUR_PILLAR, Blocks.AMETHYST_BLOCK, Blocks.HONEYCOMB_BLOCK, Blocks.DRIED_KELP_BLOCK, Blocks.HAY_BLOCK, Blocks.PUMPKIN, Blocks.BOOKSHELF, Blocks.SPONGE,
				Blocks.WARPED_WART_BLOCK, Blocks.NETHER_WART_BLOCK, Blocks.MELON, Blocks.SLIME_BLOCK, Blocks.HONEY_BLOCK);
		p.add(RpedModBlocks.POLISHED_STONE.get().defaultBlockState());
		p.add(RpedModBlocks.FRAMED_COBBLESTONE.get().defaultBlockState());
		p.add(RpedModBlocks.IRON_CASING.get().defaultBlockState());
		p.add(RpedModBlocks.OXIDIZED_IRON_CASING.get().defaultBlockState());
		p.add(RpedModBlocks.RUSTED_IRON_CASING.get().defaultBlockState());
		p.add(RpedModBlocks.STONE_BRICK.get().defaultBlockState());
		p.add(RpedModBlocks.TUMANITE_BLOCK.get().defaultBlockState());
		p.add(RpedModBlocks.CHISELED_IRON_CASING.get().defaultBlockState());
		p.add(RpedModBlocks.CHISELED_POLISHED_STONE.get().defaultBlockState());
		p.add(RpedModBlocks.TILES_IRON_CASING.get().defaultBlockState());
		p.add(RpedModBlocks.SANDS.get().defaultBlockState());
		POOL = p;
		return POOL;
	}

	private static synchronized List<BlockState> dungeonPool() {
		if (DUNGEON != null)
			return DUNGEON;
		List<BlockState> d = new ArrayList<>();
		add(d, Blocks.COBBLESTONE, Blocks.MOSSY_COBBLESTONE, Blocks.COBBLESTONE, Blocks.MOSSY_COBBLESTONE, Blocks.STONE_BRICKS, Blocks.MOSSY_STONE_BRICKS, Blocks.CRACKED_STONE_BRICKS, Blocks.CHISELED_STONE_BRICKS);
		d.add(RpedModBlocks.FRAMED_COBBLESTONE.get().defaultBlockState());
		d.add(RpedModBlocks.IRON_CASING.get().defaultBlockState());
		d.add(RpedModBlocks.RUSTED_IRON_CASING.get().defaultBlockState());
		d.add(RpedModBlocks.STONE_BRICK.get().defaultBlockState());
		DUNGEON = d;
		return DUNGEON;
	}

	private static void add(List<BlockState> list, net.minecraft.world.level.block.Block... blocks) {
		for (net.minecraft.world.level.block.Block b : blocks)
			list.add(b.defaultBlockState());
	}

	@Override
	protected Codec<? extends ChunkGenerator> codec() {
		return CODEC;
	}

	@Override
	public void applyCarvers(WorldGenRegion level, long s, RandomState random, BiomeManager biomeManager, StructureManager structureManager, ChunkAccess chunk, GenerationStep.Carving step) {
	}

	@Override
	public void buildSurface(WorldGenRegion level, StructureManager structureManager, RandomState random, ChunkAccess chunk) {
	}

	@Override
	public void spawnOriginalMobs(WorldGenRegion level) {
	}

	@Override
	public int getGenDepth() {
		return GEN_DEPTH;
	}

	@Override
	public int getSeaLevel() {
		return 0;
	}

	@Override
	public int getMinY() {
		return MIN_Y;
	}

	@Override
	public int getBaseHeight(int x, int z, Heightmap.Types t, LevelHeightAccessor level, RandomState random) {
		if (Math.abs(x) > HALF || Math.abs(z) > HALF)
			return MIN_Y;
		return baseHeight;
	}

	@Override
	public NoiseColumn getBaseColumn(int x, int z, LevelHeightAccessor level, RandomState random) {
		int height = level.getHeight();
		BlockState[] column = new BlockState[height];
		BlockState air = Blocks.AIR.defaultBlockState();
		for (int i = 0; i < height; i++)
			column[i] = air;
		return new NoiseColumn(MIN_Y, column);
	}

	@Override
	public void addDebugScreenInfo(List<String> info, RandomState random, BlockPos pos) {
	}

	@Override
	public CompletableFuture<ChunkAccess> fillFromNoise(Executor executor, Blender blender, RandomState random, StructureManager structureManager, ChunkAccess chunk) {
		int minX = chunk.getPos().getMinBlockX();
		int minZ = chunk.getPos().getMinBlockZ();
		if (minX > HALF || minX + 15 < -HALF || minZ > HALF || minZ + 15 < -HALF)
			return CompletableFuture.completedFuture(chunk);

		long ch = hash(chunk.getPos().x, chunk.getPos().z, seed ^ 0xD0A17L);
		boolean dungeon = (type == OPEN || type == CEILING || type == TERRAIN_FLOATING || type == FLAT) && (ch & 31L) < 3L;
		int rx0 = 2 + (int) ((ch >> 6) & 5L);
		int rz0 = 2 + (int) ((ch >> 12) & 5L);
		int rw = 5 + (int) ((ch >> 18) & 4L);
		int rd = 5 + (int) ((ch >> 22) & 4L);
		int rh = 4 + (int) ((ch >> 26) & 2L);
		int chestLx = rx0 + rw / 2;
		int chestLz = rz0 + rd / 2;
		int roomFloor = clamp(surface(minX + chestLx, minZ + chestLz) - rh, MIN_Y + 3, TOP_CAP - rh - 2);

		BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
		for (int lx = 0; lx < 16; lx++) {
			for (int lz = 0; lz < 16; lz++) {
				int wx = minX + lx;
				int wz = minZ + lz;
				if (Math.abs(wx) > HALF || Math.abs(wz) > HALF)
					continue;

				switch (type) {
					case FLOATING -> genIslands(chunk, m, wx, wz, FLOOR + 8, TOP_CAP);
					case SPIRAL -> genSpiral(chunk, m, wx, wz);
					case FLAT -> genFlat(chunk, m, wx, wz);
					case ONE_BLOCK -> genSolid(chunk, m, wx, wz, palette[0], false);
					case CEILING -> {
						genSolid(chunk, m, wx, wz, null, false);
						genCeiling(chunk, m, wx, wz);
					}
					case TERRAIN_FLOATING -> {
						genSolid(chunk, m, wx, wz, null, true);
						genIslands(chunk, m, wx, wz, surface(wx, wz) + 12, TOP_CAP);
					}
					default -> genSolid(chunk, m, wx, wz, null, true);
				}

				if (dungeon && lx >= rx0 && lx <= rx0 + rw && lz >= rz0 && lz <= rz0 + rd) {
					boolean edge = lx == rx0 || lx == rx0 + rw || lz == rz0 || lz == rz0 + rd;
					for (int y = roomFloor; y <= roomFloor + rh; y++) {
						boolean cap = y == roomFloor || y == roomFloor + rh;
						m.set(wx, y, wz);
						if (cap || edge)
							chunk.setBlockState(m, dungeonBlock(wx, y, wz), false);
						else
							chunk.setBlockState(m, Blocks.AIR.defaultBlockState(), false);
					}
					if (lx == chestLx && lz == chestLz)
						placeChest(chunk, new BlockPos(wx, roomFloor + 1, wz));
				}
			}
		}
		Heightmap.primeHeightmaps(chunk, EnumSet.of(Heightmap.Types.WORLD_SURFACE_WG, Heightmap.Types.OCEAN_FLOOR_WG));
		return CompletableFuture.completedFuture(chunk);
	}

	private void genSolid(ChunkAccess chunk, BlockPos.MutableBlockPos m, int wx, int wz, BlockState forced, boolean spikes) {
		int top = surface(wx, wz);
		for (int y = FLOOR; y <= top; y++) {
			m.set(wx, y, wz);
			chunk.setBlockState(m, forced != null ? forced : blockAt(wx, y, wz, top), false);
		}
		if (spikes) {
			long h = hash(wx, wz, seed ^ 0xA11CE7L);
			if ((h & 2047L) < 5L) {
				int spike = 3 + (int) ((h >> 11) & 9L);
				for (int y = top + 1; y <= top + spike; y++) {
					m.set(wx, y, wz);
					chunk.setBlockState(m, accent, false);
				}
			}
		}
	}

	private void genCeiling(ChunkAccess chunk, BlockPos.MutableBlockPos m, int wx, int wz) {
		int c = CEIL_Y + (int) (fbm2(seed ^ 0xCE11L, wx * 0.05, wz * 0.05, 2) * 8);
		for (int y = c; y <= TOP_CAP; y++) {
			m.set(wx, y, wz);
			chunk.setBlockState(m, blockAt(wx, y + 90, wz, TOP_CAP), false);
		}
	}

	private void genIslands(ChunkAccess chunk, BlockPos.MutableBlockPos m, int wx, int wz, int from, int to) {
		for (int y = from; y <= to; y++) {
			double d = fbm3(seed ^ 0x51ED0L, wx * 0.06, y * 0.085, wz * 0.06, 3);
			double span = to - from;
			double center = (y - (from + to) * 0.5) / (span * 0.5);
			double fade = 1.0 - center * center;
			if (d + fade * 0.22 > 0.72) {
				m.set(wx, y, wz);
				chunk.setBlockState(m, blockAt(wx, y + 40, wz, y), false);
			}
		}
	}

	private void genFlat(ChunkAccess chunk, BlockPos.MutableBlockPos m, int wx, int wz) {
		int top = baseHeight;
		for (int y = FLOOR; y <= top; y++) {
			int band = (y - FLOOR) * palette.length / Math.max(1, top - FLOOR);
			if (band >= palette.length)
				band = palette.length - 1;
			m.set(wx, y, wz);
			chunk.setBlockState(m, palette[band], false);
		}
	}

	private void genSpiral(ChunkAccess chunk, BlockPos.MutableBlockPos m, int wx, int wz) {
		double dist = Math.sqrt((double) wx * wx + (double) wz * wz);
		int baseY = 64;
		if (dist < 3) {
			for (int y = FLOOR; y <= baseY + 6; y++) {
				m.set(wx, y, wz);
				chunk.setBlockState(m, palette[0], false);
			}
			return;
		}
		if (dist > HALF - 6)
			return;
		double ang = Math.atan2(wz, wx);
		double angPerBlock = 0.2;
		double pathAng = dist * angPerBlock;
		double expected = pathAng % (Math.PI * 2);
		double da = Math.abs(Mth.wrapDegrees((float) Math.toDegrees(ang - expected))) / 180.0 * Math.PI;
		if (da < 0.62) {
			int y = baseY + (int) (pathAng * 1.9);
			if (y < FLOOR + 1)
				y = FLOOR + 1;
			if (y > TOP_CAP)
				return;
			m.set(wx, y - 1, wz);
			chunk.setBlockState(m, blockAt(wx, y, wz, y), false);
			m.set(wx, y, wz);
			chunk.setBlockState(m, blockAt(wx, y, wz, y), false);
		}
	}

	private int surface(int x, int z) {
		double n = fbm2(seed, x * 0.011, z * 0.011, 4);
		double ridge = fbm2(seed ^ 0x7C1L, x * 0.05, z * 0.05, 2) * 0.35;
		int h = baseHeight + (int) Math.round((n + ridge) * amplitude);
		if (h < FLOOR + 2)
			h = FLOOR + 2;
		if (h > TOP_CAP - 8)
			h = TOP_CAP - 8;
		if (type == CEILING && h > CEIL_Y - 20)
			h = CEIL_Y - 20;
		return h;
	}

	private BlockState blockAt(int x, int y, int z, int top) {
		double sel = fbm2(seed ^ 0xBEEFL, x * 0.028, z * 0.028, 2) * 0.5 + 0.5;
		int idx = (int) (sel * palette.length);
		if (idx >= palette.length)
			idx = palette.length - 1;
		if (idx < 0)
			idx = 0;
		double vein = fbm3(seed ^ 0x0FE1L, x * 0.11, y * 0.11, z * 0.11, 2);
		if (vein > 0.82)
			return accent;
		return palette[idx];
	}

	private BlockState dungeonBlock(int x, int y, int z) {
		List<BlockState> d = dungeonPool();
		long h = hash3(x, y, z, seed ^ 0xD0656L);
		return d.get((int) ((h >>> 8) % d.size()));
	}

	private void placeChest(ChunkAccess chunk, BlockPos pos) {
		BlockState chestState = Blocks.CHEST.defaultBlockState();
		chunk.setBlockState(pos, chestState, false);
		BlockEntity be = new ChestBlockEntity(pos, chestState);
		if (be instanceof RandomizableContainerBlockEntity rc)
			rc.setLootTable(DUNGEON_LOOT, hash3(pos.getX(), pos.getY(), pos.getZ(), seed ^ 0x100721L));
		chunk.setBlockEntity(be);
	}

	private static int clamp(int v, int lo, int hi) {
		return v < lo ? lo : (v > hi ? hi : v);
	}

	private static long hash(int x, int z, long seed) {
		long h = seed + x * 0x9E3779B97F4A7C15L + z * 0xC2B2AE3D27D4EB4FL;
		h ^= (h >>> 29);
		h *= 0xBF58476D1CE4E5B9L;
		h ^= (h >>> 27);
		h *= 0x94D049BB133111EBL;
		h ^= (h >>> 31);
		return h;
	}

	private static long hash3(int x, int y, int z, long seed) {
		long h = seed + x * 0x9E3779B97F4A7C15L + y * 0xC2B2AE3D27D4EB4FL + z * 0x165667B19E3779F9L;
		h ^= (h >>> 29);
		h *= 0xBF58476D1CE4E5B9L;
		h ^= (h >>> 27);
		h *= 0x94D049BB133111EBL;
		h ^= (h >>> 31);
		return h;
	}

	private static double grad(long h) {
		return ((h >>> 11) * (1.0 / 9007199254740992.0)) * 2.0 - 1.0;
	}

	private static double smooth(double t) {
		return t * t * t * (t * (t * 6 - 15) + 10);
	}

	private static double lerp(double a, double b, double t) {
		return a + (b - a) * t;
	}

	private static double value2(long seed, double x, double z) {
		int x0 = (int) Math.floor(x);
		int z0 = (int) Math.floor(z);
		double fx = smooth(x - x0);
		double fz = smooth(z - z0);
		double v00 = grad(hash(x0, z0, seed));
		double v10 = grad(hash(x0 + 1, z0, seed));
		double v01 = grad(hash(x0, z0 + 1, seed));
		double v11 = grad(hash(x0 + 1, z0 + 1, seed));
		return lerp(lerp(v00, v10, fx), lerp(v01, v11, fx), fz);
	}

	private static double value3(long seed, double x, double y, double z) {
		int x0 = (int) Math.floor(x);
		int y0 = (int) Math.floor(y);
		int z0 = (int) Math.floor(z);
		double fx = smooth(x - x0);
		double fy = smooth(y - y0);
		double fz = smooth(z - z0);
		double v000 = grad(hash3(x0, y0, z0, seed));
		double v100 = grad(hash3(x0 + 1, y0, z0, seed));
		double v010 = grad(hash3(x0, y0 + 1, z0, seed));
		double v110 = grad(hash3(x0 + 1, y0 + 1, z0, seed));
		double v001 = grad(hash3(x0, y0, z0 + 1, seed));
		double v101 = grad(hash3(x0 + 1, y0, z0 + 1, seed));
		double v011 = grad(hash3(x0, y0 + 1, z0 + 1, seed));
		double v111 = grad(hash3(x0 + 1, y0 + 1, z0 + 1, seed));
		double x00 = lerp(v000, v100, fx);
		double x10 = lerp(v010, v110, fx);
		double x01 = lerp(v001, v101, fx);
		double x11 = lerp(v011, v111, fx);
		double y0l = lerp(x00, x10, fy);
		double y1l = lerp(x01, x11, fy);
		return lerp(y0l, y1l, fz);
	}

	private static double fbm2(long seed, double x, double z, int oct) {
		double sum = 0, amp = 1, freq = 1, norm = 0;
		for (int i = 0; i < oct; i++) {
			sum += amp * value2(seed + i * 1013L, x * freq, z * freq);
			norm += amp;
			amp *= 0.5;
			freq *= 2;
		}
		return sum / norm;
	}

	private static double fbm3(long seed, double x, double y, double z, int oct) {
		double sum = 0, amp = 1, freq = 1, norm = 0;
		for (int i = 0; i < oct; i++) {
			sum += amp * value3(seed + i * 1013L, x * freq, y * freq, z * freq);
			norm += amp;
			amp *= 0.5;
			freq *= 2;
		}
		return sum / norm;
	}
}
