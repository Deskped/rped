package deskped.rped.dimension;

import com.mojang.serialization.Codec;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.biome.FixedBiomeSource;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.dimension.BuiltinDimensionTypes;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.dimension.LevelStem;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

import deskped.rped.RpedMod;

public class BreakdownDimensions {

	public static final DeferredRegister<Codec<? extends ChunkGenerator>> GENERATORS = DeferredRegister.create(Registries.CHUNK_GENERATOR, RpedMod.MODID);

	public static final RegistryObject<Codec<BreakdownChunkGenerator>> BREAKDOWN_GENERATOR = GENERATORS.register("breakdown", () -> BreakdownChunkGenerator.CODEC);

	public static void register(IEventBus bus) {
		GENERATORS.register(bus);
	}

	public static LevelStem createStem(MinecraftServer server, long seed, int genType) {
		Holder<DimensionType> dimType = server.registryAccess().registryOrThrow(Registries.DIMENSION_TYPE).getHolderOrThrow(BuiltinDimensionTypes.OVERWORLD);
		Holder<Biome> biome = server.registryAccess().registryOrThrow(Registries.BIOME).getHolderOrThrow(Biomes.THE_VOID);
		ChunkGenerator generator = new BreakdownChunkGenerator(new FixedBiomeSource(biome), seed, genType);
		return new LevelStem(dimType, generator);
	}
}
