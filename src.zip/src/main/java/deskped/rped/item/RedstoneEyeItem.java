package deskped.rped.item;

import net.minecraft.world.item.Item;

public class RedstoneEyeItem extends Item {
	public RedstoneEyeItem() {
		super(new Item.Properties());
	}
}