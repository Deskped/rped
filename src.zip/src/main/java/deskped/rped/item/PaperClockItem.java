package deskped.rped.item;

import net.minecraft.world.item.Item;

public class PaperClockItem extends Item {
	public PaperClockItem() {
		super(new Item.Properties());
	}
}