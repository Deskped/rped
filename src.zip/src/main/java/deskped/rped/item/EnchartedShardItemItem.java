package deskped.rped.item;

import net.minecraft.world.item.Item;

public class EnchartedShardItemItem extends Item {
	public EnchartedShardItemItem() {
		super(new Item.Properties().stacksTo(1));
	}
}