package deskped.rped.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.network.chat.Component;

import java.util.List;

public class IceTridentItem extends SwordItem {
	public IceTridentItem() {
		super(new Tier() {
			public int getUses() {
				return 0;
			}

			public float getSpeed() {
				return 0f;
			}

			public float getAttackDamageBonus() {
				return 24f;
			}

			public int getLevel() {
				return 0;
			}

			public int getEnchantmentValue() {
				return 1;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of();
			}
		}, 3, -2.7f, new Item.Properties());
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, level, list, flag);
		list.add(Component.translatable("item.rped.ice_trident.description_0"));
		list.add(Component.translatable("item.rped.ice_trident.description_1"));
		list.add(Component.translatable("item.rped.ice_trident.description_2"));
		list.add(Component.translatable("item.rped.ice_trident.description_3"));
		list.add(Component.translatable("item.rped.ice_trident.description_4"));
		list.add(Component.translatable("item.rped.ice_trident.description_5"));
	}
}