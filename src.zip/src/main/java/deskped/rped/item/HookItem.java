package deskped.rped.item;

import net.minecraft.world.item.Item;

public class HookItem extends Item {
	public HookItem() {
		super(new Item.Properties());
	}
}