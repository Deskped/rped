package deskped.rped.item;

import net.minecraft.world.item.Item;

public class AngelClockItem extends Item {
	public AngelClockItem() {
		super(new Item.Properties());
	}
}