package deskped.rped.item;

import net.minecraft.world.item.Item;

public class ClockPartsItem extends Item {
	public ClockPartsItem() {
		super(new Item.Properties());
	}
}