package deskped.rped.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class StarItem extends Item {
	public StarItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
	}
}