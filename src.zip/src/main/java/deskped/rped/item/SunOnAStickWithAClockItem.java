package deskped.rped.item;

import net.minecraft.world.item.Item;

public class SunOnAStickWithAClockItem extends Item {
	public SunOnAStickWithAClockItem() {
		super(new Item.Properties());
	}
}