package deskped.rped.item;

import net.minecraft.world.item.Item;

public class WoodoLeafletItem extends Item {
	public WoodoLeafletItem() {
		super(new Item.Properties());
	}
}