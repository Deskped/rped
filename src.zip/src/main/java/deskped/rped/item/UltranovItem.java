package deskped.rped.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.network.chat.Component;

import java.util.List;

public class UltranovItem extends Item {
	public UltranovItem() {
		super(new Item.Properties().stacksTo(1));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, level, list, flag);
		list.add(Component.translatable("item.rped.ultranov.description_0"));
		list.add(Component.translatable("item.rped.ultranov.description_1"));
		list.add(Component.translatable("item.rped.ultranov.description_2"));
	}
}