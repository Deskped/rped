package deskped.rped.item;

import net.minecraft.world.item.Item;

public class OveridiumItem extends Item {
	public OveridiumItem() {
		super(new Item.Properties());
	}
}