package deskped.rped.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

import java.util.List;

import deskped.rped.procedures.InfoDeleteProcedure;

public class InfoItem extends Item {
	public InfoItem() {
		super(new Item.Properties().stacksTo(1));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, level, list, flag);
		list.add(Component.translatable("item.rped.info.description_0"));
		list.add(Component.translatable("item.rped.info.description_1"));
		list.add(Component.translatable("item.rped.info.description_2"));
		list.add(Component.translatable("item.rped.info.description_3"));
		list.add(Component.translatable("item.rped.info.description_4"));
	}

	@Override
	public void inventoryTick(ItemStack itemstack, Level world, Entity entity, int slot, boolean selected) {
		super.inventoryTick(itemstack, world, entity, slot, selected);
		InfoDeleteProcedure.execute(itemstack);
	}
}