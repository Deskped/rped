package deskped.rped.item;

import net.minecraft.world.item.Item;

public class DontForgetClockItem extends Item {
	public DontForgetClockItem() {
		super(new Item.Properties());
	}
}