package deskped.rped.item;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import deskped.rped.block.CrusherBlock;

import java.util.function.Consumer;

public class CrusherBlockItem extends BlockItem {

    public CrusherBlockItem(CrusherBlock block, Properties properties) {
        super(block, properties);
    }

    @Override
    @OnlyIn(Dist.CLIENT)
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            @Override
            public net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer getCustomRenderer() {
                return deskped.rped.client.renderer.CrusherBEWLR.getInstance();
            }
        });
    }
}
