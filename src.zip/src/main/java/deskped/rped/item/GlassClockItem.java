package deskped.rped.item;

import net.minecraft.world.item.Item;

public class GlassClockItem extends Item {
	public GlassClockItem() {
		super(new Item.Properties());
	}
}