package deskped.rped.item;

import net.minecraft.world.item.Item;

public class ScrollClockItem extends Item {
	public ScrollClockItem() {
		super(new Item.Properties());
	}
}