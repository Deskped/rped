package deskped.rped.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.Entity;

import deskped.rped.procedures.KuwandTickProcedure;

public class KuwandItem extends Item {
	public KuwandItem() {
		super(new Item.Properties().durability(333));
	}

	@Override
	public void inventoryTick(ItemStack itemstack, Level world, Entity entity, int slot, boolean selected) {
		super.inventoryTick(itemstack, world, entity, slot, selected);
		KuwandTickProcedure.execute(world, entity, itemstack);
	}
}