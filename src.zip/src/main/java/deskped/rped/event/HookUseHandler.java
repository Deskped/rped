package deskped.rped.event;

import deskped.rped.RpedMod;
import deskped.rped.entity.HookEntity;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.List;

@Mod.EventBusSubscriber(modid = RpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class HookUseHandler {

    @SubscribeEvent
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        Player player = event.getEntity();
        ItemStack stack = event.getItemStack();
        Item hook = ForgeRegistries.ITEMS.getValue(new ResourceLocation("rped", "hook"));
        if (hook == null || stack.getItem() != hook)
            return;
        Level level = event.getLevel();
        if (!level.isClientSide) {
            HookEntity existing = findHook(level, player);
            if (existing != null) {
                existing.discard();
                level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.FISHING_BOBBER_RETRIEVE, SoundSource.PLAYERS, 0.8f, 1.2f);
                player.getCooldowns().addCooldown(hook, 5);
            } else {
                HookEntity h = new HookEntity(level, player);
                h.setPos(player.getX(), player.getEyeY() - 0.1, player.getZ());
                h.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0f, 2.6f, 0.0f);
                level.addFreshEntity(h);
                level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.FISHING_BOBBER_THROW, SoundSource.PLAYERS, 0.8f, 0.9f);
            }
        }
        player.swing(event.getHand());
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
    }

    private static HookEntity findHook(Level level, Player player) {
        List<HookEntity> hooks = level.getEntitiesOfClass(HookEntity.class, player.getBoundingBox().inflate(64.0));
        for (HookEntity h : hooks) {
            if (player.equals(h.getOwner()))
                return h;
        }
        return null;
    }
}
