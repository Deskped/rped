package deskped.rped.event;

import deskped.rped.RpedMod;
import deskped.rped.ext.RpedExtra;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;

import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = RpedMod.MODID)
public class DecapitatorHandler {

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide)
            return;

        DamageSource source = event.getSource();
        Entity attacker = source.getEntity();
        if (!(attacker instanceof LivingEntity killer))
            return;
        if (EnchantmentHelper.getItemEnchantmentLevel(RpedExtra.DECAPITATOR.get(), killer.getMainHandItem()) <= 0)
            return;

        ItemStack head = headFor(victim);
        if (head == null || head.isEmpty())
            return;

        ItemEntity drop = new ItemEntity(victim.level(), victim.getX(), victim.getY() + 0.5, victim.getZ(), head);
        drop.setDefaultPickUpDelay();
        victim.level().addFreshEntity(drop);
    }

    private static ItemStack headFor(LivingEntity victim) {
        if (victim instanceof Player player) {
            ItemStack head = new ItemStack(Items.PLAYER_HEAD);
            CompoundTag tag = head.getOrCreateTag();
            tag.putString("SkullOwner", player.getGameProfile().getName());
            return head;
        }

        EntityType<?> type = victim.getType();
        if (type == EntityType.ZOMBIE)
            return new ItemStack(Items.ZOMBIE_HEAD);
        if (type == EntityType.SKELETON)
            return new ItemStack(Items.SKELETON_SKULL);
        if (type == EntityType.WITHER_SKELETON)
            return new ItemStack(Items.WITHER_SKELETON_SKULL);
        if (type == EntityType.CREEPER)
            return new ItemStack(Items.CREEPER_HEAD);
        if (type == EntityType.ENDER_DRAGON)
            return new ItemStack(Items.DRAGON_HEAD);
        if (type == EntityType.PIGLIN || type == EntityType.PIGLIN_BRUTE)
            return new ItemStack(Items.PIGLIN_HEAD);

        return ItemStack.EMPTY;
    }
}
