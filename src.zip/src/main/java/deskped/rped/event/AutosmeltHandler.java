package deskped.rped.event;

import deskped.rped.RpedMod;
import deskped.rped.ext.RpedExtra;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SmeltingRecipe;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Mod.EventBusSubscriber(modid = RpedMod.MODID)
public class AutosmeltHandler {

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onBreak(BlockEvent.BreakEvent event) {
        Player player = event.getPlayer();
        if (player == null || player.isCreative())
            return;
        if (!(event.getLevel() instanceof ServerLevel level))
            return;

        ItemStack tool = player.getMainHandItem();
        if (EnchantmentHelper.getItemEnchantmentLevel(RpedExtra.AUTOSMELT.get(), tool) <= 0)
            return;
        if (EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SILK_TOUCH, tool) > 0)
            return;

        BlockState state = event.getState();
        BlockPos pos = event.getPos();
        BlockEntity be = level.getBlockEntity(pos);

        List<ItemStack> drops = Block.getDrops(state, level, pos, be, player, tool);
        List<ItemStack> result = new ArrayList<>();
        boolean smeltedAny = false;

        for (ItemStack drop : drops) {
            ItemStack smelted = smelt(level, drop);
            if (!ItemStack.matches(smelted, drop))
                smeltedAny = true;
            result.add(smelted);
        }

        if (!smeltedAny)
            return;

        event.setCanceled(true);

        int fortune = EnchantmentHelper.getItemEnchantmentLevel(Enchantments.BLOCK_FORTUNE, tool);
        int exp = state.getExpDrop(level, level.random, pos, fortune, 0);

        level.removeBlock(pos, false);
        tool.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(InteractionHand.MAIN_HAND));

        for (ItemStack stack : result) {
            if (!stack.isEmpty())
                Block.popResource(level, pos, stack);
        }

        if (exp > 0)
            state.getBlock().popExperience(level, pos, exp);

        level.sendParticles(ParticleTypes.FLAME, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 12, 0.3, 0.3, 0.3, 0.01);
        level.sendParticles(ParticleTypes.SMOKE, pos.getX() + 0.5, pos.getY() + 0.6, pos.getZ() + 0.5, 6, 0.2, 0.2, 0.2, 0.01);
        level.playSound(null, pos, SoundEvents.FIRE_EXTINGUISH, SoundSource.BLOCKS, 0.5f, 1.4f + level.random.nextFloat() * 0.2f);
    }

    private static ItemStack smelt(ServerLevel level, ItemStack input) {
        if (input.isEmpty())
            return input;
        Optional<SmeltingRecipe> recipe = level.getRecipeManager().getRecipeFor(RecipeType.SMELTING, new SimpleContainer(input), level);
        if (recipe.isEmpty())
            return input;
        ItemStack out = recipe.get().getResultItem(level.registryAccess());
        if (out.isEmpty())
            return input;
        ItemStack copy = out.copy();
        copy.setCount(out.getCount() * input.getCount());
        return copy;
    }
}
