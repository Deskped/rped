package deskped.rped.explosion;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.registries.RegistryObject;

import deskped.rped.init.RpedModEntities;
import deskped.rped.init.RpedModSounds;

public final class CoreExplosion {

    public static final double MAX_RADIUS = 33.0;
    public static final double MAX_VISUAL_RADIUS = 34.5;
    public static final double MAX_DAMAGE = 60.0;
    public static final double MAX_KNOCKBACK = 3.6;

    public static final RegistryObject<EntityType<CoreExplosionEntity>> ENTITY = RpedModEntities.REGISTRY.register("core_explosion",
            () -> EntityType.Builder.<CoreExplosionEntity>of(CoreExplosionEntity::new, MobCategory.MISC)
                    .sized(1.0f, 1.0f)
                    .clientTrackingRange(16)
                    .updateInterval(2)
                    .fireImmune()
                    .build("core_explosion"));

    public static void bootstrap() {
    }

    public static void trigger(ServerLevel level, BlockPos center) {
        Vec3 c = Vec3.atCenterOf(center);
        playIntro(level, c);
        CoreExplosionEntity visual = new CoreExplosionEntity(ENTITY.get(), level);
        visual.setPos(c.x, center.getY() + 0.5, c.z);
        level.addFreshEntity(visual);
    }

    private static void playIntro(ServerLevel level, Vec3 c) {
        level.playSound(null, c.x, c.y, c.z, RpedModSounds.CORE_EXPLODE.get(), SoundSource.BLOCKS, 6.0f, 0.7f);
        level.playSound(null, c.x, c.y, c.z, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 4.0f, 0.55f);
        level.playSound(null, c.x, c.y, c.z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.WEATHER, 6.0f, 0.7f);
        level.playSound(null, c.x, c.y, c.z, SoundEvents.END_PORTAL_SPAWN, SoundSource.BLOCKS, 3.0f, 0.6f);
        level.sendParticles(ParticleTypes.FLASH, c.x, c.y, c.z, 2, 0.0, 0.0, 0.0, 0.0);
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 1, 0.0, 0.0, 0.0, 0.0);
        level.sendParticles(ParticleTypes.SONIC_BOOM, c.x, c.y + 0.5, c.z, 1, 0.0, 0.0, 0.0, 0.0);
    }

    private CoreExplosion() {
    }
}