package deskped.rped.explosion;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import deskped.rped.RpedMod;

@Mod.EventBusSubscriber(modid = RpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class CoreExplodeCommand {

    @SubscribeEvent
    public static void onRegister(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("rped")
                .then(Commands.literal("explosion")
                        .requires(src -> src.hasPermission(2))
                        .then(Commands.literal("core")
                                .executes(ctx -> run(ctx.getSource(), sourceBlockPos(ctx.getSource())))
                                .then(Commands.argument("pos", BlockPosArgument.blockPos())
                                        .executes(ctx -> run(ctx.getSource(), BlockPosArgument.getLoadedBlockPos(ctx, "pos")))))));
    }

    private static BlockPos sourceBlockPos(CommandSourceStack source) {
        Vec3 pos = source.getPosition();
        return BlockPos.containing(pos.x, pos.y, pos.z);
    }

    private static int run(CommandSourceStack source, BlockPos pos) {
        ServerLevel level = source.getLevel();
        CoreExplosion.trigger(level, pos);
        source.sendSuccess(() -> Component.literal("\u0414\u0435\u0442\u043e\u043d\u0430\u0446\u0438\u044f \u044f\u0434\u0440\u0430: " + pos.getX() + " " + pos.getY() + " " + pos.getZ()), true);
        return 1;
    }
}