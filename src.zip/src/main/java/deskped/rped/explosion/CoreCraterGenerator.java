package deskped.rped.explosion;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public final class CoreCraterGenerator {

    public static void dress(ServerLevel level, BlockPos origin) {
        int r = (int) Math.floor(CoreExplosion.MAX_RADIUS);
        double r2 = CoreExplosion.MAX_RADIUS * CoreExplosion.MAX_RADIUS;
        int minBuild = level.getMinBuildHeight() + 1;
        RandomSource rnd = level.getRandom();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                double dh2 = (double) (dx * dx + dz * dz);
                if (dh2 > r2) continue;
                if (rnd.nextFloat() > 0.55f) continue;
                double vy = Math.sqrt(Math.max(0.0, r2 - dh2));
                int floorY = origin.getY() - (int) Math.floor(vy);
                if (floorY < minBuild) floorY = minBuild;
                BlockPos fp = new BlockPos(origin.getX() + dx, floorY, origin.getZ() + dz);
                if (level.getBlockState(fp.below()).isAir()) continue;
                double t = Math.sqrt(dh2) / CoreExplosion.MAX_RADIUS;
                BlockState accent;
                if (t < 0.30 && rnd.nextFloat() < 0.45f) {
                    accent = Blocks.LAVA.defaultBlockState();
                } else {
                    accent = pickFloor(rnd, t);
                }
                level.setBlock(fp, accent, 2);
            }
        }
        paintBiome(level, origin, Math.min(r, 26));
    }

    private static BlockState pickFloor(RandomSource rnd, double t) {
        float f = rnd.nextFloat();
        if (t < 0.35) {
            if (f < 0.5f) return Blocks.MAGMA_BLOCK.defaultBlockState();
            if (f < 0.8f) return Blocks.BLACKSTONE.defaultBlockState();
            return Blocks.BASALT.defaultBlockState();
        } else if (t < 0.7) {
            if (f < 0.4f) return Blocks.BASALT.defaultBlockState();
            if (f < 0.75f) return Blocks.BLACKSTONE.defaultBlockState();
            return Blocks.COBBLED_DEEPSLATE.defaultBlockState();
        } else {
            if (f < 0.45f) return Blocks.BLACKSTONE.defaultBlockState();
            if (f < 0.78f) return Blocks.COBBLED_DEEPSLATE.defaultBlockState();
            return Blocks.GRAVEL.defaultBlockState();
        }
    }

    private static void paintBiome(ServerLevel level, BlockPos origin, int radius) {
        MinecraftServer server = level.getServer();
        if (server == null) return;
        CommandSourceStack source = server.createCommandSourceStack()
                .withLevel(level)
                .withPermission(4)
                .withSuppressedOutput();
        int minY = level.getMinBuildHeight();
        int maxY = level.getMaxBuildHeight() - 1;
        for (int dz = -radius; dz <= radius; dz++) {
            int span = (int) Math.floor(Math.sqrt((double) (radius * radius - dz * dz)));
            int x1 = origin.getX() - span;
            int x2 = origin.getX() + span;
            int z = origin.getZ() + dz;
            String command = "fillbiome " + x1 + " " + minY + " " + z + " " + x2 + " " + maxY + " " + z + " minecraft:basalt_deltas";
            server.getCommands().performPrefixedCommand(source, command);
        }
    }

    private CoreCraterGenerator() {
    }
}