package deskped.rped.explosion;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class CoreExplosionEntity extends Entity {

    private static final double DESTROY_SPEED = 0.9;
    private static final int BLOCK_BUDGET = 1700;
    private static final int MAX_LIFETIME = 220;
    private static final int VISUAL_TOTAL_TICKS = 96;
    private static final int PARTICLES_PER_TICK = 16;

    private static volatile long[] SPHERE;

    private int cursor = 0;
    private boolean initialized = false;
    private boolean dressed = false;
    private double lastFront = 0.0;
    private BlockPos origin = BlockPos.ZERO;
    private final Set<Integer> hit = new HashSet<>();

    public CoreExplosionEntity(EntityType<? extends CoreExplosionEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) return;
        ServerLevel sl = (ServerLevel) this.level();
        if (!this.initialized) {
            this.origin = this.blockPosition();
            this.initialized = true;
        }
        long[] sphere = sphere();
        double target = Math.min(CoreExplosion.MAX_RADIUS, DESTROY_SPEED * this.tickCount);
        int budget = BLOCK_BUDGET;
        double front = this.lastFront;
        BlockState air = Blocks.AIR.defaultBlockState();
        int minBuild = sl.getMinBuildHeight() + 1;
        while (this.cursor < sphere.length && budget > 0) {
            long v = sphere[this.cursor];
            double dist = (v >>> 32) / 1000.0;
            if (dist > target) break;
            this.cursor++;
            budget--;
            int packed = (int) (v & 0xFFFFFFFFL);
            int dz = (packed & 1023) - 512;
            int dy = ((packed >> 10) & 1023) - 512;
            int dx = ((packed >> 20) & 1023) - 512;
            int wy = this.origin.getY() + dy;
            front = dist;
            if (wy < minBuild) continue;
            BlockPos pos = new BlockPos(this.origin.getX() + dx, wy, this.origin.getZ() + dz);
            BlockState state = sl.getBlockState(pos);
            if (state.isAir()) continue;
            if (state.getDestroySpeed(sl, pos) < 0.0f) continue;
            sl.setBlock(pos, air, 18);
        }
        this.lastFront = front;
        damageShell(sl, front);
        frontParticles(sl, front);
        if (this.tickCount <= 18) centerColumn(sl);
        if (this.tickCount > 0 && this.tickCount % 12 == 0) rumble(sl);
        boolean done = this.cursor >= sphere.length;
        if (done && !this.dressed) {
            CoreCraterGenerator.dress(sl, this.origin);
            this.dressed = true;
        }
        if (this.tickCount >= MAX_LIFETIME || (done && this.tickCount >= VISUAL_TOTAL_TICKS)) {
            this.discard();
        }
    }

    private void damageShell(ServerLevel sl, double front) {
        if (front <= 0.5) return;
        Vec3 c = Vec3.atCenterOf(this.origin);
        AABB box = new AABB(c.x, c.y, c.z, c.x, c.y, c.z).inflate(front + 1.0);
        for (Entity e : sl.getEntities(this, box, x -> x.isAlive())) {
            if (e instanceof CoreExplosionEntity) continue;
            int id = e.getId();
            if (this.hit.contains(id)) continue;
            Vec3 ep = e.position();
            double d = ep.distanceTo(c);
            if (d > front) continue;
            this.hit.add(id);
            double norm = Mth.clamp(1.0 - d / CoreExplosion.MAX_RADIUS, 0.0, 1.0);
            float dmg = (float) (6.0 + norm * norm * CoreExplosion.MAX_DAMAGE);
            e.hurt(sl.damageSources().explosion(null, null), dmg);
            Vec3 diff = ep.subtract(c);
            Vec3 dir = diff.lengthSqr() > 1.0e-4 ? diff.normalize() : new Vec3(0.0, 1.0, 0.0);
            double kb = 0.6 + norm * CoreExplosion.MAX_KNOCKBACK;
            e.setDeltaMovement(e.getDeltaMovement().add(dir.x * kb, Math.abs(dir.y) * kb + kb * 0.55, dir.z * kb));
            e.hurtMarked = true;
            if (e instanceof LivingEntity le && norm > 0.4) le.setSecondsOnFire(6);
        }
    }

    private void frontParticles(ServerLevel sl, double front) {
        if (front < 1.0) return;
        Vec3 c = Vec3.atCenterOf(this.origin);
        for (int i = 0; i < PARTICLES_PER_TICK; i++) {
            double theta = this.random.nextDouble() * Math.PI * 2.0;
            double phi = Math.min(Math.PI, Math.acos(Mth.clamp(1.0 - this.random.nextDouble() * 1.6, -1.0, 1.0)));
            double sinp = Math.sin(phi);
            double px = c.x + front * sinp * Math.cos(theta);
            double py = c.y + front * Math.cos(phi);
            double pz = c.z + front * sinp * Math.sin(theta);
            int pick = this.random.nextInt(3);
            SimpleParticleType p = pick == 0 ? ParticleTypes.LARGE_SMOKE : pick == 1 ? ParticleTypes.LAVA : ParticleTypes.FLAME;
            sl.sendParticles(p, px, py, pz, 1, 0.1, 0.1, 0.1, 0.02);
        }
        if (this.random.nextInt(3) == 0) {
            double theta = this.random.nextDouble() * Math.PI * 2.0;
            double sinp = 0.8 + this.random.nextDouble() * 0.2;
            double px = c.x + front * sinp * Math.cos(theta);
            double pz = c.z + front * sinp * Math.sin(theta);
            sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, px, c.y + 0.5, pz, 1, 0.0, 0.0, 0.0, 0.0);
        }
    }

    private void centerColumn(ServerLevel sl) {
        Vec3 c = Vec3.atCenterOf(this.origin);
        for (int k = 0; k < 7; k++) {
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, c.x, c.y + k * 2.0, c.z, 1, 0.6, 0.4, 0.6, 0.02);
        }
        sl.sendParticles(ParticleTypes.FLAME, c.x, c.y + 1.0, c.z, 4, 0.5, 1.5, 0.5, 0.05);
    }

    private void rumble(ServerLevel sl) {
        sl.playSound(null, this.origin, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 3.0f, 0.45f + this.random.nextFloat() * 0.2f);
    }

    private static long[] sphere() {
        long[] cached = SPHERE;
        if (cached != null) return cached;
        synchronized (CoreExplosionEntity.class) {
            if (SPHERE != null) return SPHERE;
            int r = (int) Math.ceil(CoreExplosion.MAX_RADIUS);
            double r2 = CoreExplosion.MAX_RADIUS * CoreExplosion.MAX_RADIUS;
            int count = 0;
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r; dy <= r; dy++) {
                    for (int dz = -r; dz <= r; dz++) {
                        if ((double) (dx * dx + dy * dy + dz * dz) <= r2) count++;
                    }
                }
            }
            long[] arr = new long[count];
            int i = 0;
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r; dy <= r; dy++) {
                    for (int dz = -r; dz <= r; dz++) {
                        double d2 = (double) (dx * dx + dy * dy + dz * dz);
                        if (d2 > r2) continue;
                        int q = (int) Math.round(Math.sqrt(d2) * 1000.0);
                        int packed = ((dx + 512) << 20) | ((dy + 512) << 10) | (dz + 512);
                        arr[i++] = ((long) q << 32) | (packed & 0xFFFFFFFFL);
                    }
                }
            }
            Arrays.sort(arr);
            SPHERE = arr;
            return arr;
        }
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        return this.getBoundingBox().inflate(CoreExplosion.MAX_VISUAL_RADIUS);
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distanceSqr) {
        return distanceSqr < 240.0 * 240.0;
    }

    @Override
    protected void defineSynchedData() {
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return new ClientboundAddEntityPacket(this);
    }
}