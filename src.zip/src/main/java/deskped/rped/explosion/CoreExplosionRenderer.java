package deskped.rped.explosion;

import org.joml.Matrix3f;
import org.joml.Matrix4f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.model.data.ModelData;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import deskped.rped.RpedMod;

@Mod.EventBusSubscriber(modid = RpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class CoreExplosionRenderer extends EntityRenderer<CoreExplosionEntity> {

    private static final ResourceLocation FLASH_TEXTURE = new ResourceLocation(RpedMod.MODID, "textures/entity/core_explosion_flash.png");
    private static final ResourceLocation RING_TEXTURE = new ResourceLocation(RpedMod.MODID, "textures/entity/core_explosion_ring.png");

    private static final float FLASH_DURATION = 14.0f;

    private static final float SPHERE_EXPAND = 46.0f;
    private static final float SPHERE_TOTAL = 96.0f;
    private static final float SPHERE_CENTER_Y = 1.0f;
    private static final float SPHERE_PEAK_ALPHA = 0.36f;
    private static final int SPHERE_LON = 24;
    private static final int SPHERE_LAT = 12;

    private static final int RING_COUNT = 4;
    private static final int RING_STAGGER = 6;
    private static final float RING_DURATION = 44.0f;
    private static final float RING_MAX_RADIUS = 33.0f;

    private static final float BEAM_DURATION = 34.0f;
    private static final float BEAM_HEIGHT = 56.0f;

    private static final int PLUME_COUNT = 5;
    private static final int PLUME_STAGGER = 6;
    private static final float PLUME_DURATION = 40.0f;

    private static final int DEBRIS_COUNT = 46;
    private static final float DEBRIS_DURATION = 52.0f;
    private static final BlockState[] DEBRIS_STATES = new BlockState[] {
            Blocks.BLACKSTONE.defaultBlockState(),
            Blocks.BASALT.defaultBlockState(),
            Blocks.MAGMA_BLOCK.defaultBlockState(),
            Blocks.COBBLED_DEEPSLATE.defaultBlockState(),
            Blocks.GRAVEL.defaultBlockState(),
            Blocks.DEEPSLATE.defaultBlockState()
    };

    private final BlockRenderDispatcher blockRenderer;

    public CoreExplosionRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.blockRenderer = Minecraft.getInstance().getBlockRenderer();
    }

    @Override
    public void render(CoreExplosionEntity entity, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {
        float age = entity.tickCount + partialTick;
        renderSphere(entity, age, partialTick, poseStack, bufferSource);
        renderRings(age, poseStack, bufferSource);
        renderBeam(age, poseStack, bufferSource);
        renderPlume(age, poseStack, bufferSource);
        renderDebris(entity, age, poseStack, bufferSource);
        renderFlash(age, poseStack, bufferSource);
        super.render(entity, yaw, partialTick, poseStack, bufferSource, packedLight);
    }

    private void renderFlash(float age, PoseStack poseStack, MultiBufferSource bufferSource) {
        if (age > FLASH_DURATION) return;
        float t = age / FLASH_DURATION;
        float size = Mth.lerp(Math.min(t * 2.5f, 1.0f), 0.8f, 15.0f);
        float alpha = t < 0.2f ? Mth.lerp(t / 0.2f, 0.0f, 1.0f) : Mth.lerp((t - 0.2f) / 0.8f, 1.0f, 0.0f);
        float g = Mth.lerp(t, 0.98f, 0.55f);
        float b = Mth.lerp(t, 1.0f, 0.95f);
        poseStack.pushPose();
        poseStack.translate(0.0, SPHERE_CENTER_Y, 0.0);
        poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
        poseStack.scale(size, size, size);
        drawBillboardQuad(poseStack, bufferSource, FLASH_TEXTURE, 0.9f, g, b, alpha);
        poseStack.popPose();
    }

    private void renderSphere(CoreExplosionEntity entity, float age, float partialTick, PoseStack poseStack, MultiBufferSource bufferSource) {
        if (age > SPHERE_TOTAL) return;
        float er = 1.0f - (float) Math.pow(1.0f - Math.min(age / SPHERE_EXPAND, 1.0f), 3.0);
        float radius = (float) CoreExplosion.MAX_VISUAL_RADIUS * er;
        if (radius < 0.5f) return;
        float baseAlpha;
        if (age < 3.0f) baseAlpha = SPHERE_PEAK_ALPHA * (age / 3.0f);
        else if (age < SPHERE_EXPAND) baseAlpha = SPHERE_PEAK_ALPHA;
        else baseAlpha = SPHERE_PEAK_ALPHA * Mth.clamp(1.0f - (age - SPHERE_EXPAND) / (SPHERE_TOTAL - SPHERE_EXPAND), 0.0f, 1.0f);
        if (baseAlpha <= 0.002f) return;

        Camera cam = Minecraft.getInstance().gameRenderer.getMainCamera();
        Vec3 camPos = cam.getPosition();
        double ex = Mth.lerp(partialTick, entity.xo, entity.getX());
        double ey = Mth.lerp(partialTick, entity.yo, entity.getY());
        double ez = Mth.lerp(partialTick, entity.zo, entity.getZ());
        double clx = camPos.x - ex;
        double cly = camPos.y - ey - SPHERE_CENTER_Y;
        double clz = camPos.z - ez;

        VertexConsumer consumer = bufferSource.getBuffer(RenderType.entityTranslucentEmissive(FLASH_TEXTURE));
        Matrix4f mat = poseStack.last().pose();
        Matrix3f nrm = poseStack.last().normal();
        for (int j = 0; j < SPHERE_LAT; j++) {
            double la0 = Math.PI * j / SPHERE_LAT;
            double la1 = Math.PI * (j + 1) / SPHERE_LAT;
            for (int i = 0; i < SPHERE_LON; i++) {
                double lo0 = 2.0 * Math.PI * i / SPHERE_LON;
                double lo1 = 2.0 * Math.PI * (i + 1) / SPHERE_LON;
                sphereVertex(consumer, mat, nrm, la0, lo0, radius, clx, cly, clz, baseAlpha);
                sphereVertex(consumer, mat, nrm, la1, lo0, radius, clx, cly, clz, baseAlpha);
                sphereVertex(consumer, mat, nrm, la1, lo1, radius, clx, cly, clz, baseAlpha);
                sphereVertex(consumer, mat, nrm, la0, lo1, radius, clx, cly, clz, baseAlpha);
            }
        }
    }

    private void sphereVertex(VertexConsumer consumer, Matrix4f mat, Matrix3f nrm, double lat, double lon, float radius, double clx, double cly, double clz, float baseAlpha) {
        double nx = Math.sin(lat) * Math.cos(lon);
        double ny = Math.cos(lat);
        double nz = Math.sin(lat) * Math.sin(lon);
        double px = nx * radius;
        double py = ny * radius + SPHERE_CENTER_Y;
        double pz = nz * radius;
        double vx = px - SPHERE_CENTER_Y * 0.0 - clx;
        double vy = (ny * radius) - cly;
        double vz = pz - clz;
        double vl = Math.sqrt(vx * vx + vy * vy + vz * vz);
        if (vl < 1.0e-4) vl = 1.0e-4;
        double dot = (nx * vx + ny * vy + nz * vz) / vl;
        float fres = (float) (1.0 - Math.abs(dot));
        float f2 = fres * fres;
        float r = Mth.lerp(fres, 0.85f, 0.62f) * (0.6f + 0.8f * fres);
        float g = Mth.lerp(fres, 0.95f, 0.28f) * (0.6f + 0.8f * fres);
        float b = Mth.lerp(fres, 1.0f, 1.0f) * (0.6f + 0.8f * fres);
        float alpha = baseAlpha * (0.12f + 0.88f * f2);
        vertex(consumer, mat, nrm, (float) px, (float) py, (float) pz, 0.5f, 0.5f, Math.min(r, 1.0f), Math.min(g, 1.0f), Math.min(b, 1.0f), alpha);
    }

    private void renderRings(float age, PoseStack poseStack, MultiBufferSource bufferSource) {
        for (int i = 0; i < RING_COUNT; i++) {
            float localAge = age - i * RING_STAGGER;
            if (localAge < 0.0f || localAge > RING_DURATION) continue;
            float t = localAge / RING_DURATION;
            float eased = 1.0f - (1.0f - t) * (1.0f - t);
            float radius = RING_MAX_RADIUS * eased;
            float fadeIn = Math.min(localAge / 4.0f, 1.0f);
            float fadeOut = 1.0f - t;
            float alpha = Mth.clamp(fadeIn * fadeOut, 0.0f, 1.0f) * 0.9f;
            if (alpha <= 0.001f) continue;
            float g = Mth.lerp(t, 0.85f, 0.3f);
            float b = Mth.lerp(t, 1.0f, 0.85f);
            poseStack.pushPose();
            poseStack.translate(0.0, 0.1, 0.0);
            poseStack.scale(radius, 1.0f, radius);
            drawFlatQuad(poseStack, bufferSource, RING_TEXTURE, 0.75f, g, b, alpha);
            poseStack.popPose();
        }
    }

    private void renderBeam(float age, PoseStack poseStack, MultiBufferSource bufferSource) {
        if (age > BEAM_DURATION) return;
        float t = age / BEAM_DURATION;
        float grow = 1.0f - (float) Math.pow(1.0f - Math.min(t * 1.6f, 1.0f), 3.0);
        float height = BEAM_HEIGHT * grow;
        float halfW = Mth.lerp(t, 3.2f, 0.4f);
        float aIn = Math.min(age / 2.0f, 1.0f);
        float aOut = 1.0f - t;
        float alpha = Mth.clamp(aIn * aOut, 0.0f, 1.0f) * 0.8f;
        if (alpha <= 0.002f) return;
        float g = Mth.lerp(t, 0.95f, 0.6f);
        float b = 1.0f;
        VertexConsumer consumer = bufferSource.getBuffer(RenderType.entityTranslucentEmissive(FLASH_TEXTURE));
        Matrix4f mat = poseStack.last().pose();
        Matrix3f nrm = poseStack.last().normal();
        drawVerticalStrip(consumer, mat, nrm, halfW, height, 0.85f, g, b, alpha, true);
        drawVerticalStrip(consumer, mat, nrm, halfW, height, 0.85f, g, b, alpha, false);
    }

    private void renderPlume(float age, PoseStack poseStack, MultiBufferSource bufferSource) {
        for (int i = 0; i < PLUME_COUNT; i++) {
            float localAge = age - i * PLUME_STAGGER;
            if (localAge < 0.0f || localAge > PLUME_DURATION) continue;
            float t = localAge / PLUME_DURATION;
            float height = Mth.lerp(t, 0.8f, 12.0f);
            float size = Mth.lerp(t, 2.6f, 7.5f);
            float alpha = t < 0.15f ? Mth.lerp(t / 0.15f, 0.0f, 0.5f) : Mth.lerp((t - 0.15f) / 0.85f, 0.5f, 0.0f);
            float r = Mth.lerp(t, 0.8f, 0.3f);
            float g = Mth.lerp(t, 0.55f, 0.28f);
            float b = Mth.lerp(t, 0.9f, 0.4f);
            poseStack.pushPose();
            poseStack.translate(0.0, height, 0.0);
            poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
            poseStack.scale(size, size, size);
            drawBillboardQuad(poseStack, bufferSource, FLASH_TEXTURE, r, g, b, alpha);
            poseStack.popPose();
        }
    }

    private void renderDebris(CoreExplosionEntity entity, float age, PoseStack poseStack, MultiBufferSource bufferSource) {
        if (age > DEBRIS_DURATION) return;
        int seed = entity.getId();
        float lifeT = age / DEBRIS_DURATION;
        float alpha = lifeT < 0.7f ? 1.0f : Mth.clamp(1.0f - (lifeT - 0.7f) / 0.3f, 0.0f, 1.0f);
        if (alpha <= 0.02f) return;
        for (int i = 0; i < DEBRIS_COUNT; i++) {
            float startDelay = hash(seed, i * 8 + 1) * 8.0f;
            float localAge = age - startDelay;
            if (localAge < 0.0f) continue;
            float baseAngle = i * (360.0f / DEBRIS_COUNT);
            float angle = baseAngle + (hash(seed, i * 8 + 2) - 0.5f) * 30.0f;
            float speedOut = 0.45f + hash(seed, i * 8 + 3) * 0.55f;
            float speedUp = 0.6f + hash(seed, i * 8 + 4) * 0.7f;
            float size = 0.22f + hash(seed, i * 8 + 5) * 0.4f;
            float spinSpeed = 6.0f + hash(seed, i * 8 + 6) * 16.0f;
            float spinAxisYaw = hash(seed, i * 8 + 7) * 360.0f;
            int stateIndex = (int) (hash(seed, i * 8 + 8) * DEBRIS_STATES.length) % DEBRIS_STATES.length;
            BlockState state = DEBRIS_STATES[stateIndex];
            double rad = Math.toRadians(angle);
            double dx = Math.cos(rad) * speedOut * localAge;
            double dz = Math.sin(rad) * speedOut * localAge;
            double dy = speedUp * localAge - 0.045 * localAge * localAge;
            poseStack.pushPose();
            poseStack.translate(dx, Math.max(dy, -8.0) + SPHERE_CENTER_Y, dz);
            poseStack.mulPose(Axis.YP.rotationDegrees(spinAxisYaw));
            poseStack.mulPose(Axis.XP.rotationDegrees(localAge * spinSpeed));
            poseStack.scale(size, size, size);
            poseStack.translate(-0.5, -0.5, -0.5);
            blockRenderer.renderSingleBlock(state, poseStack, bufferSource, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, ModelData.EMPTY, null);
            poseStack.popPose();
        }
    }

    private static float hash(int seed, int salt) {
        int h = seed * 374761393 + salt * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        h = h ^ (h >>> 16);
        return (h & 0xFFFFFF) / (float) 0x1000000;
    }

    private void drawBillboardQuad(PoseStack poseStack, MultiBufferSource bufferSource, ResourceLocation texture, float r, float g, float b, float alpha) {
        VertexConsumer consumer = bufferSource.getBuffer(RenderType.entityTranslucentEmissive(texture));
        Matrix4f mat = poseStack.last().pose();
        Matrix3f nrm = poseStack.last().normal();
        vertex(consumer, mat, nrm, -1.0f, -1.0f, 0.0f, 0.0f, 1.0f, r, g, b, alpha);
        vertex(consumer, mat, nrm, -1.0f, 1.0f, 0.0f, 0.0f, 0.0f, r, g, b, alpha);
        vertex(consumer, mat, nrm, 1.0f, 1.0f, 0.0f, 1.0f, 0.0f, r, g, b, alpha);
        vertex(consumer, mat, nrm, 1.0f, -1.0f, 0.0f, 1.0f, 1.0f, r, g, b, alpha);
    }

    private void drawFlatQuad(PoseStack poseStack, MultiBufferSource bufferSource, ResourceLocation texture, float r, float g, float b, float alpha) {
        VertexConsumer consumer = bufferSource.getBuffer(RenderType.entityTranslucentEmissive(texture));
        Matrix4f mat = poseStack.last().pose();
        Matrix3f nrm = poseStack.last().normal();
        vertex(consumer, mat, nrm, -1.0f, 0.0f, -1.0f, 0.0f, 1.0f, r, g, b, alpha);
        vertex(consumer, mat, nrm, -1.0f, 0.0f, 1.0f, 0.0f, 0.0f, r, g, b, alpha);
        vertex(consumer, mat, nrm, 1.0f, 0.0f, 1.0f, 1.0f, 0.0f, r, g, b, alpha);
        vertex(consumer, mat, nrm, 1.0f, 0.0f, -1.0f, 1.0f, 1.0f, r, g, b, alpha);
    }

    private void drawVerticalStrip(VertexConsumer consumer, Matrix4f mat, Matrix3f nrm, float halfW, float height, float r, float g, float b, float alpha, boolean alongX) {
        if (alongX) {
            vertex(consumer, mat, nrm, -halfW, 0.0f, 0.0f, 0.0f, 1.0f, r, g, b, alpha);
            vertex(consumer, mat, nrm, -halfW, height, 0.0f, 0.0f, 0.0f, r, g, b, alpha);
            vertex(consumer, mat, nrm, halfW, height, 0.0f, 1.0f, 0.0f, r, g, b, alpha);
            vertex(consumer, mat, nrm, halfW, 0.0f, 0.0f, 1.0f, 1.0f, r, g, b, alpha);
        } else {
            vertex(consumer, mat, nrm, 0.0f, 0.0f, -halfW, 0.0f, 1.0f, r, g, b, alpha);
            vertex(consumer, mat, nrm, 0.0f, height, -halfW, 0.0f, 0.0f, r, g, b, alpha);
            vertex(consumer, mat, nrm, 0.0f, height, halfW, 1.0f, 0.0f, r, g, b, alpha);
            vertex(consumer, mat, nrm, 0.0f, 0.0f, halfW, 1.0f, 1.0f, r, g, b, alpha);
        }
    }

    private void vertex(VertexConsumer consumer, Matrix4f mat, Matrix3f nrm, float x, float y, float z, float u, float v, float r, float g, float b, float alpha) {
        consumer.vertex(mat, x, y, z)
                .color(r, g, b, alpha)
                .uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(LightTexture.FULL_BRIGHT)
                .normal(nrm, 0.0f, 1.0f, 0.0f)
                .endVertex();
    }

    @Override
    public ResourceLocation getTextureLocation(CoreExplosionEntity entity) {
        return FLASH_TEXTURE;
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(CoreExplosion.ENTITY.get(), CoreExplosionRenderer::new);
    }
}