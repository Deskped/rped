package deskped.rped.entity;

import net.minecraft.world.entity.AnimationState;

public class AngelFastAnimationState extends AnimationState {
	@Override
	public void updateTime(float ageInTicks, float speed) {
		super.updateTime(ageInTicks, speed * AngelStages.ORB_ANIMATION_SPEED);
	}
}
