package deskped.rped.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.IntConsumer;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import deskped.rped.network.AngelFxPacket;
import deskped.rped.network.AngelNetwork;

public class AngelAbilities {
	private static final int FAN = 0;
	private static final int RING = 1;
	private static final int LANCES = 2;
	private static final int BLINK = 3;
	private static final int WELL = 4;
	private static final int CHORUS = 5;

	private final TumaniteAngelEntity angel;
	private final List<Cast> casts = new ArrayList<>();
	private final List<Cast> incoming = new ArrayList<>();
	private final int[] cooldowns = {60, 120, 140, 160, 200, 240};
	private int lock;
	private final Map<UUID, Integer> grabAge = new HashMap<>();
	private final Map<UUID, Integer> grabCooldown = new HashMap<>();
	private Vec3 lastTargetPos;
	private Vec3 targetVelocity = Vec3.ZERO;

	public AngelAbilities(TumaniteAngelEntity angel) {
		this.angel = angel;
	}

	public void tick() {
		if (!(this.angel.level() instanceof ServerLevel level))
			return;
		int stage = this.angel.getStage();
		if (!this.incoming.isEmpty()) {
			this.casts.addAll(this.incoming);
			this.incoming.clear();
		}
		Iterator<Cast> iterator = this.casts.iterator();
		while (iterator.hasNext()) {
			if (!iterator.next().tick())
				iterator.remove();
		}
		for (int i = 0; i < this.cooldowns.length; i++) {
			if (this.cooldowns[i] > 0)
				this.cooldowns[i]--;
		}
		LivingEntity target = this.angel.getTarget();
		if (target != null && target.isAlive()) {
			Vec3 now = target.position();
			this.targetVelocity = this.lastTargetPos == null ? Vec3.ZERO : now.subtract(this.lastTargetPos);
			this.lastTargetPos = now;
		} else {
			this.lastTargetPos = null;
			this.targetVelocity = Vec3.ZERO;
		}
		if (!this.angel.isTransitioning())
			this.tickGrab(level, stage);
		if (this.lock > 0) {
			this.lock--;
			return;
		}
		if (target == null || !target.isAlive() || this.angel.isTransitioning())
			return;
		List<Integer> ready = new ArrayList<>();
		for (int i = 0; i < stage && i < this.cooldowns.length; i++) {
			if (this.cooldowns[i] <= 0)
				ready.add(i);
		}
		if (ready.isEmpty())
			return;
		int ability = ready.get(this.angel.getRandom().nextInt(ready.size()));
		this.cooldowns[ability] = this.cooldownFor(ability, stage) + this.angel.getRandom().nextInt(20);
		switch (ability) {
			case FAN -> this.castFan(level, target, stage);
			case RING -> this.castRing(level, target, stage);
			case LANCES -> this.castLances(level, target, stage);
			case BLINK -> this.castBlink(level, target, stage);
			case WELL -> this.castWell(level, target, stage);
			default -> this.castChorus(level, target, stage);
		}
	}

	public void onStageChange(int stage) {
		if (!(this.angel.level() instanceof ServerLevel level))
			return;
		this.casts.clear();
		this.incoming.clear();
		this.lock = 80;
		for (int i = 0; i < this.cooldowns.length; i++)
			this.cooldowns[i] = 140;
		this.cooldowns[Math.min(stage, this.cooldowns.length) - 1] = 0;
		this.angel.setDeltaMovement(Vec3.ZERO);
		Vec3 c = this.angel.position().add(0.0D, this.angel.getBbHeight() * 0.5D, 0.0D);
		level.playSound(null, c.x, c.y, c.z, SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 3.0F, 0.6F + 0.08F * stage);
		level.playSound(null, c.x, c.y, c.z, SoundEvents.ENDER_DRAGON_GROWL, SoundSource.HOSTILE, 3.0F, 0.6F + 0.1F * stage);
		level.playSound(null, c.x, c.y, c.z, SoundEvents.BEACON_POWER_SELECT, SoundSource.HOSTILE, 3.0F, 0.5F + 0.15F * stage);
		if (stage >= 3)
			level.playSound(null, c.x, c.y, c.z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.HOSTILE, 2.0F, 1.1F);
		this.fx(level, AngelFxPacket.transition(c.x, c.y, c.z, 14.0F, 50, stage));
		for (Player p : level.getEntitiesOfClass(Player.class, new AABB(c, c).inflate(14.0D), e -> e.isAlive() && !e.isSpectator()))
			this.push(p, c, 1.5D, 0.5D);
	}

	private int cooldownFor(int ability, int stage) {
		int base = switch (ability) {
			case FAN -> Math.max(50, 130 - 12 * stage);
			case RING -> Math.max(110, 240 - 20 * stage);
			case LANCES -> Math.max(100, 220 - 18 * stage);
			case BLINK -> Math.max(110, 190 - 12 * stage);
			case WELL -> Math.max(160, 300 - 20 * stage);
			default -> 360;
		};
		return Math.max(25, (int) (base / this.power(stage)));
	}

	private float power(int stage) {
		return AngelStages.aggression(stage) * (this.angel.isShielded() ? AngelStages.SHIELD_AGGRESSION : 1.0F);
	}

	public boolean inGrabZone(Player p) {
		if (!p.isAlive() || p.isSpectator())
			return false;
		double dx = p.getX() - this.angel.getX();
		double dz = p.getZ() - this.angel.getZ();
		double dy = this.angel.getY() - p.getY();
		double radius = AngelStages.GRAB_RADIUS;
		return dy >= AngelStages.GRAB_DEPTH && dy <= 48.0D && dx * dx + dz * dz <= radius * radius;
	}

	private void setLock(int base, int stage) {
		float shield = this.angel.isShielded() ? AngelStages.SHIELD_AGGRESSION : 1.0F;
		this.lock = (int) (base / ((1.0F + 0.15F * (AngelStages.clamp(stage) - 1)) * shield));
	}

	private void castFan(ServerLevel level, LivingEntity target, int stage) {
		int count = 2 + stage + stage / 2;
		this.setLock(count * 3 + 22, stage);
		this.fx(level, AngelFxPacket.charge(this.angel.getId(), 8, 1.8F, stage));
		this.volley(level, target, count, 8);
	}

	private void volley(ServerLevel level, LivingEntity target, int count, int delay) {
		level.playSound(null, this.angel.getX(), this.angel.getY(), this.angel.getZ(), SoundEvents.EVOKER_CAST_SPELL, SoundSource.HOSTILE, 1.5F, 1.3F);
		this.schedule(delay + count * 3 + 1, age -> {
			if (age < delay)
				return;
			if ((age - delay) % 3 == 0 && target.isAlive()) {
				EnchartedShardEntity.shoot(this.angel, target);
				level.playSound(null, this.angel.getX(), this.angel.getY(), this.angel.getZ(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.HOSTILE, 1.5F, (float) (1.4D + this.rnd() * 0.6D));
			}
		});
	}

	private void castRing(ServerLevel level, LivingEntity target, int stage) {
		int charge = 26;
		double maxRadius = 10.0D + stage;
		int expand = (int) Math.ceil(maxRadius / 1.1D);
		float damage = 3.0F + 1.2F * stage;
		this.setLock(charge + expand + 10, stage);
		Set<UUID> hit = new HashSet<>();
		double[] origin = new double[3];
		level.playSound(null, this.angel.getX(), this.angel.getY(), this.angel.getZ(), SoundEvents.BEACON_POWER_SELECT, SoundSource.HOSTILE, 2.0F, 0.7F);
		this.fx(level, AngelFxPacket.charge(this.angel.getId(), charge, 3.4F, stage));
		this.schedule(charge + expand + 2, age -> {
			if (age < charge)
				return;
			if (age == charge) {
				origin[0] = this.angel.getX();
				origin[1] = this.groundY(level, target.getX(), target.getY(), target.getZ());
				origin[2] = this.angel.getZ();
				level.playSound(null, origin[0], this.angel.getY(), origin[2], SoundEvents.WARDEN_SONIC_BOOM, SoundSource.HOSTILE, 2.5F, 1.1F);
				this.fx(level, AngelFxPacket.ring(origin[0], origin[1], origin[2], (float) maxRadius, expand + 2, stage));
				this.fx(level, AngelFxPacket.flash(origin[0], this.angel.getY() + this.angel.getBbHeight() * 0.5D, origin[2], 5.0F, 10, stage));
			}
			double r = (age - charge + 1) * 1.1D;
			AABB box = new AABB(origin[0] - r - 1.5D, origin[1] - 3.0D, origin[2] - r - 1.5D, origin[0] + r + 1.5D, origin[1] + 2.0D, origin[2] + r + 1.5D);
			Vec3 center = new Vec3(origin[0], origin[1], origin[2]);
			for (Player p : level.getEntitiesOfClass(Player.class, box, e -> e.isAlive() && !e.isSpectator())) {
				double dx = p.getX() - origin[0];
				double dz = p.getZ() - origin[2];
				double dist = Math.sqrt(dx * dx + dz * dz);
				if (Math.abs(dist - r) <= 1.3D && p.getY() < origin[1] + 0.9D && hit.add(p.getUUID())) {
					this.hurt(p, damage);
					this.push(p, center, 0.9D, 0.35D);
					if (stage >= 4)
						p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1));
				}
			}
		});
	}

	private void castLances(ServerLevel level, LivingEntity target, int stage) {
		int count = 2 + stage / 2;
		int delay = 30 - 2 * stage;
		float damage = 5.0F + stage;
		this.setLock(delay + count * 3 + 14, stage);
		level.playSound(null, this.angel.getX(), this.angel.getY(), this.angel.getZ(), SoundEvents.EVOKER_PREPARE_ATTACK, SoundSource.HOSTILE, 2.0F, 1.2F);
		Vec3 lead = this.predict(target, delay);
		for (int i = 0; i < count; i++) {
			double ox = 0.0D;
			double oz = 0.0D;
			if (i > 0) {
				double a = this.rnd() * Math.PI * 2.0D;
				double d = 2.0D + this.rnd() * 4.0D;
				ox = Math.cos(a) * d;
				oz = Math.sin(a) * d;
			}
			double x = lead.x + ox;
			double z = lead.z + oz;
			this.strike(level, x, this.groundY(level, x, target.getY(), z), z, delay + i * 3, damage, stage);
		}
	}

	private void strike(ServerLevel level, double x, double y, double z, int delay, float damage, int stage) {
		this.fx(level, AngelFxPacket.strike(x, y, z, delay, stage));
		this.schedule(delay + 1, age -> {
			if (age < delay)
				return;
			level.playSound(null, x, y, z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.HOSTILE, 0.8F, 1.6F);
			level.playSound(null, x, y, z, SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.HOSTILE, 2.0F, 0.8F);
			AABB box = new AABB(x - 1.8D, y - 1.5D, z - 1.8D, x + 1.8D, y + 16.0D, z + 1.8D);
			for (Player p : level.getEntitiesOfClass(Player.class, box, e -> e.isAlive() && !e.isSpectator())) {
				double dx = p.getX() - x;
				double dz = p.getZ() - z;
				if (dx * dx + dz * dz <= 3.24D) {
					this.hurt(p, damage);
					p.setDeltaMovement(p.getDeltaMovement().add(0.0D, 0.5D, 0.0D));
					p.hurtMarked = true;
				}
			}
		});
	}

	private void castBlink(ServerLevel level, LivingEntity target, int stage) {
		int count = 2 + stage + stage / 2;
		this.setLock(18 + 6 + count * 3 + 14, stage);
		double[] dest = new double[4];
		this.schedule(18, age -> {
			if (age == 0) {
				dest[3] = this.findBlinkSpot(level, target, dest) ? 1.0D : 0.0D;
				if (dest[3] > 0.0D) {
					level.playSound(null, dest[0], dest[1], dest[2], SoundEvents.PORTAL_TRIGGER, SoundSource.HOSTILE, 0.6F, 1.8F);
					this.fx(level, AngelFxPacket.blinkMark(dest[0], dest[1] + this.angel.getBbHeight() * 0.5D, dest[2], 16, stage));
				}
			}
			if (dest[3] <= 0.0D || age < 16)
				return;
			double ox = this.angel.getX();
			double oy = this.angel.getY() + this.angel.getBbHeight() * 0.5D;
			double oz = this.angel.getZ();
			double ny = dest[1] + this.angel.getBbHeight() * 0.5D;
			this.fx(level, AngelFxPacket.blinkTrail(ox, oy, oz, dest[0], ny, dest[2], 14, stage));
			this.fx(level, AngelFxPacket.flash(ox, oy, oz, 4.0F, 12, stage));
			level.playSound(null, ox, oy, oz, SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 2.0F, 0.6F);
			this.angel.moveTo(dest[0], dest[1], dest[2], this.angel.getYRot(), this.angel.getXRot());
			this.angel.setDeltaMovement(Vec3.ZERO);
			this.angel.getNavigation().stop();
			level.playSound(null, dest[0], dest[1], dest[2], SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 2.0F, 1.5F);
			this.fx(level, AngelFxPacket.flash(dest[0], ny, dest[2], 5.0F, 12, stage));
			this.volley(level, target, count, 6);
		});
	}

	private boolean findBlinkSpot(ServerLevel level, LivingEntity target, double[] out) {
		double yaw = Math.toRadians(target.getYRot());
		double behind = Math.atan2(-Math.cos(yaw), Math.sin(yaw));
		for (int i = 0; i < 14; i++) {
			double a = behind + (this.rnd() - 0.5D) * 2.0D;
			double r = this.angel.isShielded() ? AngelStages.SHIELD_RADIUS + 3.0D + this.rnd() * 2.0D : 6.0D + this.rnd() * 3.0D;
			double x = target.getX() + Math.cos(a) * r;
			double y = target.getY() + 2.0D + this.rnd() * 3.0D;
			double z = target.getZ() + Math.sin(a) * r;
			AABB box = this.angel.getBoundingBox().move(x - this.angel.getX(), y - this.angel.getY(), z - this.angel.getZ());
			if (level.noCollision(this.angel, box)) {
				out[0] = x;
				out[1] = y;
				out[2] = z;
				return true;
			}
		}
		return false;
	}

	private void castWell(ServerLevel level, LivingEntity target, int stage) {
		int pull = 56;
		double radius = 20.0D;
		float damage = 6.0F + stage;
		this.setLock(pull + 24, stage);
		level.playSound(null, this.angel.getX(), this.angel.getY(), this.angel.getZ(), SoundEvents.BEACON_AMBIENT, SoundSource.HOSTILE, 3.0F, 0.5F);
		level.playSound(null, this.angel.getX(), this.angel.getY(), this.angel.getZ(), SoundEvents.CONDUIT_ACTIVATE, SoundSource.HOSTILE, 3.0F, 0.6F);
		this.fx(level, AngelFxPacket.well(this.angel.getId(), pull + 4, stage));
		this.schedule(pull + 4, age -> {
			Vec3 c = this.angel.position().add(0.0D, this.angel.getBbHeight() * 0.5D, 0.0D);
			if (age < pull) {
				for (Player p : level.getEntitiesOfClass(Player.class, new AABB(c, c).inflate(radius), e -> e.isAlive() && !e.isSpectator() && !e.getAbilities().flying)) {
					Vec3 d = c.subtract(p.position().add(0.0D, p.getBbHeight() * 0.5D, 0.0D));
					double len = d.length();
					Vec3 v = p.getDeltaMovement();
					if (len < 3.0D || v.x * v.x + v.z * v.z > 0.6D)
						continue;
					p.setDeltaMovement(v.add(d.scale((0.05D + 0.004D * stage) / len)));
					p.hurtMarked = true;
				}
				return;
			}
			if (age == pull) {
				level.playSound(null, c.x, c.y, c.z, SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 3.0F, 0.7F);
				this.fx(level, AngelFxPacket.burst(c.x, c.y, c.z, 8.0F, 24, stage));
				for (Player p : level.getEntitiesOfClass(Player.class, new AABB(c, c).inflate(7.0D), e -> e.isAlive() && !e.isSpectator())) {
					if (p.position().add(0.0D, p.getBbHeight() * 0.5D, 0.0D).distanceToSqr(c) <= 49.0D) {
						this.hurt(p, damage);
						this.push(p, c, 1.3D, 0.6D);
					}
				}
			}
		});
	}

	private void castChorus(ServerLevel level, LivingEntity target, int stage) {
		int total = 150;
		float damage = 5.0F + stage;
		this.setLock(total + 10, stage);
		level.playSound(null, this.angel.getX(), this.angel.getY(), this.angel.getZ(), SoundEvents.ENDER_DRAGON_GROWL, SoundSource.HOSTILE, 3.0F, 0.8F);
		this.fx(level, AngelFxPacket.charge(this.angel.getId(), 20, 5.0F, stage));
		this.schedule(total, age -> {
			if (!target.isAlive() || age < 12 || age > total - 25)
				return;
			if (age % 20 == 12) {
				Vec3 lead = this.predict(target, 22);
				this.strike(level, lead.x, this.groundY(level, lead.x, target.getY(), lead.z), lead.z, 22, damage, stage);
			}
			if (age % 6 == 0) {
				double a = this.rnd() * Math.PI * 2.0D;
				double d = 2.0D + this.rnd() * 11.0D;
				double x = target.getX() + Math.cos(a) * d;
				double z = target.getZ() + Math.sin(a) * d;
				this.strike(level, x, this.groundY(level, x, target.getY(), z), z, 20, damage, stage);
			}
		});
	}

	public void punish(ServerLevel level, Player player) {
		int stage = this.angel.getStage();
		Vec3 c = this.angel.position().add(0.0D, this.angel.getBbHeight() * 0.5D, 0.0D);
		double dx = player.getX() - c.x;
		double dz = player.getZ() - c.z;
		double len = Math.sqrt(dx * dx + dz * dz);
		if (len < 1.0E-4D) {
			double a = this.rnd() * Math.PI * 2.0D;
			dx = Math.cos(a);
			dz = Math.sin(a);
			len = 1.0D;
		}
		player.setDeltaMovement(dx / len * 2.6D, 0.9D, dz / len * 2.6D);
		player.hurtMarked = true;
		level.playSound(null, c.x, c.y, c.z, SoundEvents.LAVA_EXTINGUISH, SoundSource.HOSTILE, 3.0F, 0.6F);
		level.playSound(null, c.x, c.y, c.z, SoundEvents.WARDEN_SONIC_BOOM, SoundSource.HOSTILE, 2.0F, 1.3F);
		this.fx(level, AngelFxPacket.burst(c.x, c.y, c.z, 18.0F, 30, stage));
	}

	private void tickGrab(ServerLevel level, int stage) {
		for (Iterator<Map.Entry<UUID, Integer>> it = this.grabCooldown.entrySet().iterator(); it.hasNext();) {
			Map.Entry<UUID, Integer> entry = it.next();
			if (entry.getValue() <= 1)
				it.remove();
			else
				entry.setValue(entry.getValue() - 1);
		}
		double radius = AngelStages.GRAB_RADIUS;
		double limit = this.angel.getY() - AngelStages.GRAB_DEPTH;
		Vec3 c = this.angel.position().add(0.0D, this.angel.getBbHeight() * 0.5D, 0.0D);
		AABB box = new AABB(this.angel.getX() - radius, this.angel.getY() - 48.0D, this.angel.getZ() - radius, this.angel.getX() + radius, limit + 0.01D, this.angel.getZ() + radius);
		Set<UUID> active = new HashSet<>();
		for (Player p : level.getEntitiesOfClass(Player.class, box, e -> e.isAlive() && !e.isSpectator() && e.getY() <= limit)) {
			double dx = p.getX() - this.angel.getX();
			double dz = p.getZ() - this.angel.getZ();
			if (dx * dx + dz * dz > radius * radius || this.grabCooldown.containsKey(p.getUUID()))
				continue;
			active.add(p.getUUID());
			int age = this.grabAge.getOrDefault(p.getUUID(), 0);
			Vec3 body = p.position().add(0.0D, p.getBbHeight() * 0.5D, 0.0D);
			if (age == 0) {
				level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.EVOKER_FANGS_ATTACK, SoundSource.HOSTILE, 2.0F, 0.7F);
				this.fx(level, AngelFxPacket.blinkTrail(c.x, c.y, c.z, body.x, body.y, body.z, 8, stage));
				this.fx(level, AngelFxPacket.flash(body.x, body.y, body.z, 3.0F, 10, stage));
			}
			if (age < 6) {
				Vec3 pull = c.subtract(body);
				if (pull.lengthSqr() > 1.0E-4D)
					p.setDeltaMovement(pull.normalize().scale(0.55D));
				p.hurtMarked = true;
				this.grabAge.put(p.getUUID(), age + 1);
				continue;
			}
			double hx = dx;
			double hz = dz;
			double hl = Math.sqrt(hx * hx + hz * hz);
			if (hl < 0.2D) {
				double a = this.rnd() * Math.PI * 2.0D;
				hx = Math.cos(a);
				hz = Math.sin(a);
				hl = 1.0D;
			}
			boolean shielded = this.angel.isShielded();
			p.setDeltaMovement(hx / hl * (shielded ? 3.6D : 2.6D), shielded ? 1.8D : 1.35D, hz / hl * (shielded ? 3.6D : 2.6D));
			p.hurtMarked = true;
			this.grabAge.remove(p.getUUID());
			this.grabCooldown.put(p.getUUID(), 50);
			level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.WARDEN_ATTACK_IMPACT, SoundSource.HOSTILE, 2.0F, 0.8F);
			this.fx(level, AngelFxPacket.flash(body.x, body.y, body.z, 4.5F, 12, stage));
			this.fx(level, AngelFxPacket.blinkTrail(body.x, body.y, body.z, body.x + hx / hl * 6.0D, body.y + 5.0D, body.z + hz / hl * 6.0D, 10, stage));
		}
		this.grabAge.keySet().retainAll(active);
	}

	private void fx(ServerLevel level, AngelFxPacket packet) {
		AngelNetwork.send(level, this.angel.getX(), this.angel.getY(), this.angel.getZ(), packet);
	}

	private Vec3 predict(LivingEntity target, int ticks) {
		Vec3 v = new Vec3(this.targetVelocity.x, 0.0D, this.targetVelocity.z).scale(ticks * 0.8D);
		double len = v.length();
		if (len > 12.0D)
			v = v.scale(12.0D / len);
		return target.position().add(v);
	}

	private double groundY(ServerLevel level, double x, double y, double z) {
		BlockPos pos = BlockPos.containing(x, y + 0.5D, z);
		for (int i = 0; i < 24; i++) {
			BlockPos below = pos.below();
			if (!level.getBlockState(below).getCollisionShape(level, below).isEmpty())
				return pos.getY();
			pos = below;
		}
		return y;
	}

	private void hurt(LivingEntity victim, float amount) {
		float scaled = amount * AngelStages.damageScale(this.angel.getStage());
		victim.hurt(this.angel.level().damageSources().indirectMagic(this.angel, this.angel), scaled);
	}

	private void push(LivingEntity victim, Vec3 from, double strength, double up) {
		double dx = victim.getX() - from.x;
		double dz = victim.getZ() - from.z;
		double len = Math.sqrt(dx * dx + dz * dz);
		if (len < 1.0E-4D) {
			dx = 1.0D;
			dz = 0.0D;
			len = 1.0D;
		}
		victim.setDeltaMovement(victim.getDeltaMovement().add(dx / len * strength, up, dz / len * strength));
		victim.hurtMarked = true;
	}

	private double rnd() {
		return this.angel.getRandom().nextDouble();
	}

	private void schedule(int duration, IntConsumer step) {
		this.incoming.add(new Cast(duration, step));
	}

	private static final class Cast {
		private final int duration;
		private final IntConsumer step;
		private int age;

		private Cast(int duration, IntConsumer step) {
			this.duration = duration;
			this.step = step;
		}

		private boolean tick() {
			this.step.accept(this.age);
			this.age++;
			return this.age < this.duration;
		}
	}
}
