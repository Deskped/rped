package deskped.rped.entity;

import java.util.UUID;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.phys.Vec3;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.nbt.CompoundTag;

import deskped.rped.network.AngelFxPacket;
import deskped.rped.network.AngelNetwork;
import deskped.rped.init.RpedModEntities;

public class AngelOrbEntity extends TumaniteAngelEntity {
	public static final EntityDataAccessor<Integer> DATA_OWNER = SynchedEntityData.defineId(AngelOrbEntity.class, EntityDataSerializers.INT);
	private UUID ownerId;
	private float orbitAngle;
	private float orbitRadius = AngelStages.SHIELD_RADIUS + 3.0F;
	private float orbitHeight;
	private int orbitDirection = 1;
	private int missing;

	public AngelOrbEntity(EntityType<AngelOrbEntity> type, Level level) {
		super(type, level);
		this.noPhysics = true;
		this.xpReward = 5;
		this.entityData.set(DATA_SPAWNED, Boolean.TRUE);
		this.setGlowingTag(true);
		this.refreshDimensions();
		this.orbitDirection = this.random.nextBoolean() ? 1 : -1;
	}

	public static AttributeSupplier.Builder createOrbAttributes() {
		AttributeSupplier.Builder builder = Mob.createMobAttributes();
		builder = builder.add(Attributes.MOVEMENT_SPEED, 0.3);
		builder = builder.add(Attributes.MAX_HEALTH, AngelStages.ORB_HEALTH);
		builder = builder.add(Attributes.ARMOR, 0);
		builder = builder.add(Attributes.ATTACK_DAMAGE, 0);
		builder = builder.add(Attributes.FOLLOW_RANGE, 16);
		builder = builder.add(Attributes.FLYING_SPEED, 0.3);
		return builder;
	}

	@Override
	protected void defineSynchedData() {
		super.defineSynchedData();
		this.entityData.define(DATA_OWNER, -1);
	}

	@Override
	public boolean isOrb() {
		return true;
	}

	@Override
	protected net.minecraft.world.entity.AnimationState newAnimationState() {
		return new AngelFastAnimationState();
	}

	@Override
	public EntityDimensions getDimensions(Pose pose) {
		return RpedModEntities.TUMANITE_ANGEL.get().getDimensions().scale(0.5F);
	}

	@Override
	public boolean removeWhenFarAway(double distance) {
		return false;
	}

	@Override
	protected void registerGoals() {
	}

	public int getOwnerEntityId() {
		return this.entityData.get(DATA_OWNER);
	}

	public void setOwner(TumaniteAngelEntity boss, int slot, int count) {
		this.ownerId = boss.getUUID();
		this.entityData.set(DATA_OWNER, boss.getId());
		this.orbitAngle = (float) (Math.PI * 2.0D * slot / Math.max(1, count));
		this.orbitHeight = ((slot % 3) - 1) * 4.0F;
	}

	public void applyOrbit(Entity boss) {
		double cx = boss.getX();
		double cy = boss.getY() + boss.getBbHeight() * 0.5D;
		double cz = boss.getZ();
		double x = cx + Mth.cos(this.orbitAngle) * this.orbitRadius;
		double z = cz + Mth.sin(this.orbitAngle) * this.orbitRadius;
		double y = cy + this.orbitHeight + Math.sin(this.tickCount * 0.06D + this.orbitAngle) * 1.5D - this.getBbHeight() * 0.5D;
		this.setPos(x, y, z);
		this.setDeltaMovement(Vec3.ZERO);
		float yaw = (float) (Mth.atan2(cz - z, cx - x) * 57.29577951308232D) - 90.0F;
		this.setYRot(yaw);
		this.yBodyRot = yaw;
		this.yHeadRot = yaw;
	}

	@Override
	public void customServerAiStep() {
		if (!(this.level() instanceof ServerLevel level))
			return;
		Entity owner = this.ownerId == null ? null : level.getEntity(this.ownerId);
		if (!(owner instanceof TumaniteAngelEntity boss) || !owner.isAlive()) {
			if (owner != null || ++this.missing > 200)
				this.discard();
			return;
		}
		this.missing = 0;
		this.orbitAngle += this.orbitDirection * 0.035F;
		this.applyOrbit(boss);
	}

	@Override
	protected boolean hurtAsOrb(DamageSource source, float amount) {
		if (source.is(DamageTypes.FALL) || source.is(DamageTypes.DROWN) || source.is(DamageTypes.IN_WALL))
			return false;
		boolean result = super.hurtAsOrb(source, amount);
		if (result && this.isAlive() && !this.level().isClientSide() && this.random.nextFloat() < AngelStages.ORB_TELEPORT_CHANCE)
			this.relocate();
		return result;
	}

	private void relocate() {
		if (!(this.level() instanceof ServerLevel level))
			return;
		Entity owner = this.ownerId == null ? null : level.getEntity(this.ownerId);
		if (owner == null)
			return;
		double oldX = this.getX();
		double oldY = this.getY() + this.getBbHeight() * 0.5D;
		double oldZ = this.getZ();
		this.orbitAngle = (float) (this.random.nextDouble() * Math.PI * 2.0D);
		this.orbitRadius = AngelStages.SHIELD_RADIUS + 1.5F + this.random.nextFloat() * 10.0F;
		this.orbitHeight = (this.random.nextFloat() - 0.3F) * 14.0F;
		this.applyOrbit(owner);
		int stage = this.getStage();
		AngelNetwork.send(level, oldX, oldY, oldZ, AngelFxPacket.flash(oldX, oldY, oldZ, 3.5F, 12, stage));
		AngelNetwork.send(level, this.getX(), this.getY() + this.getBbHeight() * 0.5D, this.getZ(), AngelFxPacket.flash(this.getX(), this.getY() + this.getBbHeight() * 0.5D, this.getZ(), 3.5F, 12, stage));
		level.playSound(null, oldX, oldY, oldZ, SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 1.5F, 1.6F);
	}

	@Override
	public void addAdditionalSaveData(CompoundTag tag) {
		super.addAdditionalSaveData(tag);
		if (this.ownerId != null)
			tag.putUUID("OrbOwner", this.ownerId);
		tag.putFloat("OrbAngle", this.orbitAngle);
		tag.putFloat("OrbRadius", this.orbitRadius);
		tag.putFloat("OrbHeight", this.orbitHeight);
	}

	@Override
	public void readAdditionalSaveData(CompoundTag tag) {
		super.readAdditionalSaveData(tag);
		if (tag.hasUUID("OrbOwner"))
			this.ownerId = tag.getUUID("OrbOwner");
		if (tag.contains("OrbAngle")) {
			this.orbitAngle = tag.getFloat("OrbAngle");
			this.orbitRadius = tag.getFloat("OrbRadius");
			this.orbitHeight = tag.getFloat("OrbHeight");
		}
		this.entityData.set(DATA_SPAWNED, Boolean.TRUE);
	}
}
