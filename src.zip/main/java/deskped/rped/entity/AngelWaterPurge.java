package deskped.rped.entity;

import java.util.ArrayDeque;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.material.FluidState;

public class AngelWaterPurge {
	private static final long BUDGET_NANOS = 2_000_000L;

	private final TumaniteAngelEntity angel;
	private final ArrayDeque<int[]> sections = new ArrayDeque<>();
	private double centerX;
	private double centerY;
	private double centerZ;
	private int minY;

	public AngelWaterPurge(TumaniteAngelEntity angel) {
		this.angel = angel;
	}

	public void start(ServerLevel level) {
		this.sections.clear();
		this.centerX = this.angel.getX();
		this.centerY = this.angel.getY() + this.angel.getBbHeight() * 0.5D;
		this.centerZ = this.angel.getZ();
		this.minY = this.angel.getBlockY();
		int radius = AngelStages.PURGE_RADIUS;
		int minChunkX = (int) Math.floor(this.centerX - radius) >> 4;
		int maxChunkX = (int) Math.floor(this.centerX + radius) >> 4;
		int minChunkZ = (int) Math.floor(this.centerZ - radius) >> 4;
		int maxChunkZ = (int) Math.floor(this.centerZ + radius) >> 4;
		for (int chunkX = minChunkX; chunkX <= maxChunkX; chunkX++) {
			for (int chunkZ = minChunkZ; chunkZ <= maxChunkZ; chunkZ++) {
				LevelChunk chunk = level.getChunkSource().getChunkNow(chunkX, chunkZ);
				if (chunk == null)
					continue;
				LevelChunkSection[] array = chunk.getSections();
				for (int i = 0; i < array.length; i++) {
					int baseY = chunk.getMinBuildHeight() + (i << 4);
					if (baseY + 15 < this.minY || baseY > this.centerY + radius)
						continue;
					LevelChunkSection section = array[i];
					if (section.hasOnlyAir() || !section.maybeHas(state -> !state.getFluidState().isEmpty()))
						continue;
					this.sections.add(new int[]{chunkX, chunkZ, i});
				}
			}
		}
	}

	public void tick(ServerLevel level) {
		if (this.sections.isEmpty())
			return;
		double radiusSq = (double) AngelStages.PURGE_RADIUS * AngelStages.PURGE_RADIUS;
		long deadline = System.nanoTime() + BUDGET_NANOS;
		BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
		while (!this.sections.isEmpty() && System.nanoTime() < deadline) {
			int[] task = this.sections.poll();
			LevelChunk chunk = level.getChunkSource().getChunkNow(task[0], task[1]);
			if (chunk == null)
				continue;
			LevelChunkSection section = chunk.getSection(task[2]);
			int baseY = chunk.getMinBuildHeight() + (task[2] << 4);
			for (int y = 0; y < 16; y++) {
				int worldY = baseY + y;
				if (worldY < this.minY)
					continue;
				double dy = worldY + 0.5D - this.centerY;
				for (int z = 0; z < 16; z++) {
					for (int x = 0; x < 16; x++) {
						BlockState state = section.getBlockState(x, y, z);
						FluidState fluid = state.getFluidState();
						if (fluid.isEmpty() || !fluid.is(FluidTags.WATER))
							continue;
						int worldX = (task[0] << 4) + x;
						int worldZ = (task[1] << 4) + z;
						double dx = worldX + 0.5D - this.centerX;
						double dz = worldZ + 0.5D - this.centerZ;
						if (dx * dx + dy * dy + dz * dz > radiusSq)
							continue;
						pos.set(worldX, worldY, worldZ);
						this.evaporate(level, pos, state);
					}
				}
			}
		}
	}

	private void evaporate(ServerLevel level, BlockPos pos, BlockState state) {
		BlockState result;
		if (state.getBlock() instanceof LiquidBlock)
			result = Blocks.AIR.defaultBlockState();
		else if (state.hasProperty(BlockStateProperties.WATERLOGGED))
			result = state.setValue(BlockStateProperties.WATERLOGGED, Boolean.FALSE);
		else
			result = Blocks.AIR.defaultBlockState();
		level.setBlock(pos, result, Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
	}
}
