package deskped.rped.entity;

import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.WeakHashMap;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.Entity;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class AngelProjectileFix {
	private static final Set<Entity> SHARDS = Collections.newSetFromMap(new WeakHashMap<>());

	@SubscribeEvent
	public static void onJoin(EntityJoinLevelEvent event) {
		if (!event.getLevel().isClientSide() && event.getEntity() instanceof EnchartedShardEntity)
			SHARDS.add(event.getEntity());
	}

	@SubscribeEvent
	public static void onLevelTick(TickEvent.LevelTickEvent event) {
		if (event.phase != TickEvent.Phase.END || event.level.isClientSide() || SHARDS.isEmpty())
			return;
		Iterator<Entity> iterator = SHARDS.iterator();
		while (iterator.hasNext()) {
			Entity shard = iterator.next();
			if (shard.isRemoved()) {
				iterator.remove();
				continue;
			}
			if (shard.level() != event.level || !shard.isInWater())
				continue;
			double factor = shard instanceof AbstractArrow ? 0.99D / 0.6D : 0.99D / 0.8D;
			shard.setDeltaMovement(shard.getDeltaMovement().scale(factor));
			shard.hurtMarked = true;
		}
	}
}
