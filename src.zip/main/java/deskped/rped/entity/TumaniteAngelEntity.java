package deskped.rped.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.network.PlayMessages;
import net.minecraftforge.network.NetworkHooks;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.entity.projectile.ThrownPotion;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.*;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.util.Mth;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

import deskped.rped.procedures.TumaniteAngelSavePositionProcedure;
import deskped.rped.procedures.DieAngelUslovieProcedure;
import deskped.rped.procedures.AngelTickProcedure;
import deskped.rped.procedures.AngelHurtElseProcedure;
import deskped.rped.network.AngelFxPacket;
import deskped.rped.network.AngelNetwork;
import deskped.rped.init.RpedModEntities;
import deskped.rped.init.RpedModBlocks;

public class TumaniteAngelEntity extends PathfinderMob implements RangedAttackMob {
	public static final EntityDataAccessor<Integer> DATA_STAGE = SynchedEntityData.defineId(TumaniteAngelEntity.class, EntityDataSerializers.INT);
	public static final EntityDataAccessor<Integer> DATA_ORBS = SynchedEntityData.defineId(TumaniteAngelEntity.class, EntityDataSerializers.INT);
	public static final EntityDataAccessor<Boolean> DATA_SPAWNED = SynchedEntityData.defineId(TumaniteAngelEntity.class, EntityDataSerializers.BOOLEAN);
	public final AnimationState animationState0 = this.newAnimationState();
	public final AnimationState animationState1 = this.newAnimationState();
	public float shieldFade;
	public float shieldFadeO;
	private final AngelAbilities abilities = new AngelAbilities(this);
	private final AngelWaterPurge purge = new AngelWaterPurge(this);
	private final Map<UUID, Integer> hitCounts = new HashMap<>();
	private final List<UUID> orbIds = new ArrayList<>();
	private int appliedStage = 0;
	private int transitionTicks = 0;
	private int spawnTicks = 0;
	private boolean pendingShield = false;

	public TumaniteAngelEntity(PlayMessages.SpawnEntity packet, Level world) {
		this(RpedModEntities.TUMANITE_ANGEL.get(), world);
	}

	public TumaniteAngelEntity(EntityType<? extends TumaniteAngelEntity> type, Level world) {
		super(type, world);
		setMaxUpStep(0.1f);
		xpReward = 20;
		setNoAi(false);
		this.moveControl = new FlyingMoveControl(this, 10, true);
	}

	protected AnimationState newAnimationState() {
		return new AnimationState();
	}

	public boolean isOrb() {
		return false;
	}

	protected boolean hurtAsOrb(DamageSource damagesource, float amount) {
		return super.hurt(damagesource, amount);
	}

	@Override
	protected void defineSynchedData() {
		super.defineSynchedData();
		this.entityData.define(DATA_STAGE, 1);
		this.entityData.define(DATA_ORBS, 0);
		this.entityData.define(DATA_SPAWNED, Boolean.FALSE);
	}

	public int getStage() {
		return this.entityData.get(DATA_STAGE);
	}

	public int getOrbCount() {
		return this.entityData.get(DATA_ORBS);
	}

	public boolean isSpawned() {
		return this.entityData.get(DATA_SPAWNED);
	}

	public boolean isTransitioning() {
		return this.transitionTicks > 0;
	}

	public boolean isPassive() {
		return !this.isSpawned();
	}

	public boolean isShielded() {
		return this.getOrbCount() > 0;
	}

	@Override
	public void setHealth(float health) {
		if (this.tickCount > 1) {
			float current = this.getHealth();
			if (health > current) {
				float cap = this.getMaxHealth() * AngelStages.healthCap(this.getStage());
				health = Math.min(health, Math.max(cap, current));
			}
		}
		super.setHealth(health);
	}

	@Override
	public void addAdditionalSaveData(CompoundTag tag) {
		super.addAdditionalSaveData(tag);
		tag.putInt("AngelStage", this.getStage());
		tag.putBoolean("AngelSpawned", this.isSpawned());
		ListTag list = new ListTag();
		for (UUID id : this.orbIds)
			list.add(NbtUtils.createUUID(id));
		tag.put("AngelOrbs", list);
	}

	@Override
	public void readAdditionalSaveData(CompoundTag tag) {
		super.readAdditionalSaveData(tag);
		if (tag.contains("AngelStage")) {
			int stage = AngelStages.clamp(tag.getInt("AngelStage"));
			this.entityData.set(DATA_STAGE, stage);
			this.appliedStage = stage;
			this.entityData.set(DATA_SPAWNED, tag.contains("AngelSpawned") ? tag.getBoolean("AngelSpawned") : Boolean.TRUE);
		}
		this.orbIds.clear();
		ListTag list = tag.getList("AngelOrbs", Tag.TAG_INT_ARRAY);
		for (int i = 0; i < list.size(); i++)
			this.orbIds.add(NbtUtils.loadUUID(list.get(i)));
	}

	@Override
	public Packet<ClientGamePacketListener> getAddEntityPacket() {
		return NetworkHooks.getEntitySpawningPacket(this);
	}

	@Override
	protected PathNavigation createNavigation(Level world) {
		return new FlyingPathNavigation(this, world);
	}

	@Override
	protected void registerGoals() {
		super.registerGoals();
		this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
		this.targetSelector.addGoal(2, new NearestAttackableTargetGoal(this, Player.class, false, false));
		this.goalSelector.addGoal(1, new AngelCombatGoal(this));
	}

	@Override
	public MobType getMobType() {
		return MobType.UNDEFINED;
	}

	protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHitIn) {
		super.dropCustomDeathLoot(source, looting, recentlyHitIn);
		if (!this.isOrb())
			this.spawnAtLocation(new ItemStack(RpedModBlocks.CORE.get()));
	}

	@Override
	public SoundEvent getAmbientSound() {
		if (this.isOrb())
			return null;
		return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("rped:boss.angel.idle"));
	}

	@Override
	public SoundEvent getHurtSound(DamageSource ds) {
		return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("rped:boss.angel.hurt"));
	}

	@Override
	public SoundEvent getDeathSound() {
		return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("rped:boss.angel.die"));
	}

	@Override
	public boolean causeFallDamage(float l, float d, DamageSource source) {
		return false;
	}

	@Override
	public boolean hurt(DamageSource damagesource, float amount) {
		if (this.isOrb())
			return this.hurtAsOrb(damagesource, amount);
		double x = this.getX();
		double y = this.getY();
		double z = this.getZ();
		Level world = this.level();
		Entity entity = this;
		Entity sourceentity = damagesource.getEntity();
		Entity immediatesourceentity = damagesource.getDirectEntity();

		AngelHurtElseProcedure.execute(entity);
		if (!damagesource.is(DamageTypeTags.BYPASSES_INVULNERABILITY) && (this.transitionTicks > 0 || this.isShielded() || !this.isSpawned()))
			return false;
		if (damagesource.is(DamageTypes.IN_FIRE))
			return false;
		if (damagesource.getDirectEntity() instanceof AbstractArrow)
			return false;
		if (damagesource.getDirectEntity() instanceof ThrownPotion || damagesource.getDirectEntity() instanceof AreaEffectCloud)
			return false;
		if (damagesource.is(DamageTypes.FALL))
			return false;
		if (damagesource.is(DamageTypes.DROWN))
			return false;
		if (damagesource.is(DamageTypes.LIGHTNING_BOLT))
			return false;
		if (damagesource.is(DamageTypes.EXPLOSION) || damagesource.is(DamageTypes.PLAYER_EXPLOSION))
			return false;
		if (damagesource.is(DamageTypes.TRIDENT))
			return false;
		if (damagesource.is(DamageTypes.FALLING_ANVIL))
			return false;
		if (damagesource.is(DamageTypes.DRAGON_BREATH))
			return false;
		if (damagesource.is(DamageTypes.WITHER) || damagesource.is(DamageTypes.WITHER_SKULL))
			return false;
		boolean result = super.hurt(damagesource, amount);
		if (result && sourceentity instanceof Player player)
			this.registerHit(player);
		return result;
	}

	private void registerHit(Player player) {
		if (!(this.level() instanceof ServerLevel level))
			return;
		int hits = this.hitCounts.merge(player.getUUID(), 1, Integer::sum);
		if (hits % AngelStages.HITS_PER_PURGE != 0)
			return;
		this.abilities.punish(level, player);
		this.purge.start(level);
	}

	@Override
	public boolean ignoreExplosion() {
		return true;
	}

	@Override
	public SpawnGroupData finalizeSpawn(ServerLevelAccessor world, DifficultyInstance difficulty, MobSpawnType reason, @Nullable SpawnGroupData livingdata, @Nullable CompoundTag tag) {
		SpawnGroupData retval = super.finalizeSpawn(world, difficulty, reason, livingdata, tag);
		if (!this.isOrb())
			TumaniteAngelSavePositionProcedure.execute(this);
		return retval;
	}

	@Override
	public void tick() {
		super.tick();
		if (this.level().isClientSide()) {
			this.animationState0.animateWhen(true, this.tickCount);
			this.animationState1.animateWhen(DieAngelUslovieProcedure.execute(this) || !this.isSpawned(), this.tickCount);
			this.shieldFadeO = this.shieldFade;
			this.shieldFade = Mth.clamp(this.shieldFade + (this.isShielded() ? 0.05F : -0.05F), 0.0F, 1.0F);
		}
	}

	@Override
	public void baseTick() {
		super.baseTick();
		if (!this.isOrb())
			AngelTickProcedure.execute(this);
	}

	@Override
	public void performRangedAttack(LivingEntity target, float flval) {
		EnchartedShardEntity.shoot(this, target);
	}

	@Override
	public boolean canBreatheUnderwater() {
		double x = this.getX();
		double y = this.getY();
		double z = this.getZ();
		Level world = this.level();
		Entity entity = this;
		return true;
	}

	@Override
	public boolean isPushedByFluid() {
		double x = this.getX();
		double y = this.getY();
		double z = this.getZ();
		Level world = this.level();
		Entity entity = this;
		return false;
	}

	@Override
	public boolean canChangeDimensions() {
		return false;
	}

	@Override
	public void customServerAiStep() {
		super.customServerAiStep();
		if (!(this.level() instanceof ServerLevel level))
			return;
		if (!this.isSpawned()) {
			if (++this.spawnTicks >= AngelStages.SPAWN_TICKS)
				this.entityData.set(DATA_SPAWNED, Boolean.TRUE);
			return;
		}
		this.updateStage();
		if (this.transitionTicks > 0) {
			this.transitionTicks--;
			if (this.transitionTicks == 0 && this.pendingShield)
				this.startShield(level);
		}
		if (!this.orbIds.isEmpty()) {
			this.trackOrbs(level);
			if (this.orbIds.isEmpty())
				this.endShield(level);
			else
				this.repelPlayers(level);
		} else if (this.getOrbCount() != 0) {
			this.entityData.set(DATA_ORBS, 0);
		}
		this.abilities.tick();
		this.purge.tick(level);
	}

	private void trackOrbs(ServerLevel level) {
		boolean grace = this.tickCount < 200;
		this.orbIds.removeIf(id -> {
			Entity orb = level.getEntity(id);
			if (orb == null)
				return !grace;
			return !orb.isAlive();
		});
		if (this.getOrbCount() != this.orbIds.size())
			this.entityData.set(DATA_ORBS, this.orbIds.size());
	}

	private void startShield(ServerLevel level) {
		this.pendingShield = false;
		int stage = this.getStage();
		int count = AngelStages.orbCount(stage);
		this.orbIds.clear();
		for (int i = 0; i < count; i++) {
			AngelOrbEntity orb = AngelOrbs.TYPE.create(level);
			if (orb == null)
				continue;
			orb.setOwner(this, i, count);
			orb.applyOrbit(this);
			orb.setPersistenceRequired();
			level.addFreshEntity(orb);
			this.orbIds.add(orb.getUUID());
			double oy = orb.getY() + orb.getBbHeight() * 0.5D;
			AngelNetwork.send(level, orb.getX(), oy, orb.getZ(), AngelFxPacket.flash(orb.getX(), oy, orb.getZ(), 4.0F, 14, stage));
		}
		this.entityData.set(DATA_ORBS, this.orbIds.size());
		double cy = this.getY() + this.getBbHeight() * 0.5D;
		level.playSound(null, this.getX(), cy, this.getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.HOSTILE, 4.0F, 0.7F);
		level.playSound(null, this.getX(), cy, this.getZ(), SoundEvents.AMETHYST_CLUSTER_PLACE, SoundSource.HOSTILE, 4.0F, 0.6F);
		AngelNetwork.send(level, this.getX(), cy, this.getZ(), AngelFxPacket.flash(this.getX(), cy, this.getZ(), 14.0F, 18, stage));
	}

	private void endShield(ServerLevel level) {
		this.entityData.set(DATA_ORBS, 0);
		double cy = this.getY() + this.getBbHeight() * 0.5D;
		level.playSound(null, this.getX(), cy, this.getZ(), SoundEvents.GLASS_BREAK, SoundSource.HOSTILE, 4.0F, 0.5F);
		level.playSound(null, this.getX(), cy, this.getZ(), SoundEvents.AMETHYST_BLOCK_BREAK, SoundSource.HOSTILE, 4.0F, 0.5F);
		AngelNetwork.send(level, this.getX(), cy, this.getZ(), AngelFxPacket.burst(this.getX(), cy, this.getZ(), AngelStages.SHIELD_RADIUS * 1.6F, 30, this.getStage()));
	}

	private void repelPlayers(ServerLevel level) {
		double radius = AngelStages.SHIELD_RADIUS;
		double cx = this.getX();
		double cy = this.getY() + this.getBbHeight() * 0.5D;
		double cz = this.getZ();
		AABB box = new AABB(cx - radius - 2.0D, cy - radius - 2.0D, cz - radius - 2.0D, cx + radius + 2.0D, cy + radius + 2.0D, cz + radius + 2.0D);
		for (Player p : level.getEntitiesOfClass(Player.class, box, e -> e.isAlive() && !e.isSpectator())) {
			double dx = p.getX() - cx;
			double dy = p.getY() + p.getBbHeight() * 0.5D - cy;
			double dz = p.getZ() - cz;
			double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
			if (dist >= radius || this.abilities.inGrabZone(p))
				continue;
			double hl = Math.sqrt(dx * dx + dz * dz);
			if (hl < 0.01D) {
				double a = this.random.nextDouble() * Math.PI * 2.0D;
				dx = Math.cos(a);
				dz = Math.sin(a);
				hl = 1.0D;
			}
			double speed = 0.45D + (radius - dist) * 0.12D;
			double ox = dx / hl;
			double oz = dz / hl;
			Vec3 v = p.getDeltaMovement();
			if (v.x * ox + v.z * oz >= speed)
				continue;
			p.setDeltaMovement(ox * speed, v.y, oz * speed);
			p.hurtMarked = true;
		}
	}

	private void updateStage() {
		int computed = AngelStages.fromHealthFraction(this.getHealth() / this.getMaxHealth());
		if (this.appliedStage == 0) {
			this.appliedStage = Math.max(this.getStage(), computed);
			this.entityData.set(DATA_STAGE, this.appliedStage);
			return;
		}
		if (computed > this.appliedStage && this.transitionTicks <= 0 && !this.isShielded()) {
			this.appliedStage++;
			this.entityData.set(DATA_STAGE, this.appliedStage);
			this.transitionTicks = 60;
			this.pendingShield = true;
			this.abilities.onStageChange(this.appliedStage);
		}
	}

	@Override
	protected void checkFallDamage(double y, boolean onGroundIn, BlockState state, BlockPos pos) {
	}

	@Override
	public void setNoGravity(boolean ignored) {
		super.setNoGravity(true);
	}

	public void aiStep() {
		super.aiStep();
		this.setNoGravity(true);
	}

	public static void init() {
	}

	public static AttributeSupplier.Builder createAttributes() {
		AttributeSupplier.Builder builder = Mob.createMobAttributes();
		builder = builder.add(Attributes.MOVEMENT_SPEED, 0.3);
		builder = builder.add(Attributes.MAX_HEALTH, 1020);
		builder = builder.add(Attributes.ARMOR, 0);
		builder = builder.add(Attributes.ATTACK_DAMAGE, 3);
		builder = builder.add(Attributes.FOLLOW_RANGE, 40);
		builder = builder.add(Attributes.FLYING_SPEED, 0.3);
		return builder;
	}
}
