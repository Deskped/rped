package deskped.rped.entity;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.resources.ResourceLocation;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class AngelOrbs {
	public static EntityType<AngelOrbEntity> TYPE;

	@SubscribeEvent
	public static void onRegister(RegisterEvent event) {
		event.register(ForgeRegistries.Keys.ENTITY_TYPES, helper -> {
			TYPE = EntityType.Builder.<AngelOrbEntity>of(AngelOrbEntity::new, MobCategory.MONSTER).sized(0.6F, 1.8F).clientTrackingRange(10).updateInterval(1).fireImmune().build("angel_orb");
			helper.register(new ResourceLocation("rped", "angel_orb"), TYPE);
		});
	}

	@SubscribeEvent
	public static void onAttributes(EntityAttributeCreationEvent event) {
		event.put(TYPE, AngelOrbEntity.createOrbAttributes().build());
	}
}