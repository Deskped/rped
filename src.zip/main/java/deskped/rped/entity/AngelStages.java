package deskped.rped.entity;

import org.joml.Vector3f;

import net.minecraft.util.Mth;

public final class AngelStages {
	public static final int COUNT = 6;
	public static final int[] COLORS = {0xFFE9A0, 0x7FE3FF, 0xB48CFF, 0xFF7AD9, 0xFF8A3D, 0xFF3B3B};
	public static final float[] DAMAGE = {1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.7F};
	public static final float ORB_HEALTH = 333.0F;
	public static final float ORB_TELEPORT_CHANCE = 0.10F;
	public static final float ORB_ANIMATION_SPEED = 2.0F;
	public static final int ORB_COLOR = 0x39FF7A;
	public static final float SHIELD_AGGRESSION = 1.5F;
	public static final float SHIELD_RADIUS = 10.0F;
	public static final int SPAWN_TICKS = 80;
	public static final double GRAB_RADIUS = 4.5D;
	public static final double GRAB_DEPTH = 2.0D;
	public static final int PURGE_RADIUS = 133;
	public static final int HITS_PER_PURGE = 3;

	private AngelStages() {
	}

	public static int clamp(int stage) {
		return Mth.clamp(stage, 1, COUNT);
	}

	public static int fromHealthFraction(float fraction) {
		return clamp((int) ((1.0F - Mth.clamp(fraction, 0.0F, 1.0F)) * COUNT) + 1);
	}

	public static int color(int stage) {
		return COLORS[clamp(stage) - 1];
	}

	public static int orbCount(int stage) {
		return clamp(stage) + 1;
	}

	public static float healthCap(int stage) {
		return (COUNT - clamp(stage) + 1) / (float) COUNT;
	}

	public static float damageScale(int stage) {
		return DAMAGE[clamp(stage) - 1];
	}

	public static float aggression(int stage) {
		return 1.0F + 0.2F * (clamp(stage) - 1);
	}

	public static float musicPitch(int stage) {
		return 1.0F + 0.09F * (clamp(stage) - 1);
	}

	public static Vector3f vector(int stage) {
		int c = color(stage);
		return new Vector3f((c >> 16 & 255) / 255.0F, (c >> 8 & 255) / 255.0F, (c & 255) / 255.0F);
	}
}
