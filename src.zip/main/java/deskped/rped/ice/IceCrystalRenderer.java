package deskped.rped.ice;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import org.joml.Matrix4f;

@Mod.EventBusSubscriber(modid = "rped", value = Dist.CLIENT)
public class IceCrystalRenderer {

    private static final float CENTER_Y = 0.9f;

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) {
            return;
        }
        float partial = event.getPartialTick();
        Vec3 cam = event.getCamera().getPosition();
        PoseStack pose = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        boolean drawn = false;
        for (Player player : level.players()) {
            MobEffectInstance shield = player.getEffect(IceCrystal.ETERNAL_ICE_CRYSTAL);
            if (shield == null) {
                continue;
            }
            double x = Mth.lerp(partial, player.xo, player.getX()) - cam.x;
            double y = Mth.lerp(partial, player.yo, player.getY()) - cam.y;
            double z = Mth.lerp(partial, player.zo, player.getZ()) - cam.z;
            if (x * x + y * y + z * z > 96.0 * 96.0) {
                continue;
            }
            boolean firstPerson = player == mc.player && mc.options.getCameraType().isFirstPerson();
            float time = player.tickCount + partial;
            float fade = shield.getDuration() < 40 ? 0.35f + 0.65f * (0.5f + 0.5f * Mth.sin(time * 1.5f)) : 1.0f;
            int crystals = IceCrystal.MAX_MELEE_HITS - shield.getAmplifier();
            VertexConsumer vc = buffers.getBuffer(RenderType.lightning());
            pose.pushPose();
            pose.translate(x, y, z);
            orbit(pose, vc, time, fade, crystals);
            if (!firstPerson) {
                dome(pose.last().pose(), vc, time, fade);
            }
            pose.popPose();
            drawn = true;
        }
        if (drawn) {
            buffers.endBatch(RenderType.lightning());
        }
    }

    private static void orbit(PoseStack pose, VertexConsumer vc, float time, float fade, int count) {
        for (int i = 0; i < count; i++) {
            float angle = time * 0.07f + Mth.TWO_PI * i / count;
            float bob = Mth.sin(time * 0.09f + i * 2.1f) * 0.2f;
            pose.pushPose();
            pose.translate(Mth.cos(angle) * 1.35f, CENTER_Y + bob, Mth.sin(angle) * 1.35f);
            pose.mulPose(Axis.YP.rotationDegrees(time * 7.0f + i * 40.0f));
            pose.mulPose(Axis.ZP.rotationDegrees(20.0f));
            Matrix4f m = pose.last().pose();
            crystal(m, vc, 0.28f, 0.6f * fade, 0.6f, 0.9f, 1.0f);
            crystal(m, vc, 0.14f, 0.95f * fade, 1.0f, 1.0f, 1.0f);
            pose.popPose();
        }
    }

    private static void crystal(Matrix4f m, VertexConsumer vc, float size, float alpha, float r, float g, float b) {
        float h = size * 1.6f;
        float rad = size * 0.55f;
        for (int k = 0; k < 6; k++) {
            float a0 = Mth.TWO_PI * k / 6.0f;
            float a1 = Mth.TWO_PI * (k + 1) / 6.0f;
            float x0 = rad * Mth.cos(a0);
            float z0 = rad * Mth.sin(a0);
            float x1 = rad * Mth.cos(a1);
            float z1 = rad * Mth.sin(a1);
            float a = alpha * ((k & 1) == 0 ? 1.0f : 0.65f);
            tri(m, vc, 0.0f, h, 0.0f, x0, 0.0f, z0, x1, 0.0f, z1, r, g, b, a);
            tri(m, vc, 0.0f, -h, 0.0f, x1, 0.0f, z1, x0, 0.0f, z0, r, g, b, a);
        }
    }

    private static void tri(Matrix4f m, VertexConsumer vc, float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz, float r, float g, float b, float a) {
        float edge = a * 0.4f;
        vert(m, vc, ax, ay, az, r, g, b, a);
        vert(m, vc, bx, by, bz, r, g, b, edge);
        vert(m, vc, cx, cy, cz, r, g, b, edge);
        vert(m, vc, cx, cy, cz, r, g, b, edge);
        vert(m, vc, cx, cy, cz, r, g, b, edge);
        vert(m, vc, bx, by, bz, r, g, b, edge);
        vert(m, vc, ax, ay, az, r, g, b, a);
        vert(m, vc, ax, ay, az, r, g, b, a);
    }

    private static void vert(Matrix4f m, VertexConsumer vc, float x, float y, float z, float r, float g, float b, float a) {
        vc.vertex(m, x, y, z).color(r, g, b, a).endVertex();
    }

    private static void dome(Matrix4f m, VertexConsumer vc, float time, float fade) {
        int stacks = 8;
        int slices = 14;
        float rx = 1.05f;
        float ry = 1.25f;
        float base = (0.085f + 0.03f * Mth.sin(time * 0.15f)) * fade;
        float spin = time * 0.012f;
        for (int i = 0; i < stacks; i++) {
            float p0 = Mth.PI * i / stacks - Mth.HALF_PI;
            float p1 = Mth.PI * (i + 1) / stacks - Mth.HALF_PI;
            for (int j = 0; j < slices; j++) {
                float t0 = Mth.TWO_PI * j / slices + spin;
                float t1 = Mth.TWO_PI * (j + 1) / slices + spin;
                float a = (((i + j) & 1) == 0 ? 1.0f : 0.5f) * base;
                domeQuad(m, vc, rx, ry, a, p0, p1, t0, t1);
            }
        }
    }

    private static void domeQuad(Matrix4f m, VertexConsumer vc, float rx, float ry, float a, float p0, float p1, float t0, float t1) {
        domeVert(m, vc, rx, ry, a, p0, t0);
        domeVert(m, vc, rx, ry, a, p1, t0);
        domeVert(m, vc, rx, ry, a, p1, t1);
        domeVert(m, vc, rx, ry, a, p0, t1);
        domeVert(m, vc, rx, ry, a, p0, t1);
        domeVert(m, vc, rx, ry, a, p1, t1);
        domeVert(m, vc, rx, ry, a, p1, t0);
        domeVert(m, vc, rx, ry, a, p0, t0);
    }

    private static void domeVert(Matrix4f m, VertexConsumer vc, float rx, float ry, float a, float phi, float theta) {
        float cp = Mth.cos(phi);
        vert(m, vc, rx * cp * Mth.cos(theta), CENTER_Y + ry * Mth.sin(phi), rx * cp * Mth.sin(theta), 0.55f, 0.88f, 1.0f, a);
    }
}
