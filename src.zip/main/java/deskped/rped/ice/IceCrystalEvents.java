package deskped.rped.ice;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ShulkerBullet;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "rped")
public class IceCrystalEvents {

    @SubscribeEvent
    public static void onAttack(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        MobEffectInstance shield = player.getEffect(IceCrystal.ETERNAL_ICE_CRYSTAL);
        if (shield == null) {
            return;
        }
        DamageSource source = event.getSource();
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;
        }
        event.setCanceled(true);
        if (player.level().isClientSide || !isMelee(source)) {
            return;
        }
        int hits = shield.getAmplifier() + 1;
        int left = shield.getDuration();
        player.removeEffect(IceCrystal.ETERNAL_ICE_CRYSTAL);
        if (hits < IceCrystal.MAX_MELEE_HITS) {
            player.addEffect(new MobEffectInstance(IceCrystal.ETERNAL_ICE_CRYSTAL, left, hits, false, false, false));
            player.level().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.GLASS_HIT, SoundSource.PLAYERS, 1.0f, 1.2f);
        }
    }

    private static boolean isMelee(DamageSource source) {
        Entity direct = source.getDirectEntity();
        return direct instanceof LivingEntity
                && direct == source.getEntity()
                && !source.is(DamageTypeTags.IS_PROJECTILE)
                && !source.is(DamageTypeTags.IS_EXPLOSION);
    }

    @SubscribeEvent
    public static void onProjectileImpact(ProjectileImpactEvent event) {
        if (!(event.getRayTraceResult() instanceof EntityHitResult hit)) {
            return;
        }
        if (!(hit.getEntity() instanceof Player player)) {
            return;
        }
        if (!player.hasEffect(IceCrystal.ETERNAL_ICE_CRYSTAL)) {
            return;
        }
        event.setCanceled(true);
        Projectile projectile = event.getProjectile();
        if (player.level().isClientSide || projectile.getOwner() == player) {
            return;
        }
        if (projectile instanceof ShulkerBullet) {
            projectile.discard();
            return;
        }
        Vec3 back = projectile.getDeltaMovement().scale(-1.0);
        projectile.setOwner(player);
        projectile.setDeltaMovement(back);
        if (projectile instanceof AbstractHurtingProjectile hurting) {
            hurting.xPower = -hurting.xPower;
            hurting.yPower = -hurting.yPower;
            hurting.zPower = -hurting.zPower;
        }
        projectile.hurtMarked = true;
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.SHIELD_BLOCK, SoundSource.PLAYERS, 1.0f, 1.5f);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Player player = event.player;
        if (player.level().isClientSide) {
            return;
        }
        if (player.hasEffect(IceCrystal.ETERNAL_ICE_CRYSTAL)) {
            player.clearFire();
            return;
        }
        CompoundTag data = player.getPersistentData();
        if (data.getBoolean(IceCrystal.ACTIVE_TAG)) {
            data.remove(IceCrystal.ACTIVE_TAG);
            player.level().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, 0.9f, 1.3f);
        }
    }
}
