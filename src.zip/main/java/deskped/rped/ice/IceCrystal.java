package deskped.rped.ice;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

@Mod.EventBusSubscriber(modid = "rped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class IceCrystal {

    public static final int DURATION_TICKS = 110;
    public static final int COOLDOWN_TICKS = 600;
    public static final int MAX_MELEE_HITS = 3;
    public static final String ACTIVE_TAG = "rped_ice_crystal_active";

    public static final MobEffect ETERNAL_ICE_CRYSTAL = new MobEffect(MobEffectCategory.BENEFICIAL, 0x9FE8FF) {
    };

    @SubscribeEvent
    public static void onRegister(RegisterEvent event) {
        event.register(ForgeRegistries.Keys.MOB_EFFECTS, helper -> helper.register(new ResourceLocation("rped", "eternal_ice_crystal"), ETERNAL_ICE_CRYSTAL));
    }

    public static void activate(Player player) {
        player.addEffect(new MobEffectInstance(ETERNAL_ICE_CRYSTAL, DURATION_TICKS, 0, false, false, false));
        player.getPersistentData().putBoolean(ACTIVE_TAG, true);
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.8f, 1.7f);
    }
}
