package deskped.rped.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;

import deskped.rped.morph.ai.MorphRelations;

@Mixin(LivingEntity.class)
public class LivingEntityCanAttackMixin {

	@Inject(method = "canAttack(Lnet/minecraft/world/entity/LivingEntity;)Z", at = @At("HEAD"), cancellable = true)
	private void rped$morphCanAttack(LivingEntity target, CallbackInfoReturnable<Boolean> cir) {
		if (target instanceof Player player && (Object) this instanceof Mob mob && MorphRelations.ignores(mob, player))
			cir.setReturnValue(false);
	}
}
