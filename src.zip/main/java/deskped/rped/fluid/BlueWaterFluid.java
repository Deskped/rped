package deskped.rped.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleOptions;

import deskped.rped.init.RpedModParticleTypes;
import deskped.rped.init.RpedModItems;
import deskped.rped.init.RpedModFluids;
import deskped.rped.init.RpedModFluidTypes;
import deskped.rped.init.RpedModBlocks;

public abstract class BlueWaterFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> RpedModFluidTypes.BLUE_WATER_TYPE.get(), () -> RpedModFluids.BLUE_WATER.get(), () -> RpedModFluids.FLOWING_BLUE_WATER.get())
			.explosionResistance(100f).bucket(() -> RpedModItems.BLUE_WATER_BUCKET.get()).block(() -> (LiquidBlock) RpedModBlocks.BLUE_WATER.get());

	private BlueWaterFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return (SimpleParticleType) (RpedModParticleTypes.OUTBREAK_PARTICLES.get());
	}

	public static class Source extends BlueWaterFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends BlueWaterFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}