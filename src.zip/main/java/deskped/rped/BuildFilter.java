package deskped.rped;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class BuildFilter {

	public static final Set<ResourceKey<CreativeModeTab>> TABS = Set.of(
			CreativeModeTabs.BUILDING_BLOCKS,
			CreativeModeTabs.COLORED_BLOCKS,
			CreativeModeTabs.NATURAL_BLOCKS);

	private static final Set<String> DENY = new HashSet<>(Arrays.asList(
			"ancient_debris", "netherite_block", "diamond_block", "emerald_block", "gold_block", "iron_block", "lapis_block",
			"raw_iron_block", "raw_gold_block", "raw_copper_block",
			"budding_amethyst", "amethyst_cluster", "large_amethyst_bud", "medium_amethyst_bud", "small_amethyst_bud",
			"crying_obsidian", "gilded_blackstone", "dragon_egg", "spawner",
			"sponge", "wet_sponge", "turtle_egg", "sniffer_egg", "frogspawn",
			"reinforced_deepslate", "bedrock", "barrier", "light", "structure_block", "structure_void", "jigsaw",
			"command_block", "chain_command_block", "repeating_command_block", "end_portal_frame", "beacon", "conduit", "lodestone",
			"wither_rose", "torchflower_seeds", "pitcher_pod", "azalea", "flowering_azalea", "mangrove_propagule",
			"end_stone", "end_stone_bricks", "end_stone_brick_slab", "end_stone_brick_stairs", "end_stone_brick_wall",
			"purpur_block", "purpur_pillar", "purpur_slab", "purpur_stairs", "chorus_plant", "chorus_flower",
			"shulker_box"));

	private static final String[] DENY_SUFFIX = { "_ore", "_leaves", "_sapling", "_shulker_box" };

	private static final String[] DENY_PREFIX = { "sculk", "infested_", "suspicious_" };

	private static volatile Set<Item> allowedItems;
	private static volatile boolean failed;

	public static void reset() {
		allowedItems = null;
		failed = false;
	}

	public static boolean ruleAllowed(Item item) {
		if (!(item instanceof BlockItem))
			return false;
		ResourceLocation id = BuiltInRegistries.ITEM.getKey(item);
		if (!id.getNamespace().equals("minecraft"))
			return false;
		String path = id.getPath();
		if (DENY.contains(path))
			return false;
		for (String suffix : DENY_SUFFIX)
			if (path.endsWith(suffix))
				return false;
		for (String prefix : DENY_PREFIX)
			if (path.startsWith(prefix))
				return false;
		return true;
	}

	public static boolean allowed(ItemStack stack) {
		Item item = stack.getItem();
		Set<Item> set = allowedItems;
		if (set == null)
			return ruleAllowed(item);
		return set.contains(item);
	}

	public static void ensure(MinecraftServer server) {
		if (allowedItems != null || failed)
			return;
		try {
			CreativeModeTab.ItemDisplayParameters params = new CreativeModeTab.ItemDisplayParameters(server.getWorldData().enabledFeatures(), false, server.registryAccess());
			Set<Item> result = new HashSet<>();
			for (ResourceKey<CreativeModeTab> key : TABS) {
				CreativeModeTab tab = BuiltInRegistries.CREATIVE_MODE_TAB.get(key);
				if (tab == null)
					continue;
				tab.buildContents(params);
				for (ItemStack stack : tab.getDisplayItems()) {
					if (ruleAllowed(stack.getItem()))
						result.add(stack.getItem());
				}
			}
			if (result.isEmpty())
				failed = true;
			else
				allowedItems = result;
		} catch (Throwable t) {
			failed = true;
			RpedMod.LOGGER.error("Failed to compute allowed items", t);
		}
	}
}