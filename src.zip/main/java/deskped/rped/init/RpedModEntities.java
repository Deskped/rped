package deskped.rped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import deskped.rped.entity.*;
import deskped.rped.RpedMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class RpedModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, RpedMod.MODID);
	public static final RegistryObject<EntityType<BreakoutEntity>> BREAKOUT = register("breakout",
			EntityType.Builder.<BreakoutEntity>of(BreakoutEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BreakoutEntity::new).fireImmune().sized(2f, 2f));
	public static final RegistryObject<EntityType<BarrelKaboomEntity>> BARREL_KABOOM = register("barrel_kaboom", EntityType.Builder.<BarrelKaboomEntity>of(BarrelKaboomEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BarrelKaboomEntity::new).fireImmune().sized(1f, 1f));
	public static final RegistryObject<EntityType<CasingGolemEntity>> CASING_GOLEM = register("casing_golem",
			EntityType.Builder.<CasingGolemEntity>of(CasingGolemEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(CasingGolemEntity::new)

					.sized(3f, 3.3f));
	public static final RegistryObject<EntityType<TumaniteAngelEntity>> TUMANITE_ANGEL = register("tumanite_angel", EntityType.Builder.<TumaniteAngelEntity>of(TumaniteAngelEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(TumaniteAngelEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<EnchartedShardEntity>> ENCHARTED_SHARD = register("encharted_shard",
			EntityType.Builder.<EnchartedShardEntity>of(EnchartedShardEntity::new, MobCategory.MISC).setCustomClientFactory(EnchartedShardEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<ChirlikEntity>> CHIRLIK = register("chirlik",
			EntityType.Builder.<ChirlikEntity>of(ChirlikEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ChirlikEntity::new).fireImmune().sized(0.6f, 1.8f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			BreakoutEntity.init();
			BarrelKaboomEntity.init();
			CasingGolemEntity.init();
			TumaniteAngelEntity.init();
			ChirlikEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(BREAKOUT.get(), BreakoutEntity.createAttributes().build());
		event.put(BARREL_KABOOM.get(), BarrelKaboomEntity.createAttributes().build());
		event.put(CASING_GOLEM.get(), CasingGolemEntity.createAttributes().build());
		event.put(TUMANITE_ANGEL.get(), TumaniteAngelEntity.createAttributes().build());
		event.put(CHIRLIK.get(), ChirlikEntity.createAttributes().build());
	}
}