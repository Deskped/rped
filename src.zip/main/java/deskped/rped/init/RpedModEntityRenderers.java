package deskped.rped.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import deskped.rped.client.renderer.*;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class RpedModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(RpedModEntities.BREAKOUT.get(), BreakoutRenderer::new);
		event.registerEntityRenderer(RpedModEntities.BARREL_KABOOM.get(), BarrelKaboomRenderer::new);
		event.registerEntityRenderer(RpedModEntities.CASING_GOLEM.get(), CasingGolemRenderer::new);
		event.registerEntityRenderer(RpedModEntities.TUMANITE_ANGEL.get(), TumaniteAngelRenderer::new);
		event.registerEntityRenderer(RpedModEntities.ENCHARTED_SHARD.get(), EnchartedShardRenderer::new);
		event.registerEntityRenderer(RpedModEntities.CHIRLIK.get(), ChirlikRenderer::new);
	}
}