package deskped.rped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

import deskped.rped.RpedMod;

public class RpedModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, RpedMod.MODID);
	public static final RegistryObject<SimpleParticleType> OUTBREAK_PARTICLES = REGISTRY.register("outbreak_particles", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> ROD = REGISTRY.register("rod", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> RLSTA = REGISTRY.register("rlsta", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> DARKROD = REGISTRY.register("darkrod", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> CREATE_OUTBREAK = REGISTRY.register("create_outbreak", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> CUTTING = REGISTRY.register("cutting", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> HOTROD = REGISTRY.register("hotrod", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> FLAMEROD = REGISTRY.register("flamerod", () -> new SimpleParticleType(true));
}