package deskped.rped.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import deskped.rped.client.model.*;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class RpedModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelezonet.LAYER_LOCATION, Modelezonet::createBodyLayer);
		event.registerLayerDefinition(Modelcrusher.LAYER_LOCATION, Modelcrusher::createBodyLayer);
		event.registerLayerDefinition(Modelbenison.LAYER_LOCATION, Modelbenison::createBodyLayer);
		event.registerLayerDefinition(ModelBarrelPowder.LAYER_LOCATION, ModelBarrelPowder::createBodyLayer);
		event.registerLayerDefinition(Modeltumanitangel.LAYER_LOCATION, Modeltumanitangel::createBodyLayer);
		event.registerLayerDefinition(ModelenchartedShard.LAYER_LOCATION, ModelenchartedShard::createBodyLayer);
		event.registerLayerDefinition(ModelIronCasingGolem.LAYER_LOCATION, ModelIronCasingGolem::createBodyLayer);
		event.registerLayerDefinition(Modelchirlik.LAYER_LOCATION, Modelchirlik::createBodyLayer);
		event.registerLayerDefinition(Modeltumanite_cluster.LAYER_LOCATION, Modeltumanite_cluster::createBodyLayer);
	}
}