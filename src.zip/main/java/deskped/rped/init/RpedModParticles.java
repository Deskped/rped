package deskped.rped.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.api.distmarker.Dist;

import deskped.rped.client.particle.*;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class RpedModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(RpedModParticleTypes.OUTBREAK_PARTICLES.get(), OutbreakParticlesParticle::provider);
		event.registerSpriteSet(RpedModParticleTypes.ROD.get(), RodParticle::provider);
		event.registerSpriteSet(RpedModParticleTypes.RLSTA.get(), RlstaParticle::provider);
		event.registerSpriteSet(RpedModParticleTypes.DARKROD.get(), DarkrodParticle::provider);
		event.registerSpriteSet(RpedModParticleTypes.CREATE_OUTBREAK.get(), CreateOutbreakParticle::provider);
		event.registerSpriteSet(RpedModParticleTypes.CUTTING.get(), CuttingParticle::provider);
		event.registerSpriteSet(RpedModParticleTypes.HOTROD.get(), HotrodParticle::provider);
		event.registerSpriteSet(RpedModParticleTypes.FLAMEROD.get(), FlamerodParticle::provider);
	}
}