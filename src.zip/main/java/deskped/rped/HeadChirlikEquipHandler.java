package deskped.rped;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.InteractionResult;

import deskped.rped.block.HeadChirlikBlock;

@Mod.EventBusSubscriber(modid = "rped")
public class HeadChirlikEquipHandler {
	@SubscribeEvent
	public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
		ItemStack stack = event.getItemStack();
		if (!(stack.getItem() instanceof BlockItem blockItem) || !(blockItem.getBlock() instanceof HeadChirlikBlock)) {
			return;
		}
		Player player = event.getEntity();
		if (!player.getItemBySlot(EquipmentSlot.HEAD).isEmpty()) {
			return;
		}
		if (!event.getLevel().isClientSide()) {
			ItemStack worn = stack.copy();
			worn.setCount(1);
			if (!player.getAbilities().instabuild) {
				stack.shrink(1);
			}
			player.setItemSlot(EquipmentSlot.HEAD, worn);
		}
		event.setCancellationResult(InteractionResult.sidedSuccess(event.getLevel().isClientSide()));
		event.setCanceled(true);
	}
}