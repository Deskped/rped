package deskped.rped.morph;

import java.util.UUID;
import java.util.function.Supplier;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import deskped.rped.morph.client.MorphClient;

public final class MorphSyncPacket {
	public final UUID player;
	public final MorphSpec spec;

	public MorphSyncPacket(UUID player, MorphSpec spec) {
		this.player = player;
		this.spec = spec;
	}

	public static void encode(MorphSyncPacket packet, FriendlyByteBuf buf) {
		buf.writeUUID(packet.player);
		buf.writeBoolean(packet.spec != null);
		if (packet.spec != null) {
			buf.writeResourceLocation(packet.spec.id);
			buf.writeNbt(packet.spec.nbt);
		}
	}

	public static MorphSyncPacket decode(FriendlyByteBuf buf) {
		UUID id = buf.readUUID();
		if (!buf.readBoolean())
			return new MorphSyncPacket(id, null);
		ResourceLocation type = buf.readResourceLocation();
		CompoundTag nbt = buf.readNbt();
		return new MorphSyncPacket(id, new MorphSpec(type, nbt));
	}

	public static void handle(MorphSyncPacket packet, Supplier<NetworkEvent.Context> context) {
		NetworkEvent.Context ctx = context.get();
		ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> MorphClient.apply(packet.player, packet.spec)));
		ctx.setPacketHandled(true);
	}
}
