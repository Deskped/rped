package deskped.rped.morph;

import java.util.Optional;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MorphNetwork {
	private static final String VERSION = "1";
	public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(new ResourceLocation("rped", "morph"), () -> VERSION, VERSION::equals, VERSION::equals);

	@SubscribeEvent
	public static void onSetup(FMLCommonSetupEvent event) {
		CHANNEL.registerMessage(0, MorphSyncPacket.class, MorphSyncPacket::encode, MorphSyncPacket::decode, MorphSyncPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
	}
}
