package deskped.rped.morph;

import java.util.Collection;
import java.util.List;
import java.util.Locale;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.CompoundTagArgument;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.ResourceArgument;
import net.minecraft.commands.synchronization.SuggestionProviders;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "rped")
public class MorphCommand {

	@SubscribeEvent
	public static void onRegisterCommands(RegisterCommandsEvent event) {
		CommandBuildContext buildContext = event.getBuildContext();
		event.getDispatcher().register(Commands.literal("rped")
				.then(Commands.literal("morph")
						.requires(src -> src.hasPermission(2))
						.then(resetNode("reset"))
						.then(resetNode("human"))
						.then(Commands.argument("entity", ResourceArgument.resource(buildContext, Registries.ENTITY_TYPE))
								.suggests(SuggestionProviders.SUMMONABLE_ENTITIES)
								.executes(ctx -> morph(ctx, List.of(ctx.getSource().getPlayerOrException()), new CompoundTag()))
								.then(Commands.argument("targets", EntityArgument.players())
										.executes(ctx -> morph(ctx, EntityArgument.getPlayers(ctx, "targets"), new CompoundTag())))
								.then(Commands.argument("nbt", CompoundTagArgument.compoundTag())
										.executes(ctx -> morph(ctx, List.of(ctx.getSource().getPlayerOrException()), CompoundTagArgument.getCompoundTag(ctx, "nbt")))
										.then(Commands.argument("targets", EntityArgument.players())
												.executes(ctx -> morph(ctx, EntityArgument.getPlayers(ctx, "targets"), CompoundTagArgument.getCompoundTag(ctx, "nbt"))))))));
	}

	private static LiteralArgumentBuilder<CommandSourceStack> resetNode(String name) {
		return Commands.literal(name)
				.executes(ctx -> reset(ctx.getSource(), List.of(ctx.getSource().getPlayerOrException())))
				.then(Commands.argument("targets", EntityArgument.players())
						.executes(ctx -> reset(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets"))));
	}

	private static int morph(CommandContext<CommandSourceStack> ctx, Collection<ServerPlayer> targets, CompoundTag nbt) throws CommandSyntaxException {
		CommandSourceStack src = ctx.getSource();
		Holder.Reference<EntityType<?>> holder = ResourceArgument.getSummonableEntityType(ctx, "entity");
		MorphSpec spec = new MorphSpec(holder.key().location(), nbt);
		boolean ru = ru(src);
		int done = 0;
		ServerPlayer last = null;
		for (ServerPlayer player : targets) {
			if (MorphManager.set(player, spec)) {
				done++;
				last = player;
			}
		}
		if (done == 0) {
			src.sendFailure(Component.literal(ru ? "Не удалось превратиться в это существо" : "Cannot morph into that entity"));
			return 0;
		}
		MutableComponent mob = Component.translatable(holder.value().getDescriptionId());
		MutableComponent message;
		if (done == 1) {
			message = Component.empty().append(last.getDisplayName()).append(Component.literal(ru ? " теперь " : " is now ")).append(mob);
		} else {
			message = Component.literal(ru ? "Превращено игроков: " + done + ", в " : "Players morphed: " + done + ", into ").append(mob);
		}
		MutableComponent finalMessage = message;
		src.sendSuccess(() -> finalMessage, true);
		return done;
	}

	private static int reset(CommandSourceStack src, Collection<ServerPlayer> targets) {
		boolean ru = ru(src);
		int done = 0;
		ServerPlayer last = null;
		for (ServerPlayer player : targets) {
			if (MorphManager.get(player) != null) {
				MorphManager.clear(player);
				done++;
				last = player;
			}
		}
		if (done == 0) {
			src.sendFailure(Component.literal(ru ? "Никто из игроков не превращён" : "None of the players are morphed"));
			return 0;
		}
		MutableComponent message;
		if (done == 1)
			message = Component.empty().append(last.getDisplayName()).append(Component.literal(ru ? " снова человек" : " is human again"));
		else
			message = Component.literal((ru ? "Человеческий облик возвращён игрокам: " : "Players restored: ") + done);
		MutableComponent finalMessage = message;
		src.sendSuccess(() -> finalMessage, true);
		return done;
	}

	private static boolean ru(CommandSourceStack src) {
		return src.getEntity() instanceof ServerPlayer sp && sp.getLanguage() != null && sp.getLanguage().toLowerCase(Locale.ROOT).startsWith("ru");
	}
}
