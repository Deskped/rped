package deskped.rped.morph.client;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import deskped.rped.RpedMod;
import deskped.rped.morph.MorphClientState;
import deskped.rped.morph.MorphSize;
import deskped.rped.morph.MorphSpec;

@Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class MorphClient {
	private static final Map<UUID, Holder> DUMMIES = new HashMap<>();
	private static final int AGGRESSIVE_TICKS = 30;

	private MorphClient() {
	}

	private static final class Holder {
		final String key;
		final Level level;
		final LivingEntity entity;
		final MorphSize size;
		boolean tickBroken;
		boolean renderBroken;
		int lastSwing = -1000;

		Holder(String key, Level level, LivingEntity entity, MorphSize size) {
			this.key = key;
			this.level = level;
			this.entity = entity;
			this.size = size;
		}

		boolean failed() {
			return entity == null;
		}
	}

	public static void apply(UUID id, MorphSpec spec) {
		MorphClientState.set(id, spec);
		DUMMIES.remove(id);
		Minecraft mc = Minecraft.getInstance();
		if (mc.level == null)
			return;
		Player player = mc.level.getPlayerByUUID(id);
		if (player != null)
			player.refreshDimensions();
	}

	private static Holder holder(Player player, MorphSpec spec) {
		Holder existing = DUMMIES.get(player.getUUID());
		if (existing != null && existing.level == player.level() && existing.key.equals(spec.key()))
			return existing;
		MorphSize size = MorphSize.of(spec, player.level());
		LivingEntity entity = size.valid ? spec.create(player.level()) : null;
		if (entity != null) {
			entity.setSilent(true);
			EntityRenderer<?> renderer = Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(entity);
			if (renderer == null)
				entity = null;
		}
		Holder created = new Holder(spec.key(), player.level(), entity, size);
		DUMMIES.put(player.getUUID(), created);
		return created;
	}

	private static void rotate(Player p, LivingEntity e) {
		e.setYRot(p.getYRot());
		e.setXRot(p.getXRot());
		e.yRotO = p.yRotO;
		e.xRotO = p.xRotO;
		e.yBodyRot = p.yBodyRot;
		e.yBodyRotO = p.yBodyRotO;
		e.yHeadRot = p.yHeadRot;
		e.yHeadRotO = p.yHeadRotO;
	}

	private static void place(Player p, LivingEntity e) {
		e.setPos(p.getX(), p.getY(), p.getZ());
		e.xo = p.xo;
		e.yo = p.yo;
		e.zo = p.zo;
		e.xOld = p.xOld;
		e.yOld = p.yOld;
		e.zOld = p.zOld;
		e.setDeltaMovement(p.getDeltaMovement());
		e.setOnGround(p.onGround());
		rotate(p, e);
	}

	private static void state(Player p, Holder h) {
		LivingEntity e = h.entity;
		for (EquipmentSlot slot : EquipmentSlot.values()) {
			ItemStack want = p.getItemBySlot(slot);
			if (!ItemStack.matches(e.getItemBySlot(slot), want))
				e.setItemSlot(slot, want.copy());
		}
		e.setShiftKeyDown(p.isShiftKeyDown());
		e.setInvisible(p.isInvisible());
		e.setCustomName(p.getDisplayName());
		e.setCustomNameVisible(p != Minecraft.getInstance().player);
		e.setHealth(p.isDeadOrDying() ? 0.0F : e.getMaxHealth());
		if (p.isSleeping()) {
			e.setPose(Pose.SLEEPING);
			p.getSleepingPos().ifPresent(e::setSleepingPos);
		} else if (e.hasPose(Pose.SLEEPING)) {
			e.setPose(Pose.STANDING);
			e.clearSleepingPos();
		}
		if (e instanceof Mob mob)
			mob.setAggressive(p.isUsingItem() || e.tickCount - h.lastSwing < AGGRESSIVE_TICKS);
	}

	private static void frame(Player p, Holder h) {
		LivingEntity e = h.entity;
		place(p, e);
		e.swinging = p.swinging;
		e.swingTime = p.swingTime;
		e.swingingArm = p.swingingArm;
		e.attackAnim = p.attackAnim;
		e.oAttackAnim = p.oAttackAnim;
		e.hurtTime = p.hurtTime;
		e.hurtDuration = p.hurtDuration;
		e.deathTime = p.deathTime;
	}

	private static void tickDummy(Player p, Holder h) {
		LivingEntity e = h.entity;
		place(p, e);
		e.tickCount++;
		if (p.swinging && p.swingTime == 0) {
			h.lastSwing = e.tickCount;
			try {
				e.handleEntityEvent((byte) 4);
			} catch (Throwable ignored) {
			}
		}
		state(p, h);
		if (!h.tickBroken) {
			try {
				e.tick();
			} catch (Throwable t) {
				h.tickBroken = true;
				RpedMod.LOGGER.warn("Morph: tick failed for {}, animations limited", e.getType(), t);
			}
		}
		frame(p, h);
	}

	private static void heal(Player p, MorphSpec spec, Level level) {
		if (p.isSleeping() || p.hasPose(Pose.DYING))
			return;
		MorphSize size = MorphSize.of(spec, level);
		if (size.valid && Math.abs(p.getBbWidth() - size.width) > 1.0E-3F)
			p.refreshDimensions();
	}

	@SubscribeEvent
	public static void onClientTick(TickEvent.ClientTickEvent event) {
		if (event.phase != TickEvent.Phase.END)
			return;
		Minecraft mc = Minecraft.getInstance();
		ClientLevel level = mc.level;
		if (level == null) {
			if (!DUMMIES.isEmpty())
				DUMMIES.clear();
			return;
		}
		if (mc.isPaused())
			return;
		boolean healTick = level.getGameTime() % 20L == 0L;
		Set<UUID> used = new HashSet<>();
		for (AbstractClientPlayer p : level.players()) {
			MorphSpec spec = MorphClientState.get(p.getUUID());
			if (spec == null)
				continue;
			if (healTick)
				heal(p, spec, level);
			Holder h = holder(p, spec);
			used.add(p.getUUID());
			if (h.failed())
				continue;
			tickDummy(p, h);
		}
		DUMMIES.keySet().removeIf(id -> !used.contains(id));
	}

	@SubscribeEvent
	public static void onRenderPlayer(RenderPlayerEvent.Pre event) {
		Player p = event.getEntity();
		MorphSpec spec = MorphClientState.get(p.getUUID());
		if (spec == null)
			return;
		Holder h = holder(p, spec);
		if (h.failed() || h.renderBroken)
			return;
		LivingEntity e = h.entity;
		EntityRenderDispatcher dispatcher = Minecraft.getInstance().getEntityRenderDispatcher();
		EntityRenderer<? super LivingEntity> renderer = dispatcher.getRenderer(e);
		if (renderer == null) {
			h.renderBroken = true;
			return;
		}
		frame(p, h);
		PoseStack stack = new PoseStack();
		PoseStack.Pose top = event.getPoseStack().last();
		stack.last().pose().set(top.pose());
		stack.last().normal().set(top.normal());
		if (h.size.scale != 1.0F)
			stack.scale(h.size.scale, h.size.scale, h.size.scale);
		float partial = event.getPartialTick();
		float yaw = Mth.lerp(partial, p.yRotO, p.getYRot());
		try {
			renderer.render(e, yaw, partial, stack, event.getMultiBufferSource(), event.getPackedLight());
		} catch (Throwable t) {
			h.renderBroken = true;
			RpedMod.LOGGER.error("Morph: render failed for {}, falling back to the player model", e.getType(), t);
			return;
		}
		event.setCanceled(true);
	}

	@SubscribeEvent
	public static void onRenderHand(RenderHandEvent event) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player != null && MorphClientState.get(mc.player.getUUID()) != null)
			event.setCanceled(true);
	}

	@SubscribeEvent
	public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
		DUMMIES.clear();
		MorphClientState.clear();
		MorphSize.clearCache();
	}
}
