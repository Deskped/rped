package deskped.rped.morph;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.level.Level;

public final class MorphSize {
	public static final MorphSize INVALID = new MorphSize(0.0F, 0.0F, 0.0F, 1.0F, false);

	private static final float MAX_WIDTH = 4.0F;
	private static final float MAX_HEIGHT = 4.0F;
	private static final Map<String, MorphSize> CACHE = new ConcurrentHashMap<>();

	public final float width;
	public final float height;
	public final float eye;
	public final float scale;
	public final boolean valid;

	private MorphSize(float width, float height, float eye, float scale, boolean valid) {
		this.width = width;
		this.height = height;
		this.eye = eye;
		this.scale = scale;
		this.valid = valid;
	}

	public static MorphSize of(MorphSpec spec, Level level) {
		MorphSize cached = CACHE.get(spec.key());
		if (cached != null)
			return cached;
		MorphSize result = INVALID;
		LivingEntity entity = spec.create(level);
		if (entity != null) {
			try {
				EntityDimensions dims = entity.getDimensions(Pose.STANDING);
				float eye = entity.getEyeHeight(Pose.STANDING);
				float w = Math.max(dims.width, 0.05F);
				float h = Math.max(dims.height, 0.05F);
				float scale = Math.min(1.0F, Math.min(MAX_WIDTH / w, MAX_HEIGHT / h));
				result = new MorphSize(w * scale, h * scale, eye * scale, scale, true);
			} catch (Throwable t) {
				result = INVALID;
			}
		}
		CACHE.put(spec.key(), result);
		return result;
	}

	public static void clearCache() {
		CACHE.clear();
	}
}
