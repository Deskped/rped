package deskped.rped.morph;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

public final class MorphSpec {
	public final ResourceLocation id;
	public final CompoundTag nbt;
	private final String key;
	private EntityType<?> resolved;

	public MorphSpec(ResourceLocation id, CompoundTag nbt) {
		this.id = id;
		this.nbt = nbt == null ? new CompoundTag() : nbt;
		this.key = this.nbt.isEmpty() ? id.toString() : id + this.nbt.toString();
	}

	public String key() {
		return key;
	}

	public EntityType<?> type() {
		if (resolved == null)
			resolved = BuiltInRegistries.ENTITY_TYPE.getOptional(id).orElse(null);
		return resolved;
	}

	public LivingEntity create(Level level) {
		EntityType<?> type = type();
		if (type == null || type == EntityType.PLAYER)
			return null;
		try {
			Entity entity = type.create(level);
			if (!(entity instanceof LivingEntity living))
				return null;
			if (!nbt.isEmpty())
				living.load(nbt.copy());
			return living;
		} catch (Throwable t) {
			return null;
		}
	}

	public CompoundTag toTag() {
		CompoundTag tag = new CompoundTag();
		tag.putString("id", id.toString());
		tag.put("nbt", nbt.copy());
		return tag;
	}

	public static MorphSpec fromTag(CompoundTag tag) {
		if (tag == null || !tag.contains("id", Tag.TAG_STRING))
			return null;
		ResourceLocation id = ResourceLocation.tryParse(tag.getString("id"));
		if (id == null)
			return null;
		return new MorphSpec(id, tag.getCompound("nbt"));
	}
}
