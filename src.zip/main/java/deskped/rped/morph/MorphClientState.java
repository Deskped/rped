package deskped.rped.morph;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MorphClientState {
	private static final Map<UUID, MorphSpec> MAP = new ConcurrentHashMap<>();

	private MorphClientState() {
	}

	public static MorphSpec get(UUID id) {
		return MAP.get(id);
	}

	public static void set(UUID id, MorphSpec spec) {
		if (spec == null)
			MAP.remove(id);
		else
			MAP.put(id, spec);
	}

	public static void clear() {
		MAP.clear();
	}
}
