package deskped.rped.morph;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.network.PacketDistributor;

public final class MorphManager {
	public static final String KEY = "rped_morph";

	private static final Map<UUID, MorphSpec> SERVER = new ConcurrentHashMap<>();

	private MorphManager() {
	}

	public static MorphSpec get(Player player) {
		if (player.level().isClientSide)
			return MorphClientState.get(player.getUUID());
		UUID id = player.getUUID();
		MorphSpec cached = SERVER.get(id);
		if (cached != null)
			return cached;
		CompoundTag data = player.getPersistentData();
		if (!data.contains(KEY, Tag.TAG_COMPOUND))
			return null;
		MorphSpec spec = MorphSpec.fromTag(data.getCompound(KEY));
		if (spec != null)
			SERVER.put(id, spec);
		return spec;
	}

	public static boolean set(ServerPlayer player, MorphSpec spec) {
		if (!MorphSize.of(spec, player.level()).valid)
			return false;
		player.getPersistentData().put(KEY, spec.toTag());
		SERVER.put(player.getUUID(), spec);
		player.refreshDimensions();
		sync(player);
		return true;
	}

	public static void clear(ServerPlayer player) {
		forget(player);
		player.refreshDimensions();
		sync(player);
	}

	public static void forget(ServerPlayer player) {
		player.getPersistentData().remove(KEY);
		SERVER.remove(player.getUUID());
	}

	public static void drop(UUID id) {
		SERVER.remove(id);
	}

	public static void sync(ServerPlayer player) {
		MorphSyncPacket packet = new MorphSyncPacket(player.getUUID(), get(player));
		MorphNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
		MorphNetwork.CHANNEL.send(PacketDistributor.TRACKING_ENTITY.with(() -> player), packet);
	}

	public static void sendTo(ServerPlayer receiver, ServerPlayer target) {
		MorphSpec spec = get(target);
		if (spec == null)
			return;
		MorphNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> receiver), new MorphSyncPacket(target.getUUID(), spec));
	}
}
