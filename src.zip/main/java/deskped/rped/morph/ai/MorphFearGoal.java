package deskped.rped.morph.ai;

import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.player.Player;

public class MorphFearGoal extends AvoidEntityGoal<Player> {

	public MorphFearGoal(PathfinderMob mob) {
		super(mob, Player.class, target -> target instanceof Player player && MorphRelations.frightens(mob, player), 8.0F, 1.0D, 1.3D, target -> EntitySelector.NO_CREATIVE_OR_SPECTATOR.test(target));
	}
}
