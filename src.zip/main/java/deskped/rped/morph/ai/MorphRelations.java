package deskped.rped.morph.ai;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.player.Player;

import deskped.rped.morph.MorphManager;
import deskped.rped.morph.MorphSpec;

public final class MorphRelations {
    private static final int REVENGE_TICKS = 400;
    private static final Map<EntityType<?>, Predicate<EntityType<?>>> PREY = new HashMap<>();
    private static final Map<EntityType<?>, Predicate<EntityType<?>>> FEAR = new HashMap<>();
    private static final Set<EntityType<?>> ACTIVE_HUNTERS = Set.of(
            EntityType.WOLF,
            EntityType.FOX,
            EntityType.CAT,
            EntityType.OCELOT,
            EntityType.POLAR_BEAR,
            EntityType.IRON_GOLEM,
            EntityType.SNOW_GOLEM
    );

    static {
        prey(List.of(EntityType.ZOMBIE, EntityType.HUSK, EntityType.DROWNED, EntityType.ZOMBIE_VILLAGER),
                Set.of(EntityType.VILLAGER, EntityType.WANDERING_TRADER, EntityType.IRON_GOLEM, EntityType.TURTLE));
        prey(List.of(EntityType.SKELETON, EntityType.STRAY),
                Set.of(EntityType.IRON_GOLEM, EntityType.TURTLE));
        prey(List.of(EntityType.WITHER_SKELETON),
                Set.of(EntityType.IRON_GOLEM, EntityType.TURTLE, EntityType.PIGLIN));
        prey(List.of(EntityType.SPIDER, EntityType.CAVE_SPIDER),
                Set.of(EntityType.IRON_GOLEM));
        prey(List.of(EntityType.SLIME, EntityType.MAGMA_CUBE),
                Set.of(EntityType.IRON_GOLEM, EntityType.TURTLE));
        prey(List.of(EntityType.PILLAGER, EntityType.VINDICATOR, EntityType.EVOKER, EntityType.ILLUSIONER, EntityType.RAVAGER),
                Set.of(EntityType.VILLAGER, EntityType.WANDERING_TRADER, EntityType.IRON_GOLEM));
        prey(List.of(EntityType.GUARDIAN, EntityType.ELDER_GUARDIAN),
                Set.of(EntityType.SQUID, EntityType.GLOW_SQUID, EntityType.AXOLOTL));
        prey(List.of(EntityType.WOLF),
                Set.of(EntityType.SHEEP, EntityType.RABBIT, EntityType.FOX, EntityType.TURTLE, EntityType.SKELETON, EntityType.STRAY, EntityType.WITHER_SKELETON));
        prey(List.of(EntityType.FOX),
                Set.of(EntityType.CHICKEN, EntityType.RABBIT, EntityType.COD, EntityType.SALMON, EntityType.TROPICAL_FISH, EntityType.TURTLE));
        prey(List.of(EntityType.CAT),
                Set.of(EntityType.RABBIT, EntityType.TURTLE));
        prey(List.of(EntityType.OCELOT),
                Set.of(EntityType.CHICKEN, EntityType.TURTLE));
        prey(List.of(EntityType.POLAR_BEAR),
                Set.of(EntityType.FOX));

        PREY.put(EntityType.IRON_GOLEM,
                t -> t.getCategory() == MobCategory.MONSTER && t != EntityType.CREEPER);
        PREY.put(EntityType.SNOW_GOLEM,
                t -> t.getCategory() == MobCategory.MONSTER);

        fear(List.of(EntityType.CREEPER),
                Set.of(EntityType.CAT, EntityType.OCELOT));
        fear(List.of(EntityType.SKELETON, EntityType.STRAY, EntityType.WITHER_SKELETON),
                Set.of(EntityType.WOLF));
    }

    private MorphRelations() {
    }

    private static void prey(List<EntityType<?>> observers, Set<EntityType<?>> targets) {
        for (EntityType<?> observer : observers)
            PREY.put(observer, targets::contains);
    }

    private static void fear(List<EntityType<?>> observers, Set<EntityType<?>> targets) {
        for (EntityType<?> observer : observers)
            FEAR.put(observer, targets::contains);
    }

    public static boolean hunts(EntityType<?> observer, EntityType<?> morph) {
        Predicate<EntityType<?>> predicate = PREY.get(observer);
        return predicate != null && predicate.test(morph);
    }

    public static boolean fears(EntityType<?> observer, EntityType<?> morph) {
        Predicate<EntityType<?>> predicate = FEAR.get(observer);
        return predicate != null && predicate.test(morph);
    }

    public static boolean canHuntMorphs(EntityType<?> observer) {
        return ACTIVE_HUNTERS.contains(observer);
    }

    public static boolean canFearMorphs(EntityType<?> observer) {
        return FEAR.containsKey(observer);
    }

    private static EntityType<?> morphOf(Player player) {
        MorphSpec spec = MorphManager.get(player);
        return spec == null ? null : spec.type();
    }

    public static boolean preys(Mob mob, Player player) {
        if (mob instanceof TamableAnimal tamable && tamable.isTame())
            return false;

        EntityType<?> morph = morphOf(player);
        return morph != null && hunts(mob.getType(), morph);
    }

    public static boolean frightens(Mob mob, Player player) {
        EntityType<?> morph = morphOf(player);
        return morph != null && fears(mob.getType(), morph);
    }

    public static boolean retaliating(Mob mob, Player player) {
        return mob.getLastHurtByMob() == player
                && mob.tickCount - mob.getLastHurtByMobTimestamp() < REVENGE_TICKS;
    }

    public static boolean ignores(Mob mob, Player player) {
        if (player.level().isClientSide)
            return false;

        EntityType<?> morph = morphOf(player);
        if (morph == null)
            return false;

        if (hunts(mob.getType(), morph))
            return false;

        return !retaliating(mob, player);
    }

    public static void forget(Mob mob, Player player) {
        if (mob.getTarget() == player)
            mob.setTarget(null);

        if (mob instanceof NeutralMob neutral
                && player.getUUID().equals(neutral.getPersistentAngerTarget()))
            neutral.stopBeingAngry();

        if (mob instanceof Warden warden)
            warden.clearAnger(player);
    }
}