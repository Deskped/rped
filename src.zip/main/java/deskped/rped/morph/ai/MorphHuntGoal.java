package deskped.rped.morph.ai;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;

public class MorphHuntGoal extends NearestAttackableTargetGoal<Player> {

	public MorphHuntGoal(Mob mob) {
		super(mob, Player.class, 10, true, false, target -> target instanceof Player player && MorphRelations.preys(mob, player));
	}
}
