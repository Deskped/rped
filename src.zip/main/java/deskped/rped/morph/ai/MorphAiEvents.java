package deskped.rped.morph.ai;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.GoalSelector;
import net.minecraft.world.entity.ai.goal.WrappedGoal;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

import deskped.rped.RpedMod;
import deskped.rped.morph.MorphManager;

@Mod.EventBusSubscriber(modid = RpedMod.MODID)
public class MorphAiEvents {

	@SubscribeEvent
	public static void onJoin(EntityJoinLevelEvent event) {
		if (event.getLevel().isClientSide())
			return;
		if (!(event.getEntity() instanceof Mob mob))
			return;
		EntityType<?> type = mob.getType();
		if (MorphRelations.canHuntMorphs(type) && !has(mob.targetSelector, MorphHuntGoal.class))
			mob.targetSelector.addGoal(4, new MorphHuntGoal(mob));
		if (MorphRelations.canFearMorphs(type) && mob instanceof PathfinderMob pathfinder && !has(mob.goalSelector, MorphFearGoal.class))
			mob.goalSelector.addGoal(3, new MorphFearGoal(pathfinder));
	}

	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase != TickEvent.Phase.END || event.side != LogicalSide.SERVER)
			return;
		if (!(event.player instanceof ServerPlayer player) || player.tickCount % 10 != 0)
			return;
		if (MorphManager.get(player) == null)
			return;
		AABB area = player.getBoundingBox().inflate(48.0D);
		for (Mob mob : player.level().getEntitiesOfClass(Mob.class, area)) {
			if (MorphRelations.ignores(mob, player))
				MorphRelations.forget(mob, player);
		}
	}

	private static boolean has(GoalSelector selector, Class<? extends Goal> type) {
		for (WrappedGoal wrapped : selector.getAvailableGoals()) {
			if (type.isInstance(wrapped.getGoal()))
				return true;
		}
		return false;
	}
}
