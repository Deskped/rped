package deskped.rped.morph;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.EntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "rped")
public class MorphEvents {

	@SubscribeEvent
	public static void onSize(EntityEvent.Size event) {
		if (!(event.getEntity() instanceof Player player))
			return;
		Pose pose = event.getPose();
		if (pose == Pose.SLEEPING || pose == Pose.DYING)
			return;
		MorphSpec spec = MorphManager.get(player);
		if (spec == null)
			return;
		MorphSize size = MorphSize.of(spec, player.level());
		if (!size.valid)
			return;
		event.setNewSize(EntityDimensions.scalable(size.width, size.height));
		event.setNewEyeHeight(size.eye);
	}

	@SubscribeEvent
	public static void onClone(PlayerEvent.Clone event) {
		CompoundTag old = event.getOriginal().getPersistentData();
		if (old.contains(MorphManager.KEY, Tag.TAG_COMPOUND))
			event.getEntity().getPersistentData().put(MorphManager.KEY, old.getCompound(MorphManager.KEY).copy());
	}

	@SubscribeEvent
	public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
		resync(event.getEntity());
	}

	@SubscribeEvent
	public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
		MorphManager.drop(event.getEntity().getUUID());
	}

	@SubscribeEvent
	public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
		resync(event.getEntity());
	}

	@SubscribeEvent
	public static void onChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
		resync(event.getEntity());
	}

	@SubscribeEvent
	public static void onStartTracking(PlayerEvent.StartTracking event) {
		if (event.getEntity() instanceof ServerPlayer receiver && event.getTarget() instanceof ServerPlayer target)
			MorphManager.sendTo(receiver, target);
	}

	private static void resync(Player entity) {
		if (!(entity instanceof ServerPlayer player))
			return;
		MorphSpec spec = MorphManager.get(player);
		if (spec == null)
			return;
		if (!MorphSize.of(spec, player.level()).valid) {
			MorphManager.forget(player);
			player.refreshDimensions();
			return;
		}
		player.refreshDimensions();
		MorphManager.sync(player);
	}
}
