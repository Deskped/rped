package deskped.rped.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.chat.Component;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.List;

import deskped.rped.procedures.TombstoneBreakProcedure;

public class TombstoneBlock extends Block implements SimpleWaterloggedBlock {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
	public static final BooleanProperty WATERLOGGED = BlockStateProperties.WATERLOGGED;

	public TombstoneBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.DEEPSLATE).strength(0.8f, 25f).noOcclusion().pushReaction(PushReaction.BLOCK).isRedstoneConductor((bs, br, bp) -> false).instrument(NoteBlockInstrument.XYLOPHONE));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(WATERLOGGED, false));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, BlockGetter level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, level, list, flag);
		list.add(Component.translatable("block.rped.tombstone.description_0"));
		list.add(Component.translatable("block.rped.tombstone.description_1"));
		list.add(Component.translatable("block.rped.tombstone.description_2"));
		list.add(Component.translatable("block.rped.tombstone.description_3"));
		list.add(Component.translatable("block.rped.tombstone.description_4"));
		list.add(Component.translatable("block.rped.tombstone.description_5"));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return state.getFluidState().isEmpty();
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(4.4, 0, 6.7, 11.4, 14, 8.4), box(11.4, 0, 6.7, 12.4, 13, 8.4), box(3.4, 0, 6.7, 4.4, 13, 8.4), box(12.4, 0, 6.7, 13.4, 12, 8.4), box(2.4, 0, 6.7, 3.4, 12, 8.4), box(13.4, 0, 6.7, 14.4, 10, 8.4),
					box(1.4, 0, 6.7, 2.4, 10, 8.4));
			case NORTH -> Shapes.or(box(4.6, 0, 7.6, 11.6, 14, 9.3), box(3.6, 0, 7.6, 4.6, 13, 9.3), box(11.6, 0, 7.6, 12.6, 13, 9.3), box(2.6, 0, 7.6, 3.6, 12, 9.3), box(12.6, 0, 7.6, 13.6, 12, 9.3), box(1.6, 0, 7.6, 2.6, 10, 9.3),
					box(13.6, 0, 7.6, 14.6, 10, 9.3));
			case EAST -> Shapes.or(box(6.7, 0, 4.6, 8.4, 14, 11.6), box(6.7, 0, 3.6, 8.4, 13, 4.6), box(6.7, 0, 11.6, 8.4, 13, 12.6), box(6.7, 0, 2.6, 8.4, 12, 3.6), box(6.7, 0, 12.6, 8.4, 12, 13.6), box(6.7, 0, 1.6, 8.4, 10, 2.6),
					box(6.7, 0, 13.6, 8.4, 10, 14.6));
			case WEST -> Shapes.or(box(7.6, 0, 4.4, 9.3, 14, 11.4), box(7.6, 0, 11.4, 9.3, 13, 12.4), box(7.6, 0, 3.4, 9.3, 13, 4.4), box(7.6, 0, 12.4, 9.3, 12, 13.4), box(7.6, 0, 2.4, 9.3, 12, 3.4), box(7.6, 0, 13.4, 9.3, 10, 14.4),
					box(7.6, 0, 1.4, 9.3, 10, 2.4));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING, WATERLOGGED);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		boolean flag = context.getLevel().getFluidState(context.getClickedPos()).getType() == Fluids.WATER;
		return super.getStateForPlacement(context).setValue(FACING, context.getHorizontalDirection().getOpposite()).setValue(WATERLOGGED, flag);
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public FluidState getFluidState(BlockState state) {
		return state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
	}

	@Override
	public BlockState updateShape(BlockState state, Direction facing, BlockState facingState, LevelAccessor world, BlockPos currentPos, BlockPos facingPos) {
		if (state.getValue(WATERLOGGED)) {
			world.scheduleTick(currentPos, Fluids.WATER, Fluids.WATER.getTickDelay(world));
		}
		return super.updateShape(state, facing, facingState, world, currentPos, facingPos);
	}

	@Override
	public boolean onDestroyedByPlayer(BlockState blockstate, Level world, BlockPos pos, Player entity, boolean willHarvest, FluidState fluid) {
		boolean retval = super.onDestroyedByPlayer(blockstate, world, pos, entity, willHarvest, fluid);
		TombstoneBreakProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
		return retval;
	}

	@Override
	public void wasExploded(Level world, BlockPos pos, Explosion e) {
		super.wasExploded(world, pos, e);
		TombstoneBreakProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}
}