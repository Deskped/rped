package deskped.rped.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.AttachFace;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.List;

public class HeadChirlikBlock extends Block implements SimpleWaterloggedBlock {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
	public static final EnumProperty<AttachFace> FACE = FaceAttachedHorizontalDirectionalBlock.FACE;
	public static final BooleanProperty WATERLOGGED = BlockStateProperties.WATERLOGGED;

	public HeadChirlikBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.SHROOMLIGHT).strength(0.95f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(FACE, AttachFace.WALL).setValue(WATERLOGGED, false));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, BlockGetter level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, level, list, flag);
		list.add(Component.translatable("block.rped.head_chirlik.description_0"));
		list.add(Component.translatable("block.rped.head_chirlik.description_1"));
		list.add(Component.translatable("block.rped.head_chirlik.description_2"));
		list.add(Component.translatable("block.rped.head_chirlik.description_3"));
		list.add(Component.translatable("block.rped.head_chirlik.description_4"));
		list.add(Component.translatable("block.rped.head_chirlik.description_5"));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return state.getFluidState().isEmpty();
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(4, 0.6, 5, 12, 8.6, 11), box(3.5, 0.1, 4.5, 12.5, 9.1, 11.5));
				case WALL -> Shapes.or(box(4, 5, 0.6, 12, 11, 8.6), box(3.5, 4.5, 0.1, 12.5, 11.5, 9.1));
				case CEILING -> Shapes.or(box(4, 7.4, 5, 12, 15.4, 11), box(3.5, 6.9, 4.5, 12.5, 15.9, 11.5));
			};
			case NORTH -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(4, 0.6, 5, 12, 8.6, 11), box(3.5, 0.1, 4.5, 12.5, 9.1, 11.5));
				case WALL -> Shapes.or(box(4, 5, 7.4, 12, 11, 15.4), box(3.5, 4.5, 6.9, 12.5, 11.5, 15.9));
				case CEILING -> Shapes.or(box(4, 7.4, 5, 12, 15.4, 11), box(3.5, 6.9, 4.5, 12.5, 15.9, 11.5));
			};
			case EAST -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(5, 0.6, 4, 11, 8.6, 12), box(4.5, 0.1, 3.5, 11.5, 9.1, 12.5));
				case WALL -> Shapes.or(box(0.6, 5, 4, 8.6, 11, 12), box(0.1, 4.5, 3.5, 9.1, 11.5, 12.5));
				case CEILING -> Shapes.or(box(5, 7.4, 4, 11, 15.4, 12), box(4.5, 6.9, 3.5, 11.5, 15.9, 12.5));
			};
			case WEST -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(5, 0.6, 4, 11, 8.6, 12), box(4.5, 0.1, 3.5, 11.5, 9.1, 12.5));
				case WALL -> Shapes.or(box(7.4, 5, 4, 15.4, 11, 12), box(6.9, 4.5, 3.5, 15.9, 11.5, 12.5));
				case CEILING -> Shapes.or(box(5, 7.4, 4, 11, 15.4, 12), box(4.5, 6.9, 3.5, 11.5, 15.9, 12.5));
			};
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING, FACE, WATERLOGGED);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		boolean flag = context.getLevel().getFluidState(context.getClickedPos()).getType() == Fluids.WATER;
		return super.getStateForPlacement(context).setValue(FACE, faceForDirection(context.getNearestLookingDirection())).setValue(FACING, context.getHorizontalDirection().getOpposite()).setValue(WATERLOGGED, flag);
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	private AttachFace faceForDirection(Direction direction) {
		if (direction.getAxis() == Direction.Axis.Y)
			return direction == Direction.UP ? AttachFace.CEILING : AttachFace.FLOOR;
		else
			return AttachFace.WALL;
	}

	@Override
	public FluidState getFluidState(BlockState state) {
		return state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
	}

	@Override
	public BlockState updateShape(BlockState state, Direction facing, BlockState facingState, LevelAccessor world, BlockPos currentPos, BlockPos facingPos) {
		if (state.getValue(WATERLOGGED)) {
			world.scheduleTick(currentPos, Fluids.WATER, Fluids.WATER.getTickDelay(world));
		}
		return super.updateShape(state, facing, facingState, world, currentPos, facingPos);
	}
}