package deskped.rped;

import com.mojang.blaze3d.systems.RenderSystem;
import deskped.rped.client.ClientMenuState;
import deskped.rped.client.MenuChoice;
import deskped.rped.ext.ExtLang;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@OnlyIn(Dist.CLIENT)
public class MenuSelectScreen extends Screen {

    private static final ResourceLocation BG_GIF = ResourceLocation.fromNamespaceAndPath("rped", "textures/gui/menu/deph.gif");
    private static final ResourceLocation LOGO   = ResourceLocation.fromNamespaceAndPath("rped", "textures/screens/rped.png");
    private static final Style            OP     = Style.EMPTY.withFont(ResourceLocation.fromNamespaceAndPath("rped", "operator"));
    private static final SoundEvent       TYPE   = SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("rped", "snd"));
    private static final Random           RNG    = new Random();

    private static final String[] IDS   = {MenuChoice.RPED, MenuChoice.YOURLINE, MenuChoice.MYPED, MenuChoice.MINECRAFT};
    private static final String[] NAMES = {"RPED", "YourLine", "MyPED", "Minecraft"};

    private static final long  TYPE_DELAY_MS = 350L;
    private static final long  TYPE_STEP_MS  = 65L;
    private static final float HOLD_SEC      = 0.9f;
    private static final int   LABEL_H       = 12;
    private static final int   SQ            = 12;

    private final Screen  parent;
    private final boolean ru;
    private final String  title;
    private final long    openedAt = System.currentTimeMillis();

    private final float[] hover = new float[4];
    private final float[] fill  = new float[4];
    private final float[] shake = new float[4];

    private GifPlayer bg;
    private Button    confirm;

    private List<String> titleLines = new ArrayList<>();
    private String       typedText  = "";
    private int          titleScale = 3;
    private int          cardW;
    private int          cardH;
    private int          cardY;
    private int          gap;
    private int          startX;

    private int   pressed   = -1;
    private int   selected  = -1;
    private int   soundDone = 0;
    private float confirmA  = 0f;
    private long  lastNow   = 0L;

    public MenuSelectScreen(Screen parent) {
        super(Component.empty());
        this.parent = parent;
        this.ru     = ExtLang.ru();
        this.title  = ru ? "ВЫБЕРИТЕ НУЖНОЕ ГЛАВНОЕ МЕНЮ" : "CHOOSE YOUR MAIN MENU";
    }

    @Override
    protected void init() {
        if (bg == null) bg = GifPlayer.open(BG_GIF, true, "menu_select_bg");
        layoutTitle();
        layoutCards();

        int bw = Math.min(280, this.width - 20);
        confirm = Button.builder(
                Component.literal(ru ? "Я выбрал это меню и считаю его основным" : "I chose this menu and consider it my main one"),
                b -> confirmChoice()
        ).bounds(this.width / 2 - bw / 2, this.height - 28, bw, 20).build();
        confirm.visible = selected >= 0;
        confirm.active  = selected >= 0;
        addRenderableWidget(confirm);
    }

    private int opWidth(String s) {
        return this.font.width(Component.literal(s).withStyle(OP));
    }

    private List<String> wrap(String text, int maxW) {
        List<String> out = new ArrayList<>();
        String cur = "";
        for (String word : text.split(" ")) {
            String cand = cur.isEmpty() ? word : cur + " " + word;
            if (!cur.isEmpty() && opWidth(cand) > maxW) {
                out.add(cur);
                cur = word;
            } else {
                cur = cand;
            }
        }
        if (!cur.isEmpty()) out.add(cur);
        return out;
    }

    private void layoutTitle() {
        for (int ts = 4; ts >= 1; ts--) {
            List<String> lines = wrap(title, (this.width - 24) / ts);
            int h = lines.size() * 12 * ts + 16;
            if (ts == 1 || h <= this.height * 0.34f) {
                titleLines = lines;
                titleScale = ts;
                break;
            }
        }
        typedText = String.join("", titleLines);
    }

    private void layoutCards() {
        int titleBottom = 12 + titleLines.size() * 12 * titleScale;
        gap   = Math.max(6, this.width / 40);
        cardW = Math.max(56, Math.min(112, (this.width - gap * 5) / 4));
        int bottomBar = 34;
        int avail = this.height - titleBottom - 8 - bottomBar - (LABEL_H + 3) - (5 + SQ);
        cardH = Math.max(40, Math.min((int) (cardW * 1.25f), avail));
        int block = LABEL_H + 3 + cardH + 5 + SQ;
        int top = titleBottom + Math.max(4, (this.height - titleBottom - bottomBar - block) / 2);
        cardY  = top + LABEL_H + 3;
        startX = (this.width - (cardW * 4 + gap * 3)) / 2;
    }

    private int cardX(int i) {
        return startX + i * (cardW + gap);
    }

    private boolean inside(int i, double mx, double my) {
        int x = cardX(i);
        return mx >= x && mx <= x + cardW
            && my >= cardY - LABEL_H - 3 && my <= cardY + cardH + 5 + SQ;
    }

    private int visibleChars(long now) {
        long el = now - openedAt - TYPE_DELAY_MS;
        if (el < 0L) return 0;
        return (int) Math.min(typedText.length(), el / TYPE_STEP_MS + 1);
    }

    private void playType() {
        float pitch = 0.94f + RNG.nextFloat() * 0.12f;
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(TYPE, pitch, 0.7f));
    }

    private void typeSounds(long now) {
        int visible = Math.min(visibleChars(now), typedText.length());
        if (soundDone < visible - 6) soundDone = visible - 6;
        int budget = 3;
        while (soundDone < visible && budget > 0) {
            char c = typedText.charAt(soundDone);
            soundDone++;
            if (c != ' ') {
                playType();
                budget--;
            }
        }
    }

    private void pick(int i) {
        selected = i;
        pressed  = -1;
    }

    private void confirmChoice() {
        if (selected < 0) return;
        MenuChoice.choose(IDS[selected]);
        if (!ClientMenuState.customMenu) Menu.triggerMusicStop();
        Minecraft.getInstance().setScreen(new TitleScreen());
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (button == 0) {
            for (int i = 0; i < 4; i++) {
                if (!inside(i, mx, my)) continue;
                if (MenuChoice.available(IDS[i])) pressed = i;
                else shake[i] = 1f;
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (button == 0) pressed = -1;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        long now = System.currentTimeMillis();
        float dt = lastNow == 0L ? 0.016f : Math.min(0.1f, (now - lastNow) / 1000f);
        lastNow = now;
        double t = (now - openedAt) / 1000.0;

        if (ClientMenuState.customMenu) Menu.nukeMusic();

        drawBackground(g, now);
        updateCards(mx, my, dt);
        typeSounds(now);
        drawTitle(g, now, t);
        for (int i = 0; i < 4; i++) drawCard(g, i, mx, my, t);
        updateConfirm(g, dt);
        super.render(g, mx, my, partial);
    }

    private void drawBackground(GuiGraphics g, long now) {
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        g.fill(0, 0, this.width, this.height, 0xFF050510);
        if (bg != null) {
            bg.update(now);
            bg.draw(g, this.width, this.height, 1f, 100f);
        }
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        g.fill(0, 0, this.width, this.height, 0x44000000);
        g.fillGradient(0, 0, this.width, this.height / 3, 0x88000000, 0x00000000);
        g.fillGradient(0, this.height * 2 / 3, this.width, this.height, 0x00000000, 0x88000000);
    }

    private void updateCards(int mx, int my, float dt) {
        for (int i = 0; i < 4; i++) {
            boolean hov = inside(i, mx, my);
            hover[i] += ((hov ? 1f : 0f) - hover[i]) * Math.min(1f, dt * 10f);
            boolean holding = pressed == i && hov && MenuChoice.available(IDS[i]);
            if (holding) fill[i] = Math.min(1f, fill[i] + dt / HOLD_SEC);
            else if (selected != i) fill[i] = Math.max(0f, fill[i] - dt * 2.5f);
            if (shake[i] > 0f) shake[i] = Math.max(0f, shake[i] - dt * 3f);
            if (holding && fill[i] >= 1f && selected != i) pick(i);
        }
    }

    private void drawTitle(GuiGraphics g, long now, double t) {
        int ts = titleScale;
        int remaining = visibleChars(now);
        float cx = this.width / 2f;
        float amp = ts * 1.1f * (float) Math.abs(Math.sin(t * 0.55));
        float gx = amp * (float) Math.sin(t * 1.3);
        float gy = amp * 0.6f * (float) Math.sin(t * 1.9 + 1.0);
        int y = 12 + 2 * ts;
        for (String line : titleLines) {
            if (remaining <= 0) break;
            String part = line.substring(0, Math.min(line.length(), remaining));
            remaining -= line.length();
            float x0 = cx - opWidth(line) * ts / 2f;
            Component comp = Component.literal(part).withStyle(OP);

            g.pose().pushPose();
            g.pose().translate(x0, y, 0f);
            g.pose().scale(ts, ts, 1f);
            g.drawString(this.font, comp, 0, 0, 0xFFFFFFFF, false);
            g.pose().popPose();

            g.pose().pushPose();
            g.pose().translate(x0 + gx, y + gy, 0f);
            g.pose().scale(ts, ts, 1f);
            g.drawString(this.font, comp, 0, 0, 0x55FFFFFF, false);
            g.pose().popPose();

            y += 12 * ts;
        }
    }

    private static void frame(GuiGraphics g, int x0, int y0, int x1, int y1, int th, int c) {
        g.fill(x0, y0, x1, y0 + th, c);
        g.fill(x0, y1 - th, x1, y1, c);
        g.fill(x0, y0 + th, x0 + th, y1 - th, c);
        g.fill(x1 - th, y0 + th, x1, y1 - th, c);
    }

    private void drawCard(GuiGraphics g, int i, int mx, int my, double t) {
        boolean open = MenuChoice.available(IDS[i]);
        int x    = cardX(i);
        int top  = cardY - LABEL_H - 3;
        int bot  = cardY + cardH + 5 + SQ;
        float h  = hover[i];
        float sel = selected == i ? 1f : 0f;
        float pulse = 0.5f + 0.5f * (float) Math.sin(t * 3.0);
        float cx = x + cardW / 2f;
        float cy = (top + bot) / 2f;
        float sc = 1f + 0.07f * h + 0.03f * sel;
        float shx = shake[i] > 0f ? (float) Math.sin(shake[i] * 30f) * 3f * shake[i] : 0f;
        float ox = Math.max(-0.6f, Math.min(0.6f, (mx - cx) / cardW)) * 6f * h;
        float oy = Math.max(-0.6f, Math.min(0.6f, (my - (cardY + cardH / 2f)) / cardH)) * 6f * h;

        g.pose().pushPose();
        g.pose().translate(cx + shx, cy, 0f);
        g.pose().scale(sc, sc, 1f);
        g.pose().translate(-cx, -cy, 0f);

        int ga = (int) (0x30 * h + sel * (0x30 + 0x20 * pulse));
        if (ga > 0) g.fill(x - 3, cardY - 3, x + cardW + 3, cardY + cardH + 3, (ga << 24) | 0xFFFFFF);

        int br = 0x10 + (int) (16 * h);
        int bb = 0x28 + (int) (32 * h);
        g.fill(x, cardY, x + cardW, cardY + cardH, (0xB0 << 24) | (br << 16) | (br << 8) | bb);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);

        if (i == 0) {
            float lw = cardW * 0.9f;
            float lh = lw * 440f / 870f;
            g.pose().pushPose();
            g.pose().translate(cx - lw / 2f + ox, cardY + cardH * 0.42f - lh / 2f + oy, 0f);
            g.pose().scale(lw / 870f, lh / 440f, 1f);
            g.blit(LOGO, 0, 0, 0, 0, 870, 440, 870, 440);
            g.pose().popPose();
        } else if (i == 3) {
            float is = Math.min(cardW, cardH) * 0.6f / 16f;
            g.pose().pushPose();
            g.pose().translate(cx - 8f * is + ox, cardY + cardH * 0.45f - 8f * is + oy, 0f);
            g.pose().scale(is, is, 1f);
            g.renderItem(new ItemStack(Items.GRASS_BLOCK), 0, 0);
            g.pose().popPose();
        } else {
            int qs = Math.max(2, cardW / 24);
            Component q = Component.literal("?").withStyle(OP);
            g.pose().pushPose();
            g.pose().translate(cx - this.font.width(q) * qs / 2f + ox, cardY + cardH * 0.42f - 5f * qs + oy, 0f);
            g.pose().scale(qs, qs, 1f);
            g.drawString(this.font, q, 0, 0, 0xAAFFFFFF, false);
            g.pose().popPose();
            g.drawCenteredString(this.font, ru ? "СКОРО" : "SOON", (int) cx, cardY + cardH - 14, 0x999999);
            g.fill(x, cardY, x + cardW, cardY + cardH, 0x55000000);
        }

        if (IDS[i].equals(MenuChoice.current()))
            g.drawCenteredString(this.font, ru ? "ОСНОВНОЕ" : "MAIN", (int) cx, cardY + cardH - 12, 0xFFE9A8);

        float edge = Math.max(h, sel);
        frame(g, x, cardY, x + cardW, cardY + cardH, sel > 0f ? 2 : 1, (((int) (0x55 + 0xAA * edge)) << 24) | 0xFFFFFF);

        g.fill(x, top, x + cardW, top + LABEL_H, 0x99000000);
        g.drawCenteredString(this.font, NAMES[i], x + cardW / 2, top + 2, open ? 0xFFFFFF : 0xAAAAAA);

        int sx0 = x + (cardW - SQ) / 2;
        int sy0 = cardY + cardH + 5;
        g.fill(sx0, sy0, sx0 + SQ, sy0 + SQ, open ? 0x33FFFFFF : 0x15FFFFFF);
        frame(g, sx0, sy0, sx0 + SQ, sy0 + SQ, 1, open ? 0xFFFFFFFF : 0x55FFFFFF);
        int fh = Math.round((SQ - 2) * fill[i]);
        if (fh > 0) g.fill(sx0 + 1, sy0 + SQ - 1 - fh, sx0 + SQ - 1, sy0 + SQ - 1, 0xFFFFFFFF);

        g.pose().popPose();
    }

    private void updateConfirm(GuiGraphics g, float dt) {
        float target = selected >= 0 ? 1f : 0f;
        confirmA += (target - confirmA) * Math.min(1f, dt * 8f);
        confirm.visible = confirmA > 0.02f;
        confirm.active  = confirmA > 0.9f;
        confirm.setAlpha(confirmA);
        confirm.setY(this.height - 28 + Math.round((1f - confirmA) * 10f));

        int ha = (int) ((1f - confirmA) * 200f);
        if (ha > 4) {
            String hint = ru ? "Удерживайте левую кнопку мыши на нужном меню" : "Hold the left mouse button on the menu you want";
            g.drawCenteredString(this.font, hint, this.width / 2, this.height - 20, (ha << 24) | 0xCCCCCC);
        }
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(parent);
    }

    @Override
    public void removed() {
        if (bg != null) {
            bg.close();
            bg = null;
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
