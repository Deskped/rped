package deskped.rped.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class NovamBrautItem extends Item {
	public NovamBrautItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON));
	}
}