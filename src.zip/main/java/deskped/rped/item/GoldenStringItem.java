package deskped.rped.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.network.chat.Component;

import java.util.List;

public class GoldenStringItem extends Item {
	public GoldenStringItem() {
		super(new Item.Properties().rarity(Rarity.UNCOMMON));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, level, list, flag);
		list.add(Component.translatable("item.rped.golden_string.description_0"));
		list.add(Component.translatable("item.rped.golden_string.description_1"));
		list.add(Component.translatable("item.rped.golden_string.description_2"));
		list.add(Component.translatable("item.rped.golden_string.description_3"));
		list.add(Component.translatable("item.rped.golden_string.description_4"));
		list.add(Component.translatable("item.rped.golden_string.description_5"));
	}
}