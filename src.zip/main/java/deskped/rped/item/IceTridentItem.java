package deskped.rped.item;

import deskped.rped.ice.IceCrystal;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

public class IceTridentItem extends SwordItem {

    public IceTridentItem() {
        super(new Tier() {
            public int getUses() {
                return 0;
            }

            public float getSpeed() {
                return 0f;
            }

            public float getAttackDamageBonus() {
                return 24f;
            }

            public int getLevel() {
                return 0;
            }

            public int getEnchantmentValue() {
                return 1;
            }

            public Ingredient getRepairIngredient() {
                return Ingredient.of();
            }
        }, 3, -2.7f, new Item.Properties());
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!player.isShiftKeyDown()) {
            return InteractionResultHolder.pass(stack);
        }
        if (player.getCooldowns().isOnCooldown(this) || player.hasEffect(IceCrystal.ETERNAL_ICE_CRYSTAL)) {
            return InteractionResultHolder.fail(stack);
        }
        if (!level.isClientSide) {
            IceCrystal.activate(player);
            player.getCooldowns().addCooldown(this, IceCrystal.COOLDOWN_TICKS);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
