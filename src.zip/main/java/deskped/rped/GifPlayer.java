package deskped.rped;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.lwjgl.system.MemoryUtil;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.stream.ImageInputStream;
import javax.imageio.stream.MemoryCacheImageInputStream;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.awt.image.IndexColorModel;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.Iterator;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

@OnlyIn(Dist.CLIENT)
public final class GifPlayer {

    private static final int POOL    = 12;
    private static final int PREROLL = 6;

    private static final class Frame {
        final ByteBuffer buf;
        final long startMs;

        Frame(ByteBuffer buf, long startMs) {
            this.buf = buf;
            this.startMs = startMs;
        }
    }

    private final byte[] data;
    private final boolean loop;
    private final String texName;
    private final ArrayBlockingQueue<Frame> queue = new ArrayBlockingQueue<>(POOL);
    private final ArrayBlockingQueue<ByteBuffer> free = new ArrayBlockingQueue<>(POOL);

    private volatile int w;
    private volatile int h;
    private volatile boolean done;
    private volatile boolean failed;
    private volatile boolean stop;
    private volatile long totalMs;
    private long cursor;

    private long clockStart = -1L;
    private DynamicTexture dyn;
    private ResourceLocation tex;
    private boolean shown;

    private GifPlayer(byte[] data, boolean loop, String texName) {
        this.data = data;
        this.loop = loop;
        this.texName = texName;
    }

    public static GifPlayer open(ResourceLocation gif, boolean loop, String texName) {
        try {
            var opt = Minecraft.getInstance().getResourceManager().getResource(gif);
            if (opt.isEmpty()) return null;
            byte[] bytes;
            try (InputStream in = opt.get().open()) { bytes = in.readAllBytes(); }
            GifPlayer p = new GifPlayer(bytes, loop, texName);
            Thread th = new Thread(p::decode, "rped-gif-" + texName);
            th.setDaemon(true);
            th.start();
            return p;
        } catch (Throwable e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean failed()   { return failed; }
    public boolean ready()    { return w > 0 && (queue.size() >= PREROLL || done); }
    public boolean finished() { return done; }
    public boolean shown()    { return shown; }
    public long totalMs()     { return totalMs; }
    public int width()        { return w; }
    public int height()       { return h; }

    public long elapsed(long now) {
        return clockStart < 0L ? 0L : now - clockStart;
    }

    public boolean update(long now) {
        if (failed) return false;
        if (clockStart < 0L) {
            if (!ready()) return false;
            clockStart = now;
        }
        long el = now - clockStart;
        Frame cur = null;
        for (;;) {
            Frame f = queue.peek();
            if (f == null || f.startMs > el) break;
            queue.poll();
            if (cur != null) free.offer(cur.buf);
            cur = f;
        }
        if (cur != null) upload(cur);
        return shown;
    }

    private void upload(Frame f) {
        if (dyn == null) {
            dyn = new DynamicTexture(w, h, false);
            tex = ResourceLocation.fromNamespaceAndPath("rped", "dyn/" + texName);
            Minecraft.getInstance().getTextureManager().register(tex, dyn);
            dyn.setFilter(true, false);
        }
        dyn.bind();
        GlStateManager._pixelStore(3314, 0);
        GlStateManager._pixelStore(3315, 0);
        GlStateManager._pixelStore(3316, 0);
        GlStateManager._pixelStore(3317, 4);
        GlStateManager._texSubImage2D(3553, 0, 0, 0, w, h, 6408, 5121, MemoryUtil.memAddress(f.buf));
        free.offer(f.buf);
        shown = true;
    }

    public void draw(GuiGraphics g, int sw, int sh, float alpha, float maxZoom) {
        if (!shown || tex == null || alpha <= 0.003f) return;
        int gw = w;
        int gh = h;
        float contain = Math.min(sw / (float) gw, sh / (float) gh);
        float cover   = Math.max(sw / (float) gw, sh / (float) gh);
        float s = Math.min(cover, contain * maxZoom);
        float a = Math.min(1f, alpha);
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        RenderSystem.setShaderColor(a, a, a, a);
        g.pose().pushPose();
        g.pose().translate(sw * 0.5f, sh * 0.5f, 0f);
        g.pose().scale(s, s, 1f);
        g.pose().translate(-gw * 0.5f, -gh * 0.5f, 0f);
        g.blit(tex, 0, 0, 0, 0, gw, gh, gw, gh);
        g.pose().popPose();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    public void close() {
        stop = true;
        shown = false;
        if (tex != null) {
            Minecraft.getInstance().getTextureManager().release(tex);
            tex = null;
            dyn = null;
        }
    }

    private void decode() {
        int decoded = 0;
        try (ImageInputStream iis = new MemoryCacheImageInputStream(new ByteArrayInputStream(data))) {
            Iterator<ImageReader> it = ImageIO.getImageReadersByFormatName("gif");
            if (!it.hasNext()) { failed = true; return; }
            ImageReader r = it.next();
            r.setInput(iis, false, false);
            int cw = 0;
            int ch = 0;
            try {
                Node sroot = r.getStreamMetadata().getAsTree("javax_imageio_gif_stream_1.0");
                for (Node n = sroot.getFirstChild(); n != null; n = n.getNextSibling()) {
                    if (n.getNodeName().equals("LogicalScreenDescriptor")) {
                        NamedNodeMap at = n.getAttributes();
                        cw = Integer.parseInt(at.getNamedItem("logicalScreenWidth").getNodeValue());
                        ch = Integer.parseInt(at.getNamedItem("logicalScreenHeight").getNodeValue());
                    }
                }
            } catch (Exception ignored) {}
            int[] canvas = null;
            int[] out = null;
            int[] saved = null;
            int[] px = new int[0];
            int[] pal = new int[256];
            int prevDisp = 0;
            int pl = 0;
            int pt = 0;
            int pw = 0;
            int ph = 0;
            int pass = 0;
            for (int i = 0; !stop; i++) {
                BufferedImage bi;
                int left = 0;
                int top = 0;
                int disp = 0;
                int delay = 10;
                try {
                    IIOMetadata md = r.getImageMetadata(i);
                    Node root = md.getAsTree("javax_imageio_gif_image_1.0");
                    for (Node n = root.getFirstChild(); n != null; n = n.getNextSibling()) {
                        NamedNodeMap at = n.getAttributes();
                        switch (n.getNodeName()) {
                            case "ImageDescriptor" -> {
                                left = Integer.parseInt(at.getNamedItem("imageLeftPosition").getNodeValue());
                                top = Integer.parseInt(at.getNamedItem("imageTopPosition").getNodeValue());
                            }
                            case "GraphicControlExtension" -> {
                                String dm = at.getNamedItem("disposalMethod").getNodeValue();
                                disp = dm.equals("restoreToBackgroundColor") ? 2 : dm.equals("restoreToPrevious") ? 3 : 0;
                                delay = Math.max(1, Integer.parseInt(at.getNamedItem("delayTime").getNodeValue())) * 10;
                            }
                            default -> { }
                        }
                    }
                    bi = r.read(i);
                } catch (Exception e) {
                    if (loop && pass > 1) {
                        i = -1;
                        pass = 0;
                        prevDisp = 0;
                        if (canvas != null) Arrays.fill(canvas, 0);
                        continue;
                    }
                    break;
                }
                int fw = bi.getWidth();
                int fh = bi.getHeight();
                if (canvas == null) {
                    if (cw <= 0 || ch <= 0) { cw = left + fw; ch = top + fh; }
                    canvas = new int[cw * ch];
                    out = new int[cw * ch];
                    saved = new int[cw * ch];
                    for (int k = 0; k < POOL; k++)
                        free.offer(ByteBuffer.allocateDirect(cw * ch * 4).order(ByteOrder.nativeOrder()));
                    h = ch;
                    w = cw;
                }
                if (i > 0) {
                    if (prevDisp == 2) {
                        for (int y = pt; y < Math.min(ch, pt + ph); y++)
                            for (int x = pl; x < Math.min(cw, pl + pw); x++)
                                canvas[y * cw + x] = 0;
                    } else if (prevDisp == 3) {
                        System.arraycopy(saved, 0, canvas, 0, canvas.length);
                    }
                }
                if (disp == 3) System.arraycopy(canvas, 0, saved, 0, canvas.length);
                if (px.length < fw * fh) px = new int[fw * fh];
                if (bi.getType() == BufferedImage.TYPE_BYTE_INDEXED
                        && bi.getColorModel() instanceof IndexColorModel icm
                        && bi.getRaster().getDataBuffer() instanceof DataBufferByte db
                        && db.getData().length >= fw * fh) {
                    Arrays.fill(pal, 0);
                    icm.getRGBs(pal);
                    byte[] d = db.getData();
                    for (int k = 0; k < fw * fh; k++) px[k] = pal[d[k] & 255];
                } else {
                    bi.getRGB(0, 0, fw, fh, px, 0, fw);
                }
                for (int y = 0; y < fh; y++) {
                    int cy = top + y;
                    if (cy < 0 || cy >= ch) continue;
                    for (int x = 0; x < fw; x++) {
                        int cx = left + x;
                        if (cx < 0 || cx >= cw) continue;
                        int c = px[y * fw + x];
                        if ((c >>> 24) != 0) canvas[cy * cw + cx] = c;
                    }
                }
                pl = left;
                pt = top;
                pw = fw;
                ph = fh;
                prevDisp = disp;
                for (int k = 0; k < canvas.length; k++) {
                    int c = canvas[k];
                    out[k] = (c & 0xFF00FF00) | ((c >> 16) & 255) | ((c & 255) << 16);
                }
                ByteBuffer buf = null;
                while (!stop && (buf = free.poll(40, TimeUnit.MILLISECONDS)) == null) { }
                if (stop) break;
                buf.clear();
                buf.asIntBuffer().put(out);
                queue.offer(new Frame(buf, cursor));
                cursor += delay;
                decoded++;
                pass++;
            }
            if (decoded == 0) { failed = true; return; }
            totalMs = cursor;
            done = true;
        } catch (Throwable e) {
            e.printStackTrace();
            if (decoded == 0) failed = true;
            else { totalMs = cursor; done = true; }
        }
    }
}
