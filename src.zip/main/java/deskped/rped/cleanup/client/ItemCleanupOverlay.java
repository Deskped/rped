package deskped.rped.cleanup.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "rped", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ItemCleanupOverlay implements IGuiOverlay {

	private static final int PAD = 5;
	private static final int WARN_TICKS = 60 * 20;

	@Override
	public void render(ForgeGui gui, GuiGraphics g, float partialTick, int screenWidth, int screenHeight) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null || mc.options.hideGui)
			return;

		int mode = ItemCleanupState.mode();
		if (mode == ItemCleanupState.MODE_HIDDEN)
			return;

		boolean done = mode == ItemCleanupState.MODE_DONE;
		int ticks = Math.max(0, ItemCleanupState.ticks());

		float mul = 1.0f;
		if (done && ticks < 20)
			mul = ticks / 20.0f;
		if (mul <= 0.02f)
			return;

		boolean ru = isRussian();
		String label = done
				? (ru ? "Предметы в мире очищены" : "World items cleared")
				: (ru ? "Удаление предметов" : "Item cleanup");

		int seconds = (ticks + 19) / 20;
		String timer = done ? "" : (seconds / 60) + ":" + String.format("%02d", seconds % 60);

		int labelW = mc.font.width(label);
		int timerW = done ? 0 : mc.font.width(timer);
		int textW = Math.max(labelW, timerW);

		int panelW = PAD * 2 + textW;
		int panelH = done ? PAD * 2 + 8 : PAD * 2 + 20;

		int x0 = screenWidth - panelW - 4;
		int y0 = screenHeight - panelH - 4;
		if (x0 < screenWidth / 2 + 95)
			y0 = screenHeight - panelH - 26;

		g.fill(x0, y0, x0 + panelW, y0 + panelH, color(0x000000, 0xA6, mul));
		g.fill(x0, y0, x0 + panelW, y0 + 1, color(0xFFFFFF, 0x22, mul));
		g.fill(x0, y0 + panelH - 1, x0 + panelW, y0 + panelH, color(0xFFFFFF, 0x22, mul));
		g.fill(x0 + panelW - 1, y0, x0 + panelW, y0 + panelH, color(0xFFFFFF, 0x22, mul));

		int textX = x0 + PAD;

		if (done) {
			g.drawString(mc.font, label, textX, y0 + PAD, color(0xFFFFFF, 0xFF, mul), false);
		} else {
			g.drawString(mc.font, label, textX, y0 + PAD, color(0xFFFFFF, 0xFF, mul), false);
			g.drawString(mc.font, timer, textX, y0 + PAD + 12, color(0xFFFFFF, 0xFF, mul), false);
		}
	}

	private static int color(int rgb, int baseAlpha, float mul) {
		int a = (int) (baseAlpha * mul);
		if (a < 8)
			a = 8;
		if (a > 255)
			a = 255;
		return (a << 24) | (rgb & 0xFFFFFF);
	}

	private static boolean isRussian() {
		try {
			String lang = Minecraft.getInstance().getLanguageManager().getSelected();
			return lang != null && lang.startsWith("ru");
		} catch (Exception e) {
			return false;
		}
	}

	@SubscribeEvent
	public static void registerOverlay(RegisterGuiOverlaysEvent event) {
		event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "rped_item_cleanup", new ItemCleanupOverlay());
	}
}