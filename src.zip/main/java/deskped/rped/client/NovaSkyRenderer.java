package deskped.rped.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.DimensionSpecialEffects;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.material.FogType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;
import org.joml.Vector3f;

@Mod.EventBusSubscriber(modid = NovaSkyRenderer.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class NovaSkyRenderer {
    public static final String MOD_ID = "rped";

    private static final ResourceLocation SHEET = new ResourceLocation(MOD_ID, "textures/environment/nova.png");

    private static final int COLUMNS = 10;
    private static final int ROWS = 6;
    private static final int FRAMES = 60;
    private static final float SHEET_WIDTH = 1280.0F;
    private static final float SHEET_HEIGHT = 768.0F;
    private static final long TICKS_PER_FRAME = 30L;

    private static final float SKY_DISTANCE = 100.0F;
    private static final float BASE_HALF_SIZE = 14.0F;
    private static final float MIN_SCALE = 0.7F;
    private static final float MAX_SCALE = 2.0F;

    private static final double ROLL_TICKS_PER_TURN = 6000.0;

    private static final float DAY_ALPHA = 0.4F;
    private static final float NIGHT_ALPHA = 1.0F;
    private static final float DAY_BRIGHTNESS = 0.9F;
    private static final float NIGHT_BRIGHTNESS = 1.15F;

    private static final double TAU = Math.PI * 2.0;
    private static final double DRIFT_SPEED = 0.1;
    private static final double AZIMUTH_PERIOD_A = 96000.0;
    private static final double AZIMUTH_PERIOD_B = 57000.0;
    private static final double ELEVATION_PERIOD_A = 31000.0;
    private static final double ELEVATION_PERIOD_B = 17000.0;
    private static final double SIZE_PERIOD_A = 41000.0;
    private static final double SIZE_PERIOD_B = 23000.0;

    private NovaSkyRenderer() {
    }

    @SubscribeEvent
    public static void onRenderLevelStage(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_SKY) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null || level.effects().skyType() != DimensionSpecialEffects.SkyType.NORMAL) {
            return;
        }
        Camera camera = event.getCamera();
        if (camera.getFluidInCamera() != FogType.NONE) {
            return;
        }
        if (camera.getEntity() instanceof LivingEntity living && living.hasEffect(MobEffects.BLINDNESS)) {
            return;
        }

        float partial = event.getPartialTick();
        long gameTime = level.getGameTime();
        double time = gameTime + (double) partial;
        double drift = time * DRIFT_SPEED;

        double azimuth = Math.toRadians(
                170.0 * Math.sin(TAU * drift / AZIMUTH_PERIOD_A + 0.6)
                        + 110.0 * Math.sin(TAU * drift / AZIMUTH_PERIOD_B + 2.1));
        double elevation = Math.toRadians(
                40.0 + 22.0 * Math.sin(TAU * drift / ELEVATION_PERIOD_A + 1.3)
                        + 8.0 * Math.sin(TAU * drift / ELEVATION_PERIOD_B + 4.0));

        double cosEl = Math.cos(elevation);
        Vector3f dir = new Vector3f(
                (float) (Math.sin(azimuth) * cosEl),
                (float) Math.sin(elevation),
                (float) (-Math.cos(azimuth) * cosEl));
        Vector3f right = new Vector3f(dir).cross(0.0F, 1.0F, 0.0F).normalize();
        Vector3f up = new Vector3f(right).cross(dir).normalize();
        Vector3f center = new Vector3f(dir).mul(SKY_DISTANCE);

        double turns = time / ROLL_TICKS_PER_TURN;
        float roll = (float) ((turns - Math.floor(turns)) * TAU);
        float cos = Mth.cos(roll);
        float sin = Mth.sin(roll);
        Vector3f spriteRight = new Vector3f(right).mul(cos).fma(-sin, up);
        Vector3f spriteUp = new Vector3f(up).mul(cos).fma(sin, right);

        double sizeWave = 0.6 * Math.sin(TAU * time / SIZE_PERIOD_A + 0.9)
                + 0.4 * Math.sin(TAU * time / SIZE_PERIOD_B + 3.3);
        float scale = Mth.lerp(smoothstep(0.15F, 0.85F, (float) sizeWave), MIN_SCALE, MAX_SCALE);
        float half = BASE_HALF_SIZE * scale;

        float sunHeight = Mth.cos(level.getTimeOfDay(partial) * (float) TAU);
        float night = smoothstep(0.2F, -0.2F, sunHeight);
        float weather = 1.0F - 0.8F * level.getRainLevel(partial);
        float alpha = Mth.lerp(night, DAY_ALPHA, NIGHT_ALPHA) * weather;
        float brightness = Mth.lerp(night, DAY_BRIGHTNESS, NIGHT_BRIGHTNESS);

        int frame = (int) ((gameTime / TICKS_PER_FRAME) % FRAMES);
        int col = frame % COLUMNS;
        int row = frame / COLUMNS;
        float u0 = col / (float) COLUMNS + 0.5F / SHEET_WIDTH;
        float u1 = (col + 1) / (float) COLUMNS - 0.5F / SHEET_WIDTH;
        float v0 = row / (float) ROWS + 0.5F / SHEET_HEIGHT;
        float v1 = (row + 1) / (float) ROWS - 0.5F / SHEET_HEIGHT;

        Matrix4f pose = event.getPoseStack().last().pose();

        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShaderTexture(0, SHEET);
        RenderSystem.setShaderColor(brightness, brightness, brightness, alpha);

        drawQuad(pose, center, spriteRight, spriteUp, half, u0, v0, u1, v1);

        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private static void drawQuad(Matrix4f pose, Vector3f center, Vector3f right, Vector3f up, float half,
                                 float u0, float v0, float u1, float v1) {
        float rx = right.x() * half;
        float ry = right.y() * half;
        float rz = right.z() * half;
        float ux = up.x() * half;
        float uy = up.y() * half;
        float uz = up.z() * half;

        BufferBuilder builder = Tesselator.getInstance().getBuilder();
        builder.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
        builder.vertex(pose, center.x() - rx + ux, center.y() - ry + uy, center.z() - rz + uz).uv(u0, v0).endVertex();
        builder.vertex(pose, center.x() + rx + ux, center.y() + ry + uy, center.z() + rz + uz).uv(u1, v0).endVertex();
        builder.vertex(pose, center.x() + rx - ux, center.y() + ry - uy, center.z() + rz - uz).uv(u1, v1).endVertex();
        builder.vertex(pose, center.x() - rx - ux, center.y() - ry - uy, center.z() - rz - uz).uv(u0, v1).endVertex();
        BufferUploader.drawWithShader(builder.end());
    }

    private static float smoothstep(float edge0, float edge1, float x) {
        float t = Mth.clamp((x - edge0) / (edge1 - edge0), 0.0F, 1.0F);
        return t * t * (3.0F - 2.0F * t);
    }
}