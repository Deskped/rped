package deskped.rped.client.raid;

import net.minecraftforge.network.PacketDistributor;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import deskped.rped.RpedMod;
import deskped.rped.entity.ChirlikEntity;
import deskped.rped.init.RpedModBlocks;
import deskped.rped.init.RpedModEntities;
import deskped.rped.init.RpedModItems;
import deskped.rped.network.ScarecrowRaidTimerPacket;

public class ScarecrowRaids extends SavedData {
	public static final int HEADS_REQUIRED = 33;
	public static final int MAX_STAGE = 33;
	public static final int RADIUS = 6;
	public static final int TIME_LIMIT_TICKS = 8 * 60 * 20;
	public static final int STAGE_DELAY_TICKS = 40;
	public static final int MAX_ALIVE = 64;
	public static final int SPAWN_BATCH = 8;
	public static final double SYNC_RANGE = 96.0;
	public static final double HOVER_HEIGHT = 0.7;
	public static final double RISE_SPEED = 0.03;
	public static final float EXTRA_DROP_CHANCE = 0.5f;
	public static final int MAX_STACK = 3;
	public static final double STACK_BONUS = 0.25;
	public static final float CLIMB_CHANCE = 0.3f;
	public static final String RAID_TAG = "rped_scarecrow_raid";

	private static final String DATA_NAME = "rped_scarecrow_raids";
	private static final UUID STACK_HEALTH_ID = UUID.fromString("5a3f0f3e-8d1b-4c2a-9f55-3c1d7b9e1a01");
	private static final UUID STACK_DAMAGE_ID = UUID.fromString("5a3f0f3e-8d1b-4c2a-9f55-3c1d7b9e1a02");
	private static final String KEY_TITLE = "message.rped.raid.title";
	private static final String KEY_HEADS = "message.rped.raid.heads";
	private static final String KEY_BUSY = "message.rped.raid.busy";
	private static final String KEY_START = "message.rped.raid.start";
	private static final String KEY_WIN = "message.rped.raid.win";
	private static final String KEY_FAIL = "message.rped.raid.fail";

	private final Map<Long, Integer> heads = new HashMap<>();
	private final Map<Long, Raid> raids = new LinkedHashMap<>();
	private final List<Riser> risers = new ArrayList<>();

	public static ScarecrowRaids get(ServerLevel level) {
		return level.getDataStorage().computeIfAbsent(ScarecrowRaids::load, ScarecrowRaids::new, DATA_NAME);
	}

	public static int chirlikCount(int stage) {
		return Math.max(3, (int) Math.round(3.0 * Math.pow(1.07, stage - 1)));
	}

	public static double chirlikHealth(int stage) {
		return 6.0 + 1.5 * (stage - 1);
	}

	public static double chirlikDamage(int stage) {
		return 1.0 + 0.35 * (stage - 1);
	}

	public boolean hasRaid(long key) {
		return raids.containsKey(key);
	}

	public Component status(BlockPos pos) {
		long key = pos.asLong();
		Raid r = raids.get(key);
		if (r != null)
			return r.title();
		return Component.translatable(KEY_HEADS, heads.getOrDefault(key, 0), HEADS_REQUIRED);
	}

	public void acceptHeads(ServerLevel level, BlockPos pos, Player player, ItemStack stack) {
		long key = pos.asLong();
		if (raids.containsKey(key)) {
			player.displayClientMessage(Component.translatable(KEY_BUSY), true);
			return;
		}
		int have = heads.getOrDefault(key, 0);
		int take = Math.min(HEADS_REQUIRED - have, stack.getCount());
		if (take <= 0)
			return;
		if (!player.getAbilities().instabuild)
			stack.shrink(take);
		have += take;
		if (have >= HEADS_REQUIRED) {
			heads.remove(key);
			start(level, pos);
		} else {
			heads.put(key, have);
			player.displayClientMessage(Component.translatable(KEY_HEADS, have, HEADS_REQUIRED), true);
		}
		setDirty();
	}

	public void onChirlikDeath(long key, UUID id, boolean byPlayer) {
		Raid r = raids.get(key);
		if (r == null)
			return;
		r.misses.remove(id);
		if (r.tracked.remove(id) != null && !byPlayer)
			r.pool++;
		setDirty();
	}

	private void start(ServerLevel level, BlockPos pos) {
		Raid r = new Raid(pos.asLong());
		r.beginStage();
		r.delay = STAGE_DELAY_TICKS;
		raids.put(r.pos, r);
		broadcast(level, pos, Component.translatable(KEY_START));
		syncPlayers(level, r, pos);
		setDirty();
	}

	public void tick(ServerLevel level) {
		if (raids.isEmpty() && risers.isEmpty())
			return;
		for (Raid r : new ArrayList<>(raids.values()))
			tickRaid(level, r);
		tickRisers(level);
		if (!raids.isEmpty() && level.getGameTime() % 100 == 0)
			setDirty();
	}

	private void tickRaid(ServerLevel level, Raid r) {
		BlockPos pos = BlockPos.of(r.pos);
		if (!level.hasChunkAt(pos))
			return;
		if (!level.getBlockState(pos).is(RpedModBlocks.SCARECROW.get())) {
			end(level, r, true);
			return;
		}
		long t = level.getGameTime();
		r.timeLeft--;
		if (r.timeLeft <= 0) {
			broadcast(level, pos, Component.translatable(KEY_FAIL));
			end(level, r, true);
			return;
		}
		if (r.delay > 0)
			r.delay--;
		else if (r.pool > 0 && t % 5 == 0)
			spawnBatch(level, r, pos);
		if (t % 5 == 0)
			reconcile(level, r);
		if (t % 20 == 0)
			syncPlayers(level, r, pos);
		if (r.delay <= 0 && r.pool <= 0 && r.tracked.isEmpty()) {
			if (r.stage >= MAX_STAGE) {
				win(level, r, pos);
				return;
			}
			r.stage++;
			r.beginStage();
			r.delay = STAGE_DELAY_TICKS;
			reconcile(level, r);
			setDirty();
		}
	}

	private void spawnBatch(ServerLevel level, Raid r, BlockPos center) {
		int n = Math.min(r.pool, Math.min(SPAWN_BATCH, MAX_ALIVE - r.tracked.size()));
		double hp = chirlikHealth(r.stage);
		double dmg = chirlikDamage(r.stage);
		for (int i = 0; i < n; i++) {
			ChirlikEntity mob = RpedModEntities.CHIRLIK.get().create(level);
			r.pool--;
			if (mob == null)
				continue;
			double angle = Math.PI * 2.0 * r.ring / Math.max(1, r.stageTotal);
			r.ring++;
			double x = center.getX() + 0.5 + Math.cos(angle) * RADIUS;
			double z = center.getZ() + 0.5 + Math.sin(angle) * RADIUS;
			BlockPos ground = findGround(level, Mth.floor(x), Mth.floor(z), center.getY());
			if (ground == null) {
				x = center.getX() + 0.5;
				z = center.getZ() + 0.5;
				ground = center.above();
			}
			mob.moveTo(x, ground.getY(), z, level.random.nextFloat() * 360.0f, 0.0f);
			setBase(mob, Attributes.MAX_HEALTH, hp);
			setBase(mob, Attributes.ATTACK_DAMAGE, dmg);
			setBase(mob, Attributes.FOLLOW_RANGE, 48.0);
			mob.setHealth((float) hp);
			mob.setPersistenceRequired();
			mob.getPersistentData().putLong(RAID_TAG, r.pos);
			strike(level, x, ground.getY(), z);
			if (!level.addFreshEntity(mob))
				continue;
			r.tracked.put(mob.getUUID(), mob.blockPosition().asLong());
			Player target = level.getNearestPlayer(mob, 48.0);
			if (target != null && !target.isSpectator())
				mob.setTarget(target);
		}
		setDirty();
	}

	private static void strike(ServerLevel level, double x, double y, double z) {
		LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
		if (bolt == null)
			return;
		bolt.moveTo(x, y, z);
		bolt.setVisualOnly(true);
		level.addFreshEntity(bolt);
	}

	private static int stackSize(ChirlikEntity c) {
		int size = 1;
		Entity below = c.getVehicle();
		while (below instanceof ChirlikEntity) {
			size++;
			below = below.getVehicle();
		}
		Entity above = c.getFirstPassenger();
		while (above instanceof ChirlikEntity) {
			size++;
			above = above.getFirstPassenger();
		}
		return size;
	}

	private static void applyBonus(ChirlikEntity c, Attribute attribute, UUID id, String name, double bonus) {
		AttributeInstance instance = c.getAttribute(attribute);
		if (instance == null)
			return;
		AttributeModifier current = instance.getModifier(id);
		if (current != null && Math.abs(current.getAmount() - bonus) < 1.0E-6)
			return;
		if (current == null && bonus <= 0.0)
			return;
		float oldMax = c.getMaxHealth();
		if (current != null)
			instance.removeModifier(id);
		if (bonus > 0.0)
			instance.addTransientModifier(new AttributeModifier(id, name, bonus, AttributeModifier.Operation.MULTIPLY_BASE));
		if (attribute == Attributes.MAX_HEALTH) {
			float newMax = c.getMaxHealth();
			if (newMax > oldMax)
				c.setHealth(c.getHealth() + newMax - oldMax);
			else if (c.getHealth() > newMax)
				c.setHealth(newMax);
		}
	}

	private static void climb(ServerLevel level, List<ChirlikEntity> alive) {
		for (ChirlikEntity a : alive) {
			if (!a.isAlive() || a.isPassenger() || a.isVehicle())
				continue;
			LivingEntity target = a.getTarget();
			if (target == null || a.distanceToSqr(target) > 100.0 || level.random.nextFloat() >= CLIMB_CHANCE)
				continue;
			ChirlikEntity best = null;
			double bestDist = 4.0;
			for (ChirlikEntity b : alive) {
				if (b == a || !b.isAlive() || b.isVehicle() || stackSize(b) >= MAX_STACK)
					continue;
				if (Math.abs(a.getY() - b.getRootVehicle().getY()) > 1.0)
					continue;
				double dx = a.getX() - b.getX();
				double dz = a.getZ() - b.getZ();
				double d = dx * dx + dz * dz;
				if (d < bestDist) {
					bestDist = d;
					best = b;
				}
			}
			if (best != null && a.startRiding(best, true))
				a.getNavigation().stop();
		}
		for (ChirlikEntity c : alive) {
			if (!c.isAlive())
				continue;
			double bonus = STACK_BONUS * (stackSize(c) - 1);
			applyBonus(c, Attributes.MAX_HEALTH, STACK_HEALTH_ID, "rped_stack_health", bonus);
			applyBonus(c, Attributes.ATTACK_DAMAGE, STACK_DAMAGE_ID, "rped_stack_damage", bonus);
		}
	}

	private static void setBase(ChirlikEntity mob, Attribute attribute, double value) {
		AttributeInstance instance = mob.getAttribute(attribute);
		if (instance != null)
			instance.setBaseValue(value);
	}

	private static BlockPos findGround(ServerLevel level, int bx, int bz, int centerY) {
		for (int dy = 4; dy >= -6; dy--) {
			BlockPos p = new BlockPos(bx, centerY + dy, bz);
			BlockPos above = p.above();
			BlockPos below = p.below();
			if (level.getBlockState(p).getCollisionShape(level, p).isEmpty() && level.getBlockState(above).getCollisionShape(level, above).isEmpty() && !level.getBlockState(below).getCollisionShape(level, below).isEmpty()
					&& level.getFluidState(p).isEmpty())
				return p;
		}
		return null;
	}

	private void reconcile(ServerLevel level, Raid r) {
		double hp = chirlikHealth(r.stage);
		double left = r.pool * hp;
		List<ChirlikEntity> alive = new ArrayList<>();
		Iterator<Map.Entry<UUID, Long>> it = r.tracked.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<UUID, Long> entry = it.next();
			Entity e = level.getEntity(entry.getKey());
			if (e instanceof ChirlikEntity c) {
				r.misses.remove(entry.getKey());
				if (!c.isAlive())
					continue;
				entry.setValue(c.blockPosition().asLong());
				alive.add(c);
				left += c.getHealth();
				if (c.getTarget() == null) {
					Player p = level.getNearestPlayer(c, 48.0);
					if (p != null && !p.isSpectator())
						c.setTarget(p);
				}
				continue;
			}
			if (e == null && level.hasChunkAt(BlockPos.of(entry.getValue()))) {
				int misses = r.misses.merge(entry.getKey(), 1, Integer::sum);
				if (misses >= 4) {
					r.misses.remove(entry.getKey());
					it.remove();
					r.pool++;
					setDirty();
				}
			}
			left += hp;
		}
		climb(level, alive);
		ServerBossEvent bar = r.bar();
		if (r.barStage != r.stage) {
			bar.setName(r.title());
			r.barStage = r.stage;
		}
		double total = Math.max(1.0, r.stageTotal * hp);
		bar.setProgress((float) Mth.clamp(left / total, 0.0, 1.0));
	}

	private void syncPlayers(ServerLevel level, Raid r, BlockPos pos) {
		double range = SYNC_RANGE * SYNC_RANGE;
		ServerBossEvent bar = r.bar();
		for (ServerPlayer p : level.players()) {
			if (p.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= range) {
				bar.addPlayer(p);
				send(p, pos, true, r.timeLeft, r.stage);
			} else {
				bar.removePlayer(p);
			}
		}
	}

	private static void send(ServerPlayer player, BlockPos pos, boolean active, int remaining, int stage) {
		RpedMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> player), new ScarecrowRaidTimerPacket(pos, player.level().dimension().location(), active, remaining, stage));
	}

	private static void broadcast(ServerLevel level, BlockPos pos, Component message) {
		double range = SYNC_RANGE * SYNC_RANGE;
		for (ServerPlayer p : level.players())
			if (p.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= range)
				p.sendSystemMessage(message);
	}

	private void end(ServerLevel level, Raid r, boolean discardMobs) {
		raids.remove(r.pos);
		if (discardMobs) {
			for (UUID id : r.tracked.keySet()) {
				Entity e = level.getEntity(id);
				if (e != null)
					e.discard();
			}
		}
		if (r.bar != null) {
			r.bar.removeAllPlayers();
			r.bar.setVisible(false);
		}
		BlockPos endPos = BlockPos.of(r.pos);
		for (ServerPlayer p : level.players())
			send(p, endPos, false, 0, r.stage);
		setDirty();
	}

	private void win(ServerLevel level, Raid r, BlockPos pos) {
		end(level, r, false);
		broadcast(level, pos, Component.translatable(KEY_WIN));
		double y = pos.getY() + 1.001;
		ItemEntity item = new ItemEntity(level, pos.getX() + 0.5, y, pos.getZ() + 0.5, new ItemStack(RpedModItems.TOMBSTONE.get()));
		item.setNoGravity(true);
		item.setUnlimitedLifetime();
		item.setInvulnerable(true);
		item.setDeltaMovement(Vec3.ZERO);
		item.setPickUpDelay(60);
		if (level.addFreshEntity(item))
			risers.add(new Riser(item.getUUID(), y + HOVER_HEIGHT));
	}

	private void tickRisers(ServerLevel level) {
		Iterator<Riser> it = risers.iterator();
		while (it.hasNext()) {
			Riser riser = it.next();
			Entity e = level.getEntity(riser.id);
			if (e == null || e.isRemoved()) {
				it.remove();
				continue;
			}
			if (e.getY() >= riser.targetY) {
				e.setPos(e.getX(), riser.targetY, e.getZ());
				e.setDeltaMovement(Vec3.ZERO);
				e.hasImpulse = true;
				it.remove();
			} else {
				e.setDeltaMovement(0.0, RISE_SPEED, 0.0);
				e.hasImpulse = true;
			}
		}
	}

	@Override
	public CompoundTag save(CompoundTag tag) {
		ListTag headList = new ListTag();
		for (Map.Entry<Long, Integer> entry : heads.entrySet()) {
			CompoundTag t = new CompoundTag();
			t.putLong("pos", entry.getKey());
			t.putInt("count", entry.getValue());
			headList.add(t);
		}
		tag.put("heads", headList);
		ListTag raidList = new ListTag();
		for (Raid r : raids.values())
			raidList.add(r.save());
		tag.put("raids", raidList);
		return tag;
	}

	public static ScarecrowRaids load(CompoundTag tag) {
		ScarecrowRaids data = new ScarecrowRaids();
		ListTag headList = tag.getList("heads", Tag.TAG_COMPOUND);
		for (int i = 0; i < headList.size(); i++) {
			CompoundTag t = headList.getCompound(i);
			data.heads.put(t.getLong("pos"), t.getInt("count"));
		}
		ListTag raidList = tag.getList("raids", Tag.TAG_COMPOUND);
		for (int i = 0; i < raidList.size(); i++) {
			Raid r = Raid.load(raidList.getCompound(i));
			data.raids.put(r.pos, r);
		}
		return data;
	}

	private static class Riser {
		final UUID id;
		final double targetY;

		Riser(UUID id, double targetY) {
			this.id = id;
			this.targetY = targetY;
		}
	}

	private static class Raid {
		final long pos;
		int stage = 1;
		int timeLeft = TIME_LIMIT_TICKS;
		int pool;
		int delay;
		int stageTotal;
		int ring;
		int barStage;
		final Map<UUID, Long> tracked = new LinkedHashMap<>();
		final Map<UUID, Integer> misses = new HashMap<>();
		ServerBossEvent bar;

		Raid(long pos) {
			this.pos = pos;
		}

		void beginStage() {
			pool = chirlikCount(stage);
			stageTotal = pool;
			ring = 0;
		}

		Component title() {
			return Component.translatable(KEY_TITLE, stage, MAX_STAGE);
		}

		ServerBossEvent bar() {
			if (bar == null) {
				bar = new ServerBossEvent(title(), BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.NOTCHED_10);
				barStage = stage;
			}
			return bar;
		}

		CompoundTag save() {
			CompoundTag t = new CompoundTag();
			t.putLong("pos", pos);
			t.putInt("stage", stage);
			t.putInt("timeLeft", timeLeft);
			t.putInt("pool", pool);
			t.putInt("delay", delay);
			t.putInt("stageTotal", stageTotal);
			t.putInt("ring", ring);
			ListTag ids = new ListTag();
			for (UUID id : tracked.keySet())
				ids.add(NbtUtils.createUUID(id));
			t.put("tracked", ids);
			return t;
		}

		static Raid load(CompoundTag t) {
			Raid r = new Raid(t.getLong("pos"));
			r.stage = t.getInt("stage");
			r.timeLeft = t.getInt("timeLeft");
			r.pool = t.getInt("pool");
			r.delay = t.getInt("delay");
			r.stageTotal = t.getInt("stageTotal");
			r.ring = t.getInt("ring");
			ListTag ids = t.getList("tracked", Tag.TAG_INT_ARRAY);
			for (int i = 0; i < ids.size(); i++)
				r.tracked.put(NbtUtils.loadUUID(ids.get(i)), r.pos);
			return r;
		}
	}
}