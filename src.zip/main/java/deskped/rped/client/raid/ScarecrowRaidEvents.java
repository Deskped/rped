package deskped.rped.client.raid;

import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.EntityStruckByLightningEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

import deskped.rped.entity.ChirlikEntity;
import deskped.rped.init.RpedModBlocks;
import deskped.rped.init.RpedModItems;

@Mod.EventBusSubscriber(modid = "rped", bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ScarecrowRaidEvents {

	@SubscribeEvent
	public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
		Level level = event.getLevel();
		BlockPos pos = event.getPos();
		if (!level.getBlockState(pos).is(RpedModBlocks.SCARECROW.get()))
			return;
		ItemStack stack = event.getItemStack();
		Player player = event.getEntity();
		if (stack.is(RpedModItems.HEAD_CHIRLIK.get())) {
			if (level instanceof ServerLevel serverLevel)
				ScarecrowRaids.get(serverLevel).acceptHeads(serverLevel, pos, player, stack);
			event.setCancellationResult(InteractionResult.sidedSuccess(level.isClientSide()));
			event.setCanceled(true);
			return;
		}
		if (event.getHand() == InteractionHand.MAIN_HAND && stack.isEmpty() && level instanceof ServerLevel serverLevel)
			player.displayClientMessage(ScarecrowRaids.get(serverLevel).status(pos), true);
	}

	@SubscribeEvent
	public static void onLevelTick(TickEvent.LevelTickEvent event) {
		if (event.phase != TickEvent.Phase.END)
			return;
		if (event.level instanceof ServerLevel serverLevel)
			ScarecrowRaids.get(serverLevel).tick(serverLevel);
	}

	@SubscribeEvent(priority = EventPriority.LOWEST)
	public static void onDeath(LivingDeathEvent event) {
		if (!(event.getEntity() instanceof ChirlikEntity chirlik) || !(chirlik.level() instanceof ServerLevel serverLevel))
			return;
		CompoundTag data = chirlik.getPersistentData();
		if (!data.contains(ScarecrowRaids.RAID_TAG))
			return;
		chirlik.ejectPassengers();
		chirlik.stopRiding();
		boolean byPlayer = event.getSource().getEntity() instanceof Player;
		ScarecrowRaids.get(serverLevel).onChirlikDeath(data.getLong(ScarecrowRaids.RAID_TAG), chirlik.getUUID(), byPlayer);
	}

	@SubscribeEvent
	public static void onJoin(EntityJoinLevelEvent event) {
		if (!(event.getEntity() instanceof ChirlikEntity chirlik) || !(event.getLevel() instanceof ServerLevel serverLevel))
			return;
		CompoundTag data = chirlik.getPersistentData();
		if (data.contains(ScarecrowRaids.RAID_TAG) && !ScarecrowRaids.get(serverLevel).hasRaid(data.getLong(ScarecrowRaids.RAID_TAG)))
			event.setCanceled(true);
	}

	@SubscribeEvent
	public static void onStruck(EntityStruckByLightningEvent event) {
		if (event.getEntity() instanceof ChirlikEntity chirlik && chirlik.getPersistentData().contains(ScarecrowRaids.RAID_TAG))
			event.setCanceled(true);
	}

	@SubscribeEvent
	public static void onDrops(LivingDropsEvent event) {
		if (!(event.getEntity() instanceof ChirlikEntity chirlik) || chirlik.level().isClientSide())
			return;
		boolean raid = chirlik.getPersistentData().contains(ScarecrowRaids.RAID_TAG);
		if (raid)
			event.getDrops().removeIf(d -> d.getItem().is(RpedModItems.HEAD_CHIRLIK.get()));
		RandomSource random = chirlik.getRandom();
		if (random.nextFloat() >= ScarecrowRaids.EXTRA_DROP_CHANCE)
			return;
		ItemStack drop = switch (random.nextInt(raid ? 3 : 4)) {
			case 0 -> new ItemStack(RpedModItems.WOODO_LEAFLET.get());
			case 1 -> new ItemStack(Items.PUMPKIN_PIE);
			case 2 -> new ItemStack(Items.PUMPKIN_SEEDS);
			default -> new ItemStack(RpedModItems.HEAD_CHIRLIK.get());
		};
		event.getDrops().add(new ItemEntity(chirlik.level(), chirlik.getX(), chirlik.getY(), chirlik.getZ(), drop));
	}
}