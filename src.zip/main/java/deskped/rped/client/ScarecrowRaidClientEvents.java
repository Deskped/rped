package deskped.rped.client;

import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import org.joml.Matrix4f;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Mod.EventBusSubscriber(modid = "rped", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ScarecrowRaidClientEvents {
	private static final float TAU = (float) (Math.PI * 2.0D);
	private static final float CLOUD_HEIGHT = 5.0F;
	private static final float CLOUD_RADIUS = 13.0F;
	private static final float TEXEL_BLOCKS = 0.5F;
	private static final int RINGS = 8;
	private static final int SEGMENTS = 40;
	private static final double RENDER_DISTANCE_SQ = 160.0D * 160.0D;

	private static final float[] LAYER_HEIGHT = {0.4F, 0.0F, -0.4F};
	private static final float[] LAYER_SPEED = {0.016F, 0.021F, 0.027F};
	private static final float[] LAYER_ALPHA = {0.55F, 0.7F, 0.85F};
	private static final int[] LAYER_COLOR = {0x5C5C6B, 0x474752, 0x30303B};
	private static final float[] LAYER_U = {0.13F, 0.62F, 0.37F};
	private static final float[] LAYER_V = {0.41F, 0.07F, 0.83F};

	private static final Map<ScarecrowRaidClientState.Entry, ScarecrowRaidMusic> MUSIC = new HashMap<>();

	@SubscribeEvent
	public static void onClientTick(TickEvent.ClientTickEvent event) {
		if (event.phase != TickEvent.Phase.END)
			return;
		Minecraft mc = Minecraft.getInstance();
		if (mc.level == null || mc.player == null) {
			MUSIC.clear();
			ScarecrowRaidClientState.clear();
			return;
		}
		ResourceLocation dim = mc.level.dimension().location();
		List<ScarecrowRaidClientState.Entry> entries = ScarecrowRaidClientState.visibleEntries();
		Iterator<Map.Entry<ScarecrowRaidClientState.Entry, ScarecrowRaidMusic>> it = MUSIC.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<ScarecrowRaidClientState.Entry, ScarecrowRaidMusic> e = it.next();
			if (e.getValue().isStopped() || !entries.contains(e.getKey()) || !e.getKey().dim.equals(dim))
				it.remove();
		}
		for (ScarecrowRaidClientState.Entry entry : entries) {
			if (!entry.running() || !entry.dim.equals(dim) || MUSIC.containsKey(entry))
				continue;
			ScarecrowRaidMusic sound = new ScarecrowRaidMusic(entry);
			MUSIC.put(entry, sound);
			mc.getSoundManager().play(sound);
		}
	}

	@SubscribeEvent
	public static void onRender(RenderLevelStageEvent event) {
		if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES)
			return;
		Minecraft mc = Minecraft.getInstance();
		ClientLevel level = mc.level;
		if (level == null)
			return;
		List<ScarecrowRaidClientState.Entry> entries = ScarecrowRaidClientState.visibleEntries();
		if (entries.isEmpty())
			return;
		ResourceLocation dim = level.dimension().location();
		Camera camera = event.getCamera();
		Vec3 cam = camera.getPosition();
		Matrix4f m = event.getPoseStack().last().pose();
		MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
		VertexConsumer vc = buffers.getBuffer(ScarecrowRaidCloudType.CLOUDS);
		float time = level.getGameTime() + event.getPartialTick();
		boolean drawn = false;
		for (ScarecrowRaidClientState.Entry entry : entries) {
			if (!entry.dim.equals(dim))
				continue;
			double cx = entry.pos.getX() + 0.5D;
			double cz = entry.pos.getZ() + 0.5D;
			double dx = cx - cam.x;
			double dz = cz - cam.z;
			if (dx * dx + dz * dz > RENDER_DISTANCE_SQ)
				continue;
			float visibility = entry.visibility();
			if (visibility <= 0.01F)
				continue;
			drawClouds(vc, m, cam, entry, cx, entry.pos.getY() + CLOUD_HEIGHT, cz, time, visibility);
			drawn = true;
		}
		if (drawn)
			buffers.endBatch(ScarecrowRaidCloudType.CLOUDS);
	}

	private static void drawClouds(VertexConsumer vc, Matrix4f m, Vec3 cam, ScarecrowRaidClientState.Entry entry, double cx, double cy, double cz, float time, float visibility) {
		float density = 0.45F + 0.55F * Math.min(1.0F, entry.stage / 33.0F);
		float radius = CLOUD_RADIUS * (1.6F - 0.6F * entry.gather());
		boolean camBelow = cam.y < cy;
		for (int n = 0; n < LAYER_HEIGHT.length; n++) {
			int layer = camBelow ? n : LAYER_HEIGHT.length - 1 - n;
			float y = (float) (cy + LAYER_HEIGHT[layer] - cam.y);
			float alpha = density * LAYER_ALPHA[layer] * visibility;
			int rgb = LAYER_COLOR[layer];
			for (int ri = 0; ri < RINGS; ri++) {
				float r0 = radius * ri / RINGS;
				float r1 = radius * (ri + 1) / RINGS;
				for (int si = 0; si < SEGMENTS; si++) {
					float a0 = TAU * si / SEGMENTS;
					float a1 = TAU * (si + 1) / SEGMENTS;
					cloudVertex(vc, m, cx, cz, cam, y, r0, a0, radius, time, layer, rgb, alpha);
					cloudVertex(vc, m, cx, cz, cam, y, r1, a0, radius, time, layer, rgb, alpha);
					cloudVertex(vc, m, cx, cz, cam, y, r1, a1, radius, time, layer, rgb, alpha);
					cloudVertex(vc, m, cx, cz, cam, y, r0, a1, radius, time, layer, rgb, alpha);
				}
			}
		}
	}

	private static void cloudVertex(VertexConsumer vc, Matrix4f m, double cx, double cz, Vec3 cam, float y, float r, float a, float radius, float time, int layer, int rgb, float alpha) {
		float x = (float) (cx - cam.x) + Mth.cos(a) * r;
		float z = (float) (cz - cam.z) + Mth.sin(a) * r;
		float twist = time * LAYER_SPEED[layer] * (1.0F + 2.0F * (1.0F - Math.min(1.0F, r / CLOUD_RADIUS)));
		float sx = Mth.cos(a - twist) * r;
		float sz = Mth.sin(a - twist) * r;
		float extent = 256.0F * TEXEL_BLOCKS;
		float u = sx / extent + LAYER_U[layer];
		float v = sz / extent + LAYER_V[layer];
		float edge = 1.0F - (r / radius) * (r / radius);
		int a255 = (int) (Mth.clamp(alpha * edge, 0.0F, 1.0F) * 255.0F);
		vc.vertex(m, x, y, z).color(rgb >> 16 & 255, rgb >> 8 & 255, rgb & 255, a255).uv(u, v).endVertex();
	}
}
