package deskped.rped.client.model;

import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class Modelchirlik<T extends Entity> extends EntityModel<T> {
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("rped", "modelchirlik"), "main");
	public final ModelPart full;
	public final ModelPart left;
	public final ModelPart right;
	public final ModelPart armleft;
	public final ModelPart rightarm;
	public final ModelPart head;

	public Modelchirlik(ModelPart root) {
		this.full = root.getChild("full");
		this.left = this.full.getChild("left");
		this.right = this.full.getChild("right");
		this.armleft = this.full.getChild("armleft");
		this.rightarm = this.full.getChild("rightarm");
		this.head = this.full.getChild("head");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition full = partdefinition.addOrReplaceChild("full", CubeListBuilder.create().texOffs(28, 16).addBox(-3.0083F, -3.4141F, -2.0F, 6.0F, 6.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0083F, 18.4141F, 0.0F));
		PartDefinition left = full.addOrReplaceChild("left", CubeListBuilder.create().texOffs(0, 30).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(1.5917F, 3.5859F, 0.0F));
		PartDefinition right = full.addOrReplaceChild("right", CubeListBuilder.create().texOffs(28, 26).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(-1.5083F, 3.5859F, 0.0F));
		PartDefinition armleft = full.addOrReplaceChild("armleft", CubeListBuilder.create(), PartPose.offset(3.9917F, -1.4141F, 0.0F));
		PartDefinition cube_r1 = armleft.addOrReplaceChild("cube_r1", CubeListBuilder.create().texOffs(8, 30).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 1.0F, 0.0F, 0.0F, 0.0F, -0.9599F));
		PartDefinition rightarm = full.addOrReplaceChild("rightarm", CubeListBuilder.create(), PartPose.offset(-4.0083F, -1.4141F, 0.0F));
		PartDefinition cube_r2 = rightarm.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(16, 30).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.9163F));
		PartDefinition head = full.addOrReplaceChild("head",
				CubeListBuilder.create().texOffs(0, 16).addBox(-3.95F, -3.9847F, -3.0F, 8.0F, 8.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(0, 0).addBox(-4.55F, -4.4847F, -3.5F, 9.0F, 9.0F, 7.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-0.0583F, -7.4294F, 0.0F));
		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		full.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}
}