package deskped.rped.client;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;

import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;

public class ScarecrowRaidCloudType extends RenderType {
	public static final RenderType CLOUDS = create("rped_raid_clouds", DefaultVertexFormat.POSITION_COLOR_TEX, VertexFormat.Mode.QUADS, 8192, false, false,
			RenderType.CompositeState.builder()
					.setShaderState(POSITION_COLOR_TEX_SHADER)
					.setTextureState(new RenderStateShard.TextureStateShard(new ResourceLocation("minecraft", "textures/environment/clouds.png"), false, false))
					.setTransparencyState(TRANSLUCENT_TRANSPARENCY)
					.setCullState(NO_CULL)
					.setLightmapState(NO_LIGHTMAP)
					.setWriteMaskState(COLOR_WRITE)
					.createCompositeState(false));

	private ScarecrowRaidCloudType(String name, VertexFormat format, VertexFormat.Mode mode, int bufferSize, boolean affectsCrumbling, boolean sortOnUpload, Runnable setup, Runnable clear) {
		super(name, format, mode, bufferSize, affectsCrumbling, sortOnUpload, setup, clear);
	}
}
