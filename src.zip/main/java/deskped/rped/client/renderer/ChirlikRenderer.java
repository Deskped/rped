package deskped.rped.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import deskped.rped.entity.ChirlikEntity;
import deskped.rped.client.model.animations.chirlikAnimationRun;
import deskped.rped.client.model.animations.chirlikAnimationIdle;
import deskped.rped.client.model.animations.chirlikAnimationDeath;
import deskped.rped.client.model.Modelchirlik;

public class ChirlikRenderer extends MobRenderer<ChirlikEntity, Modelchirlik<ChirlikEntity>> {
	public ChirlikRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(Modelchirlik.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(ChirlikEntity entity) {
		return new ResourceLocation("rped:textures/entities/chirliktexture.png");
	}

	private static final class AnimatedModel extends Modelchirlik<ChirlikEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<ChirlikEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(ChirlikEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animate(entity.animationState0, chirlikAnimationDeath.death, ageInTicks, 1f);
				this.animate(entity.animationState1, chirlikAnimationIdle.idle, ageInTicks, 1f);
				this.animateWalk(chirlikAnimationRun.run, limbSwing, limbSwingAmount, 1f, 1f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(ChirlikEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}