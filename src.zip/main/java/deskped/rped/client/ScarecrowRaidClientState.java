package deskped.rped.client;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ScarecrowRaidClientState {
	private static final long STALE_MILLIS = 5000L;
	private static final long FADE_IN_MILLIS = 4000L;
	private static final long FADE_OUT_MILLIS = 2500L;

	private static final Map<String, Entry> ENTRIES = new ConcurrentHashMap<>();

	public static final class Entry {
		public final BlockPos pos;
		public final ResourceLocation dim;
		public volatile int stage;
		private volatile long endMillis;
		private volatile long startedMillis;
		private volatile long updatedMillis;
		private volatile long endedMillis;

		private Entry(BlockPos pos, ResourceLocation dim, long now) {
			this.pos = pos;
			this.dim = dim;
			this.startedMillis = now;
		}

		private long effectiveEnd() {
			if (endedMillis > 0L)
				return endedMillis;
			if (System.currentTimeMillis() - updatedMillis >= STALE_MILLIS)
				return updatedMillis + STALE_MILLIS;
			return 0L;
		}

		public boolean running() {
			return effectiveEnd() == 0L;
		}

		public boolean visible() {
			long end = effectiveEnd();
			return end == 0L || System.currentTimeMillis() - end < FADE_OUT_MILLIS;
		}

		public float visibility() {
			long now = System.currentTimeMillis();
			float in = Math.min(1.0F, (now - startedMillis) / (float) FADE_IN_MILLIS);
			long end = effectiveEnd();
			float out = end == 0L ? 1.0F : Math.max(0.0F, 1.0F - (now - end) / (float) FADE_OUT_MILLIS);
			return Math.max(0.0F, in) * out;
		}

		public float gather() {
			long now = System.currentTimeMillis();
			return Math.max(0.0F, Math.min(1.0F, (now - startedMillis) / (float) FADE_IN_MILLIS));
		}

		public int remainingTicks() {
			return (int) Math.max(0L, (endMillis - System.currentTimeMillis()) / 50L);
		}
	}

	private static String key(ResourceLocation dim, BlockPos pos) {
		return dim + "@" + pos.asLong();
	}

	public static void set(BlockPos pos, ResourceLocation dim, boolean active, int remainingTicks, int stage) {
		long now = System.currentTimeMillis();
		String key = key(dim, pos);
		if (!active) {
			Entry e = ENTRIES.get(key);
			if (e != null && e.endedMillis == 0L)
				e.endedMillis = now;
			return;
		}
		Entry e = ENTRIES.get(key);
		if (e == null || e.endedMillis > 0L) {
			e = new Entry(pos, dim, now);
			ENTRIES.put(key, e);
		}
		e.stage = stage;
		e.endMillis = now + remainingTicks * 50L;
		e.updatedMillis = now;
	}

	public static List<Entry> visibleEntries() {
		ENTRIES.values().removeIf(e -> !e.visible());
		return new ArrayList<>(ENTRIES.values());
	}

	public static Entry nearestRunning(ResourceLocation dim, double x, double y, double z) {
		Entry best = null;
		double bestDist = Double.MAX_VALUE;
		for (Entry e : ENTRIES.values()) {
			if (!e.running() || !e.dim.equals(dim))
				continue;
			double d = e.pos.distToCenterSqr(x, y, z);
			if (d < bestDist) {
				bestDist = d;
				best = e;
			}
		}
		return best;
	}

	public static void clear() {
		ENTRIES.clear();
	}
}
