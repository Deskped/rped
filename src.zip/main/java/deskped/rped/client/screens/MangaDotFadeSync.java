package deskped.rped.client.screens;

import deskped.rped.RpedClientConfig;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.world.phys.Vec3;
import com.mojang.blaze3d.shaders.Uniform;

@Mod.EventBusSubscriber(Dist.CLIENT)
public class MangaDotFadeSync {

    private static final double CYCLE_SECONDS = 120.0;
    private static final double FADE_SECONDS = 4.0;

    private static final float VIBRANCE_ON = 1.35f;
    private static final float VIBRANCE_OFF = 1.0f;

    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.START) {
            return;
        }

        Camera camera = Minecraft.getInstance().gameRenderer.getMainCamera();
        Vec3 camPos = camera.getPosition();

        boolean enabled = RpedClientConfig.MANGA_SHADING;
        float fade = enabled ? computeFade((System.currentTimeMillis() / 1000.0) % CYCLE_SECONDS) : 0.0f;
        float vibrance = enabled ? VIBRANCE_ON : VIBRANCE_OFF;

        pushUniforms(GameRenderer.getRendertypeSolidShader(), camPos, fade, vibrance);
        pushUniforms(GameRenderer.getRendertypeCutoutShader(), camPos, fade, vibrance);
        pushUniforms(GameRenderer.getRendertypeCutoutMippedShader(), camPos, fade, vibrance);
        pushUniforms(GameRenderer.getRendertypeTranslucentShader(), camPos, fade, vibrance);
    }

    private static void pushUniforms(ShaderInstance shader, Vec3 camPos, float fade, float vibrance) {
        if (shader == null) {
            return;
        }
        Uniform cameraPosUniform = shader.getUniform("CameraPos");
        if (cameraPosUniform != null) {
            cameraPosUniform.set((float) camPos.x, (float) camPos.y, (float) camPos.z);
        }
        Uniform fadeUniform = shader.getUniform("FadeAmount");
        if (fadeUniform != null) {
            fadeUniform.set(fade);
        }
        Uniform vibranceUniform = shader.getUniform("VibranceBoost");
        if (vibranceUniform != null) {
            vibranceUniform.set(vibrance);
        }
    }

    private static float computeFade(double t) {
        if (t < FADE_SECONDS) {
            return (float) (1.0 - smoothstep(t / FADE_SECONDS));
        } else if (t < 60.0) {
            return 0.0f;
        } else if (t < 60.0 + FADE_SECONDS) {
            return (float) smoothstep((t - 60.0) / FADE_SECONDS);
        } else {
            return 1.0f;
        }
    }

    private static double smoothstep(double x) {
        x = Math.max(0.0, Math.min(1.0, x));
        return x * x * (3.0 - 2.0 * x);
    }
}