package deskped.rped.client;

import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.BlockHitResult;

import deskped.rped.RpedMod;
import deskped.rped.block.entity.WoodoLeavesRegenerateBlockEntity;

@Mod.EventBusSubscriber(modid = RpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class WoodoLeavesTimerOverlay {

    @SubscribeEvent
    public static void renderOverlay(RenderGuiOverlayEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();

        if (minecraft.player == null || minecraft.level == null)
            return;

        if (!(minecraft.hitResult instanceof BlockHitResult hitResult))
            return;

        BlockPos pos = hitResult.getBlockPos();
        BlockEntity blockEntity = minecraft.level.getBlockEntity(pos);

        if (!(blockEntity instanceof WoodoLeavesRegenerateBlockEntity timerBlock))
            return;

        int remainingTicks = timerBlock.getRemainingTicks();

        if (remainingTicks <= 0)
            return;

        String time = timerBlock.getFormattedTime();

        GuiGraphics graphics = event.getGuiGraphics();
        int width = minecraft.getWindow().getGuiScaledWidth();
        int height = minecraft.getWindow().getGuiScaledHeight();

        PoseStack poseStack = graphics.pose();
        poseStack.pushPose();

        int textWidth = minecraft.font.width(time);
        graphics.drawString(
            minecraft.font,
            time,
            (width - textWidth) / 2,
            height / 2 + 12,
            0xFFFFFF
        );

        poseStack.popPose();
    }
}