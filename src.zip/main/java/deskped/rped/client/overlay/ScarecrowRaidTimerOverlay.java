package deskped.rped.client.overlay;

import deskped.rped.client.ScarecrowRaidClientState;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "rped", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ScarecrowRaidTimerOverlay implements IGuiOverlay {

	@Override
	public void render(ForgeGui gui, GuiGraphics g, float partialTick, int screenWidth, int screenHeight) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null || mc.options.hideGui)
			return;
		ScarecrowRaidClientState.Entry entry = ScarecrowRaidClientState.nearestRunning(mc.level.dimension().location(), mc.player.getX(), mc.player.getY(), mc.player.getZ());
		if (entry == null)
			return;
		int totalSec = (entry.remainingTicks() + 19) / 20;
		String text = (totalSec / 60) + ":" + String.format("%02d", totalSec % 60);
		int tw = mc.font.width(text);
		int pillW = tw + 12;
		int pillH = 14;
		int x0 = (screenWidth - pillW) / 2;
		int y0 = screenHeight - 80;
		g.fill(x0, y0, x0 + pillW, y0 + pillH, 0x80000000);
		g.drawString(mc.font, text, x0 + 6, y0 + 3, 0xFFFFFFFF, false);
	}

	@SubscribeEvent
	public static void registerOverlay(RegisterGuiOverlaysEvent event) {
		event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "scarecrow_raid_timer", new ScarecrowRaidTimerOverlay());
	}
}
