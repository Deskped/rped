package deskped.rped.client.angel;

import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;

public class AngelRenderTypes extends RenderType {
	public static final RenderType GLOW = make("glow");
	public static final RenderType STAR = make("star");
	public static final RenderType RUNE = make("rune");
	public static final RenderType RING = make("ring");
	public static final RenderType BEAM = make("beam");
	public static final RenderType FEATHER = make("feather");
	public static final RenderType SWIRL = make("swirl");
	public static final RenderType CRYSTAL = make("crystal");
	public static final RenderType[] ALL = {GLOW, STAR, RUNE, RING, BEAM, FEATHER, SWIRL, CRYSTAL};

	private AngelRenderTypes(String name, VertexFormat format, VertexFormat.Mode mode, int bufferSize, boolean affectsCrumbling, boolean sortOnUpload, Runnable setup, Runnable clear) {
		super(name, format, mode, bufferSize, affectsCrumbling, sortOnUpload, setup, clear);
	}

	private static RenderType make(String texture) {
		return create("rped_fx_" + texture, DefaultVertexFormat.POSITION_COLOR_TEX, VertexFormat.Mode.QUADS, 1024, false, false,
				RenderType.CompositeState.builder()
						.setShaderState(POSITION_COLOR_TEX_SHADER)
						.setTextureState(new RenderStateShard.TextureStateShard(new ResourceLocation("rped", "textures/fx/fx_" + texture + ".png"), false, false))
						.setTransparencyState(ADDITIVE_TRANSPARENCY)
						.setCullState(NO_CULL)
						.setLightmapState(NO_LIGHTMAP)
						.setWriteMaskState(COLOR_WRITE)
						.createCompositeState(false));
	}
}