package deskped.rped.client.angel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

final class ShieldMesh {
	static final float[] X;
	static final float[] Y;
	static final float[] Z;
	static final int[] FACES;
	static final int[] EDGES;
	static final float[] FACET;

	static {
		float t = (1.0F + (float) Math.sqrt(5.0D)) / 2.0F;
		float[][] base = {{-1, t, 0}, {1, t, 0}, {-1, -t, 0}, {1, -t, 0}, {0, -1, t}, {0, 1, t}, {0, -1, -t}, {0, 1, -t}, {t, 0, -1}, {t, 0, 1}, {-t, 0, -1}, {-t, 0, 1}};
		List<float[]> verts = new ArrayList<>();
		for (float[] v : base)
			verts.add(normalize(v[0], v[1], v[2]));
		int[][] faces = {{0, 11, 5}, {0, 5, 1}, {0, 1, 7}, {0, 7, 10}, {0, 10, 11}, {1, 5, 9}, {5, 11, 4}, {11, 10, 2}, {10, 7, 6}, {7, 1, 8}, {3, 9, 4}, {3, 4, 2}, {3, 2, 6}, {3, 6, 8}, {3, 8, 9}, {4, 9, 5}, {2, 4, 11}, {6, 2, 10}, {8, 6, 7}, {9, 8, 1}};
		List<int[]> current = new ArrayList<>();
		for (int[] f : faces)
			current.add(f);
		for (int level = 0; level < 2; level++) {
			Map<Long, Integer> cache = new HashMap<>();
			List<int[]> next = new ArrayList<>();
			for (int[] f : current) {
				int ab = midpoint(verts, cache, f[0], f[1]);
				int bc = midpoint(verts, cache, f[1], f[2]);
				int ca = midpoint(verts, cache, f[2], f[0]);
				next.add(new int[]{f[0], ab, ca});
				next.add(new int[]{f[1], bc, ab});
				next.add(new int[]{f[2], ca, bc});
				next.add(new int[]{ab, bc, ca});
			}
			current = next;
		}
		int count = verts.size();
		X = new float[count];
		Y = new float[count];
		Z = new float[count];
		for (int i = 0; i < count; i++) {
			float[] v = verts.get(i);
			float jitter = 1.0F + (hash(i * 7 + 3) - 0.5F) * 0.14F;
			X[i] = v[0] * jitter;
			Y[i] = v[1] * jitter;
			Z[i] = v[2] * jitter;
		}
		FACES = new int[current.size() * 3];
		FACET = new float[current.size()];
		Set<Long> edges = new LinkedHashSet<>();
		for (int i = 0; i < current.size(); i++) {
			int[] f = current.get(i);
			FACES[i * 3] = f[0];
			FACES[i * 3 + 1] = f[1];
			FACES[i * 3 + 2] = f[2];
			FACET[i] = hash(i * 13 + 5);
			for (int k = 0; k < 3; k++) {
				int a = f[k];
				int b = f[(k + 1) % 3];
				edges.add((long) Math.min(a, b) << 32 | Math.max(a, b));
			}
		}
		EDGES = new int[edges.size() * 2];
		int index = 0;
		for (long key : edges) {
			EDGES[index++] = (int) (key >> 32);
			EDGES[index++] = (int) (key & 0xFFFFFFFFL);
		}
	}

	private ShieldMesh() {
	}

	private static float[] normalize(float x, float y, float z) {
		float len = (float) Math.sqrt(x * x + y * y + z * z);
		return new float[]{x / len, y / len, z / len};
	}

	private static int midpoint(List<float[]> verts, Map<Long, Integer> cache, int a, int b) {
		long key = (long) Math.min(a, b) << 32 | Math.max(a, b);
		Integer found = cache.get(key);
		if (found != null)
			return found;
		float[] va = verts.get(a);
		float[] vb = verts.get(b);
		verts.add(normalize((va[0] + vb[0]) * 0.5F, (va[1] + vb[1]) * 0.5F, (va[2] + vb[2]) * 0.5F));
		int index = verts.size() - 1;
		cache.put(key, index);
		return index;
	}

	private static float hash(int n) {
		long h = (n * 2654435761L) & 0xFFFFFFFFL;
		h ^= h >>> 15;
		h = (h * 2246822519L) & 0xFFFFFFFFL;
		return (h & 1023L) / 1023.0F;
	}
}
