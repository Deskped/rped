package deskped.rped.client.angel;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.systems.RenderSystem;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.util.Mth;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.Minecraft;

import deskped.rped.entity.TumaniteAngelEntity;
import deskped.rped.entity.AngelStages;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class AngelBossBarOverlay {
	private static final ResourceLocation BACK = new ResourceLocation("rped", "textures/screens/angel_bar_back.png");
	private static final ResourceLocation FILL = new ResourceLocation("rped", "textures/screens/angel_bar_fill.png");
	private static final ResourceLocation FRAME = new ResourceLocation("rped", "textures/screens/angel_bar_frame.png");
	private static final int FRAME_W = 412;
	private static final int FRAME_H = 98;
	private static final int HOLE_X = 44;
	private static final int HOLE_Y = 56;
	private static final int HOLE_W = 324;
	private static final int HOLE_H = 8;
	private static final int[][] SEGMENTS = {{44, 58}, {108, 48}, {162, 6}, {244, 6}, {256, 48}, {310, 58}};
	private static final int VISIBLE = visibleTotal();

	@SubscribeEvent
	public static void onRegister(RegisterGuiOverlaysEvent event) {
		event.registerAbove(VanillaGuiOverlay.BOSS_EVENT_PROGRESS.id(), "angel_boss_bar", AngelBossBarOverlay::render);
	}

	private static int visibleTotal() {
		int total = 0;
		for (int[] segment : SEGMENTS)
			total += segment[1];
		return total;
	}

	private static void drawFill(GuiGraphics graphics, ResourceLocation texture, int pixels) {
		int left = pixels;
		for (int[] segment : SEGMENTS) {
			if (left <= 0)
				return;
			int length = Math.min(segment[1], left);
			graphics.blit(texture, segment[0], HOLE_Y, (float) (segment[0] - HOLE_X), 0.0F, length, HOLE_H, HOLE_W, HOLE_H);
			left -= length;
		}
	}

	private static void render(ForgeGui gui, GuiGraphics graphics, float partialTick, int width, int height) {
		TumaniteAngelEntity angel = AngelClientState.tracked;
		if (angel == null)
			return;
		int stage = AngelClientState.stage;
		int rgb = AngelStages.color(stage) & 0xFFFFFF;
		float pulse = AngelClientState.flash > 0 ? Mth.clamp((AngelClientState.flash - partialTick) / AngelClientState.FLASH_TICKS, 0.0F, 1.0F) : 0.0F;
		float cr = Mth.lerp(pulse, (rgb >> 16 & 255) / 255.0F, 1.0F);
		float cg = Mth.lerp(pulse, (rgb >> 8 & 255) / 255.0F, 1.0F);
		float cb = Mth.lerp(pulse, (rgb & 255) / 255.0F, 1.0F);
		float appear = Mth.clamp((AngelClientState.appear + partialTick) / AngelClientState.APPEAR_TICKS, 0.0F, 1.0F);
		float scale = width >= 640 && height >= 360 ? 1.0F : 0.5F;
		int drawWidth = Math.round(FRAME_W * scale);
		int drawHeight = Math.round(FRAME_H * scale);
		int left = (width - drawWidth) / 2;
		int top = 4 + Math.round((appear - 1.0F) * drawHeight * 0.45F);
		int fillPixels = Math.round(VISIBLE * Mth.clamp(AngelClientState.shown, 0.0F, 1.0F));
		int trailPixels = Math.round(VISIBLE * Mth.clamp(AngelClientState.trail, 0.0F, 1.0F));
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		PoseStack pose = graphics.pose();
		pose.pushPose();
		pose.translate(left, top, 0.0F);
		pose.scale(scale, scale, 1.0F);
		graphics.setColor(1.0F, 1.0F, 1.0F, appear);
		graphics.blit(BACK, HOLE_X, HOLE_Y, 0.0F, 0.0F, HOLE_W, HOLE_H, HOLE_W, HOLE_H);
		if (trailPixels > fillPixels) {
			graphics.setColor(1.0F, 0.85F, 0.85F, 0.55F * appear);
			drawFill(graphics, FILL, trailPixels);
		}
		if (fillPixels > 0) {
			graphics.setColor(cr, cg, cb, appear);
			drawFill(graphics, FILL, fillPixels);
		}
		graphics.setColor(0.8F + 0.2F * cr, 0.8F + 0.2F * cg, 0.8F + 0.2F * cb, appear);
		graphics.blit(FRAME, 0, 0, 0.0F, 0.0F, FRAME_W, FRAME_H, FRAME_W, FRAME_H);
		graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
		pose.popPose();
		if (AngelClientState.flash > 0) {
			float k = Mth.clamp((AngelClientState.flash - partialTick) / AngelClientState.FLASH_TICKS, 0.0F, 1.0F);
			int flashAlpha = (int) (k * k * 110.0F);
			if (flashAlpha > 0)
				graphics.fill(0, 0, width, height, (flashAlpha << 24) | rgb);
		}
		Minecraft mc = Minecraft.getInstance();
		int orbs = angel.getOrbCount();
		if (orbs > 0)
			graphics.drawString(mc.font, "Щит держат сферки: " + orbs, 6, 6, 0xFF000000 | rgb, true);
		RenderSystem.disableBlend();
	}
}