package deskped.rped.client.angel;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.entity.Entity;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundSource;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.Minecraft;

import deskped.rped.entity.TumaniteAngelEntity;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE, value = {Dist.CLIENT})
public class AngelClientState {
	public static final double RANGE = 48.0D;
	public static final int FLASH_TICKS = 50;
	public static final int APPEAR_TICKS = 12;
	public static TumaniteAngelEntity tracked;
	public static float shown = 1.0F;
	public static float trail = 1.0F;
	public static int stage = 1;
	public static int flash;
	public static int appear;
	private static AngelMusicInstance music;
	private static int restartDelay;

	@SubscribeEvent
	public static void onClientTick(TickEvent.ClientTickEvent event) {
		if (event.phase != TickEvent.Phase.END)
			return;
		Minecraft mc = Minecraft.getInstance();
		LocalPlayer player = mc.player;
		if (mc.level == null || player == null) {
			reset();
			return;
		}
		if (tracked != null && (!tracked.isAlive() || tracked.level() != mc.level)) {
			boolean died = tracked.isDeadOrDying();
			tracked = null;
			if (died)
				killMusic();
		}
		TumaniteAngelEntity best = null;
		double bestDistance = RANGE * RANGE;
		for (TumaniteAngelEntity candidate : mc.level.getEntitiesOfClass(TumaniteAngelEntity.class, player.getBoundingBox().inflate(RANGE), e -> e.isAlive() && !e.isOrb())) {
			double distance = candidate.distanceToSqr(player);
			if (distance <= bestDistance) {
				best = candidate;
				bestDistance = distance;
			}
		}
		if (best != tracked) {
			tracked = best;
			if (best != null) {
				float real = fraction(best);
				shown = real;
				trail = real;
				stage = best.getStage();
				flash = 0;
				appear = 0;
			}
		}
		if (tracked != null) {
			float real = fraction(tracked);
			shown += (real - shown) * 0.3F;
			if (Math.abs(real - shown) < 0.001F)
				shown = real;
			if (trail > shown)
				trail = Math.max(shown, trail - 0.004F);
			else
				trail = shown;
			int current = tracked.getStage();
			if (current > stage)
				flash = FLASH_TICKS;
			stage = current;
			if (appear < APPEAR_TICKS)
				appear++;
		}
		if (flash > 0)
			flash--;
		updateMusic(mc);
	}

	@SubscribeEvent
	public static void onPlaySound(PlaySoundEvent event) {
		SoundInstance sound = event.getSound();
		if (sound == null || sound instanceof AngelMusicInstance || music == null || music.isStopped())
			return;
		SoundSource source = sound.getSource();
		if (source == SoundSource.MUSIC || source == SoundSource.RECORDS)
			event.setSound(null);
	}

	@SubscribeEvent
	public static void onRenderPre(RenderLivingEvent.Pre<?, ?> event) {
		if (event.getEntity() instanceof TumaniteAngelEntity angel && angel.isOrb())
			event.getPoseStack().scale(0.5F, 0.5F, 0.5F);
	}

	@SubscribeEvent
	public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
		if (flash <= 0 || tracked == null)
			return;
		Minecraft mc = Minecraft.getInstance();
		float k = Mth.clamp(flash / (float) FLASH_TICKS, 0.0F, 1.0F);
		double t = (mc.level != null ? mc.level.getGameTime() : 0L) + event.getPartialTick();
		event.setRoll(event.getRoll() + (float) (Math.sin(t * 2.3D) * 2.2D * k));
		event.setPitch(event.getPitch() + (float) (Math.sin(t * 3.1D + 1.0D) * 1.4D * k));
		event.setYaw(event.getYaw() + (float) (Math.sin(t * 2.7D + 2.0D) * 1.4D * k));
	}

	@SubscribeEvent
	public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
		reset();
	}

	private static float fraction(TumaniteAngelEntity angel) {
		return Mth.clamp(angel.getHealth() / angel.getMaxHealth(), 0.0F, 1.0F);
	}

	private static void updateMusic(Minecraft mc) {
		if (music != null && (music.isStopped() || (music.age > 20 && !mc.getSoundManager().isActive(music)))) {
			if (!music.isStopped())
				music.kill();
			music = null;
			restartDelay = 60;
		}
		if (tracked != null) {
			if (music == null && restartDelay <= 0)
				startMusic(mc);
			if (music != null) {
				music.setStage(stage);
				music.fadeIn();
			}
		} else if (music != null) {
			music.fadeOut();
		}
		if (restartDelay > 0)
			restartDelay--;
	}

	private static void startMusic(Minecraft mc) {
		mc.getMusicManager().stopPlaying();
		mc.getSoundManager().stop(null, SoundSource.RECORDS);
		music = new AngelMusicInstance(stage);
		mc.getSoundManager().play(music);
	}

	private static void killMusic() {
		if (music != null) {
			music.kill();
			music = null;
		}
	}

	private static void reset() {
		tracked = null;
		flash = 0;
		appear = 0;
		killMusic();
	}
}
