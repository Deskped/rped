package deskped.rped.client.angel;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.model.EntityModel;

import deskped.rped.client.renderer.TumaniteAngelRenderer;
import deskped.rped.entity.TumaniteAngelEntity;
import deskped.rped.entity.AngelOrbs;
import deskped.rped.init.RpedModEntities;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class AngelLayerEvents {
	@SubscribeEvent
	public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.<TumaniteAngelEntity>registerEntityRenderer(AngelOrbs.TYPE, TumaniteAngelRenderer::new);
	}

	@SubscribeEvent
	public static void onAddLayers(EntityRenderersEvent.AddLayers event) {
		LivingEntityRenderer<TumaniteAngelEntity, ? extends EntityModel<TumaniteAngelEntity>> renderer = event.getRenderer(RpedModEntities.TUMANITE_ANGEL.get());
		if (renderer != null)
			attach(renderer);
		LivingEntityRenderer<TumaniteAngelEntity, ? extends EntityModel<TumaniteAngelEntity>> orbRenderer = event.getRenderer(AngelOrbs.TYPE);
		if (orbRenderer != null)
			attach(orbRenderer);
	}

	private static <M extends EntityModel<TumaniteAngelEntity>> void attach(LivingEntityRenderer<TumaniteAngelEntity, M> renderer) {
		renderer.addLayer(new AngelGlowLayer<>(renderer));
	}
}
