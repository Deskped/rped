package deskped.rped.client;

import deskped.rped.RpedClientConfig;

import java.util.List;

public final class MenuChoice {

    public static final String RPED      = "rped";
    public static final String YOURLINE  = "yourline";
    public static final String MYPED     = "myped";
    public static final String MINECRAFT = "minecraft";

    public static final List<String> ALL = List.of(RPED, YOURLINE, MYPED, MINECRAFT);

    private MenuChoice() {
    }

    public static boolean available(String id) {
        return RPED.equals(id) || MINECRAFT.equals(id);
    }

    public static String current() {
        String id = RpedClientConfig.MAIN_MENU;
        return available(id) ? id : RPED;
    }

    public static void applyStartup() {
        ClientMenuState.customMenu = !RpedClientConfig.CHANGE_MENU || RPED.equals(current());
    }

    public static void choose(String id) {
        if (!available(id)) return;
        RpedClientConfig.setMainMenu(id);
        ClientMenuState.customMenu = RPED.equals(id);
    }
}
