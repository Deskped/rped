package deskped.rped.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;

public class ScarecrowRaidMusic extends AbstractTickableSoundInstance {
	public static final double RANGE = 30.0D;

	private static final SoundEvent TRACK = SoundEvent.createVariableRangeEvent(new ResourceLocation("minecraft", "music_disc.pigstep"));

	private final ScarecrowRaidClientState.Entry entry;

	public ScarecrowRaidMusic(ScarecrowRaidClientState.Entry entry) {
		super(TRACK, SoundSource.RECORDS, SoundInstance.createUnseededRandom());
		this.entry = entry;
		this.looping = true;
		this.delay = 0;
		this.volume = 0.0F;
		this.relative = false;
		this.attenuation = SoundInstance.Attenuation.NONE;
		this.x = entry.pos.getX() + 0.5D;
		this.y = entry.pos.getY() + 0.5D;
		this.z = entry.pos.getZ() + 0.5D;
	}

	@Override
	public boolean canStartSilent() {
		return true;
	}

	@Override
	public void tick() {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null || !this.entry.visible() || !mc.level.dimension().location().equals(this.entry.dim)) {
			this.stop();
			return;
		}
		double distance = Math.sqrt(mc.player.distanceToSqr(this.x, this.y, this.z));
		float falloff = (float) Math.max(0.0D, 1.0D - distance / RANGE);
		this.volume = falloff * this.entry.visibility();
	}
}
