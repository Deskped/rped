package deskped.rped;

import deskped.rped.client.ClientMenuState;
import deskped.rped.ext.ExtLang;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE, modid = "rped")
@OnlyIn(Dist.CLIENT)
public class MenuSwitchEvent {

    @SubscribeEvent
    public static void onTitleInit(ScreenEvent.Init.Post event) {
        Screen screen = event.getScreen();
        if (!(screen instanceof TitleScreen)) return;
        if (ClientMenuState.customMenu || !RpedClientConfig.CHANGE_MENU) return;

        int bw = Math.min(120, screen.width - 20);
        Button button = Button.builder(
                Component.literal(ExtLang.pick("Выбрать меню", "Choose menu")),
                b -> Minecraft.getInstance().setScreen(new MenuSelectScreen(screen))
        ).bounds(screen.width / 2 - bw / 2, screen.height - 26, bw, 20).build();
        event.addListener(button);
    }
}
