package deskped.rped.block.entity;

import net.minecraftforge.items.wrapper.SidedInvWrapper;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.capabilities.Capability;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.ContainerHelper;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.core.NonNullList;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.stream.IntStream;

import deskped.rped.init.RpedModBlocks;
import deskped.rped.init.RpedModBlockEntities;
import deskped.rped.dimension.BreakdownManager;

public class CoreBlockEntity extends RandomizableContainerBlockEntity implements WorldlyContainer {
	public static final int PHASE_READY = 0;
	public static final int PHASE_ACTIVE = 1;
	public static final int PHASE_COOLDOWN = 2;
	public static final int BREAKDOWN_OFFSET = 3;
	public static final int ACTIVE_MARGIN = 40;
	public static final int ACTIVE_TICKS = BreakdownManager.LIFETIME + ACTIVE_MARGIN;
	public static final int COOLDOWN_TICKS = 3 * 60 * 60 * 20;
	private static final int CLICK_GAP = 8;
	private static final double VIEW_RANGE_SQR = 16.0 * 16.0;

	private int phase = PHASE_READY;
	private long phaseEnd;
	private final Map<UUID, Long> viewers = new HashMap<>();
	private NonNullList<ItemStack> stacks = NonNullList.withSize(9, ItemStack.EMPTY);
	private final LazyOptional<? extends IItemHandler>[] handlers = SidedInvWrapper.create(this, Direction.values());

	public CoreBlockEntity(BlockPos position, BlockState state) {
		super(RpedModBlockEntities.CORE.get(), position, state);
	}

	@Override
	public void load(CompoundTag compound) {
		super.load(compound);
		if (!this.tryLoadLootTable(compound))
			this.stacks = NonNullList.withSize(this.getContainerSize(), ItemStack.EMPTY);
		ContainerHelper.loadAllItems(compound, this.stacks);
		this.phase = compound.getInt("CorePhase");
		this.phaseEnd = compound.getLong("CorePhaseEnd");
		this.viewers.clear();
		if (compound.contains("CoreViewers", Tag.TAG_LIST)) {
			ListTag list = compound.getList("CoreViewers", Tag.TAG_INT_ARRAY);
			for (int i = 0; i < list.size(); i++)
				this.viewers.put(NbtUtils.loadUUID(list.get(i)), 0L);
		}
	}

	@Override
	public void saveAdditional(CompoundTag compound) {
		super.saveAdditional(compound);
		if (!this.trySaveLootTable(compound)) {
			ContainerHelper.saveAllItems(compound, this.stacks);
		}
		compound.putInt("CorePhase", this.phase);
		compound.putLong("CorePhaseEnd", this.phaseEnd);
	}

	public int getPhase() {
		return this.phase;
	}

	public long getPhaseEnd() {
		return this.phaseEnd;
	}

	public boolean isViewer(UUID id) {
		return this.viewers.containsKey(id);
	}

	public long getRemainingTicks(long now) {
		if (this.phase == PHASE_ACTIVE)
			return Math.max(0L, this.phaseEnd - ACTIVE_MARGIN - now);
		if (this.phase == PHASE_COOLDOWN)
			return Math.max(0L, this.phaseEnd - now);
		return 0L;
	}

	public void onUse(Player player) {
		Level world = this.level;
		if (world == null || world.isClientSide)
			return;
		long now = world.getGameTime();
		UUID id = player.getUUID();
		Long last = this.viewers.get(id);
		if (last == null) {
			this.viewers.put(id, now);
		} else if (now - last < CLICK_GAP) {
			this.viewers.put(id, now);
			return;
		} else if (player.isShiftKeyDown() || this.phase != PHASE_READY) {
			this.viewers.remove(id);
		} else {
			this.viewers.put(id, now);
			this.activate(world);
		}
		this.sync();
	}

	private void activate(Level world) {
		BlockPos target = this.worldPosition.above(BREAKDOWN_OFFSET);
		if (world.isOutsideBuildHeight(target))
			return;
		if (!world.getBlockState(target).isAir())
			world.destroyBlock(target, true);
		world.setBlock(target, RpedModBlocks.BREAKDOWN.get().defaultBlockState(), 3);
		this.phase = PHASE_ACTIVE;
		this.phaseEnd = world.getGameTime() + ACTIVE_TICKS;
	}

	private boolean pruneViewers(Level world) {
		boolean removed = false;
		Vec3 center = Vec3.atCenterOf(this.worldPosition);
		Iterator<UUID> iterator = this.viewers.keySet().iterator();
		while (iterator.hasNext()) {
			Player viewer = world.getPlayerByUUID(iterator.next());
			if (viewer == null || viewer.isSpectator() || viewer.distanceToSqr(center) > VIEW_RANGE_SQR) {
				iterator.remove();
				removed = true;
			}
		}
		return removed;
	}

	private void sync() {
		this.setChanged();
		if (this.level != null)
			this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), 3);
	}

	public static void serverTick(Level world, BlockPos pos, BlockState state, CoreBlockEntity be) {
		long now = world.getGameTime();
		boolean changed = false;
		if (be.phase == PHASE_ACTIVE && now >= be.phaseEnd) {
			BlockPos target = pos.above(BREAKDOWN_OFFSET);
			if (world.getBlockState(target).is(RpedModBlocks.BREAKDOWN.get()))
				world.removeBlock(target, false);
			be.phase = PHASE_COOLDOWN;
			be.phaseEnd = now + COOLDOWN_TICKS;
			changed = true;
		} else if (be.phase == PHASE_COOLDOWN && now >= be.phaseEnd) {
			be.phase = PHASE_READY;
			be.phaseEnd = 0L;
			changed = true;
		}
		if (now % 10L == 0L && !be.viewers.isEmpty() && be.pruneViewers(world))
			changed = true;
		if (changed)
			be.sync();
	}

	@Override
	public AABB getRenderBoundingBox() {
		return new AABB(this.worldPosition).inflate(3.5);
	}

	@Override
	public ClientboundBlockEntityDataPacket getUpdatePacket() {
		return ClientboundBlockEntityDataPacket.create(this);
	}

	@Override
	public CompoundTag getUpdateTag() {
		CompoundTag tag = this.saveWithFullMetadata();
		ListTag list = new ListTag();
		for (UUID id : this.viewers.keySet())
			list.add(NbtUtils.createUUID(id));
		tag.put("CoreViewers", list);
		return tag;
	}

	@Override
	public int getContainerSize() {
		return stacks.size();
	}

	@Override
	public boolean isEmpty() {
		for (ItemStack itemstack : this.stacks)
			if (!itemstack.isEmpty())
				return false;
		return true;
	}

	@Override
	public Component getDefaultName() {
		return Component.literal("core");
	}

	@Override
	public AbstractContainerMenu createMenu(int id, Inventory inventory) {
		return ChestMenu.threeRows(id, inventory);
	}

	@Override
	public Component getDisplayName() {
		return Component.literal("Core");
	}

	@Override
	protected NonNullList<ItemStack> getItems() {
		return this.stacks;
	}

	@Override
	protected void setItems(NonNullList<ItemStack> stacks) {
		this.stacks = stacks;
	}

	@Override
	public boolean canPlaceItem(int index, ItemStack stack) {
		return true;
	}

	@Override
	public int[] getSlotsForFace(Direction side) {
		return IntStream.range(0, this.getContainerSize()).toArray();
	}

	@Override
	public boolean canPlaceItemThroughFace(int index, ItemStack itemstack, @Nullable Direction direction) {
		return this.canPlaceItem(index, itemstack);
	}

	@Override
	public boolean canTakeItemThroughFace(int index, ItemStack itemstack, Direction direction) {
		return true;
	}

	@Override
	public <T> LazyOptional<T> getCapability(Capability<T> capability, @Nullable Direction facing) {
		if (!this.remove && facing != null && capability == ForgeCapabilities.ITEM_HANDLER)
			return handlers[facing.ordinal()].cast();
		return super.getCapability(capability, facing);
	}

	@Override
	public void setRemoved() {
		super.setRemoved();
		for (LazyOptional<? extends IItemHandler> handler : handlers)
			handler.invalidate();
	}
}