package deskped.rped.ext;

import deskped.rped.init.RpedModBlocks;
import deskped.rped.init.RpedModTabs;

import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = "rped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class RpedMasonryTabs {

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onBuild(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
            insertAfter(event, Items.POLISHED_GRANITE_SLAB, RpedMasonry.stacks("granite"));
            insertAfter(event, Items.POLISHED_DIORITE_SLAB, RpedMasonry.stacks("diorite"));
            List<ItemStack> tail = new ArrayList<>(RpedMasonry.stacks("andesite"));
            tail.addAll(RpedMasonry.stacks("calcite"));
            tail.addAll(RpedMasonry.stacks("dripstone"));
            insertAfter(event, Items.POLISHED_ANDESITE_SLAB, tail);
        } else if (event.getTab() == RpedModTabs.RPED.get()) {
            insertAfter(event, RpedModBlocks.STONE_BRICK.get().asItem(), RpedMasonry.allStacks());
        }
    }

    private static void insertAfter(BuildCreativeModeTabContentsEvent event, Item anchor, List<ItemStack> stacks) {
        var entries = event.getEntries();
        List<ItemStack> keys = new ArrayList<>();
        List<CreativeModeTab.TabVisibility> visibilities = new ArrayList<>();
        for (var e : entries) {
            keys.add(e.getKey());
            visibilities.add(e.getValue());
        }
        int index = -1;
        for (int i = 0; i < keys.size(); i++) {
            if (keys.get(i).getItem() == anchor) {
                index = i;
                break;
            }
        }
        if (index < 0) {
            for (ItemStack stack : stacks)
                entries.put(stack, CreativeModeTab.TabVisibility.PARENT_AND_SEARCH_TABS);
            return;
        }
        for (ItemStack key : keys)
            entries.remove(key);
        for (int i = 0; i <= index; i++)
            entries.put(keys.get(i), visibilities.get(i));
        for (ItemStack stack : stacks)
            entries.put(stack, CreativeModeTab.TabVisibility.PARENT_AND_SEARCH_TABS);
        for (int i = index + 1; i < keys.size(); i++)
            entries.put(keys.get(i), visibilities.get(i));
    }
}
