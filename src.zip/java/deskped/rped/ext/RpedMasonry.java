package deskped.rped.ext;

import com.google.common.base.Suppliers;

import deskped.rped.init.RpedModBlocks;
import deskped.rped.init.RpedModItems;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.WallBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.material.MapColor;

import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public final class RpedMasonry {

    private static final Map<String, List<RegistryObject<Item>>> GROUPS = new LinkedHashMap<>();

    private record Stone(String id, String en, String ruPlural, String ruGenitive, String ruFeminine, String ruNoun,
                         MapColor color, SoundType sound, float hardness, float resistance, boolean cracked) {
    }

    static {
        register(new Stone("andesite", "Andesite", "андезитовые", "андезитовых", "андезитовая", "андезит",
                MapColor.STONE, SoundType.STONE, 1.5F, 6.0F, true));
        register(new Stone("diorite", "Diorite", "диоритовые", "диоритовых", "диоритовая", "диорит",
                MapColor.QUARTZ, SoundType.STONE, 1.5F, 6.0F, true));
        register(new Stone("granite", "Granite", "гранитные", "гранитных", "гранитная", "гранит",
                MapColor.DIRT, SoundType.STONE, 1.5F, 6.0F, true));
        register(new Stone("calcite", "Calcite", "кальцитовые", "кальцитовых", "кальцитовая", "кальцит",
                MapColor.TERRACOTTA_WHITE, SoundType.CALCITE, 1.5F, 6.0F, false));
        register(new Stone("dripstone", "Dripstone", "капельниковые", "капельниковых", "капельниковая", "капельник",
                MapColor.TERRACOTTA_BROWN, SoundType.DRIPSTONE_BLOCK, 1.5F, 6.0F, false));
    }

    private RpedMasonry() {
    }

    public static void init() {
    }

    public static boolean isSectionStart(Item item) {
        List<RegistryObject<Item>> group = GROUPS.get("andesite");
        return group != null && !group.isEmpty() && group.get(0).isPresent() && group.get(0).get() == item;
    }

    public static List<ItemStack> stacks(String stoneId) {
        List<ItemStack> result = new ArrayList<>();
        List<RegistryObject<Item>> group = GROUPS.get(stoneId);
        if (group != null)
            for (RegistryObject<Item> item : group)
                result.add(new ItemStack(item.get()));
        return result;
    }

    public static List<ItemStack> allStacks() {
        List<ItemStack> result = new ArrayList<>();
        for (String id : GROUPS.keySet())
            result.addAll(stacks(id));
        return result;
    }

    private static String capitalize(String text) {
        return Character.toUpperCase(text.charAt(0)) + text.substring(1);
    }

    private static BlockBehaviour.Properties props(Stone s) {
        return BlockBehaviour.Properties.of()
                .mapColor(s.color())
                .sound(s.sound())
                .instrument(NoteBlockInstrument.BASEDRUM)
                .requiresCorrectToolForDrops()
                .strength(s.hardness(), s.resistance());
    }

    private static void register(Stone s) {
        List<RegistryObject<Item>> group = new ArrayList<>();
        GROUPS.put(s.id(), group);

        Supplier<Block> base = Suppliers.memoize(() -> new DecorBlock(props(s),
                capitalize(s.ruPlural()) + " кирпичи", s.en() + " Bricks"));

        add(group, s.id() + "_bricks", base);
        add(group, s.id() + "_brick_stairs", () -> new DecorStairs(() -> base.get().defaultBlockState(), props(s),
                "Ступеньки из " + s.ruGenitive() + " кирпичей", s.en() + " Brick Stairs"));
        add(group, s.id() + "_brick_slab", () -> new DecorSlab(props(s),
                "Плита из " + s.ruGenitive() + " кирпичей", s.en() + " Brick Slab"));
        add(group, s.id() + "_brick_wall", () -> new DecorWall(props(s).forceSolidOn(),
                "Ограда из " + s.ruGenitive() + " кирпичей", s.en() + " Brick Wall"));
        add(group, "chiseled_" + s.id(), () -> new DecorBlock(props(s),
                "Резной " + s.ruNoun(), "Chiseled " + s.en()));
        add(group, s.id() + "_pillar", () -> new DecorPillar(props(s),
                capitalize(s.ruFeminine()) + " колонна", s.en() + " Pillar"));
        if (s.cracked())
            add(group, "cracked_" + s.id() + "_bricks", () -> new DecorBlock(props(s),
                    "Потрескавшиеся " + s.ruPlural() + " кирпичи", "Cracked " + s.en() + " Bricks"));
    }

    private static void add(List<RegistryObject<Item>> group, String id, Supplier<Block> factory) {
        RegistryObject<Block> block = RpedModBlocks.REGISTRY.register(id, factory);
        RegistryObject<Item> item = RpedModItems.REGISTRY.register(id, () -> new DecorBlockItem(block.get()));
        group.add(item);
    }

    public static class DecorBlockItem extends BlockItem {
        public DecorBlockItem(Block block) {
            super(block, new Item.Properties());
        }

        @Override
        public Component getName(ItemStack stack) {
            return getBlock().getName();
        }
    }

    public static class DecorBlock extends Block {
        private final String ru;
        private final String en;

        public DecorBlock(BlockBehaviour.Properties properties, String ru, String en) {
            super(properties);
            this.ru = ru;
            this.en = en;
        }

        @Override
        public MutableComponent getName() {
            return Component.literal(ExtLang.pick(ru, en));
        }
    }

    public static class DecorStairs extends StairBlock {
        private final String ru;
        private final String en;

        public DecorStairs(Supplier<BlockState> state, BlockBehaviour.Properties properties, String ru, String en) {
            super(state, properties);
            this.ru = ru;
            this.en = en;
        }

        @Override
        public MutableComponent getName() {
            return Component.literal(ExtLang.pick(ru, en));
        }
    }

    public static class DecorSlab extends SlabBlock {
        private final String ru;
        private final String en;

        public DecorSlab(BlockBehaviour.Properties properties, String ru, String en) {
            super(properties);
            this.ru = ru;
            this.en = en;
        }

        @Override
        public MutableComponent getName() {
            return Component.literal(ExtLang.pick(ru, en));
        }
    }

    public static class DecorWall extends WallBlock {
        private final String ru;
        private final String en;

        public DecorWall(BlockBehaviour.Properties properties, String ru, String en) {
            super(properties);
            this.ru = ru;
            this.en = en;
        }

        @Override
        public MutableComponent getName() {
            return Component.literal(ExtLang.pick(ru, en));
        }
    }

    public static class DecorPillar extends RotatedPillarBlock {
        private final String ru;
        private final String en;

        public DecorPillar(BlockBehaviour.Properties properties, String ru, String en) {
            super(properties);
            this.ru = ru;
            this.en = en;
        }

        @Override
        public MutableComponent getName() {
            return Component.literal(ExtLang.pick(ru, en));
        }
    }
}