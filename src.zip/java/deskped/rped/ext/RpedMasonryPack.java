package deskped.rped.ext;

import net.minecraft.network.chat.Component;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.PathPackResources;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.repository.PackSource;

import net.minecraftforge.event.AddPackFindersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.forgespi.locating.IModFile;

import java.nio.file.Path;

@Mod.EventBusSubscriber(modid = "rped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class RpedMasonryPack {

    public static final String PACK_ID = "rped_masonry";

    @SubscribeEvent
    public static void addPackFinders(AddPackFindersEvent event) {
        if (event.getPackType() != PackType.SERVER_DATA)
            return;
        IModFile modFile = ModList.get().getModFileById("rped").getFile();
        Path root = modFile.findResource("resourcepacks", PACK_ID);
        Pack pack = Pack.readMetaAndCreate(
                PACK_ID,
                Component.literal("rped masonry"),
                true,
                id -> new PathPackResources(id, root, false),
                PackType.SERVER_DATA,
                Pack.Position.TOP,
                PackSource.BUILT_IN);
        if (pack != null)
            event.addRepositorySource(consumer -> consumer.accept(pack));
    }
}
