package deskped.rped.ext;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;

import deskped.rped.init.RpedModBlocks;
import deskped.rped.block.entity.CoreBlockEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber
public class CoreProtection {
	private static final float STRIKE_DAMAGE = 4.0F;
	private static final double STRIKE_KNOCKBACK = 1.2;
	private static final int STRIKE_SLOWNESS_TICKS = 60;
	private static final long STRIKE_GAP = 15L;

	private static final Map<UUID, Long> STRIKES = new HashMap<>();

	private static boolean locked(LevelAccessor level, BlockPos pos) {
		return level.getBlockState(pos).is(RpedModBlocks.CORE.get()) && level.getBlockEntity(pos) instanceof CoreBlockEntity core && core.getPhase() == CoreBlockEntity.PHASE_COOLDOWN;
	}

	@SubscribeEvent
	public static void onLeftClick(PlayerInteractEvent.LeftClickBlock event) {
		if (event.getLevel().isClientSide() || event.getAction() != PlayerInteractEvent.LeftClickBlock.Action.START)
			return;
		if (!locked(event.getLevel(), event.getPos()))
			return;
		event.setCanceled(true);
		if (event.getEntity() instanceof ServerPlayer player && event.getLevel() instanceof ServerLevel level)
			strike(level, event.getPos(), player);
	}

	@SubscribeEvent
	public static void onBreak(BlockEvent.BreakEvent event) {
		if (locked(event.getLevel(), event.getPos()))
			event.setCanceled(true);
	}

	private static void strike(ServerLevel level, BlockPos pos, ServerPlayer player) {
		long now = level.getGameTime();
		Long last = STRIKES.get(player.getUUID());
		if (last != null && now - last < STRIKE_GAP)
			return;
		STRIKES.values().removeIf(time -> now - time > 200L);
		STRIKES.put(player.getUUID(), now);
		double cx = pos.getX() + 0.5;
		double cy = pos.getY() + 0.5;
		double cz = pos.getZ() + 0.5;
		player.hurt(level.damageSources().magic(), STRIKE_DAMAGE);
		player.knockback(STRIKE_KNOCKBACK, cx - player.getX(), cz - player.getZ());
		player.hurtMarked = true;
		player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, STRIKE_SLOWNESS_TICKS, 1));
		level.playSound(null, cx, cy, cz, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.BLOCKS, 1.0F, 1.6F);
		level.sendParticles(ParticleTypes.FLASH, cx, cy, cz, 1, 0.0, 0.0, 0.0, 0.0);
		level.sendParticles(ParticleTypes.ELECTRIC_SPARK, player.getX(), player.getY() + 1.0, player.getZ(), 30, 0.4, 0.6, 0.4, 0.4);
	}
}
