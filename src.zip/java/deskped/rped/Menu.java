package deskped.rped;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import deskped.rped.client.ClientMenuState;
import deskped.rped.client.StreamingMenuSound;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE, modid = "rped")
@OnlyIn(Dist.CLIENT)
public class Menu {

    private static final int LOGO_SRC_W = 870;
    private static final int LOGO_SRC_H = 440;
    private static final int LOGO_W     = 280;
    private static final int LOGO_H     = 142;

    private static final int BTN_SRC_W = 700;
    private static final int BTN_SRC_H = 200;
    private static final int BTN_W     = 112;
    private static final int BTN_H     = 32;
    private static final int BTN_GAP   = 4;

    private static final String SERVER = "mc.deskped.ru";

    private static final long INTRO_END_MS    = 8000L;
    private static final long INTRO_LOGO1_MS  =  500L;
    private static final long INTRO_LOGO2_MS  = 2000L;
    private static final long INTRO_LAUNCH_MS = 7000L;

    private static final int DESKPED_LOGO_W = 128;
    private static final int DESKPED_LOGO_H = 72;
    private static final int DESKPED_FOR_W  = 128;
    private static final int DESKPED_FOR_H  = 72;

    private static final ResourceLocation TEX_A    = res("textures/gui/menu/bg/a.png");
    private static final ResourceLocation TEX_B    = res("textures/gui/menu/bg/b.png");
    private static final ResourceLocation TEX_SHIP = res("textures/gui/menu/bg/airship.png");

    private static final int   REF_W  = 1920;
    private static final int   REF_H  = 1080;
    private static final float SUN_FX = 0.34f;
    private static final float SUN_FY = 0.50f;

    private static final float K_SUN  = 0.012f;
    private static final float K_BG   = 0.045f;
    private static final float K_SHIP = 0.026f;

    private static final double BG_HOLD  = 9.0;
    private static final double BG_FADE  = 4.0;
    private static final double SHIP_OUT = 8.0;
    private static final double SHIP_IN  = 10.0;

    private static final int GLOW_N  = 128;
    private static final int RAY_W   = 32;
    private static final int RAY_H   = 256;
    private static final int CLOUD_W = 512;
    private static final int CLOUD_H = 128;

    private static final int[]   PAL_A    = {0x141238, 0x3A2A74, 0x8C3F80, 0xE0606A, 0xFFA25C, 0xFFC27A};
    private static final int[]   PAL_B    = {0x2A3F8F, 0x6A5BB0, 0xD0689A, 0xFF8E6A, 0xFFC080, 0xFFE4A8};
    private static final float[] PAL_STOP = {0f, 0.28f, 0.50f, 0.64f, 0.74f, 1f};

    private static final float[] FLARE_POS = {0.35f, 0.70f, 1.00f, 1.35f, 1.80f};
    private static final float[] FLARE_SZ  = {0.05f, 0.11f, 0.04f, 0.15f, 0.07f};
    private static final int[]   FLARE_COL = {0xFFC070, 0x70FFC8, 0xFF7AA8, 0xFFD890, 0x8FA8FF};

    private static final Layer[] SKY_LAYERS = {
        new Layer(0, 0.57f, 0.17f, 1.25f, 0.55f, 0.008f, 0.008f, 0xFFC9A0),
        new Layer(1, 0.45f, 0.22f, 1.00f, 0.50f, 0.014f, 0.014f, 0xFFB0A8),
        new Layer(0, 0.30f, 0.26f, 1.40f, 0.46f, 0.022f, 0.020f, 0xF0A8C8),
        new Layer(1, 0.14f, 0.28f, 1.15f, 0.40f, 0.032f, 0.026f, 0xD8A8E0)
    };

    private static final Layer[] MIST_LAYERS = {
        new Layer(0, 0.90f, 0.30f, 1.30f, 0.15f, 0.040f, 0.070f, 0xFFD8B0),
        new Layer(1, 0.98f, 0.22f, 0.95f, 0.13f, 0.065f, 0.100f, 0xFFC0A0)
    };

    private static final long   EPOCH = System.currentTimeMillis();
    private static final Random RNG   = new Random();

    private static StreamingMenuSound customMusic;
    private static boolean wasCustomMenu;

    private static final List<ImageButton> imgButtons = new ArrayList<>();

    private static boolean introShown  = false;
    private static boolean introActive = false;
    private static long    introStart  = 0L;

    private static final List<Star>   stars   = new ArrayList<>();
    private static final List<Dust>   dusts   = new ArrayList<>();
    private static final List<Streak> streaks = new ArrayList<>();
    private static final List<Glint>  glints  = new ArrayList<>();

    private static float breathScale = 1f;
    private static float breathDir   = 1f;
    private static final float BREATH_SPD = 0.00022f;
    private static final float BREATH_MAX = 0.011f;

    private static float   smoothMX = 0f;
    private static float   smoothMY = 0f;
    private static boolean mouseInit = false;
    private static long    lastNow = 0L;

    private static float windNow = 1f;
    private static float gustNow = 0f;

    private static double sceneStart = -1.0;
    private static int    shipPhase  = 0;
    private static double shipStart  = 0.0;
    private static double shipNext   = -1.0;
    private static double shipAway   = 8.0;

    private static boolean probed;
    private static boolean texReady;
    private static int[] bgA;
    private static int[] bgB;
    private static int[] shipDim;

    private static ResourceLocation texGlow;
    private static ResourceLocation texRing;
    private static ResourceLocation texRay;
    private static ResourceLocation texCloud0;
    private static ResourceLocation texCloud1;

    private static final float[] btnHover = new float[4];
    private static final float[] btnScale = new float[4];

    private static ResourceLocation res(String path) {
        return ResourceLocation.fromNamespaceAndPath("rped", path);
    }

    @SubscribeEvent
    public static void onScreenInit(ScreenEvent.Init.Post event) {
        if (!(event.getScreen() instanceof TitleScreen)) return;
        Screen    screen = event.getScreen();
        Minecraft mc     = Minecraft.getInstance();
        imgButtons.clear();

        boolean isCustom = ClientMenuState.customMenu;
        if (isCustom != wasCustomMenu) {
            if (isCustom) { nukeMusic(); startMusic(); } else stopMusic();
            wasCustomMenu = isCustom;
        }

        if (ClientMenuState.customMenu) {
            new ArrayList<>(event.getListenersList()).forEach(o -> { if (o instanceof Button b) event.removeListener(b); });

            probeAssets();

            boolean ru = mc.options.languageCode.startsWith("ru");
            int cx        = screen.width / 2;
            int logoTopY  = 14;
            int btnStartY = logoTopY + LOGO_H + 2;
            int total     = 4 * BTN_H + 3 * BTN_GAP;
            int avail     = screen.height - btnStartY - 8;
            float fit     = Math.max(0.55f, Math.min(1f, avail / (float) total));
            int bw        = Math.round(BTN_W * fit);
            int bh        = Math.round(BTN_H * fit);
            int gap       = Math.max(2, Math.round(BTN_GAP * fit));

            String[] keys = {"play", "options", "back", "exit"};
            for (int i = 0; i < keys.length; i++) {
                String key     = keys[i];
                String texName = ru ? key + "_ru" : key;
                ResourceLocation tex = ResourceLocation.fromNamespaceAndPath("rped", "textures/gui/menu/btn/" + texName + ".png");
                int bx = cx - bw / 2;
                int by = btnStartY + i * (bh + gap);
                final String k = key;
                ImageButton ib = new ImageButton(bx, by, bw, bh, BTN_SRC_W, BTN_SRC_H, tex,
                        b -> handleButtonClick(k, screen, mc, ru));
                imgButtons.add(ib);
                event.addListener(ib);
                btnHover[i] = 0f;
                btnScale[i] = 1f;
            }

            if (!introShown) { introActive = true; introStart = System.currentTimeMillis(); introShown = true; }
        }
    }

    private static void handleButtonClick(String key, Screen screen, Minecraft mc, boolean ru) {
        switch (key) {
            case "play" -> {
                if (ClientMenuState.confirmed) { connect(screen, mc); return; }
                mc.setScreen(new ConfirmScreen(screen, mc, ru));
            }
            case "options" -> mc.setScreen(new net.minecraft.client.gui.screens.OptionsScreen(screen, mc.options));
            case "back"    -> { ClientMenuState.customMenu = false; stopMusic(); mc.setScreen(new TitleScreen()); }
            case "exit"    -> mc.stop();
        }
    }

    static void connect(Screen from, Minecraft mc) {
        ServerData sd = new ServerData("RPED", SERVER, false);
        ConnectScreen.startConnecting(from, mc, ServerAddress.parseString(SERVER), sd, false);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onRenderPre(ScreenEvent.Render.Pre event) {
        if (!(event.getScreen() instanceof TitleScreen)) return;
        if (!ClientMenuState.customMenu) return;

        nukeMusic();
        event.setCanceled(true);

        Screen      screen  = event.getScreen();
        GuiGraphics g       = event.getGuiGraphics();
        long        now     = System.currentTimeMillis();
        int         mx      = event.getMouseX();
        int         my      = event.getMouseY();
        float       partial = event.getPartialTick();
        double      t       = (now - EPOCH) / 1000.0;

        long gap = lastNow == 0L ? Long.MAX_VALUE : now - lastNow;
        float dt = gap > 1500L ? 0.016f : Math.min(0.1f, gap / 1000f);
        lastNow = now;
        if (gap > 1500L) {
            sceneStart = t;
            mouseInit  = false;
            shipPhase  = 0;
            shipNext   = -1.0;
        }

        ensureAssets();

        if (introActive) { renderIntro(g, screen, now); return; }

        if (!mouseInit) {
            smoothMX = screen.width  * 0.5f;
            smoothMY = screen.height * 0.5f;
            mouseInit = true;
        }
        float f = 1f - (float) Math.exp(-dt * 2.6f);
        smoothMX += (mx - smoothMX) * f;
        smoothMY += (my - smoothMY) * f;

        updateBreath();
        tickScene(t, dt);

        float avX = (smoothMX - screen.width  * 0.5f) / screen.width  + (float) Math.sin(t * 0.17) * 0.05f;
        float avY = (smoothMY - screen.height * 0.5f) / screen.height + (float) Math.sin(t * 0.13 + 1.0) * 0.04f;

        drawScene(g, screen.width, screen.height, t, avX, avY);
        drawLogo(g, screen.width, screen.height, now);
        drawImageButtons(g, mx, my, partial, now);
        drawCornerLogos(g, screen.width, screen.height);

        for (Renderable r : screen.renderables) {
            if (r instanceof ImageButton) continue;
            r.render(g, mx, my, partial);
        }
    }

    public static void drawSpaceBg(GuiGraphics g, int sw, int sh, long now, float avX, float avY) {
        ensureAssets();
        drawScene(g, sw, sh, (now - EPOCH) / 1000.0, avX, avY);
    }

    private static void ensureAssets() {
        if (!probed) probeAssets();
        if (!texReady) {
            texReady = true;
            try { buildTextures(); } catch (Exception e) { e.printStackTrace(); }
        }
        if (stars.isEmpty()) buildScene();
    }

    private static void probeAssets() {
        probed   = true;
        bgA      = probe(TEX_A);
        bgB      = probe(TEX_B);
        shipDim  = probe(TEX_SHIP);
    }

    private static int[] probe(ResourceLocation rl) {
        try {
            var opt = Minecraft.getInstance().getResourceManager().getResource(rl);
            if (opt.isEmpty()) return null;
            try (InputStream in = opt.get().open()) {
                byte[] h = in.readNBytes(24);
                if (h.length < 24) return null;
                int w  = (h[16] & 255) << 24 | (h[17] & 255) << 16 | (h[18] & 255) << 8 | (h[19] & 255);
                int hh = (h[20] & 255) << 24 | (h[21] & 255) << 16 | (h[22] & 255) << 8 | (h[23] & 255);
                if (w <= 0 || hh <= 0) return null;
                return new int[]{w, hh};
            }
        } catch (Exception e) {
            return null;
        }
    }

    private static void buildScene() {
        stars.clear();
        dusts.clear();
        streaks.clear();
        glints.clear();
        for (int i = 0; i < 90; i++) stars.add(new Star());
        for (int i = 0; i < 70; i++) dusts.add(new Dust());
        for (int i = 0; i < 7; i++) { Streak s = new Streak(); s.reset(true); streaks.add(s); }
        for (int i = 0; i < 16; i++) glints.add(new Glint(i < 8));
    }

    private interface Px { int get(int x, int y); }

    private static int abgr(int r, int g, int b, int a) {
        return (Math.max(0, Math.min(255, a)) << 24) | (b << 16) | (g << 8) | r;
    }

    private static ResourceLocation makeTex(String name, int w, int h, Px px) {
        NativeImage img = new NativeImage(NativeImage.Format.RGBA, w, h, false);
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                img.setPixelRGBA(x, y, px.get(x, y));
        DynamicTexture dt = new DynamicTexture(img);
        ResourceLocation rl = res("dyn/" + name);
        Minecraft.getInstance().getTextureManager().register(rl, dt);
        dt.setFilter(true, false);
        return rl;
    }

    private static void buildTextures() {
        texGlow = makeTex("glow", GLOW_N, GLOW_N, (x, y) -> {
            float dx = (x + 0.5f) / (GLOW_N * 0.5f) - 1f;
            float dy = (y + 0.5f) / (GLOW_N * 0.5f) - 1f;
            float d  = (float) Math.sqrt(dx * dx + dy * dy);
            float a  = (float) Math.pow(Math.max(0f, 1f - d), 2.4);
            return abgr(255, 255, 255, (int) (a * 255f));
        });
        texRing = makeTex("ring", GLOW_N, GLOW_N, (x, y) -> {
            float dx = (x + 0.5f) / (GLOW_N * 0.5f) - 1f;
            float dy = (y + 0.5f) / (GLOW_N * 0.5f) - 1f;
            float d  = (float) Math.sqrt(dx * dx + dy * dy);
            float r  = (d - 0.74f) / 0.09f;
            float a  = (float) Math.exp(-r * r) * 0.85f + Math.max(0f, 1f - d) * 0.07f;
            if (d >= 1f) a = 0f;
            a = Math.min(1f, a);
            return abgr(255, 255, 255, (int) (a * 255f));
        });
        texRay = makeTex("ray", RAY_W, RAY_H, (x, y) -> {
            float u = Math.abs((x + 0.5f) / (RAY_W * 0.5f) - 1f);
            float v = (y + 0.5f) / RAY_H;
            float a = (float) Math.pow(1f - u, 1.6) * (float) Math.pow(1f - v, 1.3) * sstep(v / 0.06f);
            return abgr(255, 255, 255, (int) (a * 255f));
        });
        texCloud0 = cloudTex("cloud0", 11);
        texCloud1 = cloudTex("cloud1", 57);
    }

    private static ResourceLocation cloudTex(String name, int seed) {
        return makeTex(name, CLOUD_W, CLOUD_H, (x, y) -> {
            float fx    = x / (float) CLOUD_W * 4f;
            float fy    = y / (float) CLOUD_H * 1.7f;
            float v     = (y + 0.5f) / CLOUD_H;
            float env   = (float) Math.sin(Math.PI * v);
            float shape = fbm(fx, fy, 4, seed) + (env - 0.6f) * 0.55f;
            float dens  = sstep((shape - 0.5f) / 0.3f);
            float rim   = (1f - dens) * 0.6f;
            int r = lerp(lerp(226, 255, v), 255, rim);
            int g = lerp(lerp(216, 214, v), 238, rim);
            int b = lerp(lerp(244, 184, v), 214, rim);
            return abgr(r, g, b, (int) (dens * 0.92f * 255f));
        });
    }

    private static float hash(int x, int y, int seed) {
        int h = x * 374761393 + y * 668265263 + seed * 1274126177;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xFFFFFF) / (float) 0x1000000;
    }

    private static float vnoise(float x, float y, int period, int seed) {
        int xi = (int) Math.floor(x);
        int yi = (int) Math.floor(y);
        float fx = x - xi;
        float fy = y - yi;
        int x0 = Math.floorMod(xi, period);
        int x1 = Math.floorMod(xi + 1, period);
        float a = hash(x0, yi, seed);
        float b = hash(x1, yi, seed);
        float c = hash(x0, yi + 1, seed);
        float d = hash(x1, yi + 1, seed);
        float u = fx * fx * (3f - 2f * fx);
        float v = fy * fy * (3f - 2f * fy);
        return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
    }

    private static float fbm(float x, float y, int period, int seed) {
        float sum = 0f;
        float amp = 0.5f;
        int   p   = period;
        for (int o = 0; o < 5; o++) {
            sum += amp * vnoise(x, y, p, seed + o * 17);
            x *= 2f;
            y *= 2f;
            p *= 2;
            amp *= 0.5f;
        }
        return sum;
    }

    private static void tickScene(double t, float dt) {
        windNow = windAt(t);
        gustNow = clamp01((windNow - 0.9f) / 0.9f);
        for (Layer l : SKY_LAYERS)  l.scroll -= l.speed * windNow * dt;
        for (Layer l : MIST_LAYERS) l.scroll -= l.speed * windNow * dt;
        for (Dust d : dusts) {
            d.x -= d.spd * windNow * dt * (0.3f + d.z);
            d.y += (float) Math.sin(t * 0.8 + d.ph) * 0.02f * dt * (0.4f + d.z);
            if (d.y < 0f) d.y += 1f;
            if (d.y > 1f) d.y -= 1f;
            if (d.x < -0.06f) { d.x = 1.06f; d.y = RNG.nextFloat(); }
        }
        for (Streak s : streaks) {
            s.life -= dt;
            if (s.life <= 0f) s.reset(false);
            else s.x -= s.spd * windNow * dt;
        }
        tickShip(t);
    }

    private static float windAt(double t) {
        float w = 1f + 0.55f * (float) Math.sin(t * 0.23) + 0.3f * (float) Math.sin(t * 0.61 + 1.7) + 0.15f * (float) Math.sin(t * 1.7 + 0.4);
        return Math.max(0.25f, w);
    }

    private static void tickShip(double t) {
        if (shipNext < 0.0) { shipNext = t + 12.0 + RNG.nextDouble() * 14.0; return; }
        double el = t - shipStart;
        switch (shipPhase) {
            case 0 -> { if (t >= shipNext) { shipPhase = 1; shipStart = t; } }
            case 1 -> { if (el >= SHIP_OUT) { shipPhase = 2; shipStart = t; shipAway = 6.0 + RNG.nextDouble() * 8.0; } }
            case 2 -> { if (el >= shipAway) { shipPhase = 3; shipStart = t; } }
            default -> { if (el >= SHIP_IN) { shipPhase = 0; shipNext = t + 18.0 + RNG.nextDouble() * 26.0; } }
        }
    }

    private static float crossMix(double t) {
        double c = t % (2.0 * BG_HOLD + 2.0 * BG_FADE);
        if (c < BG_HOLD) return 0f;
        if (c < BG_HOLD + BG_FADE) return sstep((float) ((c - BG_HOLD) / BG_FADE));
        if (c < 2.0 * BG_HOLD + BG_FADE) return 1f;
        return 1f - sstep((float) ((c - 2.0 * BG_HOLD - BG_FADE) / BG_FADE));
    }

    private static float blurAmt(double t) {
        return 0.5f + 0.5f * (float) Math.sin(t * 0.27 + Math.sin(t * 0.11) * 2.0);
    }

    private static float[] bgBox(int sw, int sh, int bw, int bh, float avX, float avY, float k) {
        float s = Math.max(sw / (float) bw, sh / (float) bh) * 1.08f;
        float w = bw * s;
        float h = bh * s;
        return new float[]{(sw - w) * 0.5f - avX * sw * k, (sh - h) * 0.5f - avY * sh * k, w, h};
    }

    private static void drawScene(GuiGraphics g, int sw, int sh, double t, float avX, float avY) {
        float m = bgB != null ? crossMix(t - Math.max(0.0, sceneStart)) : 0f;
        float k = Math.min(1f, (0.5f + 0.5f * (float) Math.sin(t * 0.06)) * 0.55f + m * 0.35f);

        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        drawSky(g, sw, sh, k);
        drawStars(g, sw, sh, t, k);

        float[] sb = bgBox(sw, sh, REF_W, REF_H, avX, avY, K_SUN);
        float sx = sb[0] + SUN_FX * sb[2];
        float sy = sb[1] + SUN_FY * sb[3];

        drawSunLight(g, sw, sh, t, sx, sy);
        for (Layer l : SKY_LAYERS) drawLayer(g, sw, sh, avX, avY, t, l);
        drawStreaks(g, sw, sh, avX, avY);
        drawShip(g, sw, sh, avX, avY, t);
        drawBackdrop(g, sw, sh, avX, avY, t, m);
        for (Layer l : MIST_LAYERS) drawLayer(g, sw, sh, avX, avY, t, l);
        drawGlare(g, sw, sh, avX, avY, t, sx, sy);
        drawDust(g, sw, sh, avX, avY, t);
        drawFinish(g, sw, sh, t);
    }

    private static void drawSky(GuiGraphics g, int sw, int sh, float k) {
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        for (int i = 0; i < PAL_STOP.length - 1; i++) {
            int y0 = Math.round(sh * PAL_STOP[i]);
            int y1 = Math.round(sh * PAL_STOP[i + 1]);
            int c0 = 0xFF000000 | lerpColor(PAL_A[i], PAL_B[i], k);
            int c1 = 0xFF000000 | lerpColor(PAL_A[i + 1], PAL_B[i + 1], k);
            gradQuad(g, 0, y0, sw, y1, c0, c0, c1, c1);
        }
    }

    private static void drawStars(GuiGraphics g, int sw, int sh, double t, float k) {
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        for (Star s : stars) {
            float tw = 0.5f + 0.5f * (float) Math.sin(t * s.spd + s.ph);
            float a  = (1f - s.y * 2f) * (0.3f + 0.7f * tw) * (1f - 0.8f * k);
            if (a < 0.04f) continue;
            int px = (int) (s.x * sw);
            int py = (int) (s.y * sh);
            g.fill(px, py, px + 1, py + 1, ((int) (a * 255f) << 24) | 0xFFEEDD);
        }
    }

    private static void drawSunLight(GuiGraphics g, int sw, int sh, double t, float sx, float sy) {
        blendAdd();
        float p = 0.5f + 0.5f * (float) Math.sin(t * 0.5);
        glow(g, sw * 0.5f, sh * 0.70f, sw * 1.6f, sh * 0.50f, 0xFF9A55, 0.22f);
        glow(g, sx, sy, sh * 3.0f, sh * 3.0f, 0xFF7A30, 0.30f + 0.08f * p);
        for (int i = 0; i < 10; i++) {
            float ang = i * 36f + (float) (t * 1.4) + (float) Math.sin(i * 1.7) * 10f;
            float len = sh * (0.85f + 0.3f * (float) Math.sin(i * 2.3 + t * 0.4));
            float wd  = sh * (0.05f + 0.03f * (float) Math.sin(i * 3.1 + t * 0.3));
            float a   = (0.09f + 0.06f * (float) Math.sin(t * 0.7 + i * 1.9)) * (0.7f + 0.5f * gustNow);
            ray(g, sx, sy, wd, len, ang, 0xFFD090, a);
        }
        glow(g, sx, sy, sh * 1.5f, sh * 1.5f, 0xFFA850, 0.48f);
        glow(g, sx, sy, sh * 0.62f, sh * 0.62f, 0xFFD58A, 0.75f);
        glow(g, sx, sy, sh * 0.20f, sh * 0.20f, 0xFFF6DA, 1f);
        blendNormal();
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    private static void drawLayer(GuiGraphics g, int sw, int sh, float avX, float avY, double t, Layer l) {
        ResourceLocation tex = l.tex == 0 ? texCloud0 : texCloud1;
        if (tex == null) return;
        float tw  = sw * l.w;
        float th  = sh * l.h;
        float cy  = sh * l.cy + (float) Math.sin(t * 0.12 + l.cy * 9.0) * sh * 0.008f - avY * sh * l.k * 0.5f;
        float off = (l.scroll * sw) % tw;
        if (off > 0f) off -= tw;
        float px = off - avX * sw * l.k;
        float a  = l.alpha * (0.82f + 0.3f * gustNow);
        blendNormal();
        RenderSystem.setShaderColor(((l.tint >> 16) & 255) / 255f, ((l.tint >> 8) & 255) / 255f, (l.tint & 255) / 255f, Math.min(1f, a));
        for (int j = -1; ; j++) {
            float x = px + j * tw;
            if (x > sw) break;
            if (x + tw < 0f) continue;
            g.pose().pushPose();
            g.pose().translate(x, cy - th * 0.5f, 0f);
            g.pose().scale((tw + 1f) / CLOUD_W, th / CLOUD_H, 1f);
            g.blit(tex, 0, 0, 0, 0, CLOUD_W, CLOUD_H, CLOUD_W, CLOUD_H);
            g.pose().popPose();
        }
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    private static void drawStreaks(GuiGraphics g, int sw, int sh, float avX, float avY) {
        blendAdd();
        for (Streak s : streaks) {
            float env = (float) Math.sin(Math.PI * clamp01(s.life / s.maxLife));
            float a   = env * env * 0.30f * (0.5f + 0.8f * gustNow);
            float x   = s.x * sw - avX * sw * 0.03f;
            float y   = s.y * sh - avY * sh * 0.03f;
            glow(g, x, y, s.len * sw, s.thick * 3f, 0xFFE8D0, a);
        }
        blendNormal();
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    private static void drawShip(GuiGraphics g, int sw, int sh, float avX, float avY, double t) {
        if (shipDim == null || shipPhase == 2) return;
        float H  = sh * 0.20f * (1f + 0.012f * (float) Math.sin(t * 0.9));
        float W  = H * shipDim[0] / shipDim[1];
        float hx = sw * 0.56f + (float) Math.sin(t * 0.13) * sw * 0.04f;
        float hy = sh * 0.20f + (float) Math.sin(t * 0.29) * sh * 0.016f + (float) Math.sin(t * 0.71 + 1.0) * sh * 0.005f;
        float ox = 0f;
        float oy = 0f;
        float lean = (float) Math.sin(t * 0.37) * 2.2f + gustNow * 1.5f;
        float move = 0f;
        if (shipPhase == 1) {
            float p = clamp01((float) ((t - shipStart) / SHIP_OUT));
            float e = p * p;
            ox = -e * (hx + W * 1.7f);
            oy = -e * sh * 0.035f;
            lean -= 4f * e;
            move = p;
        } else if (shipPhase == 3) {
            float p = clamp01((float) ((t - shipStart) / SHIP_IN));
            float e = 1f - (1f - p) * (1f - p) * (1f - p);
            ox = (1f - e) * (sw - hx + W * 1.7f);
            oy = (1f - e) * sh * 0.02f;
            lean += 3f * (1f - e);
            move = 1f - p;
        }
        float cx = hx + ox - avX * sw * K_SHIP;
        float cy = hy + oy - avY * sh * K_SHIP;
        if (cx + W < 0f || cx - W > sw) return;
        smooth(TEX_SHIP);
        if (move > 0.05f) {
            blendAdd();
            for (int i = 0; i < 3; i++)
                glow(g, cx + W * 1.4f, cy + (i - 1) * H * 0.12f, W * 2.4f, H * 0.03f, 0xFFE2B8, 0.25f * move);
        }
        blendNormal();
        tex(g, TEX_SHIP, cx, cy, W, H, lean, 0xFFE8D6, 0.96f, shipDim[0], shipDim[1]);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    private static void drawBackdrop(GuiGraphics g, int sw, int sh, float avX, float avY, double t, float m) {
        float blur = blurAmt(t);
        float aa   = m < 0.5f ? 1f : Math.max(0f, 2f * (1f - m));
        if (bgA != null && aa > 0.01f) drawBgLayer(g, TEX_A, bgA, sw, sh, avX, avY, aa, blur, t);
        if (bgB != null && m > 0.01f)  drawBgLayer(g, TEX_B, bgB, sw, sh, avX, avY, m, blur, t);
    }

    private static void drawBgLayer(GuiGraphics g, ResourceLocation rl, int[] dim, int sw, int sh, float avX, float avY, float alpha, float blur, double t) {
        float[] bx = bgBox(sw, sh, dim[0], dim[1], avX, avY, K_BG);
        float s = bx[2] / dim[0];
        smooth(rl);
        blendNormal();
        bgDraw(g, rl, dim, bx[0], bx[1], s, alpha);
        float cov  = 0.10f + 0.34f * blur;
        float each = 1f - (float) Math.pow(1f - cov, 1.0 / 12.0);
        float r    = sh * (0.0022f + 0.0068f * blur);
        for (int i = 0; i < 12; i++) {
            float ang = (float) ((i % 6) * Math.PI / 3.0 + (i < 6 ? 0.0 : Math.PI / 6.0) + t * 0.35);
            float rr  = i < 6 ? r : r * 2f;
            bgDraw(g, rl, dim, bx[0] + (float) Math.cos(ang) * rr, bx[1] + (float) Math.sin(ang) * rr, s, alpha * each);
        }
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    private static void bgDraw(GuiGraphics g, ResourceLocation rl, int[] dim, float x, float y, float s, float a) {
        RenderSystem.setShaderColor(1f, 1f, 1f, Math.min(1f, a));
        g.pose().pushPose();
        g.pose().translate(x, y, 0f);
        g.pose().scale(s, s, 1f);
        g.blit(rl, 0, 0, 0, 0, dim[0], dim[1], dim[0], dim[1]);
        g.pose().popPose();
    }

    private static void drawGlare(GuiGraphics g, int sw, int sh, float avX, float avY, double t, float sx, float sy) {
        blendAdd();
        float p = 0.5f + 0.5f * (float) Math.sin(t * 0.7 + 1.0);
        glow(g, sx, sy, sh * 2.2f, sh * 2.2f, 0xFFB070, 0.12f + 0.06f * p);
        glow(g, sx, sy, sw * 1.3f, sh * 0.05f, 0xFFE0B0, 0.20f + 0.10f * p);
        glow(g, sx, sy, sw * 0.55f, sh * 0.012f, 0xFFF4DC, 0.45f);

        float vx = smoothMX - sx;
        float vy = smoothMY - sy;
        float fl = 0.55f + 0.45f * (float) Math.sin(t * 0.9 + 2.0);
        for (int i = 0; i < FLARE_POS.length; i++) {
            float px = sx + vx * FLARE_POS[i];
            float py = sy + vy * FLARE_POS[i];
            float sz = sh * FLARE_SZ[i];
            if (i % 2 == 0) tex(g, texRing, px, py, sz, sz, 0f, FLARE_COL[i], 0.16f * fl, GLOW_N, GLOW_N);
            else glow(g, px, py, sz, sz, FLARE_COL[i], 0.20f * fl);
        }

        float[] bb = bgBox(sw, sh, REF_W, REF_H, avX, avY, K_BG);
        for (Glint gl : glints) {
            float v = (float) Math.sin(t * gl.spd + gl.ph);
            if (v <= 0f) continue;
            v = v * v * v * v * v * v;
            if (v < 0.02f) continue;
            float px = bb[0] + gl.fx * bb[2];
            float py = bb[1] + gl.fy * bb[3];
            float s  = sh * gl.size;
            glow(g, px, py, s * 2.2f, s * 2.2f, 0xFFE3B0, 0.55f * v);
            glow(g, px, py, s * 7f, s * 0.35f, 0xFFF2D6, 0.80f * v);
            glow(g, px, py, s * 0.35f, s * 7f, 0xFFF2D6, 0.80f * v);
        }
        blendNormal();
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    private static void drawDust(GuiGraphics g, int sw, int sh, float avX, float avY, double t) {
        blendAdd();
        for (Dust d : dusts) {
            float pk = 0.02f + 0.10f * d.z;
            float x  = d.x * sw - avX * sw * pk;
            float y  = d.y * sh - avY * sh * pk;
            float s  = (2.5f + 6f * d.size) * (0.6f + 0.8f * d.z);
            float a  = (0.22f + 0.35f * d.z) * (0.45f + 0.55f * (float) Math.sin(t * d.tw + d.ph));
            glow(g, x, y, s * 2f, s * 2f, 0xFFE6B8, a);
        }
        blendNormal();
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    private static void drawFinish(GuiGraphics g, int sw, int sh, double t) {
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        float b = blurAmt(t);
        g.fill(0, 0, sw, sh, ((int) (6f + 16f * b) << 24) | 0xFFC090);
        int e = 0x50080410;
        int z = 0x00080410;
        gradQuad(g, 0, 0, sw, Math.round(sh * 0.25f), e, e, z, z);
        gradQuad(g, 0, Math.round(sh * 0.72f), sw, sh, z, z, 0x60080410, 0x60080410);
        gradQuad(g, 0, 0, Math.round(sw * 0.12f), sh, e, z, z, e);
        gradQuad(g, Math.round(sw * 0.88f), 0, sw, sh, z, e, e, z);
        blendNormal();
    }

    private static void blendNormal() {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
    }

    private static void blendAdd() {
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
    }

    private static void smooth(ResourceLocation rl) {
        try { Minecraft.getInstance().getTextureManager().getTexture(rl).setFilter(true, false); } catch (Exception ignored) {}
    }

    private static void tex(GuiGraphics g, ResourceLocation rl, float cx, float cy, float w, float h, float rot, int rgb, float a, int tw, int th) {
        if (rl == null || a <= 0.004f) return;
        RenderSystem.enableBlend();
        RenderSystem.setShaderColor(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f, Math.min(1f, a));
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0f);
        if (rot != 0f) g.pose().mulPose(Axis.ZP.rotationDegrees(rot));
        g.pose().scale(w / tw, h / th, 1f);
        g.pose().translate(-tw * 0.5f, -th * 0.5f, 0f);
        g.blit(rl, 0, 0, 0, 0, tw, th, tw, th);
        g.pose().popPose();
    }

    private static void glow(GuiGraphics g, float cx, float cy, float w, float h, int rgb, float a) {
        tex(g, texGlow, cx, cy, w, h, 0f, rgb, a, GLOW_N, GLOW_N);
    }

    private static void ray(GuiGraphics g, float sx, float sy, float wd, float len, float ang, int rgb, float a) {
        if (texRay == null || a <= 0.004f) return;
        RenderSystem.enableBlend();
        RenderSystem.setShaderColor(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f, Math.min(1f, a));
        g.pose().pushPose();
        g.pose().translate(sx, sy, 0f);
        g.pose().mulPose(Axis.ZP.rotationDegrees(ang));
        g.pose().scale(wd / RAY_W, len / RAY_H, 1f);
        g.pose().translate(-RAY_W * 0.5f, 0f, 0f);
        g.blit(texRay, 0, 0, 0, 0, RAY_W, RAY_H, RAY_W, RAY_H);
        g.pose().popPose();
    }

    private static void gradQuad(GuiGraphics g, int x0, int y0, int x1, int y1, int cTL, int cTR, int cBR, int cBL) {
        VertexConsumer buf = g.bufferSource().getBuffer(RenderType.gui());
        Matrix4f mat = g.pose().last().pose();
        put(buf, mat, x0, y0, cTL);
        put(buf, mat, x0, y1, cBL);
        put(buf, mat, x1, y1, cBR);
        put(buf, mat, x1, y0, cTR);
        g.bufferSource().endBatch(RenderType.gui());
    }

    private static void put(VertexConsumer b, Matrix4f m, float x, float y, int c) {
        b.vertex(m, x, y, 0f).color((c >> 16) & 255, (c >> 8) & 255, c & 255, (c >>> 24) & 255).endVertex();
    }

    private static void drawImageButtons(GuiGraphics g, int mx, int my, float partial, long now) {
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        for (int i = 0; i < imgButtons.size(); i++) {
            ImageButton ib  = imgButtons.get(i);
            boolean     hov = mx >= ib.getX() && mx <= ib.getX() + ib.getWidth()
                           && my >= ib.getY() && my <= ib.getY() + ib.getHeight();
            btnHover[i] = clamp01(btnHover[i] + (hov ? 0.08f : -0.06f));
            float h   = btnHover[i];
            float targetScale = 1f + h * 0.04f;
            btnScale[i] += (targetScale - btnScale[i]) * 0.15f;
            float sc  = btnScale[i];
            float bcx = ib.getX() + ib.getWidth()  * 0.5f;
            float bcy = ib.getY() + ib.getHeight() * 0.5f;
            float sx  = (float) ib.getWidth()  / ib.srcW * sc;
            float sy  = (float) ib.getHeight() / ib.srcH * sc;
            RenderSystem.setShaderColor(1f, 1f, 1f, 0.85f + h * 0.15f);
            g.pose().pushPose();
            g.pose().translate(bcx, bcy, 0);
            g.pose().scale(sx, sy, 1f);
            g.pose().translate(-ib.srcW * 0.5f, -ib.srcH * 0.5f, 0);
            g.blit(ib.tex, 0, 0, 0, 0, ib.srcW, ib.srcH, ib.srcW, ib.srcH);
            g.pose().popPose();
        }
        RenderSystem.setShaderColor(1, 1, 1, 1);
    }

    private static void updateBreath() {
        breathScale += breathDir * BREATH_SPD;
        if (breathScale >= 1f + BREATH_MAX) { breathScale = 1f + BREATH_MAX; breathDir = -1f; }
        if (breathScale <= 1f - BREATH_MAX) { breathScale = 1f - BREATH_MAX; breathDir =  1f; }
    }

    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }

    private static float sstep(float v) {
        v = clamp01(v);
        return v * v * (3f - 2f * v);
    }

    private static int lerp(int a, int b, float t) { return (int) (a + (b - a) * t); }

    private static int lerpColor(int a, int b, float t) {
        return (lerp((a >> 16) & 255, (b >> 16) & 255, t) << 16)
             | (lerp((a >> 8) & 255, (b >> 8) & 255, t) << 8)
             |  lerp(a & 255, b & 255, t);
    }

    private static void drawLogo(GuiGraphics g, int sw, int sh, long now) {
        double t      = now / 1000.0;
        int    cx     = sw / 2;
        float  ox     = (float)(Math.sin(t * 0.37) * 4.5);
        float  oy     = (float)(Math.cos(t * 0.28) * 3.0);
        float  logoCY = 14f + LOGO_H * 0.5f;
        float  scaleX = (float) LOGO_W / LOGO_SRC_W;
        float  scaleY = (float) LOGO_H / LOGO_SRC_H;
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        g.pose().pushPose();
        g.pose().translate(cx + ox, logoCY + oy, 0);
        g.pose().scale(breathScale * scaleX, breathScale * scaleY, 1);
        g.pose().translate(-LOGO_SRC_W * 0.5f, -LOGO_SRC_H * 0.5f, 0);
        RenderSystem.setShaderColor(1, 1, 1, 1);
        g.blit(ResourceLocation.fromNamespaceAndPath("rped", "textures/screens/rped.png"),
               0, 0, 0, 0, LOGO_SRC_W, LOGO_SRC_H, LOGO_SRC_W, LOGO_SRC_H);
        g.pose().popPose();
        RenderSystem.setShaderColor(1, 1, 1, 1);
    }

    @SubscribeEvent
    public static void onMouseClicked(ScreenEvent.MouseButtonPressed.Pre event) {
        if (!(event.getScreen() instanceof TitleScreen) || !ClientMenuState.customMenu || introActive) return;
        Screen screen = event.getScreen();
        int mx = (int)event.getMouseX(), my = (int)event.getMouseY();
        int x = screen.width  - DESKPED_LOGO_W - 10;
        int y = screen.height - DESKPED_LOGO_H - 10;
        if (mx >= x && mx <= x + DESKPED_LOGO_W && my >= y && my <= y + DESKPED_LOGO_H) {
            net.minecraft.Util.getPlatform().openUri("https://discord.gg/WEHyDw9Bcb");
            event.setCanceled(true);
        }
    }

    private static void drawCornerLogos(GuiGraphics g, int sw, int sh) {
        int x = sw - DESKPED_LOGO_W - 10;
        int y = sh - DESKPED_LOGO_H - 10;
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        RenderSystem.setShaderColor(1, 1, 1, 1);
        g.blit(ResourceLocation.fromNamespaceAndPath("rped","textures/gui/menu/deskpedlogo.png"),
               x, y, 0, 0, DESKPED_LOGO_W, DESKPED_LOGO_H, DESKPED_LOGO_W, DESKPED_LOGO_H);
        g.blit(ResourceLocation.fromNamespaceAndPath("rped","textures/gui/menu/deskpedforlogo.png"),
               x, y, 0, 0, DESKPED_FOR_W, DESKPED_FOR_H, DESKPED_FOR_W, DESKPED_FOR_H);
        RenderSystem.setShaderColor(1, 1, 1, 1);
    }

    private static void startMusic() {
        try {
            Minecraft mc=Minecraft.getInstance(); SoundManager sm=mc.getSoundManager();
            if(customMusic!=null){sm.stop(customMusic);customMusic=null;}
            customMusic=new StreamingMenuSound(ResourceLocation.fromNamespaceAndPath("rped","menu"));
            sm.play(customMusic);
        } catch(Exception e){e.printStackTrace();}
    }

    private static void stopMusic() {
        if(customMusic!=null){Minecraft.getInstance().getSoundManager().stop(customMusic);customMusic=null;}
    }

    static void nukeMusic() {
        try {
            Minecraft mc=Minecraft.getInstance();
            mc.getMusicManager().stopPlaying();
            for(SoundSource src:SoundSource.values()) if(src!=SoundSource.MASTER) mc.getSoundManager().stop(null,src);
        } catch(Exception ignored){}
    }

    private static void renderIntro(GuiGraphics g, Screen screen, long now) {
        long t=now-introStart;
        if(t>=INTRO_END_MS){introActive=false;Minecraft.getInstance().setScreen(new TitleScreen());return;}
        double ts=(now-EPOCH)/1000.0;
        drawSky(g,screen.width,screen.height,0.12f);
        drawStars(g,screen.width,screen.height,ts,0.12f);
        float cx=screen.width*0.5f,cy=screen.height*0.5f;
        boolean launched=t>=INTRO_LAUNCH_MS;
        float lt=launched?clamp01((float)(t-INTRO_LAUNCH_MS)/(INTRO_END_MS-INTRO_LAUNCH_MS)):0f;
        float a1=clamp01(t<INTRO_LOGO1_MS?0f:(t-INTRO_LOGO1_MS)/1000f);
        float a2=clamp01(t<INTRO_LOGO2_MS?0f:(t-INTRO_LOGO2_MS)/1000f);
        float bY=launched?0f:(float)(Math.sin(t/1000.0*0.9)*4);
        float bX=launched?0f:(float)(Math.sin(t/1000.0*0.6)*6);
        float jY=launched?(float)(-(Math.sin(lt*Math.PI)*screen.height*0.18f)+lt*lt*screen.height*0.9f):0f;
        float sw2=launched?lt*lt*720f:(float)(Math.sin(t/1000.0*0.7)*5);
        float fl=clamp01((lt-0.55f)/0.45f);
        float lx=cx+bX,ly=cy+bY+jY;
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA,GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        ResourceLocation r1=ResourceLocation.fromNamespaceAndPath("rped","textures/gui/menu/deskpedlogo.png");
        ResourceLocation r2=ResourceLocation.fromNamespaceAndPath("rped","textures/gui/menu/deskpedforlogo.png");
        if(a1>0f){g.pose().pushPose();g.pose().translate(lx,ly,0);g.pose().scale(2f,2f,1f);g.pose().mulPose(Axis.ZP.rotationDegrees(sw2));g.pose().translate(-DESKPED_LOGO_W*0.5f,-DESKPED_LOGO_H*0.5f,0);RenderSystem.setShaderColor(1,1,1,a1);g.blit(r1,0,0,0,0,DESKPED_LOGO_W,DESKPED_LOGO_H,DESKPED_LOGO_W,DESKPED_LOGO_H);g.pose().popPose();}
        if(a2>0f){g.pose().pushPose();g.pose().translate(lx,ly,0);g.pose().scale(2f,2f,1f);g.pose().mulPose(Axis.ZP.rotationDegrees(sw2));g.pose().translate(-DESKPED_FOR_W*0.5f,-DESKPED_FOR_H*0.5f,0);RenderSystem.setShaderColor(1,1,1,a2);g.blit(r2,0,0,0,0,DESKPED_FOR_W,DESKPED_FOR_H,DESKPED_FOR_W,DESKPED_FOR_H);g.pose().popPose();}
        RenderSystem.setShaderColor(1,1,1,1);
        if(fl>0f) g.fill(0,0,screen.width,screen.height,((int)(fl*255)<<24)|0xFFFFFF);
    }

    public static void triggerMusicStart(){nukeMusic();startMusic();}
    public static void triggerMusicStop(){stopMusic();}

    private static final class Layer {
        final int tex;
        final float cy, h, w, alpha, speed, k;
        final int tint;
        float scroll;

        Layer(int tex, float cy, float h, float w, float alpha, float speed, float k, int tint) {
            this.tex = tex;
            this.cy = cy;
            this.h = h;
            this.w = w;
            this.alpha = alpha;
            this.speed = speed;
            this.k = k;
            this.tint = tint;
        }
    }

    private static final class Star {
        final float x, y, ph, spd;

        Star() {
            x = RNG.nextFloat();
            y = RNG.nextFloat() * 0.5f;
            ph = RNG.nextFloat() * 6.2832f;
            spd = 0.4f + RNG.nextFloat() * 1.8f;
        }
    }

    private static final class Dust {
        float x, y;
        final float z, size, ph, spd, tw;

        Dust() {
            x = RNG.nextFloat();
            y = RNG.nextFloat();
            z = RNG.nextFloat();
            size = RNG.nextFloat();
            ph = RNG.nextFloat() * 6.2832f;
            spd = 0.025f + RNG.nextFloat() * 0.035f;
            tw = 0.6f + RNG.nextFloat() * 1.4f;
        }
    }

    private static final class Streak {
        float x, y, len, spd, thick, life, maxLife;

        void reset(boolean initial) {
            x = initial ? RNG.nextFloat() * 1.1f : 0.8f + RNG.nextFloat() * 0.4f;
            y = 0.04f + RNG.nextFloat() * 0.62f;
            len = 0.10f + RNG.nextFloat() * 0.25f;
            spd = 0.22f + RNG.nextFloat() * 0.5f;
            thick = 1.2f + RNG.nextFloat() * 1.4f;
            maxLife = 2.2f + RNG.nextFloat() * 3f;
            life = initial ? RNG.nextFloat() * maxLife : maxLife;
        }
    }

    private static final class Glint {
        final float fx, fy, ph, spd, size;

        Glint(boolean nearSun) {
            fx = nearSun ? SUN_FX + (RNG.nextFloat() - 0.5f) * 0.3f : 0.28f + RNG.nextFloat() * 0.58f;
            fy = nearSun ? SUN_FY + (RNG.nextFloat() - 0.3f) * 0.4f : 0.08f + RNG.nextFloat() * 0.72f;
            ph = RNG.nextFloat() * 6.2832f;
            spd = 0.25f + RNG.nextFloat() * 0.45f;
            size = 0.012f + RNG.nextFloat() * 0.018f;
        }
    }
}