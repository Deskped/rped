package deskped.rped.music.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import deskped.rped.client.VanillaGui;
import deskped.rped.music.MusicNet;
import deskped.rped.voice.client.ui.Ui;

@OnlyIn(Dist.CLIENT)
public class MusicScreen extends Screen {

	private final BlockPos pos;
	private final String trackName;
	private final boolean playing;
	private int top;

	public MusicScreen(BlockPos pos, String trackName, boolean playing) {
		super(Component.literal("\u041C\u0443\u0437\u044B\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u0431\u043B\u043E\u043A"));
		this.pos = pos;
		this.trackName = trackName == null ? "" : trackName;
		this.playing = playing;
	}

	@Override
	protected void init() {
		int w = 200;
		int x = (width - w) / 2;
		top = Math.max(30, height / 2 - 52);
		addRenderableWidget(new Ui.FlatButton(x, top + 44, w, 20, Component.literal("\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0444\u0430\u0439\u043B (.ogg / .wav)"), b -> pick()));
		int half = (w - 4) / 2;
		addRenderableWidget(new Ui.FlatButton(x, top + 68, half, 20, Component.literal("\u041F\u0440\u043E\u0438\u0433\u0440\u0430\u0442\u044C"), b -> send(true)));
		addRenderableWidget(new Ui.FlatButton(x + half + 4, top + 68, half, 20, Component.literal("\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C"), b -> send(false), true));
	}

	private void pick() {
		onClose();
		MusicClient.pickAndUpload(pos);
	}

	private void send(boolean play) {
		MusicNet.sendToServer(new MusicNet.BlockActionC2S(pos, play));
		onClose();
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		renderBackground(g);
		g.drawCenteredString(font, title, width / 2, top, 0xFFFFFF);
		String name = trackName.isEmpty() ? "\u043D\u0435\u0442" : trackName;
		if (name.length() > 34)
			name = name.substring(0, 34) + "...";
		g.drawCenteredString(font, Component.literal("\u0424\u0430\u0439\u043B: " + name), width / 2, top + 24, trackName.isEmpty() ? VanillaGui.GRAY : VanillaGui.WHITE);
		String status = playing ? "\u0421\u0435\u0439\u0447\u0430\u0441 \u0438\u0433\u0440\u0430\u0435\u0442" : "\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E";
		g.drawCenteredString(font, Component.literal(status), width / 2, top + 96, playing ? VanillaGui.GREEN : VanillaGui.GRAY);
		super.render(g, mouseX, mouseY, partialTick);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
