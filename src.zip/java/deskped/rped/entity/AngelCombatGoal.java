package deskped.rped.entity;

import java.util.EnumSet;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.LivingEntity;

public class AngelCombatGoal extends Goal {
	private final TumaniteAngelEntity angel;
	private int shootCooldown;
	private int turnTimer;
	private double orbitAngle;
	private int orbitDirection = 1;

	public AngelCombatGoal(TumaniteAngelEntity angel) {
		this.angel = angel;
		this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
	}

	@Override
	public boolean canUse() {
		LivingEntity target = this.angel.getTarget();
		return target != null && target.isAlive();
	}

	@Override
	public boolean canContinueToUse() {
		return this.canUse();
	}

	@Override
	public boolean requiresUpdateEveryTick() {
		return true;
	}

	@Override
	public void start() {
		LivingEntity target = this.angel.getTarget();
		this.shootCooldown = 20;
		this.turnTimer = 60 + this.angel.getRandom().nextInt(80);
		if (target != null)
			this.orbitAngle = Math.atan2(this.angel.getZ() - target.getZ(), this.angel.getX() - target.getX());
	}

	@Override
	public void stop() {
		this.angel.getNavigation().stop();
	}

	@Override
	public void tick() {
		LivingEntity target = this.angel.getTarget();
		if (target == null)
			return;
		this.angel.getLookControl().setLookAt(target, 40.0F, 40.0F);
		if (this.angel.isTransitioning()) {
			this.angel.getNavigation().stop();
			return;
		}
		int stage = this.angel.getStage();
		if (--this.turnTimer <= 0) {
			this.orbitDirection = -this.orbitDirection;
			this.turnTimer = 60 + this.angel.getRandom().nextInt(100);
		}
		this.orbitAngle += this.orbitDirection * (0.03D + 0.008D * stage);
		double radius = 10.0D - 0.6D * stage + Math.sin(this.angel.tickCount * 0.05D) * 1.5D;
		double height = 3.5D + Math.sin(this.angel.tickCount * 0.09D) * 1.3D;
		double tx = target.getX() + Math.cos(this.orbitAngle) * radius;
		double ty = target.getY() + height;
		double tz = target.getZ() + Math.sin(this.orbitAngle) * radius;
		this.angel.getMoveControl().setWantedPosition(tx, ty, tz, 1.0D + 0.15D * (stage - 1));
		if (--this.shootCooldown <= 0 && this.angel.getSensing().hasLineOfSight(target)) {
			this.angel.performRangedAttack(target, 1.0F);
			this.shootCooldown = Math.max(12, 36 - 4 * stage);
		}
	}
}
