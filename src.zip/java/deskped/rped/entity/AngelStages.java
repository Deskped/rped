package deskped.rped.entity;

import org.joml.Vector3f;

import net.minecraft.util.Mth;

public final class AngelStages {
	public static final int COUNT = 6;
	public static final int[] COLORS = {0xFFE9A0, 0x7FE3FF, 0xB48CFF, 0xFF7AD9, 0xFF8A3D, 0xFF3B3B};
	public static final String[] ROMAN = {"I", "II", "III", "IV", "V", "VI"};
	public static final float[] REGEN = {1.0F, 0.7F, 0.45F, 0.25F, 0.1F, 0.0F};
	public static final float[] DAMAGE = {1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.7F};

	private AngelStages() {
	}

	public static int clamp(int stage) {
		return Mth.clamp(stage, 1, COUNT);
	}

	public static int fromHealthFraction(float fraction) {
		return clamp((int) ((1.0F - Mth.clamp(fraction, 0.0F, 1.0F)) * COUNT) + 1);
	}

	public static int color(int stage) {
		return COLORS[clamp(stage) - 1];
	}

	public static String roman(int stage) {
		return ROMAN[clamp(stage) - 1];
	}

	public static float regenFactor(int stage) {
		return REGEN[clamp(stage) - 1];
	}

	public static float damageScale(int stage) {
		return DAMAGE[clamp(stage) - 1];
	}

	public static float musicPitch(int stage) {
		return 1.0F + 0.09F * (clamp(stage) - 1);
	}

	public static Vector3f vector(int stage) {
		int c = color(stage);
		return new Vector3f((c >> 16 & 255) / 255.0F, (c >> 8 & 255) / 255.0F, (c & 255) / 255.0F);
	}
}
