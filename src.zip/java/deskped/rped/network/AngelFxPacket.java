package deskped.rped.network;

import java.util.function.Supplier;

import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.network.FriendlyByteBuf;

import deskped.rped.client.angel.AngelFxManager;

public final class AngelFxPacket {
	public static final int CHARGE = 0;
	public static final int RING = 1;
	public static final int STRIKE = 2;
	public static final int BLINK_MARK = 3;
	public static final int BLINK_TRAIL = 4;
	public static final int FLASH = 5;
	public static final int BURST = 6;
	public static final int WELL = 7;
	public static final int TRANSITION = 8;

	public final int type;
	public final int stage;
	public final int entityId;
	public final int duration;
	public final double x;
	public final double y;
	public final double z;
	public final double x2;
	public final double y2;
	public final double z2;
	public final float a;

	public AngelFxPacket(int type, int stage, int entityId, int duration, double x, double y, double z, double x2, double y2, double z2, float a) {
		this.type = type;
		this.stage = stage;
		this.entityId = entityId;
		this.duration = duration;
		this.x = x;
		this.y = y;
		this.z = z;
		this.x2 = x2;
		this.y2 = y2;
		this.z2 = z2;
		this.a = a;
	}

	public static AngelFxPacket charge(int entityId, int duration, float radius, int stage) {
		return new AngelFxPacket(CHARGE, stage, entityId, duration, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, radius);
	}

	public static AngelFxPacket ring(double x, double y, double z, float maxRadius, int duration, int stage) {
		return new AngelFxPacket(RING, stage, 0, duration, x, y, z, 0.0D, 0.0D, 0.0D, maxRadius);
	}

	public static AngelFxPacket strike(double x, double y, double z, int delay, int stage) {
		return new AngelFxPacket(STRIKE, stage, 0, delay + 14, x, y, z, 0.0D, 0.0D, 0.0D, 0.0F);
	}

	public static AngelFxPacket blinkMark(double x, double y, double z, int duration, int stage) {
		return new AngelFxPacket(BLINK_MARK, stage, 0, duration, x, y, z, 0.0D, 0.0D, 0.0D, 0.0F);
	}

	public static AngelFxPacket blinkTrail(double x, double y, double z, double x2, double y2, double z2, int duration, int stage) {
		return new AngelFxPacket(BLINK_TRAIL, stage, 0, duration, x, y, z, x2, y2, z2, 0.0F);
	}

	public static AngelFxPacket flash(double x, double y, double z, float size, int duration, int stage) {
		return new AngelFxPacket(FLASH, stage, 0, duration, x, y, z, 0.0D, 0.0D, 0.0D, size);
	}

	public static AngelFxPacket burst(double x, double y, double z, float radius, int duration, int stage) {
		return new AngelFxPacket(BURST, stage, 0, duration, x, y, z, 0.0D, 0.0D, 0.0D, radius);
	}

	public static AngelFxPacket well(int entityId, int duration, int stage) {
		return new AngelFxPacket(WELL, stage, entityId, duration, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0F);
	}

	public static AngelFxPacket transition(double x, double y, double z, float radius, int duration, int stage) {
		return new AngelFxPacket(TRANSITION, stage, 0, duration, x, y, z, 0.0D, 0.0D, 0.0D, radius);
	}

	public static void encode(AngelFxPacket packet, FriendlyByteBuf buf) {
		buf.writeByte(packet.type);
		buf.writeByte(packet.stage);
		buf.writeVarInt(packet.entityId);
		buf.writeVarInt(packet.duration);
		buf.writeDouble(packet.x);
		buf.writeDouble(packet.y);
		buf.writeDouble(packet.z);
		buf.writeDouble(packet.x2);
		buf.writeDouble(packet.y2);
		buf.writeDouble(packet.z2);
		buf.writeFloat(packet.a);
	}

	public static AngelFxPacket decode(FriendlyByteBuf buf) {
		int type = buf.readByte();
		int stage = buf.readByte();
		int entityId = buf.readVarInt();
		int duration = buf.readVarInt();
		double x = buf.readDouble();
		double y = buf.readDouble();
		double z = buf.readDouble();
		double x2 = buf.readDouble();
		double y2 = buf.readDouble();
		double z2 = buf.readDouble();
		float a = buf.readFloat();
		return new AngelFxPacket(type, stage, entityId, duration, x, y, z, x2, y2, z2, a);
	}

	public static void handle(AngelFxPacket packet, Supplier<NetworkEvent.Context> context) {
		NetworkEvent.Context ctx = context.get();
		ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> AngelFxManager.add(packet)));
		ctx.setPacketHandled(true);
	}
}
