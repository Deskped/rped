package deskped.rped.network;

import net.minecraftforge.network.simple.SimpleChannel;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class AngelNetwork {
	private static final String VERSION = "1";
	public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(new ResourceLocation("rped", "angel_fx"), () -> VERSION, VERSION::equals, VERSION::equals);

	@SubscribeEvent
	public static void onSetup(FMLCommonSetupEvent event) {
		CHANNEL.registerMessage(0, AngelFxPacket.class, AngelFxPacket::encode, AngelFxPacket::decode, AngelFxPacket::handle);
	}

	public static void send(ServerLevel level, double x, double y, double z, AngelFxPacket packet) {
		CHANNEL.send(PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(x, y, z, 192.0D, level.dimension())), packet);
	}
}
