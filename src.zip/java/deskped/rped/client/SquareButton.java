package deskped.rped.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.function.Consumer;
import java.util.function.Supplier;

@OnlyIn(Dist.CLIENT)
public class SquareButton extends Button {

	private final Consumer<SquareButton> action;
	private Supplier<int[]> position;
	private ResourceLocation icon;

	public SquareButton(int x, int y, int size, Component tip, Consumer<SquareButton> action) {
		super(x, y, size, size, Component.empty(), b -> ((SquareButton) b).action.accept((SquareButton) b), Button.DEFAULT_NARRATION);
		this.action = action;
		if (tip != null)
			this.setTooltip(Tooltip.create(tip));
	}

	public SquareButton icon(ResourceLocation icon) {
		this.icon = icon;
		return this;
	}

	public SquareButton symbol(String glyph, int rgb) {
		this.setMessage(Component.literal(glyph).withStyle(s -> s.withColor(rgb)));
		return this;
	}

	public SquareButton symbol(String glyph) {
		this.setMessage(Component.literal(glyph));
		return this;
	}

	public SquareButton tip(Component tip) {
		this.setTooltip(tip == null ? null : Tooltip.create(tip));
		return this;
	}

	public SquareButton position(Supplier<int[]> position) {
		this.position = position;
		return this;
	}

	@Override
	public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partial) {
		if (this.position != null) {
			int[] pos = this.position.get();
			this.setX(pos[0]);
			this.setY(pos[1]);
		}
		super.renderWidget(g, mouseX, mouseY, partial);
		if (this.icon != null) {
			int s = this.width >= 16 ? 16 : 8;
			RenderSystem.enableBlend();
			g.setColor(1.0F, 1.0F, 1.0F, this.active ? 1.0F : 0.5F);
			g.blit(this.icon, this.getX() + (this.width - s) / 2, this.getY() + (this.height - s) / 2, s, s, 0.0F, 0.0F, 8, 8, 8, 8);
			g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
		}
	}
}
