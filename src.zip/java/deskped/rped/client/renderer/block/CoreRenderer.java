package deskped.rped.client.renderer.block;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.network.chat.Component;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.Camera;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.BlockPos;
import net.minecraft.client.gui.Font;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.Minecraft;

import deskped.rped.init.RpedModBlockEntities;
import deskped.rped.ext.ExtLang;
import deskped.rped.block.entity.CoreBlockEntity;

import org.joml.Quaternionf;
import org.joml.Matrix4f;
import org.joml.Matrix3f;
import org.joml.Vector3f;

import com.mojang.math.Axis;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.WeakHashMap;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class CoreRenderer implements BlockEntityRenderer<CoreBlockEntity> {
	private static final ResourceLocation SPRITE = new ResourceLocation("rped", "block/core");

	private static final float CORE_SIZE = 8.0f / 16.0f;
	private static final float HALF = CORE_SIZE / 2.0f;

	private static final double SPIN_X = 0.55;
	private static final double SPIN_Y = 0.80;
	private static final double SPIN_Z = 0.35;
	private static final double RAYS_SPIN_Y = 0.70;
	private static final double RAYS_SPIN_X = 0.40;
	private static final double FAST_FACTOR = 12.0;
	private static final int BURST_COUNT = 14;
	private static final double BEAM_GROW_TICKS = 25.0;
	private static final double BEAM_FADE_TICKS = 40.0;

	private static final float PANEL_SCALE = 0.015f;
	private static final float PANEL_LIFT = 1.25f;
	private static final float LINE_HEIGHT = 10.0f;
	private static final int PANEL_BG = 0xF0100010;
	private static final int BORDER_TOP = 0x505000FF;
	private static final int BORDER_BOTTOM = 0x5028007F;
	private static final int COLOR_TITLE = 0xFF55FF;
	private static final int COLOR_TEXT = 0xFFFFFF;
	private static final int COLOR_OPEN = 0x55FF55;
	private static final int COLOR_WAIT = 0xFFAA00;
	private static final int COLOR_TIME = 0xFFFF55;

	private static final Map<CoreBlockEntity, Spin> SPIN = new WeakHashMap<>();

	private record Line(String text, int color) {
	}

	private static final class Spin {
		private double angle;
		private double speed = 1.0;
		private double last = Double.NaN;

		private void advance(double time, double target) {
			double dt = Double.isNaN(this.last) ? 0.0 : Mth.clamp(time - this.last, 0.0, 10.0);
			this.last = time;
			this.speed += (target - this.speed) * Math.min(1.0, dt * 0.04);
			this.angle += dt * this.speed;
		}
	}

	private static final int RAY_COUNT = 36;
	private static final float RAY_MIN_LENGTH = 1.2f;
	private static final float RAY_EXTRA_LENGTH = 2.0f;
	private static final float RAY_MIN_WIDTH = 0.12f;
	private static final float RAY_EXTRA_WIDTH = 0.22f;
	private static final float HALF_SQRT_3 = (float) (Math.sqrt(3.0) / 2.0);
	private static final float TAU = (float) (Math.PI * 2.0);

	private static final int RAY_ROOT_R = 255;
	private static final int RAY_ROOT_G = 255;
	private static final int RAY_ROOT_B = 255;
	private static final int RAY_TIP_R = 170;
	private static final int RAY_TIP_G = 120;
	private static final int RAY_TIP_B = 255;


	private static final Quaternionf[] RAY_ORIENT = new Quaternionf[RAY_COUNT];
	private static final float[] RAY_LENGTH = new float[RAY_COUNT];
	private static final float[] RAY_WIDTH = new float[RAY_COUNT];
	private static final float[] RAY_PHASE = new float[RAY_COUNT];
	private static final float[] RAY_SPEED = new float[RAY_COUNT];

	private static final float[][] FACE_VERTS = {
			{-1, 1, 1, 1, 1, 1, 1, 1, -1, -1, 1, -1},
			{-1, -1, -1, 1, -1, -1, 1, -1, 1, -1, -1, 1},
			{-1, -1, 1, 1, -1, 1, 1, 1, 1, -1, 1, 1},
			{1, -1, -1, -1, -1, -1, -1, 1, -1, 1, 1, -1},
			{1, -1, 1, 1, -1, -1, 1, 1, -1, 1, 1, 1},
			{-1, -1, -1, -1, -1, 1, -1, 1, 1, -1, 1, -1}
	};
	private static final float[][] FACE_NORMALS = {{0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}, {1, 0, 0}, {-1, 0, 0}};
	private static final float[] FACE_SHADE = {1.0f, 0.78f, 0.92f, 0.92f, 0.85f, 0.85f};
	private static final float[] CORNER_U = {0, 1, 1, 0};
	private static final float[] CORNER_V = {1, 1, 0, 0};

	static {
		RandomSource random = RandomSource.create(432L);
		for (int i = 0; i < RAY_COUNT; i++) {
			RAY_ORIENT[i] = new Quaternionf((float) random.nextGaussian(), (float) random.nextGaussian(), (float) random.nextGaussian(), (float) random.nextGaussian()).normalize();
			RAY_LENGTH[i] = RAY_MIN_LENGTH + random.nextFloat() * RAY_EXTRA_LENGTH;
			RAY_WIDTH[i] = RAY_MIN_WIDTH + random.nextFloat() * RAY_EXTRA_WIDTH;
			RAY_PHASE[i] = random.nextFloat() * TAU;
			RAY_SPEED[i] = 0.05f + random.nextFloat() * 0.08f;
		}
	}

	CoreRenderer(BlockEntityRendererProvider.Context context) {
	}

	@Override
	public void render(CoreBlockEntity blockEntity, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int light, int overlay) {
		Level level = blockEntity.getLevel();
		if (level == null)
			return;
		double time = level.getGameTime() + (double) partialTick;
		Spin spin = SPIN.computeIfAbsent(blockEntity, key -> new Spin());
		boolean active = blockEntity.getPhase() == CoreBlockEntity.PHASE_ACTIVE;
		spin.advance(time, active ? FAST_FACTOR : 1.0);
		float strength = 0.0f;
		float length = 0.0f;
		if (active) {
			double start = blockEntity.getPhaseEnd() - CoreBlockEntity.ACTIVE_TICKS;
			double end = blockEntity.getPhaseEnd() - CoreBlockEntity.ACTIVE_MARGIN;
			float grow = (float) Mth.clamp((time - start) / BEAM_GROW_TICKS, 0.0, 1.0);
			float fade = (float) Mth.clamp((end - time) / BEAM_FADE_TICKS, 0.0, 1.0);
			strength = grow * fade;
			length = CoreBlockEntity.BREAKDOWN_OFFSET * (1.0f - (1.0f - grow) * (1.0f - grow));
		}
		Camera camera = Minecraft.getInstance().gameRenderer.getMainCamera();
		Vector3f left = camera.getLeftVector();
		Vector3f up = camera.getUpVector();
		Vec3 eye = camera.getPosition();
		BlockPos pos = blockEntity.getBlockPos();
		float eyeX = (float) (eye.x - pos.getX() - 0.5);
		float eyeY = (float) (eye.y - pos.getY() - 0.5);
		float eyeZ = (float) (eye.z - pos.getZ() - 0.5);
		poseStack.pushPose();
		poseStack.translate(0.5, 0.5, 0.5);
		renderCube(poseStack, buffer, spin.angle);
		VertexConsumer rays = buffer.getBuffer(CoreFx.ADDITIVE_CULL);
		renderRays(poseStack, rays, time, spin.angle, RAY_COUNT, 1.0f, 1.0f, 1.0f, 1.0);
		if (strength > 0.0f) {
			poseStack.pushPose();
			poseStack.translate(0.0, length, 0.0);
			renderRays(poseStack, rays, time, spin.angle, BURST_COUNT, 0.4f, 0.5f, strength, -1.0);
			poseStack.popPose();
		}
		VertexConsumer fx = buffer.getBuffer(CoreFx.ADDITIVE);
		Matrix4f pose = poseStack.last().pose();
		CoreFx.glow(fx, pose, time, left, up);
		CoreFx.beam(fx, pose, time, length, strength, eyeX, eyeY, eyeZ, left, up);
		renderPanel(blockEntity, level, poseStack, buffer);
		poseStack.popPose();
	}

	private static void renderPanel(CoreBlockEntity blockEntity, Level level, PoseStack poseStack, MultiBufferSource buffer) {
		LocalPlayer player = Minecraft.getInstance().player;
		if (player == null || !blockEntity.isViewer(player.getUUID()))
			return;
		Font font = Minecraft.getInstance().font;
		List<Line> lines = panelLines(blockEntity, level.getGameTime());
		float textWidth = 0.0f;
		for (Line line : lines)
			textWidth = Math.max(textWidth, font.width(line.text()));
		float textHeight = lines.size() * LINE_HEIGHT - 2.0f;
		float x0 = -textWidth / 2.0f;
		float y0 = -textHeight / 2.0f;
		poseStack.pushPose();
		poseStack.translate(0.0, PANEL_LIFT, 0.0);
		poseStack.mulPose(Minecraft.getInstance().gameRenderer.getMainCamera().rotation());
		poseStack.scale(-PANEL_SCALE, -PANEL_SCALE, PANEL_SCALE);
		Matrix4f pose = poseStack.last().pose();
		panelBackground(buffer.getBuffer(RenderType.guiOverlay()), pose, x0, y0, textWidth, textHeight);
		for (int i = 0; i < lines.size(); i++) {
			Line line = lines.get(i);
			font.drawInBatch(Component.literal(line.text()), x0, y0 + i * LINE_HEIGHT, line.color(), true, pose, buffer, Font.DisplayMode.SEE_THROUGH, 0, LightTexture.FULL_BRIGHT);
		}
		poseStack.popPose();
	}

	private static List<Line> panelLines(CoreBlockEntity blockEntity, long now) {
		List<Line> lines = new ArrayList<>();
		int phase = blockEntity.getPhase();
		long remaining = blockEntity.getRemainingTicks(now);
		if (phase == CoreBlockEntity.PHASE_ACTIVE) {
			lines.add(new Line(ExtLang.pick("Измерение открыто", "The dimension is open"), COLOR_OPEN));
			lines.add(new Line(ExtLang.pick("Осталось: ", "Time left: ") + formatTime(remaining), COLOR_TIME));
		} else if (phase == CoreBlockEntity.PHASE_COOLDOWN) {
			lines.add(new Line(ExtLang.pick("Ядро перезаряжается", "The core is recharging"), COLOR_WAIT));
			lines.add(new Line(ExtLang.pick("Следующее открытие через:", "Next opening in:"), COLOR_TEXT));
			lines.add(new Line(formatTime(remaining), COLOR_TIME));
		} else {
			lines.add(new Line(ExtLang.pick("Измерение", "Dimension"), COLOR_TITLE));
			lines.add(new Line(ExtLang.pick("Чтобы открыть измерение,", "To open the dimension,"), COLOR_TEXT));
			lines.add(new Line(ExtLang.pick("подтвердите, нажав по ядру.", "confirm by clicking the core."), COLOR_TEXT));
		}
		return lines;
	}

	private static String formatTime(long ticks) {
		long total = (ticks + 19L) / 20L;
		long hours = total / 3600L;
		long minutes = total % 3600L / 60L;
		long seconds = total % 60L;
		if (hours > 0L)
			return String.format(Locale.ROOT, "%d:%02d:%02d", hours, minutes, seconds);
		return String.format(Locale.ROOT, "%d:%02d", minutes, seconds);
	}

	private static void panelBackground(VertexConsumer consumer, Matrix4f pose, float x, float y, float w, float h) {
		float x1 = x + w;
		float y1 = y + h;
		rect(consumer, pose, x - 3.0f, y - 3.0f, x1 + 3.0f, y1 + 3.0f, PANEL_BG, PANEL_BG);
		rect(consumer, pose, x - 3.0f, y - 4.0f, x1 + 3.0f, y - 3.0f, PANEL_BG, PANEL_BG);
		rect(consumer, pose, x - 3.0f, y1 + 3.0f, x1 + 3.0f, y1 + 4.0f, PANEL_BG, PANEL_BG);
		rect(consumer, pose, x - 4.0f, y - 3.0f, x - 3.0f, y1 + 3.0f, PANEL_BG, PANEL_BG);
		rect(consumer, pose, x1 + 3.0f, y - 3.0f, x1 + 4.0f, y1 + 3.0f, PANEL_BG, PANEL_BG);
		rect(consumer, pose, x - 3.0f, y - 2.0f, x - 2.0f, y1 + 2.0f, BORDER_TOP, BORDER_BOTTOM);
		rect(consumer, pose, x1 + 2.0f, y - 2.0f, x1 + 3.0f, y1 + 2.0f, BORDER_TOP, BORDER_BOTTOM);
		rect(consumer, pose, x - 3.0f, y - 3.0f, x1 + 3.0f, y - 2.0f, BORDER_TOP, BORDER_TOP);
		rect(consumer, pose, x - 3.0f, y1 + 2.0f, x1 + 3.0f, y1 + 3.0f, BORDER_BOTTOM, BORDER_BOTTOM);
	}

	private static void rect(VertexConsumer consumer, Matrix4f pose, float x0, float y0, float x1, float y1, int top, int bottom) {
		corner(consumer, pose, x0, y0, top);
		corner(consumer, pose, x0, y1, bottom);
		corner(consumer, pose, x1, y1, bottom);
		corner(consumer, pose, x1, y0, top);
		corner(consumer, pose, x1, y0, top);
		corner(consumer, pose, x1, y1, bottom);
		corner(consumer, pose, x0, y1, bottom);
		corner(consumer, pose, x0, y0, top);
	}

	private static void corner(VertexConsumer consumer, Matrix4f pose, float x, float y, int argb) {
		consumer.vertex(pose, x, y, 0.0f).color(argb >> 16 & 255, argb >> 8 & 255, argb & 255, argb >>> 24 & 255).endVertex();
	}

	private static float degrees(double time, double speed) {
		return (float) ((time * speed) % 360.0);
	}

	private static void renderCube(PoseStack poseStack, MultiBufferSource buffer, double angle) {
		TextureAtlasSprite sprite = Minecraft.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS).apply(SPRITE);
		float u0 = sprite.getU0();
		float v0 = sprite.getV0();
		float du = sprite.getU1() - u0;
		float dv = sprite.getV1() - v0;
		VertexConsumer consumer = buffer.getBuffer(RenderType.beaconBeam(InventoryMenu.BLOCK_ATLAS, false));
		poseStack.pushPose();
		poseStack.mulPose(Axis.XP.rotationDegrees(degrees(angle, SPIN_X)));
		poseStack.mulPose(Axis.YP.rotationDegrees(degrees(angle, SPIN_Y)));
		poseStack.mulPose(Axis.ZP.rotationDegrees(degrees(angle, SPIN_Z)));
		Matrix4f pose = poseStack.last().pose();
		Matrix3f normal = poseStack.last().normal();
		for (int face = 0; face < 6; face++) {
			float[] verts = FACE_VERTS[face];
			float[] n = FACE_NORMALS[face];
			float shade = FACE_SHADE[face];
			for (int corner = 0; corner < 4; corner++) {
				consumer.vertex(pose, verts[corner * 3] * HALF, verts[corner * 3 + 1] * HALF, verts[corner * 3 + 2] * HALF)
						.color(shade, shade, shade, 1.0f)
						.uv(u0 + du * CORNER_U[corner], v0 + dv * CORNER_V[corner])
						.overlayCoords(OverlayTexture.NO_OVERLAY)
						.uv2(LightTexture.FULL_BRIGHT)
						.normal(normal, n[0], n[1], n[2])
						.endVertex();
			}
		}
		poseStack.popPose();
	}

	private static void renderRays(PoseStack poseStack, VertexConsumer consumer, double time, double angle, int count, float lengthScale, float widthScale, float strength, double direction) {
		poseStack.pushPose();
		poseStack.mulPose(Axis.YP.rotationDegrees(degrees(angle * direction, RAYS_SPIN_Y)));
		poseStack.mulPose(Axis.XP.rotationDegrees(degrees(angle * direction, RAYS_SPIN_X)));
		for (int i = 0; i < count; i++) {
			float wave = 0.5f + 0.5f * (float) Math.sin(time * RAY_SPEED[i] + RAY_PHASE[i]);
			wave = wave * wave * (3.0f - 2.0f * wave);
			float length = RAY_LENGTH[i] * lengthScale * (0.12f + 0.88f * wave);
			float width = RAY_WIDTH[i] * widthScale * (0.45f + 0.55f * wave);
			int alpha = (int) (255.0f * strength * (0.45f + 0.55f * wave));
			poseStack.pushPose();
			poseStack.mulPose(RAY_ORIENT[i]);
			ray(consumer, poseStack.last().pose(), length, width, alpha);
			poseStack.popPose();
		}
		poseStack.popPose();
	}

	private static void ray(VertexConsumer consumer, Matrix4f pose, float length, float width, int alpha) {
		float side = HALF_SQRT_3 * width;
		float back = -0.5f * width;
		rayFace(consumer, pose, length, alpha, -side, back, side, back);
		rayFace(consumer, pose, length, alpha, side, back, 0.0f, width);
		rayFace(consumer, pose, length, alpha, 0.0f, width, -side, back);
	}

	private static void rayFace(VertexConsumer consumer, Matrix4f pose, float length, int alpha, float x0, float z0, float x1, float z1) {
		consumer.vertex(pose, 0.0f, 0.0f, 0.0f).color(RAY_ROOT_R, RAY_ROOT_G, RAY_ROOT_B, alpha).endVertex();
		consumer.vertex(pose, 0.0f, 0.0f, 0.0f).color(RAY_ROOT_R, RAY_ROOT_G, RAY_ROOT_B, alpha).endVertex();
		consumer.vertex(pose, x0, length, z0).color(RAY_TIP_R, RAY_TIP_G, RAY_TIP_B, 0).endVertex();
		consumer.vertex(pose, x1, length, z1).color(RAY_TIP_R, RAY_TIP_G, RAY_TIP_B, 0).endVertex();
	}

	@SubscribeEvent
	public static void registerBlockEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerBlockEntityRenderer(RpedModBlockEntities.CORE.get(), CoreRenderer::new);
	}
}
