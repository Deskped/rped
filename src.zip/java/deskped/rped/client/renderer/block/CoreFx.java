package deskped.rped.client.renderer.block;

import net.minecraft.util.Mth;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.GameRenderer;

import org.joml.Matrix4f;
import org.joml.Vector3f;

import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.platform.GlStateManager;

final class CoreFx {
	static final RenderType ADDITIVE = additive("rped_core_additive", false);
	static final RenderType ADDITIVE_CULL = additive("rped_core_additive_cull", true);

	private static final float TAU = (float) (Math.PI * 2.0);

	private static final int ARC_COUNT = 7;
	private static final int ARC_SEGMENTS = 16;
	private static final float ARC_AMPLITUDE = 0.55f;
	private static final int BRANCH_ARCS = 3;
	private static final int BRANCH_PER_ARC = 2;
	private static final int BRANCH_SEGMENTS = 6;
	private static final int HELIX_COUNT = 3;
	private static final int HELIX_SEGMENTS = 28;
	private static final int COLUMN_SEGMENTS = 12;
	private static final int SPARK_COUNT = 34;

	private static final int[][] ARC_COLORS = {{255, 255, 255}, {196, 150, 255}, {140, 215, 255}};

	private static final float[][] ARC_X = new float[ARC_COUNT][ARC_SEGMENTS + 1];
	private static final float[][] ARC_Y = new float[ARC_COUNT][ARC_SEGMENTS + 1];
	private static final float[][] ARC_Z = new float[ARC_COUNT][ARC_SEGMENTS + 1];

	private static final float[] PX = new float[40];
	private static final float[] PY = new float[40];
	private static final float[] PZ = new float[40];
	private static final float[] PW = new float[40];
	private static final float[] PA = new float[40];
	private static final float[] SX = new float[40];
	private static final float[] SY = new float[40];
	private static final float[] SZ = new float[40];

	private CoreFx() {
	}

	private static RenderType additive(String name, boolean cull) {
		RenderType.CompositeState state = RenderType.CompositeState.builder()
				.setShaderState(new RenderStateShard.ShaderStateShard(GameRenderer::getRendertypeLightningShader))
				.setTransparencyState(new RenderStateShard.TransparencyStateShard("rped_core_additive", () -> {
					RenderSystem.enableBlend();
					RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
				}, () -> {
					RenderSystem.disableBlend();
					RenderSystem.defaultBlendFunc();
				}))
				.setWriteMaskState(new RenderStateShard.WriteMaskStateShard(true, false))
				.setCullState(new RenderStateShard.CullStateShard(cull))
				.createCompositeState(false);
		return RenderType.create(name, DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.QUADS, 256, false, false, state);
	}

	static void glow(VertexConsumer consumer, Matrix4f pose, double time, Vector3f left, Vector3f up) {
		float pulse = 1.0f + 0.08f * (float) Math.sin(time * 0.09);
		disc(consumer, pose, 0.0f, 0.0f, 0.0f, 1.0f * pulse, 24, 215, 205, 255, 0.5f, left, up);
		disc(consumer, pose, 0.0f, 0.0f, 0.0f, 0.55f * pulse, 24, 215, 205, 255, 0.5f, left, up);
	}

	static void beam(VertexConsumer consumer, Matrix4f pose, double time, float length, float strength, float cx, float cy, float cz, Vector3f left, Vector3f up) {
		if (length < 0.05f || strength <= 0.0f)
			return;
		float power = strength * (0.88f + 0.12f * (float) Math.sin(time * 1.1));
		arcs(consumer, pose, time, length, power, cx, cy, cz);
		branches(consumer, pose, time, power, cx, cy, cz);
		helix(consumer, pose, time, length, power, cx, cy, cz);
		column(consumer, pose, time, length, power, cx, cy, cz, 0.07f, 1.0f, 255, 255, 255);
		sparks(consumer, pose, time, length, power, left, up);
		column(consumer, pose, time, length, power, cx, cy, cz, 0.20f, 0.42f, 205, 170, 255);
		column(consumer, pose, time, length, power, cx, cy, cz, 0.50f, 0.20f, 150, 100, 255);
		float pulse = 1.0f + 0.12f * (float) Math.sin(time * 0.3);
		disc(consumer, pose, 0.0f, length, 0.0f, 0.95f * pulse, 20, 205, 175, 255, 0.55f * power, left, up);
		disc(consumer, pose, 0.0f, length, 0.0f, 0.40f * pulse, 20, 255, 255, 255, 0.85f * power, left, up);
	}

	private static void arcs(VertexConsumer consumer, Matrix4f pose, double time, float length, float power, float cx, float cy, float cz) {
		float scale = length / 3.0f;
		for (int a = 0; a < ARC_COUNT; a++) {
			double t = time * (0.45 + 0.09 * a);
			for (int i = 0; i <= ARC_SEGMENTS; i++) {
				float s = (float) i / ARC_SEGMENTS;
				float env = (float) Math.pow(Math.sin(Math.PI * s), 0.75);
				float amp = ARC_AMPLITUDE * scale * env;
				ARC_X[a][i] = amp * noise(a * 2, i, t);
				ARC_Z[a][i] = amp * noise(a * 2 + 1, i, t);
				ARC_Y[a][i] = length * s + 0.06f * env * noise(a * 2 + 50, i, t);
				PX[i] = ARC_X[a][i];
				PY[i] = ARC_Y[a][i];
				PZ[i] = ARC_Z[a][i];
				PW[i] = (0.03f + 0.012f * (a % 3)) * (0.45f + 0.55f * env);
				PA[i] = 1.0f;
			}
			float flicker = 0.55f + 0.45f * (0.5f + 0.5f * noise(a, 500, time * 0.7));
			int[] color = ARC_COLORS[a % ARC_COLORS.length];
			ribbon(consumer, pose, ARC_SEGMENTS, cx, cy, cz, color[0], color[1], color[2], power * flicker);
		}
	}

	private static void branches(VertexConsumer consumer, Matrix4f pose, double time, float power, float cx, float cy, float cz) {
		double cycle = time / 5.0;
		float life = (float) Math.sin(Math.PI * (cycle - Math.floor(cycle)));
		for (int a = 0; a < BRANCH_ARCS; a++) {
			for (int b = 0; b < BRANCH_PER_ARC; b++) {
				int id = a * BRANCH_PER_ARC + b;
				int bucket = (int) Math.floor(cycle) + id * 13;
				if (hash(id, 77, bucket) < -0.15f)
					continue;
				int start = Mth.clamp(2 + (int) (hash01(id, 78, bucket) * (ARC_SEGMENTS - 4)), 2, ARC_SEGMENTS - 2);
				float angle = hash01(id, 79, bucket) * TAU;
				float dx = Mth.cos(angle);
				float dz = Mth.sin(angle);
				float dy = hash(id, 80, bucket) * 0.5f;
				float len = 0.45f + 0.4f * hash01(id, 81, bucket);
				for (int j = 0; j <= BRANCH_SEGMENTS; j++) {
					float u = (float) j / BRANCH_SEGMENTS;
					PX[j] = ARC_X[a][start] + dx * len * u + 0.09f * u * noise(id * 3 + 200, j, time * 0.9);
					PY[j] = ARC_Y[a][start] + dy * len * u + 0.09f * u * noise(id * 3 + 201, j, time * 0.9);
					PZ[j] = ARC_Z[a][start] + dz * len * u + 0.09f * u * noise(id * 3 + 202, j, time * 0.9);
					PW[j] = 0.028f * (1.0f - u);
					PA[j] = 1.0f - u;
				}
				ribbon(consumer, pose, BRANCH_SEGMENTS, cx, cy, cz, 235, 225, 255, power * life);
			}
		}
	}

	private static void helix(VertexConsumer consumer, Matrix4f pose, double time, float length, float power, float cx, float cy, float cz) {
		for (int h = 0; h < HELIX_COUNT; h++) {
			double direction = h % 2 == 0 ? 1.0 : -1.0;
			double spin = (time * 0.16 * direction) % (Math.PI * 2.0);
			for (int i = 0; i <= HELIX_SEGMENTS; i++) {
				float s = (float) i / HELIX_SEGMENTS;
				float env = (float) Math.sin(Math.PI * s);
				float radius = (0.12f + 0.12f * env) * (1.0f + 0.35f * noise(h + 40, i, time * 0.35));
				float angle = (float) (s * TAU * 2.5 + spin + h * TAU / HELIX_COUNT);
				PX[i] = radius * Mth.cos(angle);
				PY[i] = length * s;
				PZ[i] = radius * Mth.sin(angle);
				PW[i] = 0.026f * (0.4f + 0.6f * env);
				PA[i] = 0.8f;
			}
			if (h == 1)
				ribbon(consumer, pose, HELIX_SEGMENTS, cx, cy, cz, 140, 215, 255, power);
			else
				ribbon(consumer, pose, HELIX_SEGMENTS, cx, cy, cz, 205, 150, 255, power);
		}
	}

	private static void column(VertexConsumer consumer, Matrix4f pose, double time, float length, float power, float cx, float cy, float cz, float width, float alpha, int r, int g, int b) {
		for (int i = 0; i <= COLUMN_SEGMENTS; i++) {
			float s = (float) i / COLUMN_SEGMENTS;
			float pulse = 0.72f + 0.28f * (float) Math.sin(s * 16.0 - time * 0.85);
			float turbulence = 0.85f + 0.15f * noise(60, i, time * 0.6);
			PX[i] = 0.0f;
			PY[i] = length * s;
			PZ[i] = 0.0f;
			PW[i] = width * pulse * turbulence * (1.0f - 0.3f * s);
			PA[i] = 1.0f;
		}
		ribbon(consumer, pose, COLUMN_SEGMENTS, cx, cy, cz, r, g, b, power * alpha);
	}

	private static void sparks(VertexConsumer consumer, Matrix4f pose, double time, float length, float power, Vector3f left, Vector3f up) {
		for (int i = 0; i < SPARK_COUNT; i++) {
			float direction = hash(i, 7, 0) < 0.0f ? -1.0f : 1.0f;
			double travel = (hash01(i, 5, 0) + time * (0.02 + 0.03 * hash01(i, 6, 0)) * direction) % 1.0;
			float s = (float) (travel < 0.0 ? travel + 1.0 : travel);
			float env = (float) Math.sin(Math.PI * s);
			float radius = (0.05f + 0.30f * hash01(i, 8, 0)) * (0.4f + 0.6f * env);
			double angle = hash01(i, 9, 0) * TAU + (time * (0.05 + 0.1 * hash01(i, 10, 0)) * direction) % (Math.PI * 2.0);
			float x = radius * (float) Math.cos(angle);
			float z = radius * (float) Math.sin(angle);
			float size = (0.05f + 0.10f * hash01(i, 11, 0)) * (0.5f + 0.5f * env);
			disc(consumer, pose, x, length * s, z, size, 4, 255, 255, 255, power * env, left, up);
		}
	}

	private static void ribbon(VertexConsumer consumer, Matrix4f pose, int n, float cx, float cy, float cz, int r, int g, int b, float power) {
		for (int i = 0; i <= n; i++) {
			int before = Math.max(i - 1, 0);
			int after = Math.min(i + 1, n);
			float tx = PX[after] - PX[before];
			float ty = PY[after] - PY[before];
			float tz = PZ[after] - PZ[before];
			float vx = cx - PX[i];
			float vy = cy - PY[i];
			float vz = cz - PZ[i];
			float sx = ty * vz - tz * vy;
			float sy = tz * vx - tx * vz;
			float sz = tx * vy - ty * vx;
			float len = Mth.sqrt(sx * sx + sy * sy + sz * sz);
			if (len < 1.0E-5f) {
				sx = 1.0f;
				sy = 0.0f;
				sz = 0.0f;
				len = 1.0f;
			}
			float k = PW[i] / len;
			SX[i] = sx * k;
			SY[i] = sy * k;
			SZ[i] = sz * k;
		}
		for (int i = 0; i < n; i++) {
			int a0 = alpha(PA[i] * power);
			int a1 = alpha(PA[i + 1] * power);
			vertex(consumer, pose, PX[i] - SX[i], PY[i] - SY[i], PZ[i] - SZ[i], r, g, b, 0);
			vertex(consumer, pose, PX[i], PY[i], PZ[i], r, g, b, a0);
			vertex(consumer, pose, PX[i + 1], PY[i + 1], PZ[i + 1], r, g, b, a1);
			vertex(consumer, pose, PX[i + 1] - SX[i + 1], PY[i + 1] - SY[i + 1], PZ[i + 1] - SZ[i + 1], r, g, b, 0);
			vertex(consumer, pose, PX[i], PY[i], PZ[i], r, g, b, a0);
			vertex(consumer, pose, PX[i] + SX[i], PY[i] + SY[i], PZ[i] + SZ[i], r, g, b, 0);
			vertex(consumer, pose, PX[i + 1] + SX[i + 1], PY[i + 1] + SY[i + 1], PZ[i + 1] + SZ[i + 1], r, g, b, 0);
			vertex(consumer, pose, PX[i + 1], PY[i + 1], PZ[i + 1], r, g, b, a1);
		}
	}

	private static void disc(VertexConsumer consumer, Matrix4f pose, float x, float y, float z, float radius, int segments, int r, int g, int b, float strength, Vector3f left, Vector3f up) {
		int a = alpha(strength);
		for (int i = 0; i < segments; i++) {
			float t0 = TAU * i / segments;
			float t1 = TAU * (i + 1) / segments;
			float c0 = Mth.cos(t0) * radius;
			float s0 = Mth.sin(t0) * radius;
			float c1 = Mth.cos(t1) * radius;
			float s1 = Mth.sin(t1) * radius;
			vertex(consumer, pose, x, y, z, r, g, b, a);
			vertex(consumer, pose, x, y, z, r, g, b, a);
			vertex(consumer, pose, x + left.x() * c0 + up.x() * s0, y + left.y() * c0 + up.y() * s0, z + left.z() * c0 + up.z() * s0, r, g, b, 0);
			vertex(consumer, pose, x + left.x() * c1 + up.x() * s1, y + left.y() * c1 + up.y() * s1, z + left.z() * c1 + up.z() * s1, r, g, b, 0);
		}
	}

	private static void vertex(VertexConsumer consumer, Matrix4f pose, float x, float y, float z, int r, int g, int b, int a) {
		consumer.vertex(pose, x, y, z).color(r, g, b, a).endVertex();
	}

	private static int alpha(float value) {
		return Mth.clamp((int) (value * 255.0f), 0, 255);
	}

	private static float hash(int a, int b, int c) {
		int h = a * 374761393 + b * 668265263 + c * 1274126177;
		h = (h ^ (h >>> 13)) * 1274126177;
		h ^= h >>> 16;
		return (h & 0xFFFF) / 32767.5f - 1.0f;
	}

	private static float hash01(int a, int b, int c) {
		return hash(a, b, c) * 0.5f + 0.5f;
	}

	private static float noise(int a, int b, double t) {
		int i = (int) Math.floor(t);
		float f = (float) (t - i);
		f = f * f * (3.0f - 2.0f * f);
		return Mth.lerp(f, hash(a, b, i), hash(a, b, i + 1));
	}
}
