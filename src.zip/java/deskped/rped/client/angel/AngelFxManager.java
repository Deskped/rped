package deskped.rped.client.angel;

import java.util.ArrayList;
import java.util.List;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.Minecraft;

import deskped.rped.network.AngelFxPacket;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE, value = {Dist.CLIENT})
public class AngelFxManager {
	public static final List<Fx> ACTIVE = new ArrayList<>();
	private static ClientLevel lastLevel;

	public static final class Fx {
		public final int type;
		public final int stage;
		public final int entityId;
		public final int duration;
		public final double x;
		public final double y;
		public final double z;
		public final double x2;
		public final double y2;
		public final double z2;
		public final float a;
		public final long start;

		private Fx(AngelFxPacket p, long start) {
			this.type = p.type;
			this.stage = p.stage;
			this.entityId = p.entityId;
			this.duration = Math.max(1, p.duration);
			this.x = p.x;
			this.y = p.y;
			this.z = p.z;
			this.x2 = p.x2;
			this.y2 = p.y2;
			this.z2 = p.z2;
			this.a = p.a;
			this.start = start;
		}
	}

	public static void add(AngelFxPacket packet) {
		ClientLevel level = Minecraft.getInstance().level;
		if (level == null)
			return;
		if (ACTIVE.size() > 300)
			ACTIVE.remove(0);
		ACTIVE.add(new Fx(packet, level.getGameTime()));
	}

	@SubscribeEvent
	public static void onClientTick(TickEvent.ClientTickEvent event) {
		if (event.phase != TickEvent.Phase.END)
			return;
		ClientLevel level = Minecraft.getInstance().level;
		if (level == null || level != lastLevel) {
			ACTIVE.clear();
			lastLevel = level;
			return;
		}
		long now = level.getGameTime();
		ACTIVE.removeIf(fx -> now - fx.start > fx.duration + 2);
	}

	@SubscribeEvent
	public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
		ACTIVE.clear();
		lastLevel = null;
	}
}
