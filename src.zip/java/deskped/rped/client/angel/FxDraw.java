package deskped.rped.client.angel;

import org.joml.Vector3f;
import org.joml.Matrix4f;

import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.util.Mth;

final class FxDraw {
	static final float TAU = (float) (Math.PI * 2.0D);

	private FxDraw() {
	}

	static void vertex(VertexConsumer vc, Matrix4f m, float x, float y, float z, float u, float v, int rgb, float alpha) {
		int a = (int) (Mth.clamp(alpha, 0.0F, 1.0F) * 255.0F);
		vc.vertex(m, x, y, z).color(rgb >> 16 & 255, rgb >> 8 & 255, rgb & 255, a).uv(u, v).endVertex();
	}

	static void quad(VertexConsumer vc, Matrix4f m, int rgb, float alpha, float[] p, float[] uv) {
		for (int i = 0; i < 4; i++)
			vertex(vc, m, p[i * 3], p[i * 3 + 1], p[i * 3 + 2], uv[i * 2], uv[i * 2 + 1], rgb, alpha);
	}

	static void disc(VertexConsumer vc, Matrix4f m, float cx, float cy, float cz, float ax, float ay, float az, float bx, float by, float bz, float radius, float rot, int rgb, float alpha) {
		float c = Mth.cos(rot) * radius;
		float s = Mth.sin(rot) * radius;
		float ux = ax * c + bx * s;
		float uy = ay * c + by * s;
		float uz = az * c + bz * s;
		float vx = -ax * s + bx * c;
		float vy = -ay * s + by * c;
		float vz = -az * s + bz * c;
		vertex(vc, m, cx - ux - vx, cy - uy - vy, cz - uz - vz, 0.0F, 0.0F, rgb, alpha);
		vertex(vc, m, cx + ux - vx, cy + uy - vy, cz + uz - vz, 1.0F, 0.0F, rgb, alpha);
		vertex(vc, m, cx + ux + vx, cy + uy + vy, cz + uz + vz, 1.0F, 1.0F, rgb, alpha);
		vertex(vc, m, cx - ux + vx, cy - uy + vy, cz - uz + vz, 0.0F, 1.0F, rgb, alpha);
	}

	static void flat(VertexConsumer vc, Matrix4f m, float cx, float cy, float cz, float radius, float rot, int rgb, float alpha) {
		disc(vc, m, cx, cy, cz, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, radius, rot, rgb, alpha);
	}

	static void billboard(VertexConsumer vc, Matrix4f m, Vector3f left, Vector3f up, float cx, float cy, float cz, float size, float rot, int rgb, float alpha) {
		disc(vc, m, cx, cy, cz, left.x(), left.y(), left.z(), up.x(), up.y(), up.z(), size * 0.5F, rot, rgb, alpha);
	}

	static void ring(VertexConsumer vc, Matrix4f m, float cx, float cy, float cz, float inner, float outer, int segments, float uRepeat, float uScroll, int rgb, float alpha) {
		for (int i = 0; i < segments; i++) {
			float a0 = TAU * i / segments;
			float a1 = TAU * (i + 1) / segments;
			float u0 = uScroll + uRepeat * i / segments;
			float u1 = uScroll + uRepeat * (i + 1) / segments;
			float c0 = Mth.cos(a0);
			float s0 = Mth.sin(a0);
			float c1 = Mth.cos(a1);
			float s1 = Mth.sin(a1);
			vertex(vc, m, cx + c0 * inner, cy, cz + s0 * inner, u0, 0.0F, rgb, alpha);
			vertex(vc, m, cx + c0 * outer, cy, cz + s0 * outer, u0, 1.0F, rgb, alpha);
			vertex(vc, m, cx + c1 * outer, cy, cz + s1 * outer, u1, 1.0F, rgb, alpha);
			vertex(vc, m, cx + c1 * inner, cy, cz + s1 * inner, u1, 0.0F, rgb, alpha);
		}
	}

	static void wall(VertexConsumer vc, Matrix4f m, float cx, float cy, float cz, float radius, float height, int segments, float uRepeat, float uScroll, int rgb, float alphaBottom, float alphaTop) {
		for (int i = 0; i < segments; i++) {
			float a0 = TAU * i / segments;
			float a1 = TAU * (i + 1) / segments;
			float u0 = uScroll + uRepeat * i / segments;
			float u1 = uScroll + uRepeat * (i + 1) / segments;
			float x0 = cx + Mth.cos(a0) * radius;
			float z0 = cz + Mth.sin(a0) * radius;
			float x1 = cx + Mth.cos(a1) * radius;
			float z1 = cz + Mth.sin(a1) * radius;
			vertex(vc, m, x0, cy, z0, u0, 1.0F, rgb, alphaBottom);
			vertex(vc, m, x1, cy, z1, u1, 1.0F, rgb, alphaBottom);
			vertex(vc, m, x1, cy + height, z1, u1, 0.0F, rgb, alphaTop);
			vertex(vc, m, x0, cy + height, z0, u0, 0.0F, rgb, alphaTop);
		}
	}

	static void pillar(VertexConsumer vc, Matrix4f m, float cx, float cy, float cz, float radius, float height, int planes, float vScroll, int rgb, float alphaBottom, float alphaTop) {
		float vBottom = vScroll + height * 0.12F;
		for (int p = 0; p < planes; p++) {
			float angle = (float) Math.PI * p / planes;
			float dx = Mth.cos(angle) * radius;
			float dz = Mth.sin(angle) * radius;
			vertex(vc, m, cx - dx, cy, cz - dz, 0.0F, vBottom, rgb, alphaBottom);
			vertex(vc, m, cx + dx, cy, cz + dz, 1.0F, vBottom, rgb, alphaBottom);
			vertex(vc, m, cx + dx, cy + height, cz + dz, 1.0F, vScroll, rgb, alphaTop);
			vertex(vc, m, cx - dx, cy + height, cz - dz, 0.0F, vScroll, rgb, alphaTop);
		}
	}

	static void ribbon(VertexConsumer vc, Matrix4f m, float x0, float y0, float z0, float x1, float y1, float z1, float width, float vRepeat, float vScroll, int rgb, float alphaStart, float alphaEnd) {
		float dx = x1 - x0;
		float dy = y1 - y0;
		float dz = z1 - z0;
		float tx = -(x0 + x1) * 0.5F;
		float ty = -(y0 + y1) * 0.5F;
		float tz = -(z0 + z1) * 0.5F;
		float sx = dy * tz - dz * ty;
		float sy = dz * tx - dx * tz;
		float sz = dx * ty - dy * tx;
		float len = Mth.sqrt(sx * sx + sy * sy + sz * sz);
		if (len < 1.0E-4F)
			return;
		float k = width * 0.5F / len;
		sx *= k;
		sy *= k;
		sz *= k;
		vertex(vc, m, x0 - sx, y0 - sy, z0 - sz, 0.0F, vScroll, rgb, alphaStart);
		vertex(vc, m, x0 + sx, y0 + sy, z0 + sz, 1.0F, vScroll, rgb, alphaStart);
		vertex(vc, m, x1 + sx, y1 + sy, z1 + sz, 1.0F, vScroll + vRepeat, rgb, alphaEnd);
		vertex(vc, m, x1 - sx, y1 - sy, z1 - sz, 0.0F, vScroll + vRepeat, rgb, alphaEnd);
	}
}
