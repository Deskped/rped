package deskped.rped.client.angel;

import org.joml.Vector3f;
import org.joml.Matrix4f;

import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.Mth;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Camera;

import deskped.rped.entity.TumaniteAngelEntity;
import deskped.rped.entity.AngelStages;
import deskped.rped.network.AngelFxPacket;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE, value = {Dist.CLIENT})
public class AngelFxRenderer {
	private static final float PI = (float) Math.PI;
	private static final float TAU = FxDraw.TAU;
	private static final int WHITE = 0xFFFFFF;

	private static final class View {
		private final Matrix4f m;
		private final MultiBufferSource.BufferSource buffers;
		private final double camX;
		private final double camY;
		private final double camZ;
		private final Vector3f left;
		private final Vector3f up;
		private final float pt;
		private final ClientLevel level;

		private View(Matrix4f m, MultiBufferSource.BufferSource buffers, Vec3 cam, Vector3f left, Vector3f up, float pt, ClientLevel level) {
			this.m = m;
			this.buffers = buffers;
			this.camX = cam.x;
			this.camY = cam.y;
			this.camZ = cam.z;
			this.left = left;
			this.up = up;
			this.pt = pt;
			this.level = level;
		}

		private VertexConsumer buf(RenderType type) {
			return this.buffers.getBuffer(type);
		}

		private float rx(double x) {
			return (float) (x - this.camX);
		}

		private float ry(double y) {
			return (float) (y - this.camY);
		}

		private float rz(double z) {
			return (float) (z - this.camZ);
		}
	}

	@SubscribeEvent
	public static void onRender(RenderLevelStageEvent event) {
		if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES)
			return;
		Minecraft mc = Minecraft.getInstance();
		ClientLevel level = mc.level;
		if (level == null)
			return;
		boolean any = !AngelFxManager.ACTIVE.isEmpty();
		if (!any) {
			for (Entity entity : level.entitiesForRendering()) {
				if (entity instanceof TumaniteAngelEntity) {
					any = true;
					break;
				}
			}
		}
		if (!any)
			return;
		Camera camera = event.getCamera();
		View view = new View(event.getPoseStack().last().pose(), mc.renderBuffers().bufferSource(), camera.getPosition(), new Vector3f(camera.getLeftVector()), new Vector3f(camera.getUpVector()), event.getPartialTick(), level);
		for (Entity entity : level.entitiesForRendering()) {
			if (entity instanceof TumaniteAngelEntity angel && angel.isAlive() && !angel.isInvisible() && angel.distanceToSqr(camera.getPosition()) < 16384.0D)
				drawAngel(view, angel);
		}
		for (AngelFxManager.Fx fx : AngelFxManager.ACTIVE)
			drawFx(view, fx);
		for (RenderType type : AngelRenderTypes.ALL)
			view.buffers.endBatch(type);
	}

	private static void drawAngel(View v, TumaniteAngelEntity e) {
		float pt = v.pt;
		float cx = v.rx(Mth.lerp(pt, e.xo, e.getX()));
		float cy = v.ry(Mth.lerp(pt, e.yo, e.getY()));
		float cz = v.rz(Mth.lerp(pt, e.zo, e.getZ()));
		float h = e.getBbHeight();
		int stage = e.getStage();
		int rgb = AngelStages.color(stage);
		float time = e.tickCount + pt;
		float yaw = (float) Math.toRadians(Mth.rotLerp(pt, e.yBodyRotO, e.yBodyRot));
		float lx = Mth.cos(yaw);
		float lz = Mth.sin(yaw);
		float bx = Mth.sin(yaw);
		float bz = -Mth.cos(yaw);
		float shoulder = cy + h * 0.62F;
		float pulse = 0.5F + 0.5F * Mth.sin(time * (0.1F + 0.02F * stage));

		VertexConsumer glow = v.buf(AngelRenderTypes.GLOW);
		FxDraw.billboard(glow, v.m, v.left, v.up, cx, cy + h * 0.5F, cz, h * (2.4F + 0.4F * pulse), 0.0F, rgb, 0.2F + 0.1F * pulse);
		FxDraw.billboard(glow, v.m, v.left, v.up, cx, cy + h * 0.5F, cz, h * 1.2F, 0.0F, WHITE, 0.14F + 0.08F * pulse);
		for (int side = -1; side <= 1; side += 2)
			FxDraw.billboard(glow, v.m, v.left, v.up, cx + side * lx * 0.28F + bx * 0.25F, shoulder, cz + side * lz * 0.28F + bz * 0.25F, 0.9F + 0.2F * stage, 0.0F, rgb, 0.3F + 0.15F * pulse);

		VertexConsumer feather = v.buf(AngelRenderTypes.FEATHER);
		int feathers = 4 + stage;
		float length = 1.3F + 0.28F * stage;
		float flap = Mth.sin(time * (0.14F + 0.025F * stage)) * (0.2F + 0.03F * stage);
		float[] p = new float[12];
		float[] uv = {0.0F, 1.0F, 1.0F, 1.0F, 1.0F, 0.0F, 0.0F, 0.0F};
		for (int side = -1; side <= 1; side += 2) {
			float px = cx + side * lx * 0.28F + bx * 0.25F;
			float pz = cz + side * lz * 0.28F + bz * 0.25F;
			for (int k = 0; k < feathers; k++) {
				float t = k / (float) (feathers - 1);
				float angle = (float) Math.toRadians(-35.0D + 110.0D * t) + flap * (0.4F + t);
				float l = length * (1.0F - 0.45F * t);
				float ca = Mth.cos(angle);
				float sa = Mth.sin(angle);
				float dx = side * lx * ca + bx * 0.12F;
				float dy = sa;
				float dz = side * lz * ca + bz * 0.12F;
				float dl = Mth.sqrt(dx * dx + dy * dy + dz * dz);
				dx /= dl;
				dy /= dl;
				dz /= dl;
				float nx = -side * lx * sa;
				float ny = ca;
				float nz = -side * lz * sa;
				float w0 = 0.07F;
				float w1 = 0.17F + 0.03F * stage;
				float tx = px + dx * l;
				float ty = shoulder + dy * l;
				float tz = pz + dz * l;
				p[0] = px - nx * w0;
				p[1] = shoulder - ny * w0;
				p[2] = pz - nz * w0;
				p[3] = px + nx * w0;
				p[4] = shoulder + ny * w0;
				p[5] = pz + nz * w0;
				p[6] = tx + nx * w1;
				p[7] = ty + ny * w1;
				p[8] = tz + nz * w1;
				p[9] = tx - nx * w1;
				p[10] = ty - ny * w1;
				p[11] = tz - nz * w1;
				FxDraw.quad(feather, v.m, rgb, 0.8F, p, uv);
			}
		}

		VertexConsumer rune = v.buf(AngelRenderTypes.RUNE);
		float hy = cy + h + 0.35F;
		FxDraw.flat(rune, v.m, cx, hy, cz, 0.95F, time * 0.04F, rgb, 0.7F);
		if (stage >= 2)
			FxDraw.disc(rune, v.m, cx + bx * 0.6F, shoulder, cz + bz * 0.6F, lx, 0.0F, lz, 0.0F, 1.0F, 0.0F, 1.3F + 0.18F * stage, time * 0.03F, rgb, 0.5F);

		FxDraw.ring(v.buf(AngelRenderTypes.RING), v.m, cx, hy, cz, 0.45F, 0.78F, 32, 4.0F, -time * 0.05F, rgb, 0.9F);

		VertexConsumer star = v.buf(AngelRenderTypes.STAR);
		FxDraw.billboard(star, v.m, v.left, v.up, cx, hy, cz, 0.55F + 0.2F * pulse, time * 0.05F, WHITE, 0.9F);
		int sparks = 6 + 2 * stage;
		for (int i = 0; i < sparks; i++) {
			float life = (time * (0.012F + 0.004F * (i % 3)) + i * 0.618034F) % 1.0F;
			float ang = time * (0.04F + 0.01F * (i % 4)) + i * 2.399F;
			float rad = 0.8F + 0.9F * ((i * 0.37F) % 1.0F);
			float sy = cy + h * 0.05F + life * h * 1.5F;
			float size = 0.12F + 0.2F * ((i * 0.53F) % 1.0F);
			FxDraw.billboard(star, v.m, v.left, v.up, cx + Mth.cos(ang) * rad, sy, cz + Mth.sin(ang) * rad, size, time * 0.1F + i, rgb, Mth.sin(life * PI) * 0.9F);
		}
	}

	private static void drawFx(View v, AngelFxManager.Fx fx) {
		float age = Math.max(0.0F, (float) (v.level.getGameTime() - fx.start) + v.pt);
		float p = Mth.clamp(age / fx.duration, 0.0F, 1.0F);
		int rgb = AngelStages.color(fx.stage);
		switch (fx.type) {
			case AngelFxPacket.CHARGE -> drawCharge(v, fx, age, p, rgb);
			case AngelFxPacket.RING -> drawRing(v, fx, age, rgb);
			case AngelFxPacket.STRIKE -> drawStrike(v, fx, age, rgb);
			case AngelFxPacket.BLINK_MARK -> drawBlinkMark(v, fx, age, p, rgb);
			case AngelFxPacket.BLINK_TRAIL -> drawBlinkTrail(v, fx, age, p, rgb);
			case AngelFxPacket.FLASH -> drawFlash(v, fx, age, p, rgb);
			case AngelFxPacket.BURST -> drawBurst(v, fx, age, p, rgb, false);
			case AngelFxPacket.TRANSITION -> drawBurst(v, fx, age, p, rgb, true);
			case AngelFxPacket.WELL -> drawWell(v, fx, age, rgb);
			default -> {
			}
		}
	}

	private static void drawCharge(View v, AngelFxManager.Fx fx, float age, float p, int rgb) {
		Entity e = v.level.getEntity(fx.entityId);
		if (e == null)
			return;
		float cx = v.rx(Mth.lerp(v.pt, e.xo, e.getX()));
		float cy = v.ry(Mth.lerp(v.pt, e.yo, e.getY()) + e.getBbHeight() * 0.5D);
		float cz = v.rz(Mth.lerp(v.pt, e.zo, e.getZ()));
		float fade = Mth.clamp(p * 4.0F, 0.0F, 1.0F) * (1.0F - Mth.clamp((p - 0.9F) * 10.0F, 0.0F, 1.0F));
		float radius = fx.a * (1.0F - p) + 0.35F;
		FxDraw.flat(v.buf(AngelRenderTypes.RUNE), v.m, cx, cy, cz, radius, age * 0.25F, rgb, 0.85F * fade);
		FxDraw.billboard(v.buf(AngelRenderTypes.GLOW), v.m, v.left, v.up, cx, cy, cz, 1.5F + 3.5F * p, 0.0F, rgb, 0.5F * fade);
		VertexConsumer star = v.buf(AngelRenderTypes.STAR);
		for (int i = 0; i < 6; i++) {
			float a = age * 0.35F + i * TAU / 6.0F;
			float r = radius * 1.3F + 0.3F;
			FxDraw.billboard(star, v.m, v.left, v.up, cx + Mth.cos(a) * r, cy + Mth.sin(age * 0.2F + i) * 0.6F, cz + Mth.sin(a) * r, 0.4F, age * 0.2F, rgb, 0.9F * fade);
		}
	}

	private static void drawRing(View v, AngelFxManager.Fx fx, float age, int rgb) {
		float cx = v.rx(fx.x);
		float cy = v.ry(fx.y);
		float cz = v.rz(fx.z);
		float r = (age + 1.0F) * 1.1F;
		float alpha = 1.0F - Mth.clamp((r - fx.a) / 3.0F, 0.0F, 1.0F);
		if (alpha <= 0.0F)
			return;
		int segments = Mth.clamp((int) (r * 6.0F), 24, 120);
		float scroll = -age * 0.15F;
		VertexConsumer ring = v.buf(AngelRenderTypes.RING);
		FxDraw.ring(ring, v.m, cx, cy + 0.1F, cz, Math.max(0.0F, r - 1.3F), r + 0.5F, segments, r * 0.9F, scroll, rgb, 0.85F * alpha);
		FxDraw.ring(ring, v.m, cx, cy + 0.12F, cz, Math.max(0.0F, r - 0.35F), r + 0.2F, segments, r * 0.9F, scroll * 1.3F, WHITE, 0.9F * alpha);
		FxDraw.wall(ring, v.m, cx, cy + 0.02F, cz, r, 0.95F, segments, r * 0.7F, scroll, rgb, 0.7F * alpha, 0.0F);
	}

	private static void drawStrike(View v, AngelFxManager.Fx fx, float age, int rgb) {
		float cx = v.rx(fx.x);
		float cy = v.ry(fx.y);
		float cz = v.rz(fx.z);
		int delay = fx.duration - 14;
		VertexConsumer rune = v.buf(AngelRenderTypes.RUNE);
		VertexConsumer ring = v.buf(AngelRenderTypes.RING);
		VertexConsumer beam = v.buf(AngelRenderTypes.BEAM);
		if (age < delay) {
			float k = age / Math.max(1, delay);
			FxDraw.flat(rune, v.m, cx, cy + 0.08F, cz, 1.9F, age * 0.12F, rgb, 0.25F + 0.65F * k);
			FxDraw.ring(ring, v.m, cx, cy + 0.1F, cz, 1.45F, 1.9F, 32, 6.0F, -age * 0.1F, rgb, 0.35F + 0.5F * k);
			FxDraw.pillar(beam, v.m, cx, cy, cz, 0.1F + 0.25F * k, 10.0F, 3, -age * 0.05F, rgb, 0.1F + 0.5F * k, 0.0F);
			VertexConsumer star = v.buf(AngelRenderTypes.STAR);
			for (int i = 0; i < 4; i++) {
				float a = age * 0.3F + i * TAU / 4.0F;
				float r = 1.9F * (1.0F - k);
				FxDraw.billboard(star, v.m, v.left, v.up, cx + Mth.cos(a) * r, cy + 0.2F + k * 3.0F, cz + Mth.sin(a) * r, 0.35F, age * 0.2F, rgb, 0.4F + 0.5F * k);
			}
			return;
		}
		float q = Mth.clamp((age - delay) / 12.0F, 0.0F, 1.0F);
		float fade = 1.0F - q;
		FxDraw.pillar(beam, v.m, cx, cy, cz, 1.7F * (1.0F - 0.6F * q), 22.0F, 3, -age * 0.2F, rgb, 0.9F * fade, 0.25F * fade);
		FxDraw.pillar(beam, v.m, cx, cy, cz, 0.8F * (1.0F - 0.6F * q), 22.0F, 3, -age * 0.3F, WHITE, 0.9F * fade, 0.3F * fade);
		float r = 1.5F + q * 5.0F;
		FxDraw.ring(ring, v.m, cx, cy + 0.1F, cz, r - 1.0F, r + 0.3F, 40, 6.0F, -age * 0.2F, rgb, 0.8F * fade);
		FxDraw.flat(rune, v.m, cx, cy + 0.08F, cz, 1.9F, age * 0.12F, rgb, 0.8F * fade);
		FxDraw.billboard(v.buf(AngelRenderTypes.GLOW), v.m, v.left, v.up, cx, cy + 0.8F, cz, 7.0F * (1.0F - 0.5F * q), 0.0F, rgb, fade);
	}

	private static void drawBlinkMark(View v, AngelFxManager.Fx fx, float age, float p, int rgb) {
		float cx = v.rx(fx.x);
		float cy = v.ry(fx.y);
		float cz = v.rz(fx.z);
		float fade = Mth.clamp(p * 3.0F, 0.0F, 1.0F);
		FxDraw.billboard(v.buf(AngelRenderTypes.RUNE), v.m, v.left, v.up, cx, cy, cz, 0.6F + 1.6F * p, age * 0.3F, rgb, 0.9F * fade);
		FxDraw.billboard(v.buf(AngelRenderTypes.GLOW), v.m, v.left, v.up, cx, cy, cz, 1.2F + 2.4F * p, 0.0F, rgb, 0.6F * p);
		VertexConsumer star = v.buf(AngelRenderTypes.STAR);
		for (int i = 0; i < 6; i++) {
			float a = age * 0.4F + i * TAU / 6.0F;
			float r = (1.0F - p) * 2.2F + 0.3F;
			FxDraw.billboard(star, v.m, v.left, v.up, cx + Mth.cos(a) * r, cy + Mth.sin(age * 0.3F + i) * 0.5F, cz + Mth.sin(a) * r, 0.35F, age * 0.2F, rgb, 0.9F * fade);
		}
	}

	private static void drawBlinkTrail(View v, AngelFxManager.Fx fx, float age, float p, int rgb) {
		float x0 = v.rx(fx.x);
		float y0 = v.ry(fx.y);
		float z0 = v.rz(fx.z);
		float x1 = v.rx(fx.x2);
		float y1 = v.ry(fx.y2);
		float z1 = v.rz(fx.z2);
		float fade = 1.0F - p;
		float dx = x1 - x0;
		float dy = y1 - y0;
		float dz = z1 - z0;
		float repeat = Math.max(1.0F, Mth.sqrt(dx * dx + dy * dy + dz * dz) * 0.3F);
		VertexConsumer beam = v.buf(AngelRenderTypes.BEAM);
		FxDraw.ribbon(beam, v.m, x0, y0, z0, x1, y1, z1, 1.2F * fade + 0.1F, repeat, -age * 0.3F, rgb, 0.9F * fade, 0.15F * fade);
		FxDraw.ribbon(beam, v.m, x0, y0, z0, x1, y1, z1, 0.45F * fade + 0.05F, repeat, -age * 0.4F, WHITE, 0.9F * fade, 0.2F * fade);
		VertexConsumer glow = v.buf(AngelRenderTypes.GLOW);
		FxDraw.billboard(glow, v.m, v.left, v.up, x0, y0, z0, 2.5F * fade + 0.3F, 0.0F, rgb, 0.7F * fade);
		FxDraw.billboard(glow, v.m, v.left, v.up, x1, y1, z1, 2.5F * fade + 0.3F, 0.0F, rgb, 0.7F * fade);
	}

	private static void drawFlash(View v, AngelFxManager.Fx fx, float age, float p, int rgb) {
		float cx = v.rx(fx.x);
		float cy = v.ry(fx.y);
		float cz = v.rz(fx.z);
		float fade = 1.0F - p;
		FxDraw.billboard(v.buf(AngelRenderTypes.GLOW), v.m, v.left, v.up, cx, cy, cz, fx.a * (0.5F + 0.9F * p), 0.0F, rgb, 0.9F * fade * fade);
		FxDraw.billboard(v.buf(AngelRenderTypes.STAR), v.m, v.left, v.up, cx, cy, cz, fx.a * (0.6F + 1.0F * p), age * 0.3F, WHITE, fade);
	}

	private static void drawBurst(View v, AngelFxManager.Fx fx, float age, float p, int rgb, boolean transition) {
		float cx = v.rx(fx.x);
		float cy = v.ry(fx.y);
		float cz = v.rz(fx.z);
		float radius = fx.a;
		float fade = 1.0F - p;
		float flash = Math.max(0.0F, 1.0F - p * 2.5F);
		if (flash > 0.0F) {
			FxDraw.billboard(v.buf(AngelRenderTypes.GLOW), v.m, v.left, v.up, cx, cy, cz, radius * 0.9F * (1.0F + p * 0.4F), 0.0F, rgb, flash);
			FxDraw.billboard(v.buf(AngelRenderTypes.STAR), v.m, v.left, v.up, cx, cy, cz, radius * 0.7F, age * 0.2F, WHITE, flash * 0.8F);
		}
		VertexConsumer ring = v.buf(AngelRenderTypes.RING);
		for (int k = 0; k < 3; k++) {
			float pk = Mth.clamp(p * 1.4F - k * 0.12F, 0.0F, 1.0F);
			if (pk <= 0.0F)
				continue;
			float r = radius * pk;
			FxDraw.ring(ring, v.m, cx, cy + (k - 1) * 0.5F, cz, Math.max(0.05F, r - 1.4F), r + 0.4F, Mth.clamp((int) (r * 6.0F) + 16, 24, 96), r * 0.9F, -age * 0.2F, rgb, 0.85F * (1.0F - pk));
		}
		FxDraw.flat(v.buf(AngelRenderTypes.RUNE), v.m, cx, cy - 0.3F, cz, radius * 0.7F * Mth.clamp(p * 2.0F, 0.0F, 1.0F) + 0.5F, age * 0.1F, rgb, 0.6F * fade);
		VertexConsumer star = v.buf(AngelRenderTypes.STAR);
		float pk = Mth.clamp(p * 1.2F, 0.0F, 1.0F);
		for (int i = 0; i < 20; i++) {
			float a = i * 2.399F;
			float dist = radius * pk * (0.35F + 0.65F * ((i * 0.37F) % 1.0F));
			float sy = cy + Mth.sin(i * 1.7F) * radius * 0.25F * pk + pk * 1.5F;
			FxDraw.billboard(star, v.m, v.left, v.up, cx + Mth.cos(a) * dist, sy, cz + Mth.sin(a) * dist, 0.1F + 0.5F * fade, age * 0.2F + i, rgb, fade);
		}
		if (transition) {
			VertexConsumer beam = v.buf(AngelRenderTypes.BEAM);
			FxDraw.pillar(beam, v.m, cx, cy - 6.0F, cz, 1.4F * (1.0F - 0.8F * p), 30.0F, 3, -age * 0.15F, rgb, 0.8F * fade, 0.2F * fade);
			FxDraw.pillar(beam, v.m, cx, cy - 6.0F, cz, 0.7F * (1.0F - 0.8F * p), 30.0F, 3, -age * 0.25F, WHITE, 0.8F * fade, 0.2F * fade);
		}
	}

	private static void drawWell(View v, AngelFxManager.Fx fx, float age, int rgb) {
		Entity e = v.level.getEntity(fx.entityId);
		if (e == null)
			return;
		float cx = v.rx(Mth.lerp(v.pt, e.xo, e.getX()));
		float cy = v.ry(Mth.lerp(v.pt, e.yo, e.getY()) + e.getBbHeight() * 0.5D);
		float cz = v.rz(Mth.lerp(v.pt, e.zo, e.getZ()));
		float intensity = Mth.clamp(age / 10.0F, 0.0F, 1.0F) * (1.0F - Mth.clamp((age - (fx.duration - 6)) / 6.0F, 0.0F, 1.0F));
		VertexConsumer swirl = v.buf(AngelRenderTypes.SWIRL);
		for (int k = 0; k < 4; k++) {
			float ph = (age * 0.035F + k * 0.25F) % 1.0F;
			float r = 17.0F * (1.0F - ph) + 1.0F;
			FxDraw.flat(swirl, v.m, cx, cy + (k - 1.5F) * 0.9F, cz, r, -age * 0.15F + k, rgb, Mth.sin(ph * PI) * intensity * 0.8F);
		}
		FxDraw.billboard(v.buf(AngelRenderTypes.GLOW), v.m, v.left, v.up, cx, cy, cz, 2.5F + 0.6F * Mth.sin(age * 0.4F), 0.0F, rgb, 0.7F * intensity);
		VertexConsumer star = v.buf(AngelRenderTypes.STAR);
		for (int i = 0; i < 10; i++) {
			float a = age * 0.2F + i * TAU / 10.0F;
			float ph = (age * 0.05F + i * 0.1F) % 1.0F;
			float r = 15.0F * (1.0F - ph) + 1.5F;
			FxDraw.billboard(star, v.m, v.left, v.up, cx + Mth.cos(a) * r, cy + Mth.sin(age * 0.1F + i) * 1.2F, cz + Mth.sin(a) * r, 0.45F, age * 0.2F, rgb, Mth.sin(ph * PI) * intensity);
		}
	}
}
