package deskped.rped.client.angel;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.model.EntityModel;

import deskped.rped.entity.TumaniteAngelEntity;
import deskped.rped.init.RpedModEntities;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class AngelLayerEvents {
	@SubscribeEvent
	public static void onAddLayers(EntityRenderersEvent.AddLayers event) {
		LivingEntityRenderer<TumaniteAngelEntity, ? extends EntityModel<TumaniteAngelEntity>> renderer = event.getRenderer(RpedModEntities.TUMANITE_ANGEL.get());
		if (renderer != null)
			attach(renderer);
	}

	private static <M extends EntityModel<TumaniteAngelEntity>> void attach(LivingEntityRenderer<TumaniteAngelEntity, M> renderer) {
		renderer.addLayer(new AngelGlowLayer<>(renderer));
	}
}
