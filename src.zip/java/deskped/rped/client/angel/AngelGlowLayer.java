package deskped.rped.client.angel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.util.Mth;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.model.EntityModel;

import deskped.rped.entity.TumaniteAngelEntity;
import deskped.rped.entity.AngelStages;

public class AngelGlowLayer<M extends EntityModel<TumaniteAngelEntity>> extends RenderLayer<TumaniteAngelEntity, M> {
	private static final ResourceLocation ENERGY = new ResourceLocation("rped", "textures/fx/fx_energy.png");

	public AngelGlowLayer(RenderLayerParent<TumaniteAngelEntity, M> parent) {
		super(parent);
	}

	@Override
	public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, TumaniteAngelEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
		if (entity.isInvisible())
			return;
		int stage = entity.getStage();
		int rgb = AngelStages.color(stage);
		float cr = (rgb >> 16 & 255) / 255.0F;
		float cg = (rgb >> 8 & 255) / 255.0F;
		float cb = (rgb & 255) / 255.0F;
		float time = entity.tickCount + partialTicks;
		float pulse = 0.5F + 0.5F * Mth.sin(time * (0.1F + 0.02F * stage));
		VertexConsumer emissive = buffer.getBuffer(RenderType.eyes(this.getTextureLocation(entity)));
		this.getParentModel().renderToBuffer(poseStack, emissive, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, 0.55F + 0.45F * cr, 0.55F + 0.45F * cg, 0.55F + 0.45F * cb, 0.35F + 0.35F * pulse);
		VertexConsumer swirl = buffer.getBuffer(RenderType.energySwirl(ENERGY, (time * 0.008F) % 1.0F, (time * 0.012F) % 1.0F));
		poseStack.pushPose();
		poseStack.scale(1.03F, 1.03F, 1.03F);
		this.getParentModel().renderToBuffer(poseStack, swirl, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, cr * (0.5F + 0.3F * pulse), cg * (0.5F + 0.3F * pulse), cb * (0.5F + 0.3F * pulse), 1.0F);
		poseStack.popPose();
	}
}
