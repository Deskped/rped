package deskped.rped.client.angel;

import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;

import deskped.rped.entity.AngelStages;

public class AngelMusicInstance extends AbstractTickableSoundInstance {
	private static final SoundEvent TRACK = SoundEvent.createVariableRangeEvent(new ResourceLocation("rped", "boss.music.angel"));
	private float targetVolume = 1.0F;
	private float targetPitch;
	public int age;

	public AngelMusicInstance(int stage) {
		super(TRACK, SoundSource.MUSIC, SoundInstance.createUnseededRandom());
		this.looping = true;
		this.delay = 0;
		this.volume = 0.0F;
		this.relative = true;
		this.attenuation = SoundInstance.Attenuation.NONE;
		this.targetPitch = AngelStages.musicPitch(stage);
		this.pitch = this.targetPitch;
	}

	@Override
	public boolean canStartSilent() {
		return true;
	}

	public void setStage(int stage) {
		this.targetPitch = AngelStages.musicPitch(stage);
	}

	public void fadeIn() {
		this.targetVolume = 1.0F;
	}

	public void fadeOut() {
		this.targetVolume = 0.0F;
	}

	public void kill() {
		this.volume = 0.0F;
		this.targetVolume = 0.0F;
		this.stop();
	}

	@Override
	public void tick() {
		this.age++;
		if (this.volume < this.targetVolume)
			this.volume = Math.min(this.targetVolume, this.volume + 0.025F);
		else if (this.volume > this.targetVolume)
			this.volume = Math.max(this.targetVolume, this.volume - 0.05F);
		float diff = this.targetPitch - this.pitch;
		this.pitch = Math.abs(diff) < 0.002F ? this.targetPitch : this.pitch + diff * 0.04F;
		if (this.targetVolume <= 0.0F && this.volume <= 0.0F)
			this.stop();
	}
}
