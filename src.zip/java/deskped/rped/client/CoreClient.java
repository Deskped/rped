package deskped.rped.client;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraft.world.level.Level;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.Minecraft;

import deskped.rped.ext.ExtLang;
import deskped.rped.block.entity.CoreBlockEntity;

import java.util.HashMap;
import java.util.Map;

@Mod.EventBusSubscriber(value = Dist.CLIENT)
public final class CoreClient {
	private static final Map<BlockPos, CoreSound> SOUNDS = new HashMap<>();

	private CoreClient() {
	}

	public static void tick(CoreBlockEntity core) {
		Level level = core.getLevel();
		if (level == null || core.getPhase() != CoreBlockEntity.PHASE_ACTIVE)
			return;
		BlockPos pos = core.getBlockPos();
		long now = level.getGameTime();
		SoundManager manager = Minecraft.getInstance().getSoundManager();
		CoreSound current = SOUNDS.get(pos);
		if (current != null && !current.isStopped()) {
			if (now - current.startedAt < 40L || manager.isActive(current))
				return;
			manager.stop(current);
		}
		CoreSound sound = new CoreSound(pos, now);
		SOUNDS.put(pos.immutable(), sound);
		manager.play(sound);
	}

	@SubscribeEvent
	public static void onLeftClick(PlayerInteractEvent.LeftClickBlock event) {
		if (!event.getLevel().isClientSide() || event.getAction() != PlayerInteractEvent.LeftClickBlock.Action.START)
			return;
		if (!(event.getLevel().getBlockEntity(event.getPos()) instanceof CoreBlockEntity core) || core.getPhase() != CoreBlockEntity.PHASE_COOLDOWN)
			return;
		String text = ExtLang.pick("Вы не можете сломать ядро во время перезарядки!", "You cannot break the core while it is recharging!");
		event.getEntity().displayClientMessage(Component.literal(text).withStyle(ChatFormatting.RED), true);
	}

	@SubscribeEvent
	public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
		SOUNDS.clear();
	}

	private static final class CoreSound extends AbstractTickableSoundInstance {
		private final BlockPos pos;
		private final long startedAt;

		private CoreSound(BlockPos pos, long startedAt) {
			super(SoundEvents.BEACON_AMBIENT, SoundSource.BLOCKS, SoundInstance.createUnseededRandom());
			this.pos = pos.immutable();
			this.startedAt = startedAt;
			this.looping = true;
			this.delay = 0;
			this.volume = 100.0F;
			this.pitch = 0.4F;
			this.x = pos.getX() + 0.5;
			this.y = pos.getY() + 0.5;
			this.z = pos.getZ() + 0.5;
		}

		@Override
		public void tick() {
			Level level = Minecraft.getInstance().level;
			BlockEntity entity = level == null ? null : level.getBlockEntity(this.pos);
			if (!(entity instanceof CoreBlockEntity core) || core.getPhase() != CoreBlockEntity.PHASE_ACTIVE)
				this.stop();
		}
	}
}
