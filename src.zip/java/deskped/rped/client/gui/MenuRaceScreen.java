package deskped.rped.client.gui;

import deskped.rped.RpedMod;
import deskped.rped.client.ClientRaceState;
import deskped.rped.client.SquareButton;
import deskped.rped.network.RaceDeathModePacket;
import deskped.rped.network.RaceSelectPacket;
import deskped.rped.race.RaceAttribute;
import deskped.rped.race.RaceGroup;
import deskped.rped.race.RaceLevels;
import deskped.rped.world.inventory.MenuRaceMenu;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@OnlyIn(Dist.CLIENT)
public class MenuRaceScreen extends AbstractContainerScreen<MenuRaceMenu> {

	private static final int MIN_SELECT = 1;
	private static final int MAX_SELECT = 3;
	private static final String[] GROUP_SYMBOL = {"\u2663", "\u25B2", "\u2600", "\u2248", "\u2668", "\u2726"};

	private final Set<RaceAttribute> selected = EnumSet.noneOf(RaceAttribute.class);
	private final Map<RaceAttribute, Button> attrButtons = new EnumMap<>(RaceAttribute.class);
	private final List<SquareButton> tabs = new ArrayList<>();

	private RaceGroup curGroup = RaceGroup.FOREST;
	private Button selectButton;
	private int uiState = 0;
	private boolean locked;
	private boolean ru;
	private boolean isOp;
	private boolean nothingPending;
	private int baseY;

	private SoundInstance music;
	private int musicKey = -1;

	public MenuRaceScreen(MenuRaceMenu menu, Inventory inv, Component title) {
		super(menu, inv, title);
	}

	@Override
	protected void init() {
		super.init();
		ru = Minecraft.getInstance().options.languageCode.startsWith("ru");
		isOp = Minecraft.getInstance().player != null && Minecraft.getInstance().player.hasPermissions(2);
		nothingPending = false;
		uiState = menu.mode == 1 ? 2 : 0;
		locked = menu.mode == 0 && ClientRaceState.get().isEmpty();
		selected.clear();
		for (String s : ClientRaceState.get()) {
			try {
				selected.add(RaceAttribute.valueOf(s));
			} catch (IllegalArgumentException ignored) {
			}
		}
		buildWidgets();
	}

	private int xpLevel() {
		return Minecraft.getInstance().player != null ? Minecraft.getInstance().player.experienceLevel : 0;
	}

	private boolean isLocked(RaceGroup grp) {
		return !isOp && xpLevel() < grp.reqLevel;
	}

	private boolean canSelect() {
		return selected.size() >= MIN_SELECT && selected.size() <= MAX_SELECT;
	}

	private void buildWidgets() {
		clearWidgets();
		attrButtons.clear();
		tabs.clear();
		selectButton = null;
		baseY = Math.max(0, (this.height - 196) / 2);
		switch (uiState) {
			case 0 -> buildMain();
			case 1 -> buildConfirm();
			case 2 -> buildDeath();
			default -> buildDeathMode();
		}
	}

	private void buildMain() {
		int cx = this.width / 2;
		int ty = baseY + 28;
		RaceGroup[] groups = RaceGroup.values();
		int tx = cx - (groups.length * 24 - 4) / 2;
		for (int k = 0; k < groups.length; k++) {
			RaceGroup grp = groups[k];
			SquareButton tab = new SquareButton(tx + k * 24, ty, 20, groupTip(grp), b -> {
				curGroup = grp;
				buildWidgets();
			}).symbol(GROUP_SYMBOL[grp.ordinal()], grp.color);
			tabs.add(tab);
			addRenderableWidget(tab);
		}
		int ay = ty + 42;
		boolean grpLocked = isLocked(curGroup);
		for (RaceAttribute attr : RaceAttribute.values()) {
			if (attr.group != curGroup)
				continue;
			Button b = Button.builder(attrLabel(attr), btn -> toggle(attr)).bounds(cx - 110, ay, 220, 20).build();
			b.active = !grpLocked;
			attrButtons.put(attr, b);
			addRenderableWidget(b);
			ay += 24;
		}
		int by = ty + 144;
		int sx = isOp ? cx - 125 : cx - 75;
		selectButton = Button.builder(selectLabel(), b -> {
			nothingPending = false;
			uiState = 1;
			buildWidgets();
		}).bounds(sx, by, 150, 20).build();
		selectButton.active = canSelect();
		addRenderableWidget(selectButton);
		if (isOp) {
			addRenderableWidget(Button.builder(Component.literal(ru ? "\u041d\u0438\u0447\u0442\u043e" : "Nothing"), b -> {
				nothingPending = true;
				uiState = 1;
				buildWidgets();
			}).bounds(sx + 160, by, 90, 20).build());
		}
	}

	private void buildConfirm() {
		int cx = this.width / 2;
		int by = this.height / 2 + 4;
		addRenderableWidget(Button.builder(Component.literal(ru ? "\u0414\u0430" : "Yes"), b -> {
			List<String> names = new ArrayList<>();
			if (!nothingPending)
				for (RaceAttribute a : selected)
					names.add(a.name());
			RpedMod.PACKET_HANDLER.sendToServer(new RaceSelectPacket(names));
			ClientRaceState.set(names);
			nothingPending = false;
			locked = false;
			uiState = 0;
			this.onClose();
		}).bounds(cx - 75, by, 70, 20).build());
		addRenderableWidget(Button.builder(Component.literal(ru ? "\u041d\u0435\u0442" : "No"), b -> {
			nothingPending = false;
			uiState = 0;
			buildWidgets();
		}).bounds(cx + 5, by, 70, 20).build());
	}

	private void buildDeath() {
		int cx = this.width / 2;
		int by = this.height / 2 + 4;
		addRenderableWidget(Button.builder(Component.literal(ru ? "\u0414\u0430" : "Yes"), b -> {
			uiState = 3;
			buildWidgets();
		}).bounds(cx - 75, by, 70, 20).build());
		addRenderableWidget(Button.builder(Component.literal(ru ? "\u041d\u0435\u0442" : "No"), b -> {
			locked = false;
			this.onClose();
		}).bounds(cx + 5, by, 70, 20).build());
	}

	private void buildDeathMode() {
		int cx = this.width / 2;
		int by = this.height / 2 - 14;
		addRenderableWidget(Button.builder(Component.literal(ru ? "\u042f \u0445\u043e\u0447\u0443 \u0432\u044b\u0431\u0438\u0440\u0430\u0442\u044c \u0440\u0430\u0441\u0443 \u043a\u0430\u0436\u0434\u0443\u044e \u0441\u043c\u0435\u0440\u0442\u044c" : "I want to choose my race every death"), b -> {
			RpedMod.PACKET_HANDLER.sendToServer(new RaceDeathModePacket(1));
			uiState = 0;
			buildWidgets();
		}).bounds(cx - 135, by, 270, 20).build());
		addRenderableWidget(Button.builder(Component.literal(ru ? "\u042f \u043d\u0435 \u0445\u043e\u0447\u0443 \u0432\u044b\u0431\u0438\u0440\u0430\u0442\u044c \u043d\u0438\u043a\u043e\u0433\u0434\u0430" : "I never want to choose again"), b -> {
			RpedMod.PACKET_HANDLER.sendToServer(new RaceDeathModePacket(2));
			uiState = 0;
			buildWidgets();
		}).bounds(cx - 135, by + 24, 270, 20).build());
	}

	private void toggle(RaceAttribute attr) {
		if (selected.contains(attr))
			selected.remove(attr);
		else if (selected.size() < MAX_SELECT)
			selected.add(attr);
		for (Map.Entry<RaceAttribute, Button> e : attrButtons.entrySet())
			e.getValue().setMessage(attrLabel(e.getKey()));
		if (selectButton != null) {
			selectButton.setMessage(selectLabel());
			selectButton.active = canSelect();
		}
	}

	private Component selectLabel() {
		return Component.literal((ru ? "\u0412\u044b\u0431\u0440\u0430\u0442\u044c" : "Select") + " (" + selected.size() + "/" + MAX_SELECT + ")");
	}

	private Component attrLabel(RaceAttribute attr) {
		boolean on = selected.contains(attr);
		MutableComponent c = Component.literal((on ? "\u2714 " : "") + attr.displayName(ru));
		if (on)
			c = c.withStyle(s -> s.withColor(attr.group.color));
		int rl = RaceLevels.level(ClientRaceState.xp(attr.name()));
		if (rl > 0)
			c = c.append(Component.literal("  \u2726" + rl).withStyle(ChatFormatting.AQUA));
		return c;
	}

	private Component groupTip(RaceGroup grp) {
		MutableComponent c = Component.literal(grp.title(ru)).withStyle(s -> s.withColor(grp.color));
		if (grp.reqLevel > 0) {
			boolean lock = isLocked(grp);
			c = c.append(Component.literal("\n" + (lock ? "\u2716 " : "\u2714 ") + (ru ? "\u041d\u0443\u0436\u0435\u043d \u0443\u0440\u043e\u0432\u0435\u043d\u044c \u043e\u043f\u044b\u0442\u0430: " : "Requires XP level: ") + grp.reqLevel).withStyle(lock ? ChatFormatting.RED : ChatFormatting.GREEN));
		}
		return c;
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
		super.render(g, mouseX, mouseY, partial);
		int cx = this.width / 2;
		int xpLvl = xpLevel();

		if (uiState == 0) {
			g.drawCenteredString(font, ru ? "\u0412\u044b\u0431\u043e\u0440 \u0430\u0442\u0440\u0438\u0431\u0443\u0442\u043e\u0432" : "Attribute Selection", cx, baseY + 10, 0xFFFFFF);
			int hy = baseY + 28 + 28;
			g.drawString(font, curGroup.title(ru), cx - 110, hy, 0xFF000000 | curGroup.color);
			if (curGroup.reqLevel > 0) {
				boolean lock = isLocked(curGroup);
				String req = (lock ? "\u2716 " : "\u2714 ") + curGroup.reqLevel + (ru ? " \u0443\u0440." : " lvl");
				g.drawString(font, req, cx + 110 - font.width(req), hy, lock ? 0xFFFF5555 : 0xFF55FF55);
			}
			int iy = baseY + 28 + 116;
			g.drawCenteredString(font, (ru ? "\u0412\u044b\u0431\u0440\u0430\u043d\u043e: " : "Selected: ") + selected.size() + "/" + MAX_SELECT, cx, iy, 0xFFCCCCCC);
			int rlSel = 0;
			for (RaceAttribute a : selected)
				rlSel = Math.max(rlSel, a.group.reqLevel);
			if (rlSel > 0 && !isOp)
				g.drawCenteredString(font, (ru ? "\u041d\u0443\u0436\u0435\u043d \u0443\u0440\u043e\u0432\u0435\u043d\u044c \u043e\u043f\u044b\u0442\u0430: " : "Requires XP level: ") + rlSel, cx, iy + 12, xpLvl >= rlSel ? 0xFF55FF55 : 0xFFFF5555);
		} else if (uiState == 1) {
			g.drawCenteredString(font, ru ? "\u0412\u044b \u0443\u0432\u0435\u0440\u0435\u043d\u044b?" : "Are you sure?", cx, this.height / 2 - 14, 0xFFFFFF);
		} else if (uiState == 2) {
			g.drawCenteredString(font, ru ? "\u0412\u044b \u0443\u043c\u0435\u0440\u043b\u0438." : "You died.", cx, this.height / 2 - 30, 0xFFFF5555);
			g.drawCenteredString(font, ru ? "\u0416\u0435\u043b\u0430\u0435\u0442\u0435 \u0438\u0437\u043c\u0435\u043d\u0438\u0442\u044c \u0432\u044b\u0431\u043e\u0440?" : "Do you want to change your choice?", cx, this.height / 2 - 16, 0xFFFFFF);
		} else {
			g.drawCenteredString(font, ru ? "\u041d\u0443\u0436\u0435\u043d \u043b\u0438 \u0432\u044b\u0431\u043e\u0440 \u043f\u043e\u0441\u043b\u0435 \u0441\u043c\u0435\u0440\u0442\u0438?" : "Choose race after every death?", cx, this.height / 2 - 30, 0xFFFFFF);
		}

		if (uiState == 0) {
			for (int k = 0; k < tabs.size(); k++) {
				if (RaceGroup.values()[k] == curGroup) {
					SquareButton tab = tabs.get(k);
					g.fill(tab.getX() - 2, tab.getY() + tab.getHeight() + 1, tab.getX() + tab.getWidth() + 2, tab.getY() + tab.getHeight() + 3, 0xFF000000 | curGroup.color);
				}
			}
			for (Map.Entry<RaceAttribute, Button> e : attrButtons.entrySet()) {
				Button b = e.getValue();
				if (mouseX >= b.getX() && mouseX < b.getX() + b.getWidth() && mouseY >= b.getY() && mouseY < b.getY() + b.getHeight()) {
					renderAttrTooltip(g, e.getKey(), mouseX, mouseY);
					break;
				}
			}
		}

		updateMusic(curGroup == RaceGroup.NETHER ? 1 : curGroup == RaceGroup.END ? 2 : 0);
	}

	private void renderAttrTooltip(GuiGraphics g, RaceAttribute hv, int mouseX, int mouseY) {
		boolean hvLocked = isLocked(hv.group);
		int xp = ClientRaceState.xp(hv.name());
		int lvl = RaceLevels.level(xp);
		int nBuffs = RaceLevels.buffs(lvl);
		int nDebuffs = RaceLevels.debuffs(lvl);
		List<Component> lines = new ArrayList<>();
		lines.add(Component.literal(hv.displayName(ru)).withStyle(s -> s.withColor(hv.group.color).withBold(true)));
		if (hvLocked)
			lines.add(Component.literal((ru ? "\u041d\u0443\u0436\u0435\u043d \u0443\u0440\u043e\u0432\u0435\u043d\u044c \u043e\u043f\u044b\u0442\u0430: " : "Requires XP level: ") + hv.group.reqLevel).withStyle(ChatFormatting.RED));
		String lvlLine = (ru ? "\u0423\u0440\u043e\u0432\u0435\u043d\u044c \u0440\u0430\u0441\u044b: " : "Race level: ") + lvl + " / " + RaceLevels.MAX_LEVEL;
		if (lvl < RaceLevels.MAX_LEVEL)
			lvlLine += (ru ? "  (\u0434\u043e \u0441\u043b\u0435\u0434.: " : "  (to next: ") + RaceLevels.toNext(xp) + (ru ? " \u043e\u043f.)" : " xp)");
		lines.add(Component.literal(lvlLine).withStyle(ChatFormatting.AQUA));
		String[] ls = hv.lines(ru);
		int bi = 0, di = 0;
		for (String line : ls) {
			if (line.startsWith("+")) {
				if (bi < nBuffs)
					lines.add(Component.literal(line).withStyle(ChatFormatting.GREEN));
				else
					lines.add(Component.literal(line + "  [" + (ru ? "\u0443\u0440. " : "lvl ") + RaceLevels.buffUnlockLevel(bi) + "]").withStyle(ChatFormatting.DARK_GRAY));
				bi++;
			} else {
				if (di < nDebuffs)
					lines.add(Component.literal(line).withStyle(ChatFormatting.RED));
				else
					lines.add(Component.literal(line).withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.STRIKETHROUGH));
				di++;
			}
		}
		g.renderComponentTooltip(font, lines, mouseX, mouseY);
	}

	private void updateMusic(int theme) {
		if (musicKey == theme)
			return;
		stopMusic();
		ResourceLocation loc = switch (theme) {
			case 1 -> new ResourceLocation("minecraft", "music_disc.pigstep");
			case 2 -> new ResourceLocation("rped", "music_honoro");
			default -> new ResourceLocation("rped", "music_dying_world");
		};
		music = new SimpleSoundInstance(loc, SoundSource.MUSIC, 0.8f, 1f, SoundInstance.createUnseededRandom(), true, 0, SoundInstance.Attenuation.NONE, 0, 0, 0, true);
		Minecraft.getInstance().getSoundManager().play(music);
		musicKey = theme;
	}

	private void stopMusic() {
		if (music != null) {
			Minecraft.getInstance().getSoundManager().stop(music);
			music = null;
		}
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (locked && (keyCode == 256 || Minecraft.getInstance().options.keyInventory.matches(keyCode, scanCode)))
			return true;
		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return !locked;
	}

	@Override
	public void onClose() {
		if (locked)
			return;
		super.onClose();
	}

	@Override
	public void removed() {
		stopMusic();
		super.removed();
	}

	@Override
	protected void renderBg(GuiGraphics g, float partial, int mx, int my) {
	}

	@Override
	protected void renderLabels(GuiGraphics g, int mx, int my) {
	}
}
