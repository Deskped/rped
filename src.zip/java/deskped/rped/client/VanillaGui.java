package deskped.rped.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class VanillaGui {

	public static final ResourceLocation WIDGETS = new ResourceLocation("textures/gui/widgets.png");

	public static final int WHITE = 0xFFFFFFFF;
	public static final int TEXT = 0xFF404040;
	public static final int GRAY = 0xFFA0A0A0;
	public static final int YELLOW = 0xFFFFFF55;
	public static final int GREEN = 0xFF55FF55;
	public static final int RED = 0xFFFF5555;

	private VanillaGui() {
	}

	public static void button(GuiGraphics g, int x, int y, int w, int h, boolean active, boolean hovered) {
		int v = 46 + (!active ? 0 : (hovered ? 2 : 1)) * 20;
		RenderSystem.enableBlend();
		RenderSystem.enableDepthTest();
		g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
		g.blitNineSliced(WIDGETS, x, y, w, h, 20, 4, 200, 20, 0, v);
	}

	public static void panel(GuiGraphics g, int x, int y, int w, int h) {
		g.fill(x + 1, y, x + w - 1, y + h, 0xFF000000);
		g.fill(x, y + 1, x + w, y + h - 1, 0xFF000000);
		g.fill(x + 1, y + 1, x + w - 3, y + h - 3, 0xFFFFFFFF);
		g.fill(x + 4, y + 4, x + w - 1, y + h - 1, 0xFF555555);
		g.fill(x + 4, y + 4, x + w - 4, y + h - 4, 0xFFC6C6C6);
		g.fill(x + w - 4, y + 1, x + w - 1, y + 4, 0xFFC6C6C6);
		g.fill(x + 1, y + h - 4, x + 4, y + h - 1, 0xFFC6C6C6);
	}

	public static void inset(GuiGraphics g, int x, int y, int w, int h) {
		g.fill(x, y, x + w, y + h, 0xFFFFFFFF);
		g.fill(x, y, x + w - 1, y + h - 1, 0xFF373737);
		g.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFF8B8B8B);
	}

	public static void frame(GuiGraphics g, int x, int y, int w, int h, int color) {
		g.fill(x, y, x + w, y + 1, color);
		g.fill(x, y + h - 1, x + w, y + h, color);
		g.fill(x, y + 1, x + 1, y + h - 1, color);
		g.fill(x + w - 1, y + 1, x + w, y + h - 1, color);
	}
}
