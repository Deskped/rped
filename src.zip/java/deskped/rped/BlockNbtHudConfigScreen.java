package deskped.rped;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class BlockNbtHudConfigScreen extends Screen {

    private final Screen parent;

    public BlockNbtHudConfigScreen(Screen parent) {
        super(Component.literal("Rped"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        super.init();
        this.addRenderableWidget(Button.builder(text(), b -> {
            BlockNbtHudConfig.setEnabled(!BlockNbtHudConfig.ENABLED);
            b.setMessage(text());
        }).bounds(this.width / 2 - 100, this.height / 2 - 10, 200, 20).build());
    }

    private static Component text() {
        boolean on = BlockNbtHudConfig.ENABLED;
        String label = isRussian() ? "Показ названия блока" : "Block name display";
        return Component.literal(label + ": ").append(Component.literal(String.valueOf(on)).withStyle(on ? ChatFormatting.GREEN : ChatFormatting.RED));
    }

    private static boolean isRussian() {
        String lang = Minecraft.getInstance().options.languageCode;
        return lang != null && lang.startsWith("ru");
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        String title = isRussian() ? "Настройки Rped" : "Rped Settings";
        graphics.drawCenteredString(this.font, title, this.width / 2, this.height / 2 - 40, 0xFFFFFF);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(parent);
    }
}
